TOOL.AddToMenu = true
TOOL.Category = 'Construction'
TOOL.Name = '#tool.textscreen.name'
TOOL.Description = '#tool.textscreen.desc'

if CLIENT then 
	language.Add('tool.textscreen.name', 'Text Screen')
	language.Add('tool.textscreen.desc', 'Use this tool to create 3D text in the world')
	language.Add('tool.textscreen.0', 'LMB to spawn Text Screen')
	language.Add('SBoxLimit_textscreens', 'You\'ve hit the Text Screens limit!')
else
	CreateConVar('sbox_maxtextscreens', 5, FCVAR_SERVER_CAN_EXECUTE)
end

for i = 1, 4 do
	TOOL.ClientConVar['text' .. i] = ''
	TOOL.ClientConVar['size' .. i] = 20
	TOOL.ClientConVar['r' .. i] = 255
	TOOL.ClientConVar['g' .. i] = 255
	TOOL.ClientConVar['b' .. i] = 255
end

function TOOL:LeftClick(trace)
	if IsValid(trace.Entity) and trace.Entity:IsPlayer() then return false elseif CLIENT then return true end
	if SERVER and self:GetOwner():CheckLimit('textscreens') then
		local text = ents.Create('textscreen')
		text:SetPos(trace.HitPos)

		local angle = trace.HitNormal:Angle()
		angle:RotateAroundAxis(trace.HitNormal:Angle():Right(), -90)
		angle:RotateAroundAxis(trace.HitNormal:Angle():Forward(), 90)
		text:SetAngles(angle)

		text:SetModel('models/squad/sf_plates/sf_plate1x8.mdl')
		text:Spawn()
		text:PhysicsInit(SOLID_VPHYSICS)

		text:GetPhysicsObject():EnableMotion(false)
		text:SetCollisionGroup(COLLISION_GROUP_DEBRIS)

		for i = 1, 4 do
			local txt = self:GetClientInfo('text' .. tostring(i)):sub(1,60)
			text['SetText' .. tostring(i)](text, txt)
			text['SetTextColor' .. tostring(i)](text, Vector(self:GetClientInfo('r' .. tostring(i)),self:GetClientInfo('g' .. tostring(i)),self:GetClientInfo('b' .. tostring(i))))
			text['SetAvailable' .. tostring(i)](text, txt ~= '' and true or false)
		end

		self:GetOwner():AddCount('textscreens', text)
		self:GetOwner():AddCleanup("textscreens", text)

		undo.Create('Text Screen')
		undo.AddEntity(text)
		undo.SetPlayer(self:GetOwner())
		undo.Finish()

		return true
	end
end

local ConVarsDefault = TOOL:BuildConVarList()

function TOOL.BuildCPanel(CP)
	CP:AddControl('Header', { Description = 'Use this tool to create text in the world' } )
	CP:AddControl("ComboBox", {MenuButton = 1, Folder = "textscreen", Options = { ["#preset.default"] = ConVarsDefault}, CVars = table.GetKeys(ConVarsDefault) })
	for i = 1, 4 do

		CP:AddControl("Color", {
			Label = "Line " .. i .. " font color",
			Red = "textscreen_r" .. i,
			Green = "textscreen_g" .. i,
			Blue = "textscreen_b" .. i,
			ShowHSV = 1,
			ShowRGB = 1,
			Multiplier = 255
		})

		local textbox = vgui.Create("DTextEntry", CP)
		textbox:SetUpdateOnType(true)
		textbox:SetEnterAllowed(true)
		textbox:SetConVar('textscreen_text' .. i)
		textbox:SetValue(GetConVar('textscreen_text' .. i):GetString())

		CP:AddItem(textbox)
	end
end
