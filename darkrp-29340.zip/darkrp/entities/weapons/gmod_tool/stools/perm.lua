TOOL.AddToMenu = true
TOOL.Category = 'Construction'
TOOL.Name = '#tool.perm.name'
TOOL.Description = '#tool.perm.desc'

if CLIENT then 
	language.Add('tool.perm.name', 'Perma Props')
    language.Add('tool.perm.desc', 'Use it to save your props. That\'s simple!')
    language.Add('tool.perm.0', 'LMB to add, RMB to remove, Reload to save changes')
else
    TOOL.Props = {}
end

function TOOL:Mark(bool, ent)
    if self.Props[ent] and self.Props[ent] == bool then
        self.Props[ent] = nil
        ent:SetColor(Color(255, 255, 255))
        return
    end

    if bool then
        ent:SetColor(Color(0, 255, 0))
        self.Props[ent] = true
    else
        ent:SetColor(Color(255, 0, 0))
        self.Props[ent] = false
    end
end

function TOOL:Main(bool, trace)
    local ent = trace.Entity
    if self:GetOwner():IsSuperAdmin() and ent and IsValid(ent) and not ent:IsPlayer() then
        if CLIENT then
            local snd = CreateSound(self:GetOwner(), 'buttons/button9.wav')
            snd:Play()
            return true 
        else
            self:Mark(bool, ent)
        end
        self.Cool = CurTime()
    end
end

function TOOL:LeftClick(trace)
    self:Main(true, trace)
end

function TOOL:RightClick(trace)
    self:Main(false, trace)
end

function TOOL:Reload()
    if SERVER and self:GetOwner():IsSuperAdmin() then
        for ent, bool in pairs(self.Props) do
            if IsValid(ent) then
                ent:SetColor(Color(255, 255, 255))
                if bool then
                    Perm:Add(ent)
                else
                    Perm:Remove(ent)
                end
            end
        end
        self.Props = {}
    end
end

local ConVarsDefault = TOOL:BuildConVarList()

function TOOL.BuildCPanel(CP)
	CP:AddControl('Header', { Description = 'че' } )
end
