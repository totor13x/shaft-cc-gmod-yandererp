SWEP.Category = "Other"
SWEP.Spawnable = true
SWEP.AdminSpawnable = true

SWEP.ViewModel = Model('models/weapons/v_crowbar.mdl')
SWEP.WorldModel = Model('models/weapons/w_crowbar.mdl')

SWEP.Primary.Ammo = "none"
SWEP.Secondary.Ammo = "none"

SWEP.IsPicking 	= false
SWEP.PickTime = 15

SWEP.Tag = 'lampserv_lockpick'

function SWEP:Holster()
	self.IsPicking = false
	return true
end

function SWEP:SecondaryAttack()
end

local sounds = {
	"weapons/357/357_reload1.wav",
	"weapons/357/357_reload3.wav",
	"weapons/357/357_reload4.wav"
}

SWEP.SoundTime = 0

function SWEP:MakeSound()
	if self.SoundTime and self.IsPicking and CurTime() - self.SoundTime > 0.75 then
		self:EmitSound(sounds[math.random(#sounds)], 50, 100)
		self.SoundTime = CurTime()
	end
end