include('shared.lua')

AddCSLuaFile 'shared.lua'
AddCSLuaFile 'cl_init.lua'

util.AddNetworkString(SWEP.Tag)

function SWEP:SendState(bool,time)
	self.IsPicking = bool
	net.Start(self.Tag)
	net.WriteBool(bool)
	if time then
		self.StartTime = time
		net.WriteInt(time,32)
	end
	net.Send(self.Owner)
end

function SWEP:PrimaryAttack()
	local door = self.Owner:GetEyeTrace().Entity
	if IsValid(door) and GAMEMODE.isDoor(door) and not self.IsPicking and self.Owner:GetShootPos():DistToSqr(door:GetPos()) < 7500 then
		self:SendState(true,CurTime())
	end
end

function SWEP:Think()
	local door = self.Owner:GetEyeTrace().Entity
	self:MakeSound()
	if self.IsPicking and (not IsValid(door) or not GAMEMODE.isDoor(door) or self.Owner:GetShootPos():DistToSqr(door:GetPos()) > 7500) then
		self:SendState(false)
		return
	elseif self.StartTime and CurTime() - self.StartTime >= self.PickTime - 1 and self.IsPicking then
		self:SendState(false)
		door:Fire('unlock')
		door:Fire('open')
		return
	end
end