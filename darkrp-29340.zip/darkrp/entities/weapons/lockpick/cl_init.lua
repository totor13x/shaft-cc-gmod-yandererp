include('shared.lua')

SWEP.PrintName = L'lockpick'
SWEP.Slot = 2
SWEP.SlotPos = 1
SWEP.DrawAmmo = false
SWEP.Purpose = L'lockpick_purpose'
SWEP.Author = '\nLampServ' // \n чтоб как описание было!!

SWEP.HoldType = 'pistol'

SWEP.AutoSwitchTo = false
SWEP.AutoSwitchFrom = false
SWEP.DrawCrosshair = false

local w,h = ScrW(), ScrH()
function SWEP:DrawHUD()
	if self.IsPicking and self.StartTime then
		surface.SetDrawColor(Color(0, 0, 0, 150))
		surface.DrawRect(w / 2 - 150, h / 2 - 15, 300, 30)
		surface.SetDrawColor(Color(255, 255, 0, 200))
		surface.DrawRect(w / 2 - 150, h / 2 - 15, 300 * (CurTime() - self.StartTime) / self.PickTime, 30)
	end
end

function SWEP:PrimaryAttack()
end

function SWEP:Think()
	self:MakeSound()
end

net.Receive(SWEP.Tag, function()
	local lockpick = LocalPlayer():GetWeapon('lockpick')
	if net.ReadBool() and IsValid(lockpick) then
		lockpick.IsPicking = true
		lockpick.StartTime = net.ReadInt(32)
	else
		lockpick.IsPicking = false
	end
end)