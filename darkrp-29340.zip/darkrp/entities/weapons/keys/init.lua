include "shared.lua"

AddCSLuaFile 'cl_init.lua'
AddCSLuaFile 'shared.lua'

function SWEP:Deploy()
    if IsValid(self:GetOwner()) then return true end
    self:GetOwner():DrawWorldModel(false)
    return true
end

local function lockUnlockAnimation(ply, snd)
    ply:EmitSound("npc/metropolice/gear" .. math.floor(math.Rand(1,7)) .. ".wav")
    timer.Simple(0.9, function() if IsValid(ply) then ply:EmitSound(snd) end end)

    net.Start('keys_anim')
        net.WriteEntity(ply)
        net.WriteBool(false)
    net.SendPVS(ply:GetPos())
end

local function doKnock(ply, sound)
    ply:EmitSound(sound, 100, math.random(90, 110))

    net.Start('keys_anim')
        net.WriteEntity(ply)
        net.WriteBool(true)
    net.SendPVS(ply:GetPos())
end

local function canLock(ply, ent)
    if ent:GetNWBool('door_canbuy') then
        return ent:GetNWEntity('door_owner') == ply
    else
        local group = GAMEMODE.DoorGroups[ent:GetNWString('door_group')]
        return group and table.HasValue(group, ply:Team())
    end
end

local function lookingAtLockable(ply, ent, hitpos)
    local eyepos = ply:EyePos()
    return IsValid(ent) and GAMEMODE.isDoor(ent) and eyepos:DistToSqr(hitpos) < 2000
end


function SWEP:PrimaryAttack()
    self:SetNextPrimaryFire(CurTime() + self.Primary.Delay)

    local trace = self:GetOwner():GetEyeTrace()

    if not lookingAtLockable(self:GetOwner(), trace.Entity, trace.HitPos) then return end

    if canLock(self:GetOwner(), trace.Entity) then
        trace.Entity:Fire('Lock')
        lockUnlockAnimation(self:GetOwner(), self.Sound)
    else
        doKnock(self:GetOwner(), "physics/wood/wood_crate_impact_hard2.wav")
    end
end

function SWEP:SecondaryAttack()
    self:SetNextSecondaryFire(CurTime() + self.Secondary.Delay)

    local trace = self:GetOwner():GetEyeTrace()

    if not lookingAtLockable(self:GetOwner(), trace.Entity, trace.HitPos) then return end

    if canLock(self:GetOwner(), trace.Entity) then
        trace.Entity:Fire('Unlock')
        lockUnlockAnimation(self:GetOwner(), self.Sound)
    else
        doKnock(self:GetOwner(), "physics/wood/wood_crate_impact_hard3.wav")
    end
end

util.AddNetworkString('keys_anim')

util.AddNetworkString('Gestures')
net.Receive('Gestures', function(l, p)
	net.Start('Gestures')
	net.WriteEntity(p)
	net.WriteInt(net.ReadInt(16), 16)
	net.Broadcast()
end)