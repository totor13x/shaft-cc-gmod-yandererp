include 'shared.lua'

SWEP.PrintName = L'keys'
SWEP.Slot = 1
SWEP.SlotPos = 1
SWEP.DrawAmmo = false
SWEP.DrawCrosshair = false

function SWEP:PrimaryAttack()
	self:SetNextPrimaryFire(CurTime() + self.Primary.Delay)
end

function SWEP:SecondaryAttack()
	self:SetNextSecondaryFire(CurTime() + self.Secondary.Delay)
end

net.Receive('keys_anim', function()
	local ply = net.ReadEntity()
	local knock = net.ReadBool()

	
	if ply.AnimRestartGesture then
		if knock then
			ply:AnimRestartGesture(GESTURE_SLOT_ATTACK_AND_RELOAD, ACT_HL2MP_GESTURE_RANGE_ATTACK_FIST, true)
		else
			ply:AnimRestartGesture(GESTURE_SLOT_ATTACK_AND_RELOAD, ACT_GMOD_GESTURE_ITEM_PLACE, true)
		end
	end
end)

local gestures = {
	{gest = ACT_GMOD_GESTURE_BOW, name = 'Поклон'},
	{gest = ACT_GMOD_TAUNT_MUSCLE, name = 'Стриптиз'},
	{gest = ACT_GMOD_GESTURE_BECON, name = 'Иди за мной!'},
	{gest = ACT_GMOD_TAUNT_LAUGH, name = 'Смех'},
	{gest = ACT_GMOD_TAUNT_PERSISTENCE, name = 'Поза льва'},
	{gest = ACT_GMOD_GESTURE_DISAGREE, name = 'Нет!'},
	{gest = ACT_GMOD_GESTURE_AGREE, name = 'Палец вверх'},
	{gest = ACT_GMOD_GESTURE_WAVE, name = 'Помахать'},
	{gest = ACT_GMOD_TAUNT_DANCE, name = 'Танец'},
}

net.Receive('Gestures', function()
	local ent = net.ReadEntity()
	if ent.AnimRestartGesture then
		ent:AnimRestartGesture(GESTURE_SLOT_CUSTOM, net.ReadInt(16), true)
	end
end)

local frame = vgui.Create('DFrame')
frame:SetSize(220, 620)
frame:Center()
frame:SetPos(ScrW() * 0.6, frame.Y)
frame:SetTitle('Анимации')
frame:Hide()
frame:ShowCloseButton(false)
frame:MakePopup()
frame:SetKeyBoardInputEnabled(false)

local old_paint = frame.Paint
function frame:Paint(w, h)
	old_paint(self, w, h)
	
	if not input.IsKeyDown(KEY_R) then
		self:Hide()
		
		gui.EnableScreenClicker(false)
	end
end

local y = 64
for i, elem in ipairs(gestures) do
	i = i - 1
	local butt = vgui.Create('DButton', frame)
	butt:SetSize(200, 64)
	butt:SetPos(10, 32 + y * i)
	butt:SetText(elem.name)
	function butt:DoClick()
		net.Start('Gestures')
		net.WriteInt(elem.gest, 16)
		net.SendToServer()
	end
	
end

local cd = 0
function SWEP:Reload()
	local ent = self:GetOwner():GetEyeTrace().Entity
	
	if ent and GAMEMODE.isDoor(ent) then
		if cd < SysTime() then
			cd = SysTime() + 1
			RunConsoleCommand('rp', 'door')
		end
	else
		if cd < SysTime() then 
			cd = SysTime() + 0.2
			frame:Show()
			
			gui.EnableScreenClicker(true)
		end
	end
end