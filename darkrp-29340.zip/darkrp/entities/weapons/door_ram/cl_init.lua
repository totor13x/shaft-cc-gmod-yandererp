include('shared.lua')

SWEP.Slot = 5
SWEP.SlotPos = 1
SWEP.DrawAmmo = false
SWEP.DrawCrosshair = false

SWEP.PrintName = 'Выламыватель дверей'
SWEP.Purpose = 'Выламывает двери...'
SWEP.Author = 'LampServ'