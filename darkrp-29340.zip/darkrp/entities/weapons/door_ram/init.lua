include('shared.lua')

AddCSLuaFile('shared.lua')
AddCSLuaFile('cl_init.lua')

function SWEP:Initialize()
	self:SetHoldType("rpg")
end

local function exit_vehicle(veh)
	local driver = veh:GetDriver()

	if IsValid(driver) then
		driver:ExitVehicle()
	end
end

function SWEP:PrimaryAttack()	
	local trace = self:GetOwner():GetEyeTrace()
	local ent = trace.Entity
	if ent and IsValid(ent) and trace.HitPos:DistToSqr(self:GetOwner():EyePos()) < 6000 then

		if GAMEMODE.isDoor(ent) and (ent:GetNWBool('door_canbuy') or ent:GetNWString('door_group') ~= '') then
			ent:Fire('unlock')
			ent:Fire('open')
			ent:EmitSound('physics/wood/wood_box_impact_hard3.wav')
			
			return
		end

		if ent:IsVehicle() then		
			for i, child in ipairs(ent:GetChildren()) do 
				if child:IsVehicle() then
					exit_vehicle(child)
				end
			end

			exit_vehicle(ent)
			ent:EmitSound('physics/wood/wood_box_impact_hard3.wav')
			
			return
		end
		
		local phys = ent:GetPhysicsObject()
		if ent:GetClass() == 'prop_physics' and MPP.owner(ent) and phys and not phys:IsMotionEnabled() then
			phys:EnableMotion(true)
			ent:EmitSound('physics/wood/wood_box_impact_hard3.wav')
		end
	end
end

function SWEP:SecondaryAttack()
end