SWEP.Category = "Other"
SWEP.Spawnable = true
SWEP.AdminSpawnable = true

SWEP.ViewModel = Model('models/weapons/v_stunbaton.mdl')
SWEP.WorldModel = Model('models/weapons/w_stunbaton.mdl')

SWEP.Delay = 0.5
SWEP.Last = 0

SWEP.Primary.Ammo = ""
SWEP.Secondary.Ammo = ""

SWEP.Color = Color(255, 0, 0)

function SWEP:Holster()
    return true
end

function SWEP:SecondaryAttack()
end