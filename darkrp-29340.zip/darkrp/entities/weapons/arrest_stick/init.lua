include('shared.lua')

AddCSLuaFile('cl_init.lua')
AddCSLuaFile('shared.lua')

function SWEP:Initialize()
	self.Material = '!' .. self:GetClass()

	self:SetMaterial(self.Material)
	self:SetHoldType('melee')
end

function SWEP:PrimaryFunction(ent)
	if hook.Run('CanArrest', self:GetOwner(), ent) then
		ent:Arrest(nil, self:GetOwner())
	end
end

function SWEP:PrimaryAttack()
	if CurTime() - self.Last > self.Delay then
		self.Last = CurTime()

		self:GetOwner():SetAnimation(PLAYER_ATTACK1)
		self:GetOwner():EmitSound(Sound('weapons/stunstick/stunstick_swing1.wav'))

		local vm = self:GetOwner():GetViewModel()
		if IsValid(vm) then
			vm:SendViewModelMatchingSequence(vm:LookupSequence('attackch'))
			vm:SetPlaybackRate(1.25)

			timer.Simple(self.Delay - 0.1, function() 
				vm:SendViewModelMatchingSequence(vm:LookupSequence("idle01")) 
			end)
		end

		local ent = self:GetOwner():getEyeSightHitEntity(90, 15)
		if ent and IsValid(ent) and ent:IsPlayer() then 
			self:PrimaryFunction(ent)
		end
	end
end