include 'shared.lua'

SWEP.PrintName = L'arrest_stick'
SWEP.Slot = 1
SWEP.SlotPos = 1
SWEP.DrawAmmo = false
SWEP.Purpose = L'arrest_stick_purpose'
SWEP.Author = '\nLampServ'
SWEP.UseHands = false

function SWEP:Initialize()
	self.Material = '!' .. self:GetClass()

	if IsValid(self) then
		CreateMaterial(self:GetClass(), "VertexLitGeneric", {
            ["$basetexture"] = "models/debug/debugwhite",
            ["$surfaceprop"] = "metal",
            ["$envmap"] = "env_cubemap",
            ["$envmaptint"] = "[ .5 .5 .5 ]",
            ["$selfillum"] = 0,
            ["$model"] = 1
        }):SetVector("$color2", self.Color:ToVector())
	end
end


function SWEP:PreDrawViewModel(model, wep, me)
	me:GetHands():SetMaterial()
	for i = 9 , 16 do
		model:SetSubMaterial(i, self.Material)
	end
	me:GetHands():SetMaterial()
end

function SWEP:ViewModelDrawn(model)
	model:SetSubMaterial()
end

function SWEP:PrimaryAttack()
	if CurTime() - self.Last > self.Delay then
		self.Last = CurTime()
		self:GetOwner():SetAnimation(PLAYER_ATTACK1)
    end
end