file.CreateDir('ls_inventory')
util.AddNetworkString('ls_inventory')
util.AddNetworkString('ls_inventory_shared')

local function loadInv(ply)
	local fn = 'ls_inventory/' .. ply:SteamID64() .. '.txt'
	if file.Exists(fn, 'DATA') then
		ply.Inventory = util.JSONToTable(file.Read(fn, 'DATA'))
	end
end

local function saveInv(ply)
	file.Write('ls_inventory/' .. ply:SteamID64() .. '.txt', util.TableToJSON(ply.Inventory))
end

hook.Add('PlayerFullyLoaded', 'loadInv', function(ply)
	ply.Inventory = {}
	loadInv(ply)
	if not IsValid(ply) then return end
	net.Start('ls_inventory')
		net.WriteInt(6, 5)
		net.WriteTable(ply.Inventory)
	net.Send(ply)

	ply.SharedInventory = {}
	local exists = false
	for k, v in pairs(ply.Inventory) do
		if k < 0 then
			ply.SharedInventory[k] = v
			exists = true
		end
	end

	if exists then
		local rec = RecipientFilter()
		rec:AddAllPlayers()
		rec:RemovePlayer(ply)

		net.Start('ls_inventory_shared')
			net.WriteEntity(ply)
			net.WriteInt(6, 5)
			net.WriteTable(ply.SharedInventory)
		net.Send(rec)
	else
		ply.SharedInventory = nil
	end

	for k, v in ipairs(player.GetAll()) do
		if v == ply then continue end

		if v.SharedInventory then
			net.Start('ls_inventory_shared')
				net.WriteEntity(v)
				net.WriteInt(6, 5)
				net.WriteTable(v.SharedInventory)
			net.Send(ply)
		end
	end
end)

local function spawnFromInv(ply, itemindex)
	local item = ply.Inventory[itemindex]

	if not item then return end

	local e = inv_items[item.class].spawn(item, ply)
	e:SetPos(DarkRP.playerDropPos(ply))
	e:Spawn()
	e.rp_owner = ply
	if e.Setowning_ent then
		e:Setowning_ent(ply)
	end
	ply.rp_ents = ply.rp_ents or {}
	table.insert(ply.rp_ents, e)

	ply.Inventory[itemindex] = nil --table.remove(ply.Inventory, itemindex)
	
	if itemindex < 0 and ply.SharedInventory then
		ply.SharedInventory[itemindex] = nil

		local rec = RecipientFilter()
		rec:AddAllPlayers()
		rec:RemovePlayer(ply)

		net.Start('ls_inventory_shared')
			net.WriteEntity(ply)
			net.WriteInt(4, 5)
			net.WriteInt(itemindex, 8)
		net.Send(rec)
	end

	saveInv(ply)
end

local SWEP = SWEP

net.Receive('ls_inventory', function(len, ply)
	local act = net.ReadInt(5)
	
	if act == 1 then
		local itemindex = net.ReadInt(8)
		timer.Simple(0.1, function()
			spawnFromInv(ply, itemindex)
		end)
	elseif act == 2 then
		local itemindex = net.ReadInt(8)
		local item = ply.Inventory[itemindex]
		if not item or not inv_items[item.class].use then return end

		local ret = inv_items[item.class].use(item, ply)
		if ret then
			ply.Inventory[itemindex] = nil --table.remove(ply.Inventory, itemindex)
			net.Start('ls_inventory')
				net.WriteInt(4, 5)
				net.WriteInt(itemindex, 8)
			net.Send(ply)

			if itemindex < 0 then
				ply.SharedInventory[itemindex] = nil

				local rec = RecipientFilter()
				rec:AddAllPlayers()
				rec:RemovePlayer(ply)

				net.Start('ls_inventory_shared')
					net.WriteEntity(ply)
					net.WriteInt(4, 5)
					net.WriteInt(itemindex, 8)
				net.Send(rec)
			end
		else
			net.Start('ls_inventory')
				net.WriteInt(5, 5)
				net.WriteInt(itemindex, 8)
				net.WriteTable(ply.Inventory[itemindex])
			net.Send(ply)

			if itemindex < 0 and ply.SharedInventory then
				local rec = RecipientFilter()
				rec:AddAllPlayers()
				rec:RemovePlayer(ply)

				net.Start('ls_inventory_shared')
					net.WriteEntity(ply)
					net.WriteInt(5, 5)
					net.WriteInt(itemindex, 8)
					net.WriteTable(ply.SharedInventory[itemindex])
				net.Send(rec)
			end
		end
		saveInv(ply)
	elseif act == 3 then
		local from = net.ReadInt(8)
		local to = net.ReadInt(8)

		local count = SWEP.SlotsCount(ply)
		if from > count or to > count or from < -1 or to < -1 then
			return
		end

		local temp = ply.Inventory[to]
		ply.Inventory[to] = ply.Inventory[from]
		ply.Inventory[from] = temp

		ply.SharedInventory = {}
		if from < 0 then
			ply.SharedInventory[from] = temp
		end

		if to < 0 then
			ply.SharedInventory[to] = ply.Inventory[to]
		end

		local rec = RecipientFilter()
		rec:AddAllPlayers()
		rec:RemovePlayer(ply)

		net.Start('ls_inventory_shared')
			net.WriteEntity(ply)
			net.WriteInt(6, 5)
			net.WriteTable(ply.SharedInventory)
		net.Send(rec)
		saveInv(ply)
	end
end)

function SWEP:Reload()
	if SERVER and (not self.RCoolDown or CurTime() >= self.RCoolDown) then 
		net.Start('ls_inventory')
			net.WriteInt(1, 5)
		net.Send(self.Owner)
		
		self.RCoolDown = CurTime() + 1
	end
end

inv_put = function(ent, ply)
	if ent.pickedUp then return end

	if not inv_items[ent:GetClass()] or hook.Call("canPocket", GAMEMODE, ply, ent) == false or ent.USED then
		DarkRP:Notify(ply, L'you_cant_pickup')
		return
	end

	local slots = SWEP.SlotsCount(ply)

	local check = false
	local saved
	for i = 1, slots do 
		if not ply.Inventory[i] then
			saved = inv_items[ent:GetClass()].getTable(ent)
			saved.class = ent:GetClass()
			ply.Inventory[i] = saved
			check = i
			break
		end
	end

	if not check then
		DarkRP:Notify(ply, L'inventory_full')
		return
	end

	ent.pickedUp = true

	net.Start('ls_inventory')
		net.WriteInt(5, 5)
		net.WriteInt(check, 8)
		net.WriteTable(saved)
	net.Send(ply)

	ent:Remove()

	saveInv(ply)

		return true
end

function SWEP:PrimaryAttack()
	self:SetNextPrimaryFire(CurTime() + 0.2)

	local ent = self:GetOwner():GetEyeTrace().Entity
	
	if not IsValid(ent) or ent:GetPos():Distance(self:GetOwner():GetShootPos()) > 150 then
		return
	end

	inv_put(ent, self:GetOwner())
end

function SWEP:SecondaryAttack()
	local slots = SWEP.SlotsCount(self.Owner)
	local item
	for i = slots, 1, -1 do
		if self:GetOwner().Inventory[i] then
			item = i
			break
		end
	end

	if not item then
		DarkRP:Notify(self:GetOwner(), L("inventory_no_items"))
		return
	end

	spawnFromInv(self:GetOwner(), item)
	net.Start('ls_inventory')
		net.WriteInt(4, 5)
				net.WriteInt(item, 8)
	net.Send(self.Owner)
	saveInv(self.Owner)
end