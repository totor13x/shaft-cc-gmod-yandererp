function SWEP:PreDrawViewModel(vm)
	return true
end

function SWEP:PrimaryAttack()
	self:SetNextPrimaryFire(CurTime() + 0.2)
end


function SWEP:SecondaryAttack() end -- to remove click sound

function SWEP:OnRemove()
	timer.Simple(1, function() self.ent:Remove() end)
end

local ScrW, ScrH = ScrW(), ScrH()

surface.CreateFont('PANELS_TITLE', {
	font = "Segoe UI Bold",
	size = ScrW*0.0125,
	weight = 800,
	blursize = 0,
})

surface.CreateFont( "PANELS_SUBTITLE", {
	font = "Segoe UI Bold",
	size = ScrW*0.011,
	weight = 800,
	blursize = 0,
})

surface.CreateFont( "PANELS_LABEL", {
	font = "Segoe UI Bold",
	size = ScrW*0.008,
	weight = 700,
	blursize = 0,
})

local inv = inv_panel
if inv then if IsValid(inv.pers_f) then inv.pers_f:Remove() end inv:Remove() end

local emptySpace = 8
local itemsize = 42

local SWEP = SWEP

local pers = Material('../data/lampserv_touhourp_person.png')
http.Fetch('https://lampserv.org/assets/gmod/1111.png', function(data)
	file.Write('lampserv_touhourp_person.png', data)
	timer.Simple(1, function()
		pers = Material('../data/lampserv_touhourp_person.png')
	end)
end)

local function openInv()
	if IsValid(inv) then
		inv:Show()
		inv.holdingQ = true
		return
	end
	
	local slots = 22--SWEP.SlotsCount(LocalPlayer())
	local rows = math.ceil(slots/11)
	
	local lp = LocalPlayer()
	inv = vgui.Create('DFrame', g_ContextMenu)
	inv_panel = inv
	local w = 552
	local h = 26 + rows * (itemsize + emptySpace)
	inv:SetSize(w, h)
	inv:SetPos(ScrW/2 - w/2, ScrH - h - 32)
	inv:SetTitle('LampServ Inventory')
	inv.btnClose:Hide()
	inv.btnMaxim:Hide()
	inv.btnMinim:Hide()
	inv:SetMouseInputEnabled(true)
	
	local dragitem

	local function slot(curindex, parent, bx, by)
				local item = LocalPlayer().Inventory[curindex]
				local perform
				if item then perform = inv_items[item.class].perform(item) end
				local itemmodel
				local itempnl = vgui.Create('DButton', parent)
				itempnl:SetSize(itemsize, itemsize)
				itempnl.inv_item = true
				
				itempnl:SetPos(bx, by)
				itempnl:SetText('')
				itempnl.Paint = function(btn, w, h)
					local bg = (btn.Depressed and Color(191, 106, 165)) or (btn:IsHovered() and Color(255, 145, 211)) or Color(58, 66, 78)
					draw.RoundedBox(4, 0, 0, w, h, bg)

					if perform and perform.amount then draw.SimpleText(perform.amount, 'PANELS_LABEL', w/2, h*0.9, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM) end
					
					if dragitem == btn and btn.icon then
						local x, y = btn:LocalCursorPos()
						if math.abs(x - w/2) > w/2 or math.abs(y - h/2) > h/2 then
							surface.DisableClipping(true)
							surface.SetDrawColor(255, 255, 255, 196)
							surface.DrawCircle(x, y, 4, 255, 255, 255, 128)
							surface.DrawLine(w/2, h/2, x, y)
							surface.DisableClipping(false)
						end
					end 
					return true
				end
				itempnl.index = curindex
				
				if item then
					itempnl:SetTooltip(perform.name)
					
					itemmodel = vgui.Create('ModelImage', itempnl)
					itemmodel:SetPos(0, 0)
					itemmodel:SetSize(itempnl:GetWide(), itempnl:GetTall())
					itemmodel:SetModel(perform.model)
					itemmodel:SetMouseInputEnabled(false)
					itempnl.icon = itemmodel

					itempnl.DoClick = function()
						local menu = DermaMenu()
						local mlabel = menu:AddOption(perform.name or '')
						
						mlabel.OnMousePressed = function() end
						
						mlabel.Paint = function(s, w, h)
							
						end
						
						menu:AddSpacer()
						
						menu:AddOption(L'drop', function() 
							net.Start('ls_inventory')
								net.WriteInt(1, 5)
								net.WriteInt(curindex, 8)
							net.SendToServer()

							LocalPlayer().Inventory[curindex] = false --table.remove(LocalPlayer().Inventory, curindex)

							parent:ReloadItems()
						end)

						if inv_items[item.class].use then
							menu:AddOption(inv_items[item.class].usename or L'use', function() 
								net.Start('ls_inventory')
									net.WriteInt(2, 5)
									net.WriteInt(curindex, 8)
								net.SendToServer()
							end)
						end
						
						menu:Open()
					end
				end	
	end
	
	inv._Paint = inv.Paint
	inv.Paint = function(self, w, h)
		self:_Paint(w, h)

		--surface.SetDrawColor(ls_style.MainBackground)
		--surface.DrawRect(0, 0, w, h)
		
		if not input.IsMouseDown(MOUSE_LEFT) and dragitem then
			dragitem:SetZPos(dragitem.oldZ)
			dragitem:GetParent():GetParent():SetZPos(0)
			local p = vgui.GetHoveredPanel()
			if p then
				if p.inv_item then
					local from = dragitem.index
					local to = p.index
			
					local temp = LocalPlayer().Inventory[to]
					LocalPlayer().Inventory[to] = LocalPlayer().Inventory[from]
					LocalPlayer().Inventory[from] = temp
					
					net.Start('ls_inventory')
						net.WriteInt(3, 5)
						net.WriteInt(from, 8)
						net.WriteInt(to, 8)
					net.SendToServer()
					self.rpanel:ReloadItems()
				elseif p == g_ContextMenu then
					net.Start('ls_inventory')
						net.WriteInt(1, 5)
						net.WriteInt(dragitem.index, 8)
					net.SendToServer()
					LocalPlayer().Inventory[dragitem.index] = false
					self.rpanel:ReloadItems()
				end
			end
			
			dragitem = nil
		end
		
		if input.IsMouseDown(MOUSE_LEFT) and not dragitem then
			local p = vgui.GetHoveredPanel()
			if p and p.inv_item and p.icon then
				dragitem = p
				p.oldZ = p:GetZPos()
				p:SetZPos(p.oldZ + 256)
				p:GetParent():GetParent():SetZPos(256)
			end
		end
	end
	
	inv.rpanel = vgui.Create('EditablePanel', inv)
	inv.rpanel:Dock(FILL)
	
	local pers_f = vgui.Create('DFrame', g_ContextMenu)
	pers_f:SetSize(323, 400)
	local x, y = inv:GetPos()
	pers_f:SetPos(32, ScrH - 432)
	pers_f:SetTitle('')
	pers_f.btnClose:Hide()
	pers_f.btnMaxim:Hide()
	pers_f.btnMinim:Hide()
	pers_f:SetMouseInputEnabled(true)
	
	pers_f._Paint = pers_f.Paint
	pers_f.Paint = function(self, w, h)
		self:_Paint(w, h)
		
		surface.SetMaterial(pers)
		surface.SetDrawColor(255, 255, 255)
		surface.DrawTexturedRect(0, 0, 323, 400)
	end
	
	pers_f.p = vgui.Create('EditablePanel', pers_f)
	pers_f.p:Dock(FILL)
	
	inv.pers_f = pers_f
	
	function inv.rpanel:ReloadItems()
		self:Clear()
		dragitem = nil

		local index = 0
		for i = 0, rows - 1 do
			for j = 0, 10 do
				index = index + 1

				if index > slots then break end

				local curindex = index
				
				local bx, by = (itemsize + emptySpace)*j, (itemsize + emptySpace)*i
				slot(curindex, self, bx, by)
			end
		end
		
		pers_f.p:Clear()
		
		slot(-1, pers_f.p, 140 - itemsize/2, 40)
	end
	inv.rpanel:ReloadItems()
end

hook.Add("OnContextMenuOpen", "inv", openInv)

net.Receive('ls_inventory', function()
	local act = net.ReadInt(5)
	
	if act == 1 then
		openInv()
	elseif act == 2 then
		local t = net.ReadTable()
		for i = 1, SWEP.SlotsCount(LocalPlayer()) do 
			if not LocalPlayer().Inventory[i] then
				LocalPlayer().Inventory[i] = t
				break
			end
		end

		if inv and inv.rpanel then inv.rpanel:ReloadItems() end
	elseif act == 5 then
		local ii = net.ReadInt(8)
		local t = net.ReadTable()
		LocalPlayer().Inventory[ii] = t

		if inv and inv.rpanel then inv.rpanel:ReloadItems() end
	elseif act == 3 then
		LocalPlayer().Inventory[#LocalPlayer().Inventory] = false
		if inv and inv.rpanel then inv.rpanel:ReloadItems() end
	elseif act == 4 then
		local ii = net.ReadInt(8)
		LocalPlayer().Inventory[ii] = false
		if inv and inv.rpanel then inv.rpanel:ReloadItems() end
	elseif act == 6 then
		LocalPlayer().Inventory = net.ReadTable()
		if inv and inv.rpanel then inv.rpanel:ReloadItems() end
	end
end)

net.Receive('ls_inventory_shared', function()
	local ply = net.ReadEntity()
	local act = net.ReadInt(5)
	
	if act == 5 then
		local ii = net.ReadInt(8)
		local t = net.ReadTable()
		ply.Inventory = ply.Inventory or {}
		ply.Inventory[ii] = t
	elseif act == 4 then
		local ii = net.ReadInt(8)
		ply.Inventory = ply.Inventory or {}
		ply.Inventory[ii] = nil
	elseif act == 6 then
		ply.Inventory = net.ReadTable()
	end
end)

function SWEP:DrawWorldModel()
	local ply = self.Owner
	
	self.ent = IsValid(self.ent) and self.ent 
		or (function()
			local mdl = ClientsideModel('models/weapons/w_suitcase_passenger.mdl', RENDERGROUP_OTHER)
			mdl:SetNoDraw(true)

			local matrix = Matrix()
			matrix:Scale(Vector(0.8, 0.8, 0.8))
			mdl:EnableMatrix("RenderMultiply", matrix)

			return mdl
		end)()
	
	local attI = ply:LookupAttachment('anim_attachment_RH')
	if not attI then return end
	local att = ply:GetAttachment(attI)
	if not att then return end
	local pos, ang = att.Pos, att.Ang
	
	ang:RotateAroundAxis(ang:Right(),   90)
	ang:RotateAroundAxis(ang:Forward(), 90)
	ang:RotateAroundAxis(ang:Right(),   -90)
	ang:RotateAroundAxis(ang:Forward(),   -90)
	ang:RotateAroundAxis(ang:Up(),   90)
		
	self.ent:SetPos(pos)
	self.ent:SetAngles(ang)
	self.ent:DrawModel()
end