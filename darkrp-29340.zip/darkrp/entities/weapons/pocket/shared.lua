AddCSLuaFile()

if SERVER then
	AddCSLuaFile("cl_menu.lua")
	include("sv_init.lua")
end

if CLIENT then
	include("cl_menu.lua")
end

SWEP.PrintName = L'inventory'
SWEP.Slot = 1
SWEP.SlotPos = 1
SWEP.DrawAmmo = false
SWEP.DrawCrosshair = true
SWEP.Author = "maxmol"
SWEP.Instructions = "ЛКМ - Взять\nПКМ - Выкинуть последнюю вещь\nC - Открыть чемодан"
SWEP.WorldModel = "models/weapons/w_suitcase_passenger.mdl"
SWEP.Spawnable = true
SWEP.Category = "LampServ"

SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = 0
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = ""

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = 0
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = ""

--hook.Add('PostGamemodeLoaded', 'inv_items', function()

hook.Add('Initialize', 'inv_items', function()
	inv_items = {}
	hook.Call('InvItems', GAMEMODE, inv_items)
end)

function SWEP:Initialize()
	self:SetHoldType("normal")
end

function SWEP:Holster() 
	if IsValid(self.ent) then self.ent:Remove() end
	self.ent = nil
	if not SERVER then return true end

	self:GetOwner():DrawViewModel(true)
	self:GetOwner():DrawWorldModel(true)

	return true
end

function SWEP:OnRemove()
	if IsValid(self.ent) then self.ent:Remove() end
end

SWEP.SlotsCount = function(p)
	return 22
end