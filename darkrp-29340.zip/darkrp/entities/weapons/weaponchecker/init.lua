include('shared.lua')

AddCSLuaFile('shared.lua')
AddCSLuaFile('cl_init.lua')

function SWEP:PrimaryAttack()
	if self.cd and self.cd > CurTime() then
		return	
	end
	self.cd = CurTime() + 3
	
	
	local ent = self:GetOwner():getEyeSightHitEntity(90, 15)
	local owner = self:GetOwner()

	if IsValid(ent) then
		local player_weps = {}
		local perm_weps = ent:GetPermWeapons()

		for i, weapon in ipairs(ent:GetWeapons()) do
			local class = weapon:GetClass()

			if table.HasValue(GAMEMODE.Settings.default_weapons, class) or table.HasValue(ent:GetJobTable().weapons, class) or (perm_weps and table.HasValue(perm_weps, class)) then
				continue
			end
			
			table.insert(player_weps, weapon)
		end

		if #player_weps > 0 then
			GAMEMODE:ChatPrintTo(owner, Color(128, 255, 128), L'player_weps', ent, ':')
			
			for i, weapon in ipairs(player_weps) do 
				local class = weapon:GetClass()
				local printname = weapon.PrintName and weapon.PrintName ~= 'Scripted Weapon' and weapon.PrintName or class

				GAMEMODE:ChatPrintTo(owner, printname)
			end
			
			GAMEMODE:ChatPrintTo(owner, '')
		else 
			GAMEMODE:ChatPrintTo(owner, Color(128, 255, 128), L'no_illegal_weps')
		end

		owner:EmitSound("npc/combine_soldier/gear5.wav", 50, 100)
	end

end