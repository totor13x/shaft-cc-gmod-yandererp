include('shared.lua')

SWEP.Slot = 1
SWEP.SlotPos = 100
SWEP.DrawAmmo = false
SWEP.DrawCrosshair = false

SWEP.PrintName = L'weaponchecker'
SWEP.Purpose = L'weaponchecker_purpose'
SWEP.Author = 'LampServ'

function SWEP:PreDrawViewModel()
    return true
end