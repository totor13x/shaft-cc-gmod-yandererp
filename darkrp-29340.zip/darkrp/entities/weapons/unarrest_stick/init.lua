include('shared.lua')

AddCSLuaFile('cl_init.lua')
AddCSLuaFile('shared.lua')

function SWEP:PrimaryFunction(ent)
	ent:UnArrest(self:GetOwner())
end