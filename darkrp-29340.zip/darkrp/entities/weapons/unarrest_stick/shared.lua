SWEP.Base = 'arrest_stick'
SWEP.Category = "Other"
SWEP.Spawnable = true
SWEP.AdminSpawnable = true
SWEP.Color = Color(0, 255, 0)