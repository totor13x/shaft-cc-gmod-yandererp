include('shared.lua')

SWEP.PrintName = L'unarrest_stick'
SWEP.Purpose = L'unarrest_stick_purpose'