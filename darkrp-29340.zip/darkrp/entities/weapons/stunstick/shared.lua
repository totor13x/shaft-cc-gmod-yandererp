SWEP.Category = "Other"
SWEP.Spawnable = true
SWEP.AdminSpawnable = true

SWEP.ViewModel = Model('models/weapons/v_stunbaton.mdl')
SWEP.WorldModel = Model('models/weapons/w_stunbaton.mdl')

SWEP.Delay = 0.75
SWEP.Last = 0

SWEP.Primary.Ammo = ""
SWEP.Secondary.Ammo = ""

SWEP.Mode = true

function SWEP:Initialize()
    if CLIENT then
        CreateMaterial(self:GetClass(), "VertexLitGeneric", {
            ["$basetexture"] = "models/debug/debugwhite",
            ["$surfaceprop"] = "metal",
            ["$envmap"] = "env_cubemap",
            ["$envmaptint"] = "[ .5 .5 .5 ]",
            ["$selfillum"] = 0,
            ["$model"] = 1
        }):SetVector("$color2", Color(0,0,255):ToVector())
    end

    self:SetMaterial('!'..self:GetClass())
    self:SetHoldType('melee')
end

function SWEP:Holster()
    return true
end

local swingsounds = {
    'weapons/stunstick/stunstick_swing1.wav',
    'weapons/stunstick/stunstick_swing2.wav'
}

local hitsounds = {
    'weapons/stunstick/stunstick_fleshhit1.wav',
    'weapons/stunstick/stunstick_fleshhit2.wav',
    'weapons/stunstick/stunstick_impact1.wav',
    'weapons/stunstick/stunstick_impact2.wav'
}

function SWEP:MakeSound(bool)
    if not bool then
        self:EmitSound(Sound(swingsounds[math.random(#swingsounds)]))
    else
        self:EmitSound(Sound(hitsounds[math.random(#hitsounds)]))
    end
end

/*SWEP.LastReload = CurTime()

function SWEP:Reload()
end
