include 'shared.lua'

SWEP.PrintName = L'stunbaton'
SWEP.Slot = 2
SWEP.SlotPos = 1
SWEP.DrawAmmo = false
SWEP.Purpose = L'stunbaton_purpose'
SWEP.Author = '\nLampServ'
SWEP.UseHands = false

CreateMaterial('stunstick_beam', "UnlitGeneric", {
    ["$basetexture"] = "sprites/lgtning",
    ["$additive"] = 1
})


local stunstickMaterial = Material("effects/stunstick")
local stunstickBeam = Material('!stunstick_beam')

function SWEP:PostDrawViewModel(vm)
    if self.Last >= CurTime() - 0.1 then
        local attachment = vm:GetAttachment(1)
        local pos = attachment.Pos
        cam.Start3D(EyePos(), EyeAngles())
            render.SetMaterial(stunstickMaterial)
            render.DrawSprite(pos, 12, 12, Color(180, 180, 180))
            for i = 1, 3 do
                local randVec = VectorRand() * 3
                local offset = (attachment.Ang:Forward() * randVec.x) + (attachment.Ang:Right() * randVec.y) + (attachment.Ang:Up() * randVec.z)
                render.SetMaterial(stunstickBeam)
                render.DrawBeam(pos, pos + offset, 3.25 - i, 1, 1.25, Color(180, 180, 180))
                pos = pos + offset
            end
        cam.End3D()
    end
end

local light_glow02_add = Material("sprites/light_glow02_add")
function SWEP:RenderOverride()
    if self.Last >= CurTime() - 0.1 then
        local bone = self:GetOwner():LookupBone("ValveBiped.Bip01_R_Hand")
        if not bone then self:DrawModel() return end
        local bonePos, boneAng = self:GetOwner():GetBonePosition(bone)
        if bonePos then
            local pos = bonePos + (boneAng:Up() * -16) + (boneAng:Right() * 3) + (boneAng:Forward() * 6.5)
            render.SetMaterial(light_glow02_add)
            render.DrawSprite(pos, 32, 32, Color(255, 255, 255))
        end
    end
    self:DrawModel()
end

function SWEP:PreDrawViewModel(model,wep,me)
	me:GetHands():SetMaterial()
	for i = 9 , 16 do
		model:SetSubMaterial(i, '!'..self:GetClass())
	end
	me:GetHands():SetMaterial()
end

function SWEP:ViewModelDrawn(model)
	model:SetSubMaterial()
end

function SWEP:Attack()
    if CurTime() - self.Last > self.Delay then
		self.Last = CurTime()
		self:GetOwner():SetAnimation(PLAYER_ATTACK1)
		if IsValid(self:GetOwner():getEyeSightHitEntity(90, 15, function(ent) return self:GetOwner() ~= ent and ent:IsSolid() end)) then
			self:MakeSound(true)

			local effectData = EffectData()
    		effectData:SetOrigin(self:GetOwner():GetShootPos() + (self:GetOwner():EyeAngles():Forward() * 45))
    		effectData:SetNormal(self:GetOwner():EyeAngles():Forward())
    		util.Effect("StunstickImpact", effectData)

			return
		end

		self:MakeSound(false)
    end
end

function SWEP:PrimaryAttack()
	self:Attack()
end

function SWEP:SecondaryAttack()
    self:Attack()
end


