include "shared.lua"

AddCSLuaFile 'shared.lua'
AddCSLuaFile 'cl_init.lua'

function SWEP:Animate()
    self.Last = CurTime()
	self:GetOwner():SetAnimation(PLAYER_ATTACK1)

    local vm = self:GetOwner():GetViewModel()
    if IsValid(vm) then 
        vm:SendViewModelMatchingSequence(vm:LookupSequence('attackch'))
        vm:SetPlaybackRate(1)
        timer.Simple(self.Delay, function() 
            vm:SendViewModelMatchingSequence(vm:LookupSequence("idle01")) 
        end)
    end
end

function SWEP:Attack(mode)
    if CurTime() - self.Last > self.Delay then
        self:Animate()

        local ent = self:GetOwner():getEyeSightHitEntity(90, 15, function(ent) return self:GetOwner() ~= ent and ent:IsSolid() end)
		if IsValid(ent) then
            if mode then
                ent:TakeDamage(10, self:GetOwner(), self)
            end
            local normal = self:GetOwner():GetEyeTrace().Normal normal.z = 0
            if ent:IsPlayer() then
                ent:SetVelocity(normal * 300) -- !!!!!!!!
                ent:ScreenFade(SCREENFADE.IN, color_white, 1.2, 0)
            else
                local phys = ent:GetPhysicsObject()
                if IsValid(phys) then phys:AddVelocity(normal * 100) end
            end
            
            self:MakeSound(true)
            return
        end
        self:MakeSound(false)
	end
end

function SWEP:PrimaryAttack()
    self:Attack(false)
end

function SWEP:SecondaryAttack()
	self:Attack(true)
end