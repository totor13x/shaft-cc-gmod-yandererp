AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")

include("shared.lua")
include("commands.lua")

function ENT:Initialize()
	self:SetModel("models/Items/item_item_crate.mdl")
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)

	local phys = self:GetPhysicsObject()

	if phys:IsValid() then
		phys:Wake()
	end

	self.cooldown = CurTime() + 1
	if self:GetCount() < 1 or not self.wepclass or self:GetWModel() == '' then
		SafeRemoveEntity(self)
	end
end

function ENT:Use(activator, caller)
	local diff = self.cooldown - CurTime()
	if diff > 0 then
		--GAMEMODE:Error(activator, {'wait_for', math.ceil(diff)})
		return
	end

	self.cooldown = CurTime() + 1

	local effectdata = EffectData()
	effectdata:SetOrigin(self:GetPos() + self:GetUp() * 50)
	effectdata:SetMagnitude(1)
	effectdata:SetScale(1)
	effectdata:SetRadius(2)
	util.Effect("Sparks", effectdata)

	local weapon = ents.Create("spawned_weapon")
	weapon:SetWeaponClass(self.wepclass)
	weapon:SetModel(self:GetWModel())
	weapon.ammoadd = 0
	weapon.clip1 = self.clip1
	weapon.clip2 = self.clip2

	local weaponAng = self:GetAngles()
	local weaponPos = self:GetAngles():Up() * 40 + weaponAng:Up() * (math.sin(CurTime() * 3) * 8)
	weaponAng:RotateAroundAxis(weaponAng:Up(), (CurTime() * 180) % 360)

	weapon:SetPos(self:GetPos() + weaponPos)
	weapon:SetAngles(weaponAng)
	weapon:Spawn()
	weapon.WName = self:GetWName()

	self:SetCount(self:GetCount() - 1)

	if self:GetCount() < 1 then
		SafeRemoveEntity(self)
	end
end

function ENT:StartTouch(ent)
	if not ent.IsSpawnedShipment 
		or self.cooldown > CurTime()
		or self.wepclass != ent.wepclass
		then return end

	local selfCount, entCount = self:GetCount(), ent:GetCount()
	local count = selfCount + entCount
	self:SetCount(count)

	ent:Remove()
	ent.cooldown = CurTime() + 1
end
