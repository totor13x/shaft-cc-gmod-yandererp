ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Shipment"
ENT.Author = "philxyz"
ENT.Spawnable = false
ENT.IsSpawnedShipment = true

function ENT:SetupDataTables()
	self:NetworkVar("Int", 1, "Count")
	self:NetworkVar('String', 1, 'WModel')
	self:NetworkVar('String', 2, 'WName')
end

hook.Add('InvItems', 'spawned_shipment', function(items)
	items['spawned_shipment'] = {
		perform = function(data)
			return {
				name = 'Коробка с ' .. data.WName,
				model = "models/items/item_item_crate.mdl",
				amount = data.count
			}
		end,
		getTable = function(e)
			return {
				WModel = e:GetWModel(),
				wepclass = e.wepclass,
				count = e:GetCount(),
				clip1 = e.clip1,
				clip2 = e.clip2,
				ammoadd = e.ammoadd,
				WName = ent:GetWName(),
			}
		end,
		spawn = function(data)
			local e = ents.Create('spawned_shipment')
			e:SetCount(data.count)
			e:SetWModel(data.WModel)
			e.clip1 = data.clip1
			e.clip2 = data.clip2
			e.ammoadd = data.ammoadd
			e:SetWName(data.WName)
			
			return e
		end
	}
end)