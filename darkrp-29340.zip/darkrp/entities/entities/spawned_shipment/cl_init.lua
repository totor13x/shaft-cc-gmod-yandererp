include("shared.lua")

function ENT:Draw()
    self:DrawModel()

    local pos = self:GetPos()
    local ang = self:GetAngles()

    local gunPos = pos + ang:Up() * 40 + ang:Up() * (math.sin(CurTime() * 3) * 8)
    ang:RotateAroundAxis(ang:Up(), (CurTime() * 180) % 360)

    local cmodel = self.cmodel
    if not IsValid(cmodel) then
        cmodel = ClientsideModel(self:GetWModel())
        cmodel:SetNoDraw(true)
        self.cmodel = cmodel
    end
	
	if IsValid(cmodel) then
    	cmodel:SetPos(gunPos)
    	cmodel:SetAngles(ang)
    	cmodel:DrawModel()
	end
end

function ENT:RPHUDDraw()
    return language.GetPhrase(self:GetWName()) .. ' : ' .. self:GetCount()
end

function ENT:OnRemove()
    if IsValid(self.cmodel) then
		self.cmodel:Remove()
	end
end

--[[---------------------------------------------------------------------------
Create a shipment from a spawned_weapon
---------------------------------------------------------------------------]]
properties.Add("splitShipment",
{
    MenuLabel   =   L"split_shipment",
    Order       =   2003,
    MenuIcon    =   "icon16/arrow_divide.png",

    Filter      =   function(self, ent, ply)
                        if not IsValid(ent) then return false end
                        return ent.IsSpawnedShipment
                    end,

    Action      =   function(self, ent)
                        if not IsValid(ent) then return end
                        RunConsoleCommand("rp", "splitshipment", ent:EntIndex())
                    end
})

DarkRP:DescribeCommand('splitshipment', L"splitshipment")
DarkRP:DescribeCommand('makeshipment', L"makeshipment")