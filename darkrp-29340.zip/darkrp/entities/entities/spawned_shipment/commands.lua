--[[---------------------------------------------------------------------------
Create a shipment from a spawned_weapon
---------------------------------------------------------------------------]]
local function createShipment(ply, args)
    local id = tonumber(args) or -1
    local ent = Entity(id)

    ent = IsValid(ent) and ent or ply:GetEyeTrace().Entity

    if not IsValid(ent) or not ent.IsSpawnedWeapon or ent.USED == false then
        GAMEMODE:Error(ply, {"wrong_argument", id})
        return
    end

    local pos = ent:GetPos()

    if pos:DistToSqr(ply:GetShootPos()) > 16900 then
        GAMEMODE:Error(ply, "distance_too_big")
        return
    end

    ent.PlayerUse = false

    if ent.USED then
        GAMEMODE:Error(ply, {"unable", '/makeshipment'} )
        return
    end

    local crate = ents.Create("spawned_shipment")
    crate.SID = ply.SID
    crate:SetPos(ent:GetPos())
    crate.wepclass = ent:GetWeaponClass()
    crate:SetWModel(ent:GetModel())
    crate:SetWName(ent.WName)
    crate:SetCount(1)
    crate:Spawn()
    crate:SetPlayer(ply)
    crate.clip1 = ent.clip1
    crate.clip2 = ent.clip2
    crate.ammoadd = ent.ammoadd or 0

    SafeRemoveEntity(ent)
    ent.USED = true

    local phys = crate:GetPhysicsObject()
    phys:Wake()
end
DarkRP:AddCommand("makeshipment", createShipment)

--[[---------------------------------------------------------------------------
Split a shipment in two
---------------------------------------------------------------------------]]
local function splitShipment(ply, args)
    local id = tonumber(args) or -1
    local ent = Entity(id)

    ent = IsValid(ent) and ent or ply:GetEyeTrace().Entity

    if not IsValid(ent) or not ent.IsSpawnedShipment then
        GAMEMODE:Error(ply, {"wrong_argument", id})
        return
    end

    if ent:GetCount() < 2 or ent.locked or ent.USED then
        GAMEMODE:Error(ply, "shipment_cannot_split")
        return
    end

    local pos = ent:GetPos()

    if pos:DistToSqr(ply:GetShootPos()) > 16900 then
        GAMEMODE:Error(ply, "distance_too_big")
        return
    end

    local count = math.floor(ent:GetCount() / 2)
    ent:SetCount(ent:GetCount() - count)

    local crate = ents.Create("spawned_shipment")
    crate:SetPos(ent:GetPos())
    crate:SetPlayer(ply)
    crate:SetWModel(ent:GetWModel())
    crate.wepclass = ent.wepclass
    crate.clip1 = ent.clip1
    crate.clip2 = ent.clip2
    crate.ammoadd = ent.ammoadd
    crate:SetWName(ent:GetWName())

    crate:Spawn()

    local phys = crate:GetPhysicsObject()
    phys:Wake()
end
DarkRP:AddCommand("splitshipment", splitShipment)
