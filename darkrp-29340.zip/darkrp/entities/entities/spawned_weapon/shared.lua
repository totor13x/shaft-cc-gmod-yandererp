ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Spawned Weapon"
ENT.Author = "Rickster"
ENT.Spawnable = false
ENT.IsSpawnedWeapon = true

function ENT:SetupDataTables()
    self:NetworkVar("String", 0, "WeaponClass")
end

hook.Add('InvItems', 'spawned_weapon', function(items)
    items['spawned_weapon'] = {
        perform = function(data)
            return {
                name = data.wname,
                model = data.model,
            }
        end,
        getTable = function(e)
            return {
                wepclass = e:GetWeaponClass(),
                model = e:GetModel(),
                clip1 = e.clip1,
                clip2 = e.clip2,
                ammoadd = e.ammoadd or 0,
                wname = e.WName
            }
        end,
        use = function(data, ply)
            local e = ents.Create('spawned_weapon')
            e:SetWeaponClass(data.wepclass)
            e:SetModel(data.model)
            e.clip1 = data.clip1
            e.clip2 = data.clip2
            e.WName = data.wname
            e.ammoadd = data.ammoadd
            e:Spawn()

            timer.Simple(0, function() e:Use(ply, ply, 3, 0) end)
            return true
        end,
        spawn = function(data)
            local e = ents.Create('spawned_weapon')
            e:SetWeaponClass(data.wepclass)
            e:SetModel(data.model)
            e.clip1 = data.clip1
            e.clip2 = data.clip2
            e.WName = data.wname
            e.ammoadd = data.ammoadd
            
            return e
        end
    }
end)