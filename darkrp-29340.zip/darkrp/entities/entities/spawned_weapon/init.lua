AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")

include("shared.lua")

function ENT:Initialize()
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)
    self:SetUseType(SIMPLE_USE)
    local phys = self:GetPhysicsObject()
    if IsValid(phys) then phys:Wake() end
end

function ENT:Use(activator, caller)
    if self.USED then return end

    local class = self:GetWeaponClass()
    local weapon = ents.Create(class)

    if not weapon:IsWeapon() then
        weapon:SetPos(self:GetPos())
        weapon:SetAngles(self:GetAngles())
        weapon:Spawn()
        weapon:Activate()
        self.USED = true
        self:Remove()
        return
    end

    -- Store ammo count before weapon pickup
    local primaryAmmoType = weapon:GetPrimaryAmmoType()
    local secondaryAmmoType = weapon:GetSecondaryAmmoType()
    weapon:Remove()

    weapon = activator:Give(class, true)

    local clip1, clip2 = self.clip1, self.clip2
    if weapon:IsValid() then
        if clip1 and clip1 ~= -1 and weapon:Clip1() ~= -1 then
            weapon:SetClip1(clip1)
            clip1 = 0
        end
        if clip2 and clip2 ~= -1 and weapon:Clip2() ~= -1 then
            weapon:SetClip2(self.clip2)
            clip2 = 0
        end
    else
        weapon = activator:GetWeapon(class)
        if clip2 and clip2 > 0 and weapon:Clip2() ~= -1 then
            weapon:SetClip2(weapon:Clip2() + clip2)
            clip2 = 0
        end
    end

    if primaryAmmoType > 0 then
        local primAmmo = activator:GetAmmoCount(primaryAmmoType)
        primAmmo = primAmmo + (self.ammoadd or 0) + (clip1 or 0) -- Gets rid of any ammo given during weapon pickup
        activator:SetAmmo(primAmmo, primaryAmmoType)
    end

    if secondaryAmmoType > 0 then
        local secAmmo = activator:GetAmmoCount(secondaryAmmoType) + (clip2 or 0)
        activator:SetAmmo(secAmmo, secondaryAmmoType)
    end

    self.USED = true
    self:Remove()
end

local meta = FindMetaTable("Player")
function meta:dropDRPWeapon(weapon)
    if table.HasValue(GAMEMODE.Settings.default_weapons, weapon:GetClass())
        or table.HasValue(GAMEMODE.Jobs[self:Team()].weapons, weapon:GetClass()) then
        GAMEMODE:Error(self, 'cant_drop')
        return
    end

    local primAmmo = self:GetAmmoCount(weapon:GetPrimaryAmmoType())
    self:DropWeapon(weapon) -- Drop it so the model isn't the viewmodel

    local ent = ents.Create("spawned_weapon")

    local model = (weapon:GetModel() == "models/weapons/v_physcannon.mdl" and "models/weapons/w_physics.mdl") or weapon:GetModel()
    model = util.IsValidModel(model) and model or "models/weapons/w_rif_ak47.mdl"

    ent:SetModel(model)
    ent:SetSkin(weapon:GetSkin() or 0)
    ent:SetWeaponClass(weapon:GetClass())
    ent.WName = weapon:GetPrintName()
    ent.nodupe = true
    ent.clip1 = weapon:Clip1()
    ent.clip2 = weapon:Clip2()
    ent.ammoadd = primAmmo

    self:RemoveAmmo(primAmmo, weapon:GetPrimaryAmmoType())
    self:RemoveAmmo(self:GetAmmoCount(weapon:GetSecondaryAmmoType()), weapon:GetSecondaryAmmoType())

    local trace = {}
    trace.start = self:GetShootPos()
    trace.endpos = trace.start + self:GetAimVector() * 50
    trace.filter = {self, weapon, ent}

    local tr = util.TraceLine(trace)

    ent:SetPos(tr.HitPos)
    ent:Spawn()

    ent:SetPos(GAMEMODE.playerDropPos(self))

    weapon:Remove()
end

local function DropWeapon(ply)
    local ent = ply:GetActiveWeapon()
    if not ent:IsValid() or ent:GetModel() == "" then
        GAMEMODE:Error(ply, 'cant_drop')
        return
    end

    local canDrop = hook.Call("canDropWeapon", GAMEMODE, ply, ent)
    if canDrop == false then
        GAMEMODE:Error(ply, 'cant_drop')
        return
    end

    ply:DoAnimationEvent(ACT_GMOD_GESTURE_ITEM_DROP)

    timer.Simple(1, function()
        if IsValid(ply) and IsValid(ent) and ply:Alive() and ent:GetModel() ~= "" and not IsValid(ply:GetObserverTarget()) then
            ply:dropDRPWeapon(ent)
        end
    end)
end

DarkRP:AddCommand('drop', DropWeapon)
DarkRP:AddCommand('dropweapon', DropWeapon)
DarkRP:AddCommand('weapondrop', DropWeapon)