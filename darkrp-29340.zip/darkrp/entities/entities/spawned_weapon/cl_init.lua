include("shared.lua")

properties.Add("create_shipment",
{
    MenuLabel   =   "Create a shipment",
    Order       =   2002,
    MenuIcon    =   "icon16/add.png",
    Filter      =   function(self, ent, ply)
        if not IsValid(ent) then return false end
        return ent.IsSpawnedWeapon
    end,
    Action      =   function(self, ent)
        if not IsValid(ent) then return end
        RunConsoleCommand("rp", "makeshipment", ent:EntIndex())
    end
})

DarkRP:DescribeCommand('drop', L'dropweapon')