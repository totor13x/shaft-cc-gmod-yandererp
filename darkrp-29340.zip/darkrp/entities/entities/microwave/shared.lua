ENT.Type = 'anim'
ENT.Base = 'base_anim'
ENT.Model = 'models/props/cs_office/microwave.mdl'
ENT.Spawnable = false

function ENT:SetupDataTables()
    self:NetworkVar('Int', 0, 'FoodPrice')
end