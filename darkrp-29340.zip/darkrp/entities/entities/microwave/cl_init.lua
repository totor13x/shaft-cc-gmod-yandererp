include 'shared.lua'

ENT.PrintName = L'microwave'

function ENT:RPHUDDraw()
	return L'food_price1' .. GAMEMODE.formatMoney(self:GetFoodPrice()), self:WorldSpaceCenter()
end