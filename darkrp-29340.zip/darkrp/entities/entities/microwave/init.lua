include 'shared.lua'

AddCSLuaFile 'shared.lua'
AddCSLuaFile 'cl_init.lua'

ENT.Cooldown = 3

GAMEMODE:AddCommand('price', function(ply, arg)
    local price, ent = tonumber(arg[1]), ply:GetEyeTrace().Entity

    if price and ent and IsValid(ent) and ent:GetClass() == 'microwave' and ent.rp_owner == ply then
        price = math.Clamp(price, 50, 500)

        ent:SetFoodPrice(price)
        GAMEMODE:Notify(ply, L('food_price2', GAMEMODE.formatMoney(price)))
    else
        GAMEMODE:Error(ply, 'should_look')
    end
end) 

function ENT:Initialize()
	--self:SetModel(self.Model)
	self:PhysicsInit(SOLID_VPHYSICS)
    self:SetUseType(ONOFF_USE)
    self:SetFoodPrice(150)
    self.LastUse = CurTime()
end

function ENT:Check()
    if CurTime() - self.LastUse > self.Cooldown then
        self.LastUse = CurTime()

        return true
    else
        return false 
    end
end

function ENT:Use(ply)
    if self:Check() then
        local isowner = ply == self.rp_owner
        local price = isowner and 50 or self:GetFoodPrice()
        if ply:CanAfford(price) then
            if not isowner then
                self.rp_owner:AddMoney(price / 4)
                GAMEMODE:Notify(self.rp_owner, 'got_money_food')
            end
            ply:AddMoney(-price)

            local food = ents.Create('spawned_food')
            food:SetPos(self:WorldSpaceCenter() + Vector(0, 0, 10))
            food:SetModel('models/props_junk/garbage_takeoutcarton001a.mdl')
            food:Spawn()

            if math.random(100) == 1 then
                food.poisoned = true
            end
        
            hook.Call('PlayerMadeFood', GAMEMODE, self, food, ply)

            GAMEMODE:Notify(ply, L('food_bought', GAMEMODE.formatMoney(price)))
        else
            GAMEMODE:Error(ply, 'cant_afford')
        end
    end
end