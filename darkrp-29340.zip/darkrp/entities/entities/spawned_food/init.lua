AddCSLuaFile("shared.lua")

include("shared.lua")

function ENT:Initialize()
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)
    self:SetUseType(SIMPLE_USE)

    local phys = self:GetPhysicsObject()

    if phys:IsValid() then
        phys:Wake()
    end
end

function ENT:Use(activator, caller)
    if self.USED then return end
    self.USED = true
    
    activator:EmitSound("vo/sandwicheat09.mp3", 100, 100)

    if self.poisoned then
        activator:SetHealth(activator:Health() - math.random(45))
        activator:SetCSVar("Hunger", math.Clamp(activator:GetCSVar("Hunger", 100) - math.random(25, 50), 0, 100))

        hook.Call('PlayerGotPoisoned', GAMEMODE, self, activator)
    else
        activator:SetCSVar("Hunger", math.Clamp(activator:GetCSVar("Hunger", 100) + (self:GetTable().FoodEnergy or 25), 0, 100))
    end

    self:Remove()
end

function ENT:OnTakeDamage(dmg)
    self:TakePhysicsDamage(dmg)

    local typ = dmg:GetDamageType()
    if bit.band(typ, bit.bor(DMG_FALL, DMG_VEHICLE, DMG_DROWN, DMG_RADIATION, DMG_PHYSGUN)) > 0 then return end

    self.USED = true
    self:Remove()
end