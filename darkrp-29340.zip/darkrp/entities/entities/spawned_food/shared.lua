ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Spawned Food"
ENT.Author = "Rickster"
ENT.Spawnable = false
ENT.IsSpawnedFood = true

function ENT:SetupDataTables()
    self:NetworkVar("Entity", 1, "owning_ent")
end

hook.Add('InvItems', 'spawned_food', function(items)
    items['spawned_food'] = {
        perform = function(data)
            return {
                name = 'Еда',
                model = data.model
            }
        end,
        getTable = function(e)
            return {
                model = e:GetModel(),
                energy = e.FoodEnergy,
            }
        end,
        use = function(data, ply)
            ply:SetCSVar("Hunger", math.Clamp(ply:GetCSVar("Hunger", 100) + (data.energy or 25), 0, 100))

            return true
        end,
        usename = 'Съесть',
        spawn = function(data) 
            local e = ents.Create("spawned_food")
            e:SetModel(data.model)
            e.FoodEnergy = data.energy
            
            return e
        end
    }
end)