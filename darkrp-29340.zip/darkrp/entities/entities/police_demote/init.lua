AddCSLuaFile('shared.lua')
AddCSLuaFile('cl_init.lua')
include('shared.lua')

function ENT:CanDemote(ply)
	if ply:Team() == TEAM_POLICE_CHIEF then
		return true
	end
end

function ENT:Initialize()
	self:SetModel(self.Model)
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetUseType(ONOFF_USE)

	local cool = 0

	util.AddNetworkString(self.Tag)
	net.Receive(self.Tag, function(l, ply)
		if self:CanDemote(ply) then
			if CurTime() - cool > 30 then
				local ent = net.ReadEntity()
				cool = CurTime()

				if self:CanBeDemoted(ent) then
					hook.Call('OnPlayerDemoted', GAMEMODE, ply, ent, L'police_demote_reason')
					
					ent:ChangeTeam(GAMEMODE.DefaultTeam, true)
				end
			else
				GAMEMODE:Error(ply, L'police_demote_cooldown')
			end
		end
	end)
end

function ENT:Use(ply, _, val)
	if val == 0 then
		if self:CanDemote(ply) then
			net.Start(self.Tag)
			net.Send(ply)
		else
			GAMEMODE:Error(ply, L'not_allowed')
		end
	end
end
