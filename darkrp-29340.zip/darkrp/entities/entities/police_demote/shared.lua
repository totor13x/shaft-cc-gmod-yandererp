ENT.Type = 'anim'
ENT.Base = 'base_anim'

ENT.Spawnable = false
ENT.AdminSpawnable = false

ENT.Model = 'models/props_interiors/paper_tray.mdl'
ENT.Tag = 'PoliceDemote'

function ENT:CanBeDemoted(ply) 
	if ply:Team() == TEAM_POLICE then 
		return true 
	end
end
