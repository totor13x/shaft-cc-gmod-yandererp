include('shared.lua')

function ENT:RPHUDDraw()
	return {L'police_demote_officer'}
end

function ENT:Initialize()
	if not IsValid(self) then
		return
	end

	local function demote(ent)
		net.Start(self.Tag)
		net.WriteEntity(ent)
		net.SendToServer()
	end

	net.Receive(self.Tag, function()
		local frame = vgui.Create('DFrame')
		frame:SetSize(ScrW() / 6, ScrH() / 2)
		frame:SetTitle(L'demote_player')
		frame:Center()
		frame:MakePopup()

		local button = vgui.Create('DButton', frame)
		local listview
		button:SetText(L'police_demote')
		button:DockMargin(0,5,0,0)
		button:Dock(BOTTOM)
		function button:DoClick()
			local pnl = listview:GetSelected()

			if listview:GetSelected()[1] then
				demote( listview:GetSelected()[1].Entity )
				frame:Remove()
			else
				chat.AddText(Color(255,255,50), L'police_choose_player')	
			end
		end

		listview = vgui.Create('DListView', frame)
		listview:Dock(FILL)
		listview:AddColumn(L'player')
		listview:AddColumn(L'job')

		for k, ply in ipairs(player.GetAll()) do
			if self:CanBeDemoted(ply) and ply ~= LocalPlayer() then
				listview:AddLine( ply:GetName(), ply:GetJobTable().name ).Entity = ply
			end
		end
	end)
end

