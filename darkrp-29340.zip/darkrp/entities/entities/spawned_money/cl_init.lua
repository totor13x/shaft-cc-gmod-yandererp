include("shared.lua")

function ENT:RPHUDDraw()
    return DarkRP.formatMoney(self:GetAmount())
end