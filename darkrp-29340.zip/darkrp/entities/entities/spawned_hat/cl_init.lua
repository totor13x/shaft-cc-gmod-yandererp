include("shared.lua")

function ENT:RPHUDDraw()
	return {self:GetHatName(), 'Можно одеть в инвентаре'}	
end