AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")
include("shared.lua")

function ENT:Initialize()
	self:PhysicsInitSphere(12, 'plastic')
	self:SetUseType(SIMPLE_USE)

	local phys = self:GetPhysicsObject()

	if phys:IsValid() then
		phys:Wake()
	end
end

function ENT:SetHat(data)
	self:SetModel(data.model)
	self:SetHatName(data.name)
	self:SetHatPos(data.pos)
	self:SetHatAng(data.ang)
	self:SetHatScale(data.scale or 1)
end

function ENT:Use(ply)
	if inv_put(self, ply) then
		GAMEMODE:Notify(ply, "Вы взяли шапку в инвентарь, зажмите C и перетащите её на персонажа")
	end
end