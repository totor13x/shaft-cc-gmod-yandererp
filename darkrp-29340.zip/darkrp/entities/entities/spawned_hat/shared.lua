ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Spawned Hat"
ENT.Author = "maxmol"
ENT.Spawnable = false

function ENT:SetupDataTables()
	self:NetworkVar("Entity", 1, "owning_ent")
	self:NetworkVar("String", 1, "HatName")
	self:NetworkVar("Vector", 1, "HatPos")
	self:NetworkVar("Angle", 1, "HatAng")
	self:NetworkVar("Float", 1, "HatScale")
end

hook.Add('InvItems', 'spawned_hat', function(items)
	items['spawned_hat'] = {
		perform = function(data)
			return data
		end,
		getTable = function(e)
			return {
				name = e:GetHatName(),
				model = e:GetModel(),
				pos = e:GetHatPos(),
				ang = e:GetHatAng(),
				scale = e:GetHatScale(),
				hat = true,
			}
		end,
		spawn = function(data) 
			local e = ents.Create("spawned_hat")
			e:SetHat(data)
			e:Spawn()
			
			return e
		end
	}
end)