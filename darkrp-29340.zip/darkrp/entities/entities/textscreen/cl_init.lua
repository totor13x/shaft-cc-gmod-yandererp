include 'shared.lua'

surface.CreateFont('TextScreen',{
	font = 'Arial',
	size = 50,
	weight = 550,
	antialias = true
})

function ENT:DrawTranslucent()
	if EyePos():DistToSqr(self:GetPos()) < 250000 then 
		for i = 1, 4 do
			if self['GetAvailable' .. tostring(i)](self) then
				cam.Start3D2D(self:GetPos() - self:GetAngles():Right() * 20, self:GetAngles(), 0.2)
					local col = self['GetTextColor' .. tostring(i)](self)
					local txt = self['GetText' .. tostring(i)](self)
					surface.SetFont('TextScreen')
					draw.SimpleText(txt, 'TextScreen', -surface.GetTextSize(txt) / 2, -50 - i * -50, Color(col.x, col.y, col.z))
				cam.End3D2D()
			end
		end
	end
end