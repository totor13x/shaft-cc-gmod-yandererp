ENT.Type = 'anim'
ENT.Base = 'base_anim'
ENT.Spawnable = false 
ENT.AdminOnly = true
ENT.Tag = 'textscreen'
ENT.RenderGroup = RENDERGROUP_TRANSLUCENT

function ENT:SetupDataTables()
    for i = 1, 4 do
	    self:NetworkVar('String', i - 1, 'Text' .. tostring(i))	
	    self:NetworkVar('Vector', i - 1, 'TextColor' .. tostring(i))
        self:NetworkVar('Float', i - 1, 'Size' .. tostring(i))
        self:NetworkVar('Bool', i - 1, 'Available' .. tostring(i))
        if SERVER then
            self['SetAvailable' .. tostring(i)](self, false)
        end
    end
end