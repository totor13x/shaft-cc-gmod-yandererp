include('shared.lua')

function ENT:RPHUDDraw()
	return {'Документ', self:GetWriter(), 'Нажми Е, чтобы прочитать'}
end

surface.CreateFont('rp_document', {
	font = "Times New Roman",
	extended = true,
	size = 20,
})

net.Receive('rp_document', function()
	local e = net.ReadEntity()
	local f = vgui.Create('DFrame')
	f:SetSize(400, 600)
	f:Center()
	f.Paint = function(self, w, h)
		surface.SetDrawColor(255, 254, 237)
		surface.DrawRect(0, 0, w, h)
	end
	f.btnMaxim:Hide()
	f.btnMinim:Hide()
	f:SetTitle("")
	f:MakePopup()
	
	local t = vgui.Create("RichText", f)
	t:Dock(FILL)
	t:InsertColorChange(0, 0, 0, 255)
	t:SetVerticalScrollbarEnabled(false)
	
	function t:PerformLayout()
		self:SetFontInternal("rp_document")
		self:SetFGColor(color_black)
	end
	
	t:AppendText("\n\n\t\t\t\tДокумент\n\n\n" .. e:GetWrittenText() .. '\n\n\n' .. e:GetWriter() .. '\n\t\t\t\t\t' .. e:GetDate())
end)

DarkRP:DescribeCommand('document', 'Выписать документ', {'Текст документа'})
