AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

function ENT:Initialize()
	self:SetModel('models/school/paper.mdl')
	
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)
	local physObj = self:GetPhysicsObject()
	if IsValid(physObj) then
		physObj:SetMass(50)
		physObj:Wake()
	end
	
	self:MakeBreakable({
		health = 50,
		nocolor = true,
	})
end

util.AddNetworkString('rp_document')
function ENT:Use(_, ply)
	if IsValid(ply) and ply:IsPlayer() then
		net.Start('rp_document')
			net.WriteEntity(self)
		net.Send(ply)
	end
end

DarkRP:AddCommand("document", function(ply, args, argstr)
	if ply.rp_document_cooldown and ply.rp_document_cooldown > CurTime() then
		GAMEMODE:Error(ply, "Вы не можете создавать документы так часто!")
		return	
	end
	
	ply.rp_document_cooldown = CurTime() + 30
	
	local e = ents.Create('rp_document')
	e:SetPos(GAMEMODE.playerDropPos(ply))
	e:SetWriter(ply:GetName() .. ', ' .. team.GetName(ply:Team()))
	e:SetWrittenText(argstr)
	e:SetDate(os.date("%H:%M:%S - %d/%m/%Y" , os.time()))
	e:Spawn()
end)
