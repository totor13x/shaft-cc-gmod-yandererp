ENT.PrintName = 'Документ'
ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.Author = 'maxmol'

function ENT:SetupDataTables()
	self:NetworkVar('String', 0, 'WrittenText')
	self:NetworkVar('String', 1, 'Writer')
	self:NetworkVar('String', 2, 'Date')
end

hook.Add('InvItems', 'rp_document', function(items)
	items['rp_document'] = {
		perform = function(data)
			return {
				name = 'Документ ' .. data.Writer,
				model = "models/school/paper.mdl"
			}
		end,
		getTable = function(e)
			local t = {
				Writer = e:GetWriter(),
				WrittenText = e:GetWrittenText(),
				Date = e:GetDate()
			}

			return t
		end,
		spawn = function(data)
			local e = ents.Create('rp_document')
			e:SetWriter(data.Writer)
			e:SetWrittenText(data.WrittenText)
			e:SetDate(data.Date)
			
			return e
		end
	}
end)
