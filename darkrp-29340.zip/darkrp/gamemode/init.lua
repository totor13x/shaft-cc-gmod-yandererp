AddCSLuaFile "cl_init.lua"
AddCSLuaFile "shared.lua"

include "shared.lua"

-- configs
do 
    local location = GM.ConfigFolder
    local files = file.Find(location .. '*', 'LUA')

    for _, f in ipairs(files) do
        AddCSLuaFile(location .. f)
    end
end

-- modules
do 
    local location = GM.ModuleFolder
    local files, dirs = file.Find(location .. '*', 'LUA')

    for _, d in ipairs(dirs) do
        local location_svinit = location .. d .. '/init.lua'
        local location_clinit = location .. d .. '/cl_init.lua'
        local location_shared = location .. d .. '/shared.lua'

        if file.Exists(location_shared, 'LUA') then
            include(location_shared)
            AddCSLuaFile(location_shared)
        end

        if file.Exists(location_svinit, 'LUA') then
            include(location_svinit)
        end

        if file.Exists(location_clinit, 'LUA') then
            AddCSLuaFile(location_clinit)
        end

        print('[rp] loaded module ' .. d)
    end

    for _, f in ipairs(files) do
        include(location .. f)
        AddCSLuaFile(location .. f)

        print('[rp] loaded module ' .. f)
    end
end