GM:CreateBuyEntity{
	name = 'SMG Ammo',
	class = 'item_ammo_smg1',
	desc = "Патроны для автомата",
	max = 4,
	model = "models/Items/BoxMRounds.mdl",
	price = 100,
	category = 'Патроны',
}

GM:CreateBuyEntity{
	name = 'Pistol Ammo',
	class = 'item_ammo_pistol',
	desc = "Патроны для пистолета",
	max = 4,
	model = "models/Items/BoxSRounds.mdl",
	price = 60,
	category = 'Патроны',
}

GM:CreateBuyEntity{
	name = 'SMG',
	class = 'weapon_smg1',
	desc = "Пистолет-пулемет самый крутой в мире",
	max = 4,
	model = "models/weapons/w_smg1.mdl",
	price = 2000,
	category = 'Оружие',
	jobs = TEAM_GANGSTAR,
}