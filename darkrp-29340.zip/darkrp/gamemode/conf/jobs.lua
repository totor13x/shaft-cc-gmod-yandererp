TEAM_CITIZEN = GM:CreateJob({
	name = 'Гражданин',
	color = Color(0, 200, 64),
	salary = 100,
	category = 'Мирные жители',
	model = {
		'models/player/group01/female_01.mdl',
		'models/player/group01/female_02.mdl',
		'models/player/group01/female_03.mdl',
		'models/player/group01/female_04.mdl',
		'models/player/group01/female_05.mdl',
		'models/player/group01/female_06.mdl',
		'models/player/group01/male_01.mdl',
		'models/player/group01/male_02.mdl',
		'models/player/group01/male_03.mdl',
		'models/player/group01/male_04.mdl',
		'models/player/group01/male_05.mdl',
		'models/player/group01/male_06.mdl',
		'models/player/group01/male_07.mdl',
		'models/player/group01/male_08.mdl',
		'models/player/group01/male_09.mdl',
	},
})

TEAM_DOCTOR = GM:CreateJob({
	name = 'Доктор',
	color = Color(32, 200, 255),
	salary = 100,
	category = 'Мирные жители',
	model = 'models/player/kleiner.mdl',
})

TEAM_GANGSTAR = GM:CreateJob({
	name = 'Гангстер',
	color = Color(64, 64, 64),
	weapons = {'weapon_pistol'},
	salary = 50,
	category = 'Вне закона',
	model = {
		'models/player/group03/female_01.mdl',
		'models/player/group03/female_02.mdl',
		'models/player/group03/female_03.mdl',
		'models/player/group03/female_04.mdl',
		'models/player/group03/female_05.mdl',
		'models/player/group03/female_06.mdl',
		'models/player/group03/male_01.mdl',
		'models/player/group03/male_02.mdl',
		'models/player/group03/male_03.mdl',
		'models/player/group03/male_04.mdl',
		'models/player/group03/male_05.mdl',
		'models/player/group03/male_06.mdl',
		'models/player/group03/male_07.mdl',
		'models/player/group03/male_08.mdl',
		'models/player/group03/male_09.mdl',
	},
})

TEAM_THIEF = GM:CreateJob({
	name = 'Вор',
	color = Color(64, 64, 100),
	weapons = {'weapon_pistol'},
	salary = 50,
	category = 'Вне закона',
	model = 'models/player/arctic.mdl',
})

TEAM_POLICE = GM:CreateJob({
	name = 'Полицейский',
	color = Color(64, 64, 200),
	weapons = {'weapon_pistol'},
	salary = 50,
	category = 'Полиция',
	police = true,
	model = 'models/player/police.mdl',
})

TEAM_MAYOR = GM:CreateJob({
	name = 'Мэр',
	color = Color(196, 0, 0, 255),
	model = "models/player/breen.mdl",
	weapons = {"arrest_stick", "unarrest_stick", "stunstick", "weaponchecker"},
	max = 1,
	salary = 100,
	vote = true,
	mayor = true,
	police = true,
	category = "Полиция",
})

GM.DefaultTeam = TEAM_CITIZEN
GM:AddDoorGroup('Police', TEAM_POLCE, TEAM_MAYOR)