GM.Settings = {
	respawn_on_job_change = true,
	can_use_job_command = true,
	can_use_buy_command = true,
	currency_right = false,
	drop_money_on_death = true, 
	default_jobs = true, -- add default f4 jobs
	default_entities = true, -- add default f4 entities

	hunger_damage = 10, -- damage per 10 seconds
	hunger_starve = 0.5, -- hunger points per 10 seconds,
	hunger_premium_starve = 0.25,
	job_change_cooldown = 60,
	entity_buy_cooldown = 1,
	money_give_cooldown = 1,
	run_speed = 250,
	walk_speed = 120,
	start_money = 500,
	door_cost = 100,
	max_doors = 5,
	arrest_time = 60,
	salary_delay = 300,
	drop_money_on_death_portion = 0.1,
	give_money_max = 10000,
	wanted_time = 10,
	zfar = 2000, -- maximum drawing distance

	currency = '$',

	default_weapons = {
		'weapon_physgun',
		'weapon_physcannon',
		'gmod_camera',
		'weapon_fists',
		'gmod_tool',
		'keys',
		'pocket',
	},

	disabled_modules = {
		-- ['name'] = true,
	},

	force_language = 'ru', -- set `false` for auto

	roof_positions = {
		Vector(0, 0, 0),
	},

	randompos_limit = 512
}

hook.Run('RPSettings', GM.Settings)