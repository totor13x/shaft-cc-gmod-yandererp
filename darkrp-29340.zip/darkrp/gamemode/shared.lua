DeriveGamemode "sandbox"

GM.Name = "DarkRP"
GM.Author = "maxmol"
GM.Email = ""
GM.Website = "https://steamcommunity.com/id/maxmol/"
GM.TeamBased = false

DEFINE_BASECLASS("gamemode_sandbox")
GM.Sandbox = BaseClass

GM.ModuleFolder = GM.FolderName .. '/gamemode/module/'
GM.ConfigFolder = GM.FolderName .. '/gamemode/conf/'

DarkRP = GM

include(GM.ConfigFolder .. 'settings.lua')