include "shared.lua"

-- modules
do 
    local location = GM.ModuleFolder
    local files, dirs = file.Find(location .. '*', 'LUA')

    for _, d in ipairs(dirs) do
        local location_clinit = location .. d .. '/cl_init.lua'
        local location_shared = location .. d .. '/shared.lua'

        if file.Exists(location_shared, 'LUA') then
            include(location_shared)
        end

        if file.Exists(location_clinit, 'LUA') then
            include(location_clinit)
        end
    end

    for _, f in ipairs(files) do
        include(location .. f)
    end
end