local Player = FindMetaTable('Player')
function Player:IsPremium()
	return self:GetNWBool('Premium')
end