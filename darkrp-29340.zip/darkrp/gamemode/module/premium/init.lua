include('shared.lua')

if not sql.TableExists('Premium') then
    sql.Query('CREATE TABLE Premium (SteamID string, Expires int)')
end

local function delete(steamid)
	sql.Query( string.format('DELETE FROM Premium WHERE SteamID = "%s"', steamid) )
end

local function timer_create(ply, expiration)
	timer.Create('Premium' .. ply:SteamID(), expiration - os.time(), 1, function()
		ply:SetPremium(false)
	end)
end

local meta = FindMetaTable('Player')
function meta:SetPremium(bool, days)
	local exists = sql.Query( string.format('SELECT * FROM Premium WHERE SteamID = "%s"', self:SteamID()) )

	if bool then
		days = days and days or 0
    	local time = os.time() + (days * 24 * 60 ^ 2)
    	
		if not exists then
			sql.Query( string.format('INSERT INTO Premium VALUES ("%s", %d)', self:SteamID(), days ~= 0 and time or 0) )
			self:SetNWBool('Premium', true)
		else
			sql.Query( string.format('UPDATE Premium SET Expires = %d Where SteamID = %s', days ~= 0 and time or 0, SQLStr(self:SteamID())) )	
		end
		
		if days ~= 0 then
			timer_create(self, time)
		end

		GAMEMODE:ChatPrint(Color(255, 215, 0),'[Premium] ', Color(245, 245, 245), L('is_premium', self:GetName()) .. (days == 0 and L'forever' or L('for_days', days)))
	end
	
	if not bool and exists then
		delete(self:SteamID())
		self:SetNWBool('Premium', false)

		GAMEMODE:ChatPrint(Color(255, 215, 0),'[Premium] ', Color(245, 245, 245), L('not_premium', self:GetName()))
	end
end

function meta:GetPremiumTime()
	if not self:IsPremium() then
		return	
	end
	
	local expires = sql.Query( string.format('SELECT * FROM Premium WHERE SteamID = "%s"', self:SteamID()) )[1].Expires
	local days = (((expires - os.time()) / 60) / 60) / 24
	if days < 0 then
		days = 0	
	end
	
	return days
end

local tab = sql.Query('SELECT * FROM Premium')
if tab then 
	for _, member in ipairs(tab) do
		if tonumber(member.Expires) ~= 0 and tonumber(member.Expires) < os.time() then
			local ply = player.GetBySteamID(member.SteamID)
			if IsValid(ply) then
				ply:SetPremium(false)
			else
                delete(member.SteamID)
            end
		end
	end
end

hook.Add('PlayerInitialSpawn', 'Premium', function(ply)
	local tab = sql.Query(string.format('SELECT * FROM Premium WHERE SteamID = "%s"', ply:SteamID()))
	ply:SetNWBool('Premium', tobool(tab))
	
	if ply:IsPremium() and tab.Expires and tonumber(tab.Expires) ~= 0 then
		timer_create(ply, tab.Expires)
	end
end)

hook.Add('PlayerDisconnected', 'Premium', function(ply)
	timer.Remove('Premium' .. ply:SteamID())
end)