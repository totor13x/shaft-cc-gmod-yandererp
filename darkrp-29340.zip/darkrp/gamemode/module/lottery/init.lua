util.AddNetworkString('ls_lottery')
util.AddNetworkString('ls_lottery_part')

local lottery_players = {}
local lottery_current = nil
function GM:Lottery(part, win, amt)
	lottery_current = {part, amt}
	net.Start('ls_lottery')
		net.WriteBool(true)
		net.WriteInt(amt, 32)
	net.Broadcast()
	
	timer.Create('ls_lottery', 60, 1, function()
		lottery_current = nil
		if #lottery_players == 0 then 
			net.Start('ls_lottery')
				net.WriteBool(false)
				net.WriteEntity(NULL)
				net.WriteInt(0, 32)
			net.Broadcast()
			return
		end
		
		local winner = lottery_players[math.random(#lottery_players)]
		local winmuch = amt * #lottery_players
		win(winner, winmuch)
		net.Start('ls_lottery')
			net.WriteBool(false)
			net.WriteEntity(winner)
			net.WriteInt(winmuch, 32)
		net.Broadcast()
		
		lottery_players = {}
	end)
end

GM:AddCommand('lot', function(ply)
	if lottery_current then
		if table.HasValue(lottery_players, ply) then
			GAMEMODE:Notify(ply, 'Вы уже участвуете в лотерее')
			return
		end
		
		if lottery_current[1](ply, lottery_current[2]) then
			table.insert(lottery_players, ply)
			net.Start('ls_lottery_part')
				net.WriteEntity(ply)
			net.Broadcast()
		end
	end
end)
