local ltrclr = Color(255, 255, 0)
local LotteryText = 'Чтобы принять участие в лотерее напишите /lot | Взнос: %s'
local LotteryWinText = '%s выиграл в лотерее и получил %s!'
local LotteryPartText = '%s принял участие в лотерее'


net.Receive('ls_lottery', function()
	local bool = net.ReadBool()
	if bool then
		local amt = net.ReadInt(32)
		notification.AddProgress('ls_lottery', LotteryText and string.format(LotteryText, DarkRP.formatMoney(amt)) or 'lottery')
		GAMEMODE:Tip(ltrclr, string.format(LotteryText, DarkRP.formatMoney(amt)), false, 'ambient/alarms/warningbell1.wav', true)
	else
		notification.Kill('ls_lottery')
		local winner = net.ReadEntity()
		if not IsValid(winner) then return end
		local winmuch = net.ReadInt(32)
		
		GAMEMODE:Tip(ltrclr, string.format(LotteryWinText, winner:GetName(), DarkRP.formatMoney(winmuch)), false, 'lampoviy_server/winner.ogg', true)
	end
end)

net.Receive('ls_lottery_part', function()
	local ply = net.ReadEntity()
	if IsValid(ply) then
		notification.AddLegacy(string.format(LotteryPartText, ply:GetName()), -1, 2)
		surface.PlaySound('ambient/tones/elev1.wav')
	end
end)
