if not sql.TableExists('Playtime') then
	sql.Query('CREATE TABLE Playtime (SteamID string, Time int)')	
end

local PLAYER = FindMetaTable('Player')
function PLAYER:SetPlayTime(time)
	sql.Query( string.format('UPDATE Playtime SET Time = %d WHERE SteamID = "%s"', time, self:SteamID()) )
end
function PLAYER:GetPlayTime()
	return self.playtime_initial + math.floor((CurTime() - self.playtime_initial_when))
end

util.AddNetworkString('playtime')
hook.Add('PlayerFullyLoaded', 'playtime', function(ply)
	local time = sql.QueryValue( string.format('SELECT Time FROM Playtime WHERE SteamID = "%s" ', ply:SteamID()) )
	if not time then
		sql.Query( string.format('INSERT INTO Playtime VALUES ("%s", %d)', ply:SteamID(), 0) )
		time = 0
	end

	ply.playtime_initial = time
	ply.playtime_initial_when = math.ceil(CurTime())

	for k, v in ipairs(player.GetAll()) do 
		if not v.playtime_initial then continue end
		
		net.Start('playtime')
		net.WriteUInt(v:EntIndex(), 8)
		net.WriteUInt(v.playtime_initial, 32)
		net.WriteUInt(v.playtime_initial_when, 32)
		if v == ply then
			net.Broadcast()
		else
			net.Send(ply)
		end
	end
end)

timer.Create('save_playtime', 60, 0, function()
	for k, ply in ipairs(player.GetAll()) do 
		if ply.playtime_initial then
			ply:SetPlayTime(ply:GetPlayTime())
		end
	end
end)