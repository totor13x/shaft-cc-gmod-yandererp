PLAYTIMES = PLAYTIMES or (function()
	local t = {}
	for i = 1, 128 do
		t[i] = false
	end

	return t
end)()

local playtimes = PLAYTIMES

net.Receive('playtime', function()
	local playerindex = net.ReadUInt(8) /* :EntIndex() */
	local playtime = net.ReadUInt(32)
	local playtime_when = net.ReadUInt(32)
	playtimes[playerindex] = {playtime, playtime_when}
end)

local PLAYER = FindMetaTable('Player')
function PLAYER:GetPlayTime()
	local pt = playtimes[self:EntIndex()]
	return pt and pt[1] + math.floor(CurTime() - pt[2]) or 0
end
	
surface.CreateFont('PlaytimeFont', {
	font='Segoe UI', 
	extended = true, 
	size = 26, 
	outline = false, 
	weight = 600, 
	antialias = true, 
	shadow = false, 
	italic = true
})
	
local function format_time(time)
	local hours = string.format("%02.f", math.floor(time/3600));
	local mins = string.format("%02.f", math.floor(time/60 - (hours*60)));
	local secs = string.format("%02.f", math.floor(time - hours*3600 - mins *60));
	
	return string.format("%s:%s:%s", hours, mins, secs)
end

local x = ScrW() - 101
local GetEyeTrace = FindMetaTable('Player').GetEyeTrace
hook.Add('HUDPaint', 'Playtime', function()
	local ent = GetEyeTrace(LocalPlayer()).Entity
	local bool = IsValid(ent) and ent:IsPlayer()

	draw.RoundedBoxEx(8, x, 0, 101, bool and 50 or 30, Color(50, 60, 70), false, false, true, false)

	local text = format_time(LocalPlayer():GetPlayTime())
	
	surface.SetTextColor(Color(255, 255, 255, 255))
	surface.SetFont('PlaytimeFont')
	surface.SetTextPos(x + 101 / 2 - surface.GetTextSize(text) / 2, 1.75)
	surface.DrawText(text)

	if bool then
		local text = format_time(ent:GetPlayTime())

		surface.SetTextColor(Color(255, 255, 255, 255))
		surface.SetFont('PlaytimeFont')
		surface.SetTextPos(x + 101 / 2 - surface.GetTextSize(text) / 2, 22)
		surface.DrawText(text)
	end
end)