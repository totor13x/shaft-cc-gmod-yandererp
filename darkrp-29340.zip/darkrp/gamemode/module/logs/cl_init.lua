ls_logs = ls_logs or {}

ls_logs.create = function()
	ls_logs.p = vgui.Create('DFrame')
	ls_logs.p:SetSize(1000, 700)
	ls_logs.p:Center()
	ls_logs.p:ShowCloseButton(false)
	ls_logs.p:MakePopup()
	ls_logs.p:SetTitle('LampServ Logs')
	ls_logs.p.Paint = function(s, w, h) 
		draw.RoundedBox(0, 0, 0, w, h, Color(50, 50, 50))
	end
	
	local closebtn = vgui.Create("DButton", ls_logs.p)
	closebtn:SetSize(42, 18)
	closebtn:SetPos(ls_logs.p:GetWide() - closebtn:GetWide(), 0)
	closebtn.Paint = function(self, w, h)
		local bg = (self.Depressed and Color(128, 32, 32)) or (self:IsHovered() and Color(255, 0, 0)) or Color(255, 64, 64)
		draw.RoundedBox(0, 0, 0, w, h, bg)
		draw.SimpleTextOutlined("r", "marlett", w/2, h/2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black )
		return true
	end
	closebtn.DoClick = function()
		RememberCursorPosition()
		ls_logs.p:Hide()
	end
	
	ls_logs.p.properties = vgui.Create("DPropertySheet", ls_logs.p)
	ls_logs.p.properties:Dock(FILL)
	ls_logs.p.properties.Paint = function(self, w, h) 
		draw.RoundedBox(0, 0, 0, w, h, Color(60, 60, 60)) 
	end
	
	ls_logs.p.lists = {}	
end

concommand.Add('logs', function(p)
	if not p:IsAdmin() then return end
	
	if IsValid(ls_logs.p) then ls_logs.p:Show() return end
	ls_logs:create()
end)

net.Receive('ls_logs', function()

	local t = net.ReadTable()
	
	if not IsValid(ls_logs.p) then ls_logs:create() ls_logs.p:Hide() end
	
	local logtype = t[1]
	
	if not ls_logs.p.lists[logtype] then
		local sheet = vgui.Create("Panel")
		sheet.Paint = function(self, w, h)
			surface.SetDrawColor(0, 0, 0)
			surface.DrawRect(0, 0, w, h)
		end
		
		local lst = vgui.Create("DListView", sheet)
		lst:Dock(FILL)
		lst:SetMultiSelect(false)
		lst:SetPaintBackground(false)
		lst:SetSortable(false)
		lst.OnRowSelected = function(self, index, pnl)
			local s = ''
			for k, v in ipairs(pnl.Columns) do
				s = s .. v:GetText() .. ' '
			end
			
			SetClipboardText(s)
			chat.AddText(Color(0, 255, 0), 'copied to clipboard')
			surface.PlaySound('buttons/button15.wav')
		end
		
		for i = 1, #t do
			lst:AddColumn('')
		end
		
		local te = vgui.Create('DTextEntry', sheet)
		te:SetSize(0, 24)
		te:SetText('Search...')
		te.OnEnter = function(self)
			for _, l in ipairs(ls_logs.p.lists[logtype].Lines) do
				local hide = true
				
				for _, col in ipairs(l.Columns) do
					if col:GetText():find(self:GetValue()) then
						hide = false
						break
					end
				end
			
				if hide then 
					if not l.oldSetSize then
						l:SetTall(0)
						l.oldSetSize = l.SetSize
						function l:SetSize(w, h)
							self:oldSetSize(w, 0)
						end
					end
				else
					l:SetTall(24)
					l.SetSize = l.oldSetSize
					l.oldSetSize = nil
				end
			end
			lst:DataLayout()
		end
		te:Dock(TOP)
		
		ls_logs.p.lists[logtype] = lst
		
		ls_logs.p.properties:AddSheet(logtype, sheet, "icon16/bullet_purple.png", false, false)
		
		for _, v in pairs(ls_logs.p.properties.Items) do
			v.Tab.Paint = function(self, w, h)
				draw.RoundedBox(0, 0, 0, w, h, Color(70, 70, 70)) 
			end
		end
	end
	
	table.remove(t, 1)
	local line = ls_logs.p.lists[logtype]:AddLine(os.date('%H:%M:%S', os.time()), unpack(t))
	for k, v in ipairs(line.Columns) do
		v:SetColor(color_white)
	end
end)