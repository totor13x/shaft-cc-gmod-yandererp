local tag = 'ls_logs'

util.AddNetworkString(tag)

function GM:Log(...)
	local t = {...}
	for k, v in ipairs(t) do
		if isentity(v) then
			if v:IsPlayer() then
				t[k] = v:GetName() .. ' ('.. v:SteamID() .. ')'
			else
				t[k] = IsValid(v) and v:GetClass() or 'UNKNOWN'
			end
		else
			t[k] = tostring(v)
		end	
	end
	
	
	local plys = {}
	for _, v in ipairs(player.GetAll()) do
		if v:IsAdmin() then
			table.insert(plys, v)
		end	
	end
	
	net.Start(tag)
		net.WriteTable(t)
	net.Send(plys)
	
	print('[LS Logs] ', unpack(t))
end

hook.Add('PlayerHurt', tag, function(victim, att, hlth, dmg)
	if dmg > 0 and IsValid(att) and att:IsPlayer() and att != victim then
		GAMEMODE:Log(
			'Damage',
			att,
			victim,
			(att.GetActiveWeapon and IsValid(att:GetActiveWeapon())) and att:GetActiveWeapon() or wep,
			dmg
		)
	end
end)

hook.Add('PlayerDeath', tag, function(victim, wep, killer)
	GAMEMODE:Log(
		'Kills',
		killer,
		victim,
		(killer.GetActiveWeapon and IsValid(killer:GetActiveWeapon())) and killer:GetActiveWeapon() or wep
	)
end)

hook.Add('PlayerArrested', tag, function(criminal, actor, time)
	GAMEMODE:Log('Arrests', criminal, actor)
end)

gameevent.Listen("player_disconnect")
hook.Add('player_disconnect', tag, function(data)
	GAMEMODE:Log('Connections', data.name, data.networkid, data.reason, 'LEFT')
end)

gameevent.Listen('player_connect')
hook.Add('player_connect', tag, function(data)
	GAMEMODE:Log('Connections', data.name, data.networkid, 'JOINED')
end)

hook.Add('OnPlayerDemoted', tag, function(source, target, reason)
	GAMEMODE:Log('Demotions', source, target, reason)
end)

hook.Add('PlayerSpawnedProp', tag, function(ply, mdl)
	GAMEMODE:Log('Props', ply, mdl)
end)

hook.Add('OnPlayerChangedTeam', tag, function(ply, old, new)
	GAMEMODE:Log('Jobs', ply, team.GetName(old), team.GetName(new))
end)