if IsValid(rp_quick_commands) then
	rp_quick_commands:Remove()
end

hook.Add('OnContextMenuOpen', 'rp_quick_commands', function()
	if IsValid(rp_quick_commands) then
		rp_quick_commands:Show()
		return	
	end
	
	local _RegisterDermaMenuForClose = RegisterDermaMenuForClose
	function RegisterDermaMenuForClose()
		
	end
	
	rp_quick_commands = vgui.Create('DMenu', g_ContextMenu)
	
	local count = #GAMEMODE.CommandsHelp
	for k = 1, count do
		local v = GAMEMODE.CommandsHelp[k]
		local opt = rp_quick_commands:AddOption(v[2], function()
			GAMEMODE:ClientQuickCommand(k)
		end)
		
		opt._Paint = opt.Paint
		opt.Paint = function(self, w, h)
		local canuse = true
			if v[4] then
				canuse = v[4]()
			end
			
			if canuse then
				self:_Paint(w, h)
				return false
			else
				surface.SetDrawColor(128, 128, 128, 64)
				surface.DrawRect(0, 0, w, h)
			end
		end
	end
	
	rp_quick_commands:SetPos(0, 256)
	
	RegisterDermaMenuForClose = _RegisterDermaMenuForClose
end)

hook.Add('OnContextMenuClose', 'rp_quick_commands', function()
	if IsValid(rp_quick_commands) then
		rp_quick_commands:Hide()
	end
end)