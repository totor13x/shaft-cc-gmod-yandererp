RunConsoleCommand('sv_skyname', 'painted')
AddCSLuaFile('cl_init.lua')

local tag = 'Sky'
local Sky = Sky

local function CreateSkyEnt()
	if not IsValid(Sky.ent) then
		local sky_ents = ents.FindByClass("env_skypaint")
		if #sky_ents > 0 then
			Sky.ent = sky_ents[1]
		else
			Sky.ent = ents.Create('env_skypaint')
			Sky.ent:Spawn()
			Sky.ent:Activate()
		end
	end

	Sky.ent:SetSunSize(0)
	Sky.ent:SetSunNormal(Vector(0, 0, -1))
	Sky.ent:SetStarSpeed(0.015)
	Sky.ent:SetDrawStars(true)
	
	if not IsValid(Sky.EnvSun) then
		local sun_ents = ents.FindByClass("env_sun")
		if #sun_ents > 0 then
			Sky.EnvSun = sun_ents[1]
		end
	end
end

hook.Add('InitPostEntity', tag, CreateSkyEnt)
hook.Add('PostCleanupMap', tag, CreateSkyEnt)

util.AddNetworkString(tag)

function Sky:Lightning(i, p)
	engine.LightStyle(0, p)

	net.Start(tag)
	net.WriteInt(i, 4)
	net.Broadcast()
end

local night = 1
local dawn = 2
local day = 3
local dusk = 4

local time = {
	[night] = {
		top = Vector(0,0,0),
		bottom = Vector(0,0,0),
		dusk = Vector(0,0,0),
		dusk_intense = 0,
		fade = 0,
		star_scale = 1,
		pattern = 'b'
	},
	[dawn] = {
		top = Vector(0.13, 0.27, 0.80),
		bottom = Vector(0.82, 0.80, 1.00),
		dusk = Vector(1.00, 0.67, 0.00),
		dusk_intense = 1,
		fade = 0.25,
		star_scale = 1,
		pattern = 'f'
	},
	[day] = {
		top = Vector(0.07, 0.23, 1.00),
		bottom = Vector(0.20, 0.52, 1.00),
		dusk = Vector(1.00, 1.00, 1.00),
		dusk_intense = 0.5,
		fade = 0.5,
		star_scale = 0,
		pattern = 'h'
	},
	[dusk] = {
		top = Vector(0.34, 0.47, 1.00),
		bottom = Vector(1.00, 0.38, 0.64),
		dusk = Vector(1.00, 0.93, 0.34),
		dusk_intense = 2,
		fade = 0.3,
		star_scale = 1,
		pattern = 'c'
	},
}

local frac = {
	top = Vector(0.34, 0.47, 1.00),
	bottom = Vector(1.00, 0.38, 0.64),
	dusk = Vector(1.00, 0.93, 0.34),
	dusk_intense = 2,
	fade = 0.3,
}

local function Move(v, v1, v2, steps)
  return v + (v2 - v1) / steps
end

--hook.Add('PostGamemodeLoaded', 'Sky', function()
local oldcurrent, current = dusk, dusk
timer.Create(tag, 0.1, 0, function()
	local Time = Sky.GetTime()

	oldcurrent = current
	current = Time < 6 and night 
		or Time < 9 and dawn 
		or Time < 17 and day 
		or Time < 21 and dusk 
		or night

	if oldcurrent ~= current then
		hook.Call('SkyChange', GAMEMODE, current)		
		Sky:Lightning(current, time[current].pattern)

		local oldcurrent = oldcurrent -- store local old
		local i = 0
		timer.Create('ProcessTime', 0.1, 100, function()
			for k, v in pairs(frac) do
				frac[k] = Move(v, time[oldcurrent][k], time[current][k], 100)
			end

			i = i + 1
			if i == 100 then
				local frac = time[current]
			end

			Sky.ent:SetTopColor( frac.top )
			Sky.ent:SetBottomColor( frac.bottom )
			Sky.ent:SetDuskColor( frac.dusk )
			Sky.ent:SetDuskIntensity( frac.dusk_intense )
			Sky.ent:SetFadeBias( frac.fade )
			Sky.ent:SetStarScale( time[current].star_scale )
		end)
	end

	if IsValid(Sky.EnvSun) then
		local a = ((Time+10) * 2 * math.pi) / 24
		local sun_normal = Vector(0, math.sin(a) + 0.4, math.cos(a) + 0.4):GetNormalized()
		Sky.EnvSun:SetKeyValue("sun_dir", tostring(sun_normal))
	end
end)
--end)

hook.Add('PlayerFullyLoaded', tag, function(ply)
	net.Start(tag)
	net.WriteInt(current, 4)
	net.Send(ply)
end)