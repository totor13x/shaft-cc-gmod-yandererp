/*
local night = 1
local dawn = 2
local day = 3
local dusk = 4
*/
local colors = {
	Vector(0, 0, 0),
	Vector(204, 220, 220),
	Vector(204, 255, 255),
	Vector(204, 220, 220),
}
	
local color_num = 1
local color = colors[color_num]
    
function GM:SetupWorldFog(n)
	local zfar = self.Settings.zfar or 2000
	
	if zfar == 0 then return end

	n = n or 1

	render.FogMode(1) 
	render.FogStart((color.x - 102)/102 * (zfar - 1000)*n)
	render.FogEnd(zfar*n)
	render.FogMaxDensity(1)
	render.FogColor(color.x, color.y, color.z)

	return true
end

GM.SetupSkyboxFog = GM.SetupWorldFog

local function Move(v, v1, v2, steps)
  return v + (v2 - v1) / steps
end

net.Receive('Sky', function()
	local old_clr = color
	color_num = net.ReadInt(4)
	Sky.timeOfDay = color_num

	local steps = 100
	local counter = 0
	timer.Create('Sky_fogcolor', 0.1, steps, function()
		color = Move(color, old_clr, colors[color_num], steps)
		counter = counter + 1
		if counter == steps then
			render.RedownloadAllLightmaps(true)	
		end
	end)
end)