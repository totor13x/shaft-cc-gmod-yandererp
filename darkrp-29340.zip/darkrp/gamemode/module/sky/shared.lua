Sky = Sky or {}

Sky.GetTime = function()
	return (CurTime() / 120) % 24
end
