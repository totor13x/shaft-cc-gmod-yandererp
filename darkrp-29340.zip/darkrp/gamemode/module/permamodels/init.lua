if not sql.TableExists('rp_permmodels') then
	sql.Query('CREATE TABLE rp_permmodels (SteamID string, Model string)')
end

local player = FindMetaTable('Player')

function player:GetPermModel()
	local p = sql.Query(string.format('SELECT Model FROM rp_permmodels WHERE SteamID = "%s"', self:SteamID()))

	if p then
		return p[1].Model
	else
		return false
	end
end

function player:SetPermModel(model)
	if self:GetPermModel() then
		sql.Query(string.format('DELETE FROM rp_permmodels WHERE SteamID = "%s"', self:SteamID()))
	end
	
	if model then
		sql.Query(string.format('INSERT INTO rp_permmodels VALUES ("%s", %s)', self:SteamID(), SQLStr(model)))
			
		self:SetModel(model)
		timer.Simple(0, function() self:SetupHands() end)
	end
end

hook.Add('PlayerSetModel', 'PermModel', function(ply)
	local mdl = ply:GetPermModel()

	if mdl then
		timer.Simple(0, function()
			ply:SetModel(mdl)
			ply:SetupHands()
		end)
	end
end)

