local PLAYER = FindMetaTable('Player')

function PLAYER:getDarkRPVar(var)
	if var == 'money' then
		return self:GetMoney()
	elseif var == 'Energy' then
		return self:GetCSVar('Hunger')
	end

	print('!!! INVALID :getDarkRPVar ' .. var .. ' on player', self)
end

function DarkRP.createCategory()
end