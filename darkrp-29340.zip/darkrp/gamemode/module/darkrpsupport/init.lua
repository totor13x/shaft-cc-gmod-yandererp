function DarkRP.notify(ply, msgtype, len, msg)
	GAMEMODE:Notify(ply, msg, msgtype)
end

local PLAYER = FindMetaTable('Player')

function PLAYER:setSelfDarkRPVar(var, val)
	if var == "Energy" then
		self:SetCSVar('Hunger', val)
	else
		print('!!! INVALID :setSelfDarkRPVar ', var, val)
	end
end