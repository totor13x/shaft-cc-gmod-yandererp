local tag = 'TripleSlash'

util.AddNetworkString(tag)

local function WriteToAdmins(from, message, makepopup)
	for i, adm in ipairs(player.GetAll()) do
		if adm:IsAdmin() then
			net.Start(tag)
			net.WriteEntity(from)
			net.WriteBool(makepopup)
			net.WriteString(message)
			net.Send(adm)
		end
	end
end

GM:AddCommand('//', function(ply, _, argstr)
	WriteToAdmins(ply, argstr, not ply:IsAdmin())
	if not ply:IsAdmin() then
		GAMEMODE:ChatPrintTo(ply, Color(255, 64, 64), '[Админам] ', color_white, argstr)
	end
end)

net.Receive(tag, function(l, p)
	if p:IsAdmin() then
		WriteToAdmins(net.ReadEntity(), string.format('>>> Принял "%s"', p:GetName()), false)
	end
end)
