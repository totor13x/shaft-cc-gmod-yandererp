local tag = 'TripleSlash'
local reports = {}

net.Receive(tag, function()
	local ply, bool, text = net.ReadEntity(), net.ReadBool(), net.ReadString()
	
	chat.AddText(Color(255, 64, 64), '[Админ-Чат] ', ply, Color(255, 255, 255), ': ', text)
		
	for i, report in ipairs(reports) do
		if report.ply == ply and not report.taken then
			print(report.ply)
			report.panel:Remove()	
		end
	end

	if bool then
		local w, h = ScrW() / 7.5, ScrH() / 9
		
		local panel = vgui.Create('DPanel')
		panel:SetSize(w, h)
		panel:SetPos(ScrW() - w - 5, ScrH() / 2.5 - h + (h + 5) * #reports)
		function panel:Paint(w, h)
			surface.SetDrawColor(Color( 50, 50, 50, 255 ))
			surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(Color( 100, 100, 100, 255 ))
			surface.DrawOutlinedRect(0, 0, w, h)
		end
		function panel:OnRemove()
			local idx
			for k, report in ipairs(reports) do
				if report.panel == self then
					idx = k
				end
			end
			
			table.remove(reports, idx)
			
			for i = idx, #reports do 
				reports[i].panel:SetPos(ScrW() - w - 5, ScrH() / 2.5 - h + (h + 5) * (i - 1))
			end 
		
		end
		
		table.insert(reports, {ply = ply, panel = panel})
		
		local exit = vgui.Create('DButton', panel)
		exit:SetText('x')
		exit:SetContentAlignment(8)
		exit:SetSize(panel:GetWide() / 7.5, panel:GetTall() / 7)
		exit:SetPos(panel:GetWide() - exit:GetWide(), 0)
		function exit:Paint(w, h) 
			surface.SetDrawColor(Color(150, 50, 50, 255))
			surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(Color( 100, 100, 100, 255 ))
			surface.DrawOutlinedRect(0, 0, w, h)
		end
		function exit:DoClick()
			panel:Remove()
		end
		
		local label = vgui.Create('DLabel', panel)
		label:DockMargin(0, 5, 0, 0)
		label:Dock(TOP)
		label:SetTextColor(Color(255, 255, 255))
		label:SetFont('TargetID')
		label:SetText(ply:GetName())
		label:SetContentAlignment(5)
		
		local reportlabel = vgui.Create('DLabel', panel)
		reportlabel:DockMargin(7.5, 12.5, 7.5, 0)
		reportlabel:Dock(TOP)
		reportlabel:SetTextColor(Color(255, 255, 255))
		reportlabel:SetFont('TargetIDSmall')
		reportlabel:SetText(text)
		reportlabel:SetContentAlignment(5)
		
		local helpbutton = vgui.Create('DButton', panel)
		helpbutton:Dock(BOTTOM)
		helpbutton:SetSize(panel:GetWide(), panel:GetTall() / 5)
		helpbutton:SetText('Помочь игроку')
		function helpbutton:DoClick()
			net.Start(tag)
			net.WriteEntity(ply)
			net.SendToServer()
            
			for i, report in ipairs(reports) do
				if report.panel == panel then
					report.taken = true	
				end
			end

			local w, h = helpbutton:GetSize()
			helpbutton:Remove()
			
			local gotobutton = vgui.Create('DButton', panel)
			gotobutton:SetPos(0, panel:GetTall() - h)
			gotobutton:SetSize(w / 3, h)
			gotobutton:SetText('GOTO')
			function gotobutton:DoClick()
				RunConsoleCommand('say', string.format('/goto %s', ply:GetName()))
			end
			
			local tpbutton = vgui.Create('DButton', panel)
			tpbutton:SetPos(gotobutton:GetWide(), panel:GetTall() - h)
			tpbutton:SetSize(w / 3, h)
			tpbutton:SetText('TP')
			function tpbutton:DoClick() 
				RunConsoleCommand('say', string.format('/tp %s', ply:GetName()))
			end
			
			local tproof = vgui.Create('DButton', panel)
			tproof:SetPos(tpbutton.X + tpbutton:GetWide(), panel:GetTall() - h)
			tproof:SetSize(w / 3, h)
			tproof:SetText('ТП НА КРЫШУ')
			function tproof:DoClick()
				RunConsoleCommand('say', string.format('/tproof %s', ply:GetName()))
			end
		end
	end
end)

GM:DescribeCommand('//', 'Написать админам', {
	'Текст'
})