if not sql.TableExists('rp_arrest_poses') then
	sql.Query('CREATE TABLE rp_arrest_poses (pos string)')
end

GM:AddCommand('setjailpos', function(ply)
	if not ply:IsSuperAdmin() then
		GAMEMODE:Error(ply, 'not_allowed')
		return
	end

	local pos = ply:GetEyeTrace().HitPos
	sql.Query('DELETE FROM rp_arrest_poses')
	sql.Query('INSERT INTO rp_arrest_poses (pos) VALUES (' .. SQLStr(util.TypeToString(pos)) .. ')')
end)

GM:AddCommand('addjailpos', function(ply)
	if not ply:IsSuperAdmin() then
		GAMEMODE:Error(ply, 'not_allowed')
		return
	end

	local pos = ply:GetEyeTrace().HitPos
	sql.Query('INSERT INTO rp_arrest_poses (pos) VALUES (' .. SQLStr(util.TypeToString(pos)) .. ')')
end)

function GM:GetJailPos()
	local poses = sql.Query("SELECT * FROM rp_arrest_poses")

	if poses and #poses > 0 then
		return util.StringToType(poses[math.random(#poses)].pos, 'Vector')
	end
end

local arrested_players = {}

local meta = FindMetaTable('Player')

function meta:Arrest(time, arrester)
	local stm = self:SteamID()

	if time or not arrested_players[stm] then
		GAMEMODE:Notify(player.GetAll(), L('arrested', arrester and arrester:GetName() or 'SERVER', self:GetName()))
		time = time or GAMEMODE.Settings.arrest_time
		arrested_players[stm] = true

		timer.Create('rp_arrest_' .. stm, time, 1, function()
			arrested_players[stm] = nil
			local p = player.GetBySteamID(stm)
			if p then
				p:UnArrest()
			end
		end)

		self.arrested = true
		self:KillSilent()
		hook.Run('PlayerArrested', self, arrester, time)

		GAMEMODE:NotWanted(self)
	elseif arrested_players[stm] then
		self:Spawn()
	end
end

function meta:IsArrested()
	return arrested_players[self:SteamID()] and true or false
end

hook.Add('PlayerLoadout', 'rp_arrest', function(ply)
	if ply:IsArrested() then
		ply:StripWeapons()
		return true
	end
end)

hook.Add('PlayerSelectSpawn', 'rp_arrest', function(ply)
	if ply:IsArrested() then
		return {GetPos = function() return GAMEMODE:GetJailPos() end}
	end
end)

function meta:UnArrest(unarrester)
	local stm = self:SteamID()

	arrested_players[stm] = nil
	timer.Remove('rp_arrest_' .. stm)

	if self.arrested then
		self.arrested = nil
		self:KillSilent()
		GAMEMODE:Notify(player.GetAll(), L('unarrested', self:GetName()))
		hook.Call('PlayerUnArrested', GAMEMODE, self, unarrester or nil)
	end
end

hook.Add('PlayerSpawnObject', 'rp_arrest', function(ply)
	if ply:IsArrested() then
		return false
	end
end)

hook.Add('CanArrest', 'Police', function(arrester, ply)
	if arrester:IsPolice() and not ply:IsPolice() then
		return true
	end
end)