return {
	no_desc = "No description...",
	wrong_argument = "Wrong argument (%s)",
	cant_become = "You can't become %s.",
	you_already = "You are already a %s",
	limit_reached = "Limit reached for %s",
	wait_for = "Wait for %s second(s)",
	change_job = "Change Job",
	unlock_for = "Unlock for %s",
	disabled = "This function is disabled",
	
	blocking_player = "You are blocking a player!",
	object_frozen = "Your object has been frozen!",
	object_blocked = "This object is blocked!",
	prop_too_large = "You're triying to spawn a prop that is too large!",
	spawning_objects_too_fast = "You are spawning objects too fast!",
	tool_blocked = "This tool is blocked",

	menu = "LampServ Menu 3",
	commands = "COMMANDS",
	jobs = "JOBS",
	entities = "ENTITIES",
	ammo = "AMMO",
	buy = "Buy",

	cant_buy = "You can't buy %s",
	cant_afford = "You can't afford this",
	not_enough = "You don't have enough",
	bought = "Bought %s",
	picked_up = "You picked up %s",
	dropped = "Dropped %s",
	must_be_looking_player = 'You must be looking at a player',
	have_given = "You have given %s to %s",
	were_given = "You were given %s by %s",
	give = "Give money to player you're looking at",
	dropmoney = "Drop money in front of you",
	amount = 'The Amount',
	provide = 'Provide',

	cant_drop = "Can't drop this",
	dropweapon = "Drop the weapon you're holding",
	distance_too_big = "You are too far away",

	unable = "Unable to %s",
	not_allowed = "You are not allowed to do this",

	splitshipment = "Split the shipment you're looking at",
	makeshipment = "Create a shipment from a dropped weapon",
	shipment_cannot_split = "Cannot split this shipment",
	split_shipment = "Split shipment",
	door_can_buy = "Press R with keys to buy",
	door_sell = "Press R with keys to sell",
	door_bought = "You bought this door for %s",
	door_sold = "You sold this door for %s",
	shipments = "Shipments",
	doors = "Doors",
	
	yes = "Yes",
	no = "No",

	wants_to_become = "%s wants to become \"%s\"",
	players_voted_against = "Players voted against you becoming \"%s\"",
	
	youve_been_paid = "You've been paid a salary of %s",

	became = "%s became \"%s\"",
	became_was = "%s became \"%s\" (was \"%s\")",

	arrested = "%s arrested %s",
	unarrested = "%s was released from jail",

	players_can_hear = "Players who can hear you",
	noone_can_hear = "Noone can hear you",

	-- admin
	kicked = ' kicked ',
	chat_muted = ' chat muted ',
	chat_unmuted = ' chat unmuted ',
	voice_muted = ' voice muted ',
	voice_unmuted = ' voice unmuted ',
	returned = ' returned ',
	min = '(%s min.)',
	freezed = ' freezed ',
	unfreezed = ' unfreezed ',
	slayed = ' slayed ',
	spawned = ' spawned ',
	maxed_health = ' regained health of ',
	admin_arrested = ' arrested ',
	admin_unarrested = ' unarrested ',
	banned = ' banned ',
	unbanned = ' unbanned ',
	ban_reason = ' for %s min. ("%s")',
	changejob = ' changed job of player ',

	demote_vote = "%s wants to demote %s",
	players_voted_against_demote = "Players voted against demoting %s",

	jail = ' jailed for %s player ',

	-- premium
	is_premium = '%s became premium ',
	forever = 'forever',
	for_days = 'for %s days',
	not_premium = '%s is not premium anymore.',

	-- microwave
	food_price1 = 'Food price: ',
	food_price2 = 'You changed food price to: %s',
	food_bought = 'You bought food for %s',
	microwave = 'Microwave',
	got_money_food = "You've got money for selling food!",
	should_look = 'You should look at the microwave!',
	-- lohpick
	lockpick = 'Lockpick',
	lockpick_purpose = 'Press LMB and wait 15 seconds',
	-- stunbaton
	stunbaton = 'Stun Baton',
	stunbaton_purpose = 'LMB To Stun\nRMB To Damage',
	-- keys
	keys = 'Keys',
	keys_purpose = 'Left click to lock\nRight click to unlock',
	-- arrest_stick
	arrest_stick = 'Arrest Stick',
	arrest_stick_purpose = 'LMB to arrest',
	unarrest_stick = 'Unarrest Stick',
	unarrest_stick_purpose = 'LMB to unarrest',
	-- weaponchecker
	player_weps = 'Weapons of player ',
	no_illegal_weps = 'No illegal weapons.',
	weaponchecker = 'Weapon Checker',
	weaponchecker_purpose = 'Press LMB to search a player',

	-- wanted
	police = '[Police] ',
	wanted = '%s wanted %s for: ',
	not_wanted = '%s is no longer wanted.',
	no_reason = 'No reason',

	-- mayor
	president = 'Президент',
	killing_mayor = 'Убийство Мэра',

	-- lockdown
	lockdown = 'Lockdown! You must go home!',
	lockdown_start = 'The lockdown has started! Everyone must go home!',
	lockdown_end = 'The lockdown has ended.',
	
	vote_in_progress = 'Vote already in progress',

	-- inventory
	inventory = "Inventory",
	you_cant_pickup = "You can't pick up that",
	inventory_full = 'Your inventory is full',
	inventory_no_items = "You don't have anything in inventory",
	drop = "Drop",
	use = "Use",

	-- rpnames
	name_invalid_length = 'Invalid name length',
	name_invalid_symbol = 'Invalid symbols in name',
	rpname = 'RP Name',

	demote_tag = '[Demote] ',
	demote = '%s demoted %s: "%s".',
	demote_player = "Demote a player",
	reason = "Reason",
	player = "Player",

	whisper = '[Whisper] ',
	yell = '[Yell] ',

	-- police_demote
	job = 'Job',
	police_demote = 'DEMOTE',
	police_demote_officer = 'Demote police officer',
	police_choose_player = 'You have to choose someone!',
	police_demote_reason = 'Using demote entity',
	police_demote_cooldown = 'You have to wait before demoting another person!',

	-- ministuff
	roll = ' got: %s.',
}