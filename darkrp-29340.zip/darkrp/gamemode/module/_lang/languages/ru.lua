return {
	no_desc = "Описание отсутствует..",
	wrong_argument = "Неправильный аргумент (%s)",
	cant_become = "Вы не можете стать %s.",
	you_already = "Вы уже %s",
	limit_reached = 'Вы превысили лимит "%s"',
	wait_for = "Подождите %s сек.",
	change_job = "Сменить работу",
	unlock_for = "Разблокировать за %s",
	disabled = "Эта функция отключена",
	
	blocking_player = "Вы блокируете игрока",
	object_frozen = "Ваш объект был заморожен!",
	object_blocked = "Этот объект заблокирован!",
	prop_too_large = "Вы пытаетесь создать слишком большой объект!",
	spawning_objects_too_fast = "Вы создаете объекты слишком быстро!",
	tool_blocked = "Этот инструмен заблокирован",

	menu = "LampServ F4 Menu v3",
	commands = "КОММАНДЫ",
	jobs = "РАБОТЫ",
	entities = "ОБЪЕКТЫ",
	ammo = "АММУНИЦИЯ",
	buy = "КУПИТЬ",

	cant_buy = "Вы не можете купить %s",
	cant_afford = "Вы не можете себе это позволить",
	not_enough = "Вам не хватает",
	bought = "Вы купили %s",
	picked_up = "Вы подобрали %s",
	dropped = "Вы уронили %s",
	must_be_looking_player = 'Вы должны смотреть на игрока',
	have_given = "Вы дали %s игроку %s",
	were_given = "Игрок %s дал Вам %s",
	give = "Дать денег игроку, на которого Вы смотрите",
	dropmoney = "Выкинуть деньги перед собой",
	amount = 'Количество',
	provide = 'Введите',

	cant_drop = "Нельзя выкинуть этот предмет",
	dropweapon = "Выкинуть предмет из рук",
	distance_too_big = "Вы слишком далеко",

	unable = "Нельзя %s",
	not_allowed = "Вам нельзя это делать",

	splitshipment = "Поделить коробку, на которую Вы смотрите, пополам",
	makeshipment = "Сделать коробку из оружия",
	shipment_cannot_split = "Нельзя поделить эту коробку",
	split_shipment = "Поделить коробку",
	door_can_buy = "Возьми ключи и нажми R для покупки",
	door_sell = "Возьми ключи и нажми R для продажи",
	door_bought = "Вы купили эту дверь за %s",
	door_sold = "Вы продали эту дверь за %s",
	shipments = "Грузы",
	doors = "Двери",
	
	yes = "Да",
	no = "Нет",

	wants_to_become = "%s хочет стать \"%s\"",
	players_voted_against = "Игроки проголосовали против того, чтобы Вы стали \"%s\"",
	
	youve_been_paid = "Вам заплатили %s",

	became = "%s стал \"%s\"",
	became_was = "%s стал \"%s\" (был \"%s\")",

	arrested = "%s арестовал %s",
	unarrested = "%s был выпущен из тюрьмы",

	players_can_hear = "Игроки, которые вас слышат",
	noone_can_hear = "Вас никто не слышит",

	-- admin
	kicked = ' кикнул ',
	chat_muted = ' замутил чат игроку ',
	chat_unmuted = ' размутил чат игрока ',
	voice_muted = ' замутил голос игроку ',
	voice_unmuted = ' размутил голос игрока ',
	returned = ' вернул ',
	min = ' (%s мин.)',
	freezed = ' заморозил ',
	unfreezed = ' разморозил ',
	slayed = ' убил ',
	spawned = ' заспавнил ',
	maxed_health = ' восстановил здоровье ',
	admin_arrested = ' арестовал ',
	admin_unarrested = ' выпустил с тюрьмы ',
	banned = ' забанил ',
	unbanned = ' разбанил ',
	ban_reason = ' на %s мин. ("%s")',
	changejob = ' сменил работу ',

	demote_vote = "%s хочет уволить %s",
	players_voted_against_demote = "Игроки проголосовали против увольнения %s",

	jail = ' посадил в джаил на %s игрока ',

	-- premium
	is_premium = '%s получил премиум ',
	forever = 'навсегда',
	for_days = 'на %s дн.',
	not_premium = '%s больше не премиум.',

	-- microwave
	food_price = 'Цена еды: ',
	food_price2 = 'Вы поменяли цену еды на: %s',
	food_bought = 'Вы купили еду за %s',
	microwave = 'Микроволновка',
	got_money_food = 'Вы получили деньги за продажу еды!',
	should_look = 'Вы должны смотреть на микроволновку!',
	-- lohpick
	lockpick = 'Отмычка',
	lockpick_purpose = 'Нажми ЛКМ и жди 15 секунд',
	-- stunbaton
	stunbaton = 'Станстик',
	stunbaton_purpose = 'ЛКМ чтобы оглушить\nПКМ чтобы нанести урон',
	-- keys
	keys = 'Ключи',
	keys_purpose = 'ЛКМ чтобы закрыть\nПКМ чтобы открыть',
	-- arrest_stick
	arrest_stick = 'Палка ареста',
	arrest_stick_purpose = 'ЛКМ чтоб арестовать',
	unarrest_stick = 'Палка разареста',
	unarrest_stick_purpose = 'ЛКМ чтоб разарестовать',
	-- weaponchecker
	player_weps = 'Оружия игрока ',
	no_illegal_weps = 'Нет нелегальных оружий.',
	weaponchecker = 'Обыск',
	weaponchecker_purpose = 'Нажми ЛКМ чтобы обыскать игрока',

	-- wanted
	police = '[Полиция] ',
	wanted = '%s объявил в розыск %s за: ',
	not_wanted = '%s больше не в розыске.',
	no_reason = 'Нет причины',

	-- mayor
	president = 'Президент',
	killing_mayor = 'Убийство мэра',

	-- lockdown
	lockdown = 'Комендантский час! Вы должны идти домой!',
	lockdown_start = 'Начался комендантский час! Всем разойтись по домам!',
	lockdown_end = 'Комендантский час окончен.',

	vote_in_progress = 'Уже идёт другое голосование',
	
	-- инвентарь
	inventory = "Инвентарь",
	you_cant_pickup = 'Вы не можете это взять',
	inventory_full = 'Ваш инвентарь заполнен',
	inventory_no_items = "В вашем инвентаре ничего нет",
	drop = "Выкинуть",
	use = "Использовать",

	-- rpnames
	name_invalid_length = 'Недопустимая длина имени',
	name_invalid_symbol = 'Запрещённые символы в имени',
	rpname = 'RP Имя',

	demote_tag = '[Увольнение] ',
	demote = '%s уволил %s: "%s".',
	demote_player = "Уволить игрока",
	reason = "Причина",
	player = "Игрок",
	
	whisper = '[Шёпот] ',
	yell = '[Крик] ',

	-- police_demote
	job = 'Профессия',
	police_demote = 'УВОЛИТЬ',
	police_demote_officer = 'Уволить полицейского',
	police_choose_player = 'Вы должны выбрать кого-нибудь!',
	police_demote_reason = 'Используя энтити-увольнялку',
	police_demote_cooldown = 'Вы должны подождать перед увольнением другого человека!',

	-- ministuff
	roll = ' получил число: %s.',
}