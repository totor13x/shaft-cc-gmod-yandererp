local location = GM.ModuleFolder .. '_lang/languages/'
local lang_files = file.Find(location .. '*', 'LUA')

for _, f in ipairs(lang_files) do
    AddCSLuaFile(location .. f)
end