local lang = {}
local my_lang = GM.Settings.force_language or GetConVar('gmod_language'):GetString()
local lang_files = file.Find(GM.ModuleFolder .. '_lang/languages/*', 'LUA')

if file.Exists(GM.ModuleFolder .. '_lang/languages/default.lua', 'LUA') then
	lang = include(GM.ModuleFolder .. '_lang/languages/default.lua')
end

for _, f in ipairs(lang_files) do
	if f == my_lang .. '.lua' then
		table.Merge(lang, include(GM.ModuleFolder .. '_lang/languages/' .. f) or {})
	end
end

function L(str, ...)
	local text = lang[str] or str

	if ... then
		--pcall(function()
			text = string.format(text, ...)
		--end)
	end

	return text
end