local function hidetick(ply, t)
	ply:SetNoDraw(t)
	ply:SetSolid(t and 0 or 2)
	local wep = ply:GetActiveWeapon()
	if not IsValid(wep) then return end
	wep:SetNoDraw(t)
	if wep:GetClass() == "weapon_physgun" then
        for a,b in pairs(ents.FindByClass("physgun_beam")) do
            if b:GetParent() == ply then
                b:SetNoDraw(t)
            end
        end
    end
end

GM:AddCommand('hide_me', function(ply)
	if ply:GetUserAccess() >= 1 then
		local t = not ply:GetNWBool('ls_hidden')
		ply:SetNWBool('ls_hidden', t)
		hidetick(ply, t)
	end
end)
timer.Create('hide_me_tick', 1, 0, function()
	for k, v in ipairs(player.GetAll()) do
		local t = v:GetNWBool('ls_hidden')
		if t then hidetick(v, t) end
	end
end)

hook.Add('PlayerFootstep', 'ls_hidden', function(ply)
	if ply:GetNWBool('ls_hidden') then return true end
end)