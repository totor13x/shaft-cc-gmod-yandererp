local jail = {
	{Vector(0, 0, -2), Angle(90, 0, 0)},
	{Vector(51, 0, 50), Angle(0, 180, 0)},
	{Vector(-51, 0, 50), Angle(0, 180, 0)},
	{Vector(0, 0, 100), Angle(-90, 180, 180)},
	{Vector(-21, 30, 50), Angle(0, 90, 0)},
	{Vector(21, 30, 50), Angle(0, 90, 0)},
	{Vector(-21, -30, 50), Angle(0, 90, 0)},
	{Vector(21, -30, 50), Angle(0, 90, 0)}
}

GM:AddCommand('jail', function(admin, args, argstr)
	local ply = GAMEMODE.FindEntity(args[1])
	if not ply or not IsValid(ply) or not ply:IsPlayer() then
		GAMEMODE:Error(ply, L('wrong_argument', args[1]))
		return
	end
	
	local time = tonumber(args[2])
	if not time or not isnumber(time) then
		GAMEMODE:Error(ply, L('wrong_argument', args[2]))
		return	
	end
	
	time = math.Clamp(time * 60, 1, 1800)
	
	if ply.jail then
		for i = 1, #ply.jail do
		  if not IsValid(ply.jail[i]) then continue end
		  ply.jail[i]:Remove()
		end
	end
	
	ply.jail = {}
	
	for i = 1, #jail do
		ply.jail[i] = ents.Create('prop_dynamic')
		ply.jail[i]:SetModel('models/props_building_details/Storefront_Template001a_Bars.mdl')
		ply.jail[i]:SetPos(jail[i][1] + ply:GetPos())
		ply.jail[i]:SetAngles(jail[i][2])
		ply.jail[i]:PhysicsInit(SOLID_VPHYSICS)
		ply.jail[i]:Spawn()
	end
	
	timer.Create(ply:SteamID() .. 'jail', time, 1, function()
		if IsValid(ply) and ply.jail then
		  for i = 1, #ply.jail do
			if not IsValid(ply.jail[i]) then continue end
				
			ply.jail[i]:Remove()
		  end
		  ply.jail = nil
		end
	end)

	GAMEMODE:ChatPrint(Color(255, 64, 64), '[Admin] ', admin, L('jail', GAMEMODE.secondsToClock(time)), ply)
end, GM.UserGroups.isAdmin)

GM:AddCommand('unjail', function(admin, args, argstr)
	local ply = GAMEMODE.FindEntity(args[1])
	if not ply or not IsValid(ply) or not ply:IsPlayer() then
		GAMEMODE:Error(ply, L('wrong_argument', args[1]))
		return
	end

	if IsValid(ply) and ply.jail then
		for i = 1, #ply.jail do

		if not IsValid(ply.jail[i]) then 
			continue 
		end
			
			ply.jail[i]:Remove()
		end
		ply.jail = nil
	end
end, GM.UserGroups.isAdmin)

local jailcant = function(ply)
	if ply.jail then return false end
end

hook.Add("PlayerUse", "some_unique_name2", jailcant)
hook.Add('PlayerSpawnObject', 'BanSpawn', jailcant)

timer.Create('jail_check', 1, 0, function()
	for _, p in pairs(player.GetAll()) do
		if p.jail and IsValid(p.jail[1]) and p:GetPos():Distance(p.jail[1]:GetPos()) > 100 then
			p:SetPos(p.jail[1]:GetPos() + Vector(0, 0, 2))
		end
	end
end)

hook.Add('PlayerDisconnected', 'remove_jail', function(ply)
	if ply.jail then
		for i = 1, #ply.jail do
			if not IsValid(ply.jail[i]) then continue end
			ply.jail[i]:Remove()
		end
		ply.jail = nil
	end
end)