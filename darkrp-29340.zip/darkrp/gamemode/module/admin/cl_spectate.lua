local tag = 'Spectate'
local font = tag .. 'Font'
surface.CreateFont(tag .. 'Font', {
	size = 16,
	weight = 800,
	antialias = true,
	shadow = false,
	font = "Verdana"}
)

local fore, back = Color(240, 240, 255, 255), Color(20, 20, 20, 120)
local half = math.floor(ScrH() / 2)
local roampos = Vector(0)
local tracetable = {}
local filter = game.GetWorld()
local target, startspectate, endspectate

local function hudpaint()
	local me = LocalPlayer()

	draw.WordBox(2, 10, half, "Left click: (Un)select player to spectate", font, back, fore)
	draw.WordBox(2, 10, half + 20, "Right click: quickly move forwards", font, back, fore)
	draw.WordBox(2, 10, half + 40, "Jump: Stop spectating", font, back, fore)
	draw.WordBox(2, 10, half + 60, "Reload: Stop spectating and teleport", font, back, fore)
	
	for k, ply in ipairs(player.GetAll()) do
		if ply:GetUserAccess() >= 3 then
			continue
		end

		local pos = ply:GetShootPos():ToScreen()
		if not pos.visible then continue end
		
		local x, y = pos.x, pos.y

		draw.RoundedBox(2, x, y - 6, 12, 12, team.GetColor(ply:Team()))
		draw.WordBox(2, x, y - 66, ply:Nick(), font, back, fore)
		draw.WordBox(2, x, y - 46, "Health: " .. ply:Health(), font, back, fore)
		draw.WordBox(2, x, y - 26, ply:GetUserGroup(), font, back, fore)
	end

	if isvector(roampos) then
		util.TraceHull({start = roampos, endpos = roampos + me:GetAimVector() * 1000, ignoreworld = true, filter = filter, output = tracetable})
		target = tracetable.Entity
		if IsValid(target) then
			local center = target:LocalToWorld(target:OBBCenter())
			local eyeAng = EyeAngles()
			local rightUp = eyeAng:Right() * 16 + eyeAng:Up() * 36
			local topRight = (center + rightUp):ToScreen()
			local bottomLeft = (center - rightUp):ToScreen()
		
			draw.RoundedBox(12, bottomLeft.x, bottomLeft.y, math.max(20, topRight.x - bottomLeft.x), topRight.y - bottomLeft.y, Color(255, 0, 0))
			draw.WordBox(2, bottomLeft.x, bottomLeft.y + 12, "Left click to spectate!", font, back, fore)	
		end
	end
end

local calcviewtable = {}
local corigin
local function calcview(me, origin, angles)
	if not isvector(roampos) then
		local pos = roampos:IsPlayer() and roampos:GetShootPos() or roampos:LocalToWorld(roampos:OBBCenter())
		local endpos = pos - me:GetAimVector() * 100
		util.TraceHull({
			start = pos, 
			endpos = endpos,
			filter = roampos,
			output = calcviewtable
		})
		corigin = calcviewtable.HitPos + calcviewtable.HitNormal * 10
	end
	
	return {origin = isvector(roampos) and roampos or corigin, angles = angles, drawviewer = true}
end

local function playerbindpress(me, bind, p)
	if bind == '+attack' and p and IsValid(target) then
		roampos = isvector(roampos) and target or corigin
	end
	if bind == '+attack2' and p and isvector(roampos) then
		roampos = roampos + me:GetAimVector() * 500
	end
	if bind == '+reload' and p then
		net.Start(tag)
		net.WriteInt(2, 4)
		net.WriteVector(isvector(roampos) and roampos or corigin)
		net.SendToServer()
	end
	if bind == '+jump' and p then
		endspectate()
	end
	
	return true
end

local delay = 0
local function think()
	local me = LocalPlayer()

	if CurTime() - delay > 1 then
		net.Start(tag)
		net.WriteInt(1, 4)
		net.WriteVector(isvector(roampos) and roampos or roampos:GetPos())
		net.SendToServer()
		
		delay = CurTime()
	end
	
	if isvector(roampos) then
		local multiplier = 10 * (FrameTime() * 100)
		
		if input.IsKeyDown(KEY_LSHIFT) then
			multiplier = 25 * (FrameTime() * 100)
		end
		if input.IsKeyDown(KEY_W) then
			roampos = roampos + me:GetAimVector() * multiplier
		end
		if input.IsKeyDown(KEY_S) then
			roampos = roampos + me:GetAimVector() * -multiplier
		end
		if input.IsKeyDown(KEY_A) then
			roampos = roampos - me:GetAimVector():Angle():Right() * multiplier
		end
		if input.IsKeyDown(KEY_D) then
			roampos = roampos + me:GetAimVector():Angle():Right() * multiplier
		end
	end

end

startspectate = function(target_n)
	roampos = IsEntity(target_n) and target_n:EyePos() or target_n
	filter = game.GetWorld()
	
	hook.Add('Think', tag, think)
	hook.Add('PlayerBindPress', tag, playerbindpress)
	hook.Add('CalcView', tag, calcview)
	hook.Add('HUDPaint', tag, hudpaint)
	
	net.Start(tag)
	net.WriteInt(1, 4)
	net.WriteVector(isvector(roampos) and roampos or roampos:GetPos())
	net.SendToServer()
end


endspectate = function()
	hook.Remove('Think', tag)
	hook.Remove('PlayerBindPress', tag)
	hook.Remove('CalcView', tag)
	hook.Remove('HUDPaint', tag)
	
	net.Start(tag)
	net.WriteInt(3, 4)
	net.SendToServer()
end

net.Receive(tag, function()
	if net.ReadBool() then
		startspectate(net.ReadVector())	
	else
		endspectate()	
	end
end)
