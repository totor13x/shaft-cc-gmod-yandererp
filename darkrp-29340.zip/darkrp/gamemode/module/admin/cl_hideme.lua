timer.Create('hide_me_tick', 2, 0, function()
	for k, v in ipairs(player.GetAll()) do
		local t = v:GetNWBool('ls_hidden')
		local wep = v:GetActiveWeapon()
		if t then 
			v.RenderOverride = function() return false end
			if IsValid(wep) then wep.RenderOverride = function() return false end end
		else
			v.RenderOverride = nil
			wep.RenderOverride = nil
		end
	end
end)

hook.Add('PlayerFootstep', 'ls_hidden', function(ply)
	if ply:GetNWBool('ls_hidden') then return true end
end)
