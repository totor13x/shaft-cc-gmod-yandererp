GM.UserGroups = {}
GM.UserGroups.hierarchy = {
	['superadmin'] = 3,
	['admin'] = 2,
	['@admin'] = 1,
	['#admin'] = 1,
	['user'] = 0,
}

GM.UserGroups.functions = {
	{
		name = 'SteamID',
		cmd = 'steamid',
		access = 0,
		args = {
			{'player', 'Player'},
		}
	},
	{
		name = 'Spectate',
		cmd = 'spectate',
		access = 1,
		args = {
			{'player', 'Player'}
		}
	},
	{
		name = 'Kick',
		cmd = 'kick',
		access = 1,
		args = {
			{'player', 'Player'},
			{'string', 'Reason'},
		}
	},
	{
		name = 'Jail',
		cmd = 'jail',
		access = 1,
		args = {
			{'player', 'Player'},
			{'minutes', 'Jail Length'},
		}
	},
	{
		name = 'UnJail',
		cmd = 'unjail',
		access = 1,
		args = {
			{'player', 'Player'},
		}
	},
	{
		name = 'MaxHealth',
		cmd = 'maxhealth',
		access = 1,
		args = {
			{'player', 'Player'},
		}
	},
	{
		name = 'Go to',
		cmd = 'goto',
		access = 1,
		args = {
			{'player', 'Player'},
		}
	},
	{
		name = 'Teleport here',
		cmd = 'tp',
		access = 1,
		args = {
			{'player', 'Player'},
		}
	},
	{
		name = 'Teleport to roof',
		cmd = 'tproof',
		access = 1,
		args = {
			{'player', 'Player'},
		}
	},
	{
		name = 'Slay',
		cmd = 'slay',
		access = 1,
		args = {
			{'player', 'Player'},
		}
	},
	{
		name = 'Spawn',
		cmd = 'spawn',
		access = 1,
		args = {
			{'player', 'Player'},
		}
	},
	{
		name = 'Freeze',
		cmd = 'freeze',
		access = 1,
		args = {
			{'player', 'Player'},
		}
	},
	{
		name = 'UnFreeze',
		cmd = 'unfreeze',
		access = 1,
		args = {
			{'player', 'Player'},
		}
	},
	{
		name = 'Chat mute',
		cmd = 'chatmute',
		access = 1,
		args = {
			{'player', 'Player'},
			{'minutes', 'Mute Length'},
		}
	},
	{
		name = 'Chat unmute',
		cmd = 'chatunmute',
		access = 1,
		args = {
			{'player', 'Player'},
		}
	},
	{
		name = 'Voice mute',
		cmd = 'voicemute',
		access = 1,
		args = {
			{'player', 'Player'},
			{'minutes', 'Mute Length'},
		}
	},
	{
		name = 'Voice unmute',
		cmd = 'voiceunmute',
		access = 1,
		args = {
			{'player', 'Player'},
		}
	},
	{
		name = 'Ban',
		cmd = 'ban',
		access = 1,
		args = {
			{'player', 'Player'},
			{'minutes', 'Ban Length'},
			{'string', 'Reason'},
		}
	},
	{
		name = 'Unban',
		cmd = 'unban',
		access = 1,
		args = {
			{'string', 'SteamID'},
		}
	},
	{
		name = 'Change Job',
		cmd = 'changejob',
		access = 1,
		args = {
			{'player', 'Player'},
			{'string', 'Job Name'},
		}
	},
	{
		name = 'Return',
		cmd = 'return',
		access = 1,
		args = {
			{'player', 'Player'},
		}
	},
	{
		name = 'Arrest',
		cmd = 'arrest',
		access = 1,
		args = {
			{'player', 'Player'},
		}
	},
	{
		name = 'UnArrest',
		cmd = 'unarrest',
		access = 1,
		args = {
			{'player', 'Player'},
		}
	},
}

local meta = FindMetaTable('Player')
function meta:GetUserAccess()
	return GAMEMODE.UserGroups.hierarchy[self:GetUserGroup()] or 0
end

function meta:IsAdmin()
	local p = GAMEMODE.UserGroups.hierarchy[self:GetUserGroup()]
	return p and p ~= 0 and true or false
end

hook.Add('PlayerNoClip', 'admin', function(ply)
	if ply:GetUserAccess() >= 1 then
		return true
	end
end)