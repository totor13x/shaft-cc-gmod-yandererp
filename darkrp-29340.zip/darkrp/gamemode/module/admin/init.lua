if not sql.TableExists('usergroups') then
	sql.Query('CREATE TABLE usergroups (steam string, grp string)')
end

local meta = FindMetaTable("Player")

CheckLimit = CheckLimit or meta.CheckLimit

function meta:CheckLimit(...)
	if self:IsSuperAdmin() then
		return true
	end
	return CheckLimit(self, ...)
end

function meta:SetUserGroup(group)
	GAMEMODE.SetUserGroup(self:SteamID(), group, self:GetName())
	self:SetNWString("UserGroup", group)
end

GM.SetUserGroup = function(steamid, group, player_name)
	local current_group = sql.QueryValue('SELECT grp FROM usergroups WHERE steam = ' .. SQLStr(steamid))

	if not group or group == 'user' or group == '' then
		sql.Query('DELETE FROM usergroups WHERE steam = ' .. SQLStr(steamid))
		group = 'user'

		if current_group then
			GAMEMODE:ChatPrint(L('became_was', player_name or steamid, group, current_group))
		end
	elseif current_group then
		sql.Query('UPDATE usergroups SET grp = ' .. SQLStr(group) .. ' WHERE steam = ' .. SQLStr(steamid))
		GAMEMODE:ChatPrint(L('became_was', player_name or steamid, group, current_group))
	else
		sql.Query('INSERT INTO usergroups (steam, grp) VALUES (' .. SQLStr(steamid) .. ', ' .. SQLStr(group) .. ')')
		GAMEMODE:ChatPrint(L('became', player_name or steamid, group))
	end
end

GM.GetUserGroup = function(steamid)
	local group = sql.QueryValue('SELECT grp FROM usergroups WHERE steam = ' .. SQLStr(steamid))
	return group or 'user'
end

hook.Add("PlayerInitialSpawn", "PlayerAuthSpawn", function(ply)
	ply:SetNWString("UserGroup", GAMEMODE.GetUserGroup(ply:SteamID()))
end)

hook.Add('OnPhysgunPickup', 'PhysgunFix', function(ply, ent)
	if ent:IsPlayer() then
		ent:Lock()
		ent:SetMoveType(MOVETYPE_FLY)
	end
end)

hook.Add('PhysgunDrop', 'PhysgunFix', function(ply, ent)
	if ent:IsPlayer() then
		ent:SetMoveType(MOVETYPE_WALK)
	end
end)

--

GM.UserGroups.isAdmin = function(cmd, ply)
	for k, v in pairs(GAMEMODE.UserGroups.functions) do
		if v.cmd == cmd then
			return ply:GetUserAccess() >= v.access
		end
	end
end

GM:AddCommand('steamid', function(ply, args, argstr)
	local target = GAMEMODE.FindEntity(args[1])

	if not IsValid(target) then 
		GAMEMODE:Error(ply, L('wrong_argument', args[1]))
		return 
	end

	GAMEMODE:ChatPrintTo(ply, 'SteamID ' .. target:GetName() .. ' скопирован в буфер обмена ( ' .. target:SteamID() .. ' )')
		ply:SendLua('SetClipboardText("' .. target:SteamID() .. '")')
end, GM.UserGroups.isAdmin)

GM:AddCommand('kick', function(ply, args, argstr)
	local target = GAMEMODE.FindEntity(args[1])

	if not IsValid(target) then 
		GAMEMODE:Error(ply, L('wrong_argument', args[1]))
		return 
	end

	local reason = args[2] or 'No reason'

	target:Kick(reason)

	GAMEMODE:ChatPrint(Color(255, 64, 64), '[Admin] ', ply, L'kicked', target, ' ("' .. reason .. '")')
end, GM.UserGroups.isAdmin)

GM:AddCommand('goto', function(ply, args, argstr)
	local target = GAMEMODE.FindEntity(args[1])

	if not IsValid(target) then 
		GAMEMODE:Error(ply, L('wrong_argument', args[1]))
		return 
	end

	if ply:GetUserAccess() < target:GetUserAccess() then
		GAMEMODE:Error(ply, L'not_allowed')
		return
	end

	ply.last_teleported_from = ply:GetPos()
	
	if not ply:Alive() then ply:Spawn() end
	ply:SetPos(target:GetPos())

	if not ply:GetNWBool('ls_hidden') then
		ply:EmitSound('garrysmod/balloon_pop_cute.wav')
	end
end, GM.UserGroups.isAdmin)

GM:AddCommand('tp', function(ply, args, argstr)
	local target = GAMEMODE.FindEntity(args[1])

	if not IsValid(target) then 
		GAMEMODE:Error(ply, L('wrong_argument', args[1]))
		return 
	end

	if ply:GetUserAccess() < target:GetUserAccess() then
		GAMEMODE:Error(ply, L'not_allowed')
		return
	end

	if target:InVehicle() then
		target:ExitVehicle()
	end

	target.last_teleported_from = target:GetPos()

	if not target:Alive() then target:Spawn() end
	local tr = ply:GetEyeTrace()
	target:SetPos(tr.HitPos + tr.HitNormal * 25)

	if not target:GetNWBool('ls_hidden') then
		target:EmitSound('garrysmod/balloon_pop_cute.wav')
	end
end, GM.UserGroups.isAdmin)

GM:AddCommand('tproof', function(ply, args, argstr)
	local target = GAMEMODE.FindEntity(args[1])

	if not IsValid(target) then 
		GAMEMODE:Error(ply, L('wrong_argument', args[1]))
		return 
	end

	if target:InVehicle() then
		target:ExitVehicle()
	end

	target.last_teleported_from = target:GetPos()
	ply.last_teleported_from = ply:GetPos()

	local pos = GAMEMODE.Settings.roof_positions[math.random(#GAMEMODE.Settings.roof_positions)]
	target:SetPos(pos + Vector(20, 20, 0))
	ply:SetPos(pos - Vector(20, 20, 0))
	
	target:EmitSound('garrysmod/balloon_pop_cute.wav')
end, GM.UserGroups.isAdmin)

GM:AddCommand('slay', function(ply, args, argstr)
	local target = GAMEMODE.FindEntity(args[1])

	if not IsValid(target) then 
		GAMEMODE:Error(ply, L('wrong_argument', args[1]))
		return 
	end

	GAMEMODE:ChatPrint(Color(255, 64, 64), '[Admin] ', ply, L'slayed', target)

	target:Kill()
end, GM.UserGroups.isAdmin)

GM:AddCommand('spawn', function(ply, args, argstr)
	local target = GAMEMODE.FindEntity(args[1])

	if not IsValid(target) then 
		GAMEMODE:Error(ply, L('wrong_argument', args[1]))
		return 
	end

	GAMEMODE:ChatPrint(Color(255, 64, 64), '[Admin] ', ply, L'spawned', target)

	target:Spawn()
end, GM.UserGroups.isAdmin)

include(GM.ModuleFolder .. 'admin/ban.lua')

GM:AddCommand('ban', function(ply, args, argstr)
	local target = GAMEMODE.FindEntity(args[1])
	local steamid
	if IsValid(target) then
		steamid = target:SteamID()
	else
		steamid = args[1]
	end

	local time = tonumber(args[2])
	if not time then
		GAMEMODE:Error(ply, L('wrong_argument', args[2]))
		return 
	end

	time = math.Clamp(time, 0, 525600)

	GAMEMODE:Ban(steamid, time, args[3], ply)
end, GM.UserGroups.isAdmin)

GM:AddCommand('unban', function(ply, args, argstr)
	local steamid = args[1]
	if not steamid or util.SteamIDTo64(steamid) == 0 then
		GAMEMODE:Error(ply, L('wrong_argument', steamid or 'steamid'))
		return 
	end

	GAMEMODE:Unban(steamid, ply)
end, GM.UserGroups.isAdmin)

include(GM.ModuleFolder .. 'admin/mute.lua')

GM:AddCommand('chatmute', function(ply, args, argstr)
	local target = GAMEMODE.FindEntity(args[1])

	if not IsValid(target) then 
		GAMEMODE:Error(ply, L('wrong_argument', args[1]))
		return 
	end

	local time = tonumber(args[2])
	if not time then
		GAMEMODE:Error(ply, L('wrong_argument', args[2]))
		return 
	end

	time = math.Clamp(time, 0, 1440)

	target:ChatMute(time)

	GAMEMODE:ChatPrint(Color(255, 64, 64), '[Admin] ', ply, L'chat_muted', target, L('min', time))
end, GM.UserGroups.isAdmin)

GM:AddCommand('chatunmute', function(ply, args, argstr)
	local target = GAMEMODE.FindEntity(args[1])

	if not IsValid(target) then 
		GAMEMODE:Error(ply, L('wrong_argument', args[1]))
		return 
	end

	target:ChatUnMute()

	GAMEMODE:ChatPrint(Color(255, 64, 64), '[Admin] ', ply, L'chat_unmuted', target)
end, GM.UserGroups.isAdmin)

GM:AddCommand('voicemute', function(ply, args, argstr)
	local target = GAMEMODE.FindEntity(args[1])

	if not IsValid(target) then 
		GAMEMODE:Error(ply, L('wrong_argument', args[1]))
		return 
	end

	local time = tonumber(args[2])
	if not time then
		GAMEMODE:Error(ply, L('wrong_argument', args[2]))
		return 
	end

	time = math.Clamp(time, 0, 1440)

	target:VoiceMute(time)

	GAMEMODE:ChatPrint(Color(255, 64, 64), '[Admin] ', ply, L'voice_muted', target, L('min', time))
end, GM.UserGroups.isAdmin)

GM:AddCommand('voiceunmute', function(ply, args, argstr)
	local target = GAMEMODE.FindEntity(args[1])

	if not IsValid(target) then 
		GAMEMODE:Error(ply, L('wrong_argument', args[1]))
		return 
	end

	target:VoiceUnMute()

	GAMEMODE:ChatPrint(Color(255, 64, 64), '[Admin] ', ply, L'voice_unmuted', target)
end, GM.UserGroups.isAdmin)

GM:AddCommand('changejob', function(ply, args, argstr)
	local target = GAMEMODE.FindEntity(args[1])

	if not IsValid(target) then 
		GAMEMODE:Error(ply, L('wrong_argument', args[1]))
		return 
	end

	local tm = GAMEMODE.teamByName(args[2])
	if not tm then 
		GAMEMODE:Error(ply, L('wrong_argument', args[2]))
		return 
	end

	target:ChangeTeam(tm, true)

	GAMEMODE:ChatPrint(Color(255, 64, 64), '[Admin] ', ply, L'changejob', target)
end, GM.UserGroups.isAdmin)

GM:AddCommand('return', function(ply, args, argstr)
	local target = GAMEMODE.FindEntity(args[1])

	if not IsValid(target) then 
		GAMEMODE:Error(ply, L('wrong_argument', args[1]))
		return 
	end

	if not target.last_teleported_from then 
		return 
	end

	target:SetPos(target.last_teleported_from)

	GAMEMODE:ChatPrint(Color(255, 64, 64), '[Admin] ', ply, L'returned', target)
end, GM.UserGroups.isAdmin)

GM:AddCommand('arrest', function(ply, args, argstr)
	local target = GAMEMODE.FindEntity(args[1])

	if not IsValid(target) then 
		GAMEMODE:Error(ply, L('wrong_argument', args[1]))
		return 
	end

	GAMEMODE:ChatPrint(Color(255, 64, 64), '[Admin] ', ply, L'admin_arrested', target)

	target:Arrest(nil, ply)
end, GM.UserGroups.isAdmin)

GM:AddCommand('unarrest', function(ply, args, argstr)
	local target = GAMEMODE.FindEntity(args[1])

	if not IsValid(target) then 
		GAMEMODE:Error(ply, L('wrong_argument', args[1]))
		return 
	end

	GAMEMODE:ChatPrint(Color(255, 64, 64), '[Admin] ', ply, L'admin_unarrested', target)

	target:UnArrest()
end, GM.UserGroups.isAdmin)

GM:AddCommand('maxhealth', function(ply, args, argstr)
	local target = GAMEMODE.FindEntity(args[1])

	if not IsValid(target) then 
		GAMEMODE:Error(ply, L('wrong_argument', args[1]))
		return 
	end

	GAMEMODE:ChatPrint(Color(255, 64, 64), '[Admin] ', ply, L'maxed_health', target)

	target:SetHealth(target:GetMaxHealth())
end, GM.UserGroups.isAdmin)

GM:AddCommand('freeze', function(ply, args, argstr)
	local target = GAMEMODE.FindEntity(args[1])

	if not IsValid(target) then 
		GAMEMODE:Error(ply, L('wrong_argument', args[1]))
		return 
	end

	target:Lock()

	local ed = EffectData()
	
	ed:SetEntity(target)
	ed:SetOrigin(target:GetShootPos())

	util.Effect('phys_freeze', ed, nil, true)
	util.Effect('entity_remove', ed, nil, true)

	GAMEMODE:ChatPrint(Color(255, 64, 64), '[Admin] ', ply, L'freezed', target)
end, GM.UserGroups.isAdmin)

GM:AddCommand('unfreeze', function(ply, args, argstr)
	local target = GAMEMODE.FindEntity(args[1])

	if not IsValid(target) then 
		GAMEMODE:Error(ply, L('wrong_argument', args[1]))
		return 
	end

	target:UnLock()

	GAMEMODE:ChatPrint(Color(255, 64, 64), '[Admin] ', ply, L'unfreezed', target)
end, GM.UserGroups.isAdmin)

include('sv_hideme.lua')
include('sv_spectate.lua')

include('jail.lua')

AddCSLuaFile('cl_hideme.lua')
AddCSLuaFile('cl_spectate.lua')
