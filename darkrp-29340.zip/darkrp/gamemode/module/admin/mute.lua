local chat_mute, voice_mute = {}, {}

for i = 1, 128 do
	chat_mute[i] = false
	voice_mute[i] = false
end

local meta = FindMetaTable('Player')
local function fast_create(name, table_n)
	local pdata_name = string.lower(name) .. 'mute'
	
	meta[name .. 'MuteTimer'] = function(self, minutes)
		timer.Create(self:SteamID() .. name, minutes, 1, function()
			meta[name .. 'UnMute'](self)
		end)
	end
	
	meta[name .. 'Mute'] = function(self, minutes)
		self:SetPData(pdata_name, os.time() + minutes * 60)
		
		table_n[self:EntIndex()] = true
		meta[name .. 'MuteTimer'](self, minutes * 60)
	end
	
	meta[name .. 'UnMute'] = function(self) 
		self:RemovePData(pdata_name)
		
		table_n[self:EntIndex()] = false
		timer.Remove(self:SteamID() .. name)
	end

	meta['Is' .. name .. 'Muted'] = function(self)
		return table_n[self:EntIndex()] or false
	end
	
	meta[name .. 'MuteTime'] = function(self)
		return self:GetPData(pdata_name, false)
	end
	
	meta[name .. 'MuteInit'] = function(self) 
		local mute_time = meta[name .. 'MuteTime'](self)
		
		if tobool(mute_time) then
			if os.time() - mute_time > 0 then
				meta[name .. 'UnMute'](self)
			else
				table_n[self:EntIndex()] = true
				meta[name .. 'MuteTimer'](self, mute_time - os.time())
			end
		end
	end
end

fast_create('Chat', chat_mute)
fast_create('Voice', voice_mute)

hook.Add('PlayerInitialSpawn', 'Mute', function(ply)
	ply:ChatMuteInit()
	ply:VoiceMuteInit()
end)

hook.Add('PlayerDisconnected', 'Mute', function(ply)
	timer.Remove(ply:SteamID() .. 'Chat')
	timer.Remove(ply:SteamID() .. 'Voice')
end)

hook.Add('PlayerCanSeePlayersChat', 'ChatMute', function(_, _, listener, talker)
	if chat_mute[talker:EntIndex()] then return false end
end)

hook.Add('PlayerCanHearPlayersVoice', 'VoiceMute', function(listener, talker) 
	if voice_mute[talker:EntIndex()] then return false end
end)

