local tag = 'Spectate'
spectating = spectating or {}

local function SpectatePos(ply, target)
	spectating[ply] = target
end

local function EndSpectate(ply, bool)
	if spectating[ply] then
		spectating[ply] = nil
		
		if bool then
			net.Start(tag)
			net.WriteBool(false)
			net.Send(ply)
		end
	end
end

local nets = {
	function(ply) 
		SpectatePos(ply, net.ReadVector())
	end,
	function(ply) 
		ply:SetPos(net.ReadVector())
		EndSpectate(ply, true)
	end,
	function(ply) 
		EndSpectate(ply, false)
	end
}

util.AddNetworkString(tag)
net.Receive(tag, function(l, ply)
	if ply:IsAdmin() then
		local mode = net.ReadInt(4)
		nets[mode](ply)
	end
end)

hook.Add('SetupPlayerVisibility', tag, function()
	for ply, vec in pairs(spectating) do
		if not IsValid(ply) then
			spectating[ply] = nil
			return
		else
			AddOriginToPVS(vec)
		end
	end
end)

local function juchok(listener, speaker)
	if spectating[listener] then
		if spectating[listener]:DistToSqr(speaker:GetPos()) < 255000 then
			return true
		end
	end
end

hook.Add('PlayerCanSeePlayersChat', tag, function(_, _, listener, speaker)
	return juchok(listener, speaker)
end)

GM:AddCommand('spectate', function(ply, args, argstr)
	local target = ply:EyePos()
	if argstr ~= '' then
		target = GAMEMODE.FindEntity(argstr)
		target = target ~= game.GetWorld() and target or ''
	end

	if IsEntity(target) and target:IsPlayer() and target:IsSuperAdmin() then
		return
	end

	net.Start(tag)
	net.WriteBool(true)
	net.WriteVector(isvector(target) and target or target:EyePos())
	net.Send(ply)
	
	//StartSpectate(ply, target, true)
end, GM.UserGroups.isAdmin)

hook.Add('PlayerCanHearPlayersVoice', tag, juchok)
