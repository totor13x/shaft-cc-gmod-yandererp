local ban_msg = [[Вы были забанены на %s мин. 
Забанил: %s 
Причина: %s]]

local ban_connect_msg = [[Вы были забанены до %s МСК 
Забанил: %s 
Причина: %s]]

if not sql.TableExists('rp_bans') then
    sql.Query[[
        CREATE TABLE rp_bans (SteamID string, Time int, Length int, Reason string, WhoBanned string)
    ]]
end

function GM:Ban(steamid, time, reason, who)
    if not time then return end

	reason = reason or 'No Reason'
	time = math.ceil(time)

    local ply = player.GetBySteamID(steamid)
	local name = IsValid(ply) and ply:GetName() or 'Unknown'
	local usergroup = sql.QueryValue('SELECT grp FROM usergroups WHERE steam = ' .. SQLStr(steamid))
	local whostr = who and who:GetName() .. ' (' .. who:SteamID() .. ')' or 'Console'

    if who and usergroup and who:GetUserAccess() <= (self.UserGroups.hierarchy[usergroup] or 0) then
        self:ChatPrint(who:GetName() .. ' tried to ban ' .. steamid .. (ply and ' (' .. ply:GetName() .. ')' or ''))
        return
    end

    sql.Query('DELETE FROM rp_bans WHERE SteamID = "' .. steamid .. '"')

    sql.Query(string.format(
        "INSERT INTO rp_bans(SteamID, Time, Length, Reason, WhoBanned) VALUES ('%s', %s, %s, %s, %s)", 
        steamid, os.time(), time, SQLStr(reason), SQLStr(whostr)
    ))

    if who then
        self:DiscordEmbed({
            title = '**Бан**',
            color = 15158332,
            fields = {
                {name = self.minutesToClock(time), value = GAMEMODE.discordPlayer(steamid, util.SteamIDTo64(steamid)) .. '\n_'  .. reason .. '_'},
            }
        }, 'bans', who)
    end

	GAMEMODE:ChatPrint(Color(255, 64, 64), '[Admin] ', who, L'banned', ply or steamid, L('ban_reason', time, reason))

    if ply then
        ply:Kick(string.format(ban_msg, time, whostr, reason))
    end
end

function GM:Unban(steamid, who, silent)
    local ban = sql.Query('SELECT * FROM rp_bans WHERE SteamID = "' .. steamid .. '"')

    if not ban then return end

	sql.Query('DELETE FROM rp_bans WHERE SteamID = "' .. steamid .. '"')

	local whostr = (who and who:GetName() or 'Console')

	if not silent then
    	GAMEMODE:ChatPrint(Color(255, 64, 64), '[Admin] ', who, L'unbanned', steamid)

    	if who then
		    self:DiscordEmbed({
				title = '**Разбан**',
		        color = 3066993,
    	        fields = {
    	            {value = GAMEMODE.discordPlayer(steamid, util.SteamIDTo64(steamid))},
    	        }
		    }, 'bans', who)
    	end
	end
end

hook.Add('CheckPassword', 'rp_bans', function(steam64)
    local steamid = util.SteamIDFrom64(steam64)

	local query = sql.Query('SELECT Time, Length, Reason, WhoBanned FROM rp_bans WHERE SteamID = "' .. steamid .. '" AND ((Length*60 + Time) > ' .. os.time() .. ' OR Time = 0)')
	local ban = istable(query) and query[1] or nil
	if ban then
        return false, string.format(ban_connect_msg, os.date("%H:%M:%S - %d/%m/%Y", ban.Time + ban.Length*60), ban.WhoBanned, ban.Reason)
    end
end)