GM.CommandsHelp = {}

function GM:DescribeCommand(cmd, name, args, canuse)
	for k, v in ipairs(self.CommandsHelp) do
		if v[1] == cmd then
			return
		end
	end
	
	table.insert(self.CommandsHelp, {cmd, name, args, canuse})
end

function GM:ClientQuickCommand(k)
	local v = GAMEMODE.CommandsHelp[k]

	local args = v[3]
	local i

	local args_query_and_run
	local finalargs
	args_query_and_run = function(s)
		if s then
			table.insert(finalargs, s)
		end

		if not args or not args[i] then
			RunConsoleCommand('rp', v[1], unpack(finalargs))
			return
		end

		Derma_StringRequest(args[i], L'provide' .. ' ' .. args[i], '', args_query_and_run)
		i = i + 1
	end

	i = 1
	finalargs = {}
	args_query_and_run()
end

hook.Add('f4menu_onload', 'commands_tab', function(f4)
	f4:AddTab(L'commands', function(p)
		local count = #GAMEMODE.CommandsHelp
		for k = 1, count do
			local v = GAMEMODE.CommandsHelp[k]
			local b = vgui.Create('DButton', p)
			b:SetSize(p:GetWide(), 40)
			b:SetPos(0, (p:GetTall() - 40 * count) / 2 + 40*(k-1))
			b.Paint = function(self, w, h)
				local canuse = true
				if v[4] then
					canuse = v[4]()
				end

				surface.SetDrawColor(canuse and (self:IsHovered() and Color(68, 76, 88) or Color(58, 66, 78)) or Color(54, 62, 72))
				surface.DrawRect(0, 1, w, h - 2)
				
				draw.SimpleText(v[2], 'nunito20', w/2, h/2, canuse and color_white or Color(180, 180, 180), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				return true
			end

			function b:DoClick()
				GAMEMODE:ClientQuickCommand(k)
			end
		end
	end, 1)
end)
