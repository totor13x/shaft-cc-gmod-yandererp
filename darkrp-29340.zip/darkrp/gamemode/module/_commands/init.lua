GM.Commands = {}
local checks = {}

concommand.Add('rp', function(ply, cmd, args, argstr)
    local rpcmd = args[1]
    if not rpcmd then return end

    rpcmd = rpcmd:lower()

    local rpfunc = GAMEMODE.Commands[rpcmd]

    if rpfunc then
        if checks[rpcmd] then
            if not checks[rpcmd](rpcmd, ply) then return end
        end
    	
    	table.remove(args, 1)
        argstr = table.concat(args, ' ')
        rpfunc(ply, args, argstr)
    else
        GAMEMODE:Error(ply, L('wrong_argument', rpcmd))
    end
end)

function GM:AddCommand(cmd, func, check)
    self.Commands[cmd] = func
    checks[cmd] = check
end

GM.defineChatCommand = function(...)
    GAMEMODE:AddCommand(...)
end

hook.Add('PlayerSay', '_commands', function(ply, t)
    if t[1] == '/' then
        local argstr = t:sub(2)
        local args = string.Split(argstr, ' ')

        local rpcmd = args[1]
        if not rpcmd then return end

        rpcmd = rpcmd:lower()
        
        local rpfunc = GAMEMODE.Commands[rpcmd]

        if rpfunc then
            if checks[rpcmd] then
                if not checks[rpcmd](rpcmd, ply) then return end
            end
            
            table.remove(args, 1)
            argstr = table.concat(args, ' ')
            rpfunc(ply, args, argstr)
            return ""
        end
    end
end)