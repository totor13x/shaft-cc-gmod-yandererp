local me = function(ply, _, str)
	local players = {}
	for k, v in ipairs(player.GetAll()) do
		if hook.Call('PlayerCanSeePlayersChat', GAMEMODE, str, false, ply, v) then
			table.insert(players, v)
		end 
	end
	
	GAMEMODE:ChatPrintTo(
		players, 
		team.GetColor(ply:Team()), ply, 
		Color(255, 255, 150), ' ' .. str
	)
end

GM:AddCommand('me', me)