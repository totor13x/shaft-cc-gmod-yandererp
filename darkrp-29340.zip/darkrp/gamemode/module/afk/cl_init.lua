local last_move = CurTime()
local mx, my = 0, 0
local afk = false

hook.Add('Think', 'afk', function()
	local t = CurTime()
	
	if last_move < t - 60 then
		if not afk then
			net.Start('afkon')
			net.SendToServer()
			afk = true
		end
	elseif afk then
		chat.AddText(Color(100, 256, 180), 'AFK - ' .. GAMEMODE.secondsToClock(math.floor(CurTime() - LocalPlayer():GetNWInt('WentAFK', 0))))
		net.Start('afkoff')
		net.SendToServer()
		afk = false	
	end
end)

hook.Add('KeyPress', 'afk', function()
	last_move = CurTime()
end)

hook.Add("InputMouseApply", "afk", function(cmd, x, y, ang)
	if x != 0 or y != 0 then
		last_move = CurTime()
	end
end)
