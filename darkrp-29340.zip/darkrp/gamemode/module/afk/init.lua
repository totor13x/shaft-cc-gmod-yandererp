util.AddNetworkString('afkon')
util.AddNetworkString('afkoff')

net.Receive('afkon', function(len, ply)
	ply:SetNWInt('WentAFK', math.floor(CurTime() - 60))
	ply:EmitSound('npc/roller/remote_yes.wav', 60, 100, 0.2)
end)

net.Receive('afkoff', function(len, ply)
	ply:SetNWInt('WentAFK', 0)
	ply:EmitSound('npc/roller/code2.wav', 60, 100, 0.2)
end)