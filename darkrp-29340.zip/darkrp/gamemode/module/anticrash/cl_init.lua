surface.CreateFont( "CrashNotice", {
	font	= "Nunito Black",
	size	= 32,
	weight	= 900,
	extended = true,
	shadow = true,
} )

local crashtimer = SysTime()
timer.Create('CrashNotice', 1, 0, function()
	crashtimer = SysTime()
end)

local reconnected = false

local starttime = SysTime()

hook.Add('HUDPaint', 'CrashNotice', function()
	if SysTime() - starttime < 60*5 then
		return
	end

	local delay = math.floor(SysTime() - crashtimer)
	if delay > 5 then
		draw.SimpleText('Сервер крашнулся!', 'CrashNotice', ScrW()/2, ScrH()/2 - 25, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText('Автоматическое переподключение через ' .. (45 - delay),  'CrashNotice', ScrW()/2, ScrH()/2 + 25, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	
	if delay > 44 then
		LocalPlayer():ConCommand('connect ' .. game.GetIPAddress())
		reconnected = true
	end
end)
