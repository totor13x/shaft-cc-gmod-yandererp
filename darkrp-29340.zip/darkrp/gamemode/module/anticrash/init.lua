save = {}
save.important_entities = {
	['bm2_bitminer_1'] = true,
	['bm2_bitminer_2'] = true,
	['bm2_bitminer_server'] = true,
	['bm2_bitminer_rack'] = true,
	['bm2_generator'] = true,
	['bm2_extention_lead'] = true,
	['bm2_power_lead'] = true,
}
save.important_fields = {
	--['bitcoin'] = 'SetBitcoinAmount', could retry too fast and dupe money
	['buy_table_id'] = true,
	['fuel'] = 'SetFuelLevel',
}

save.table = {}

function save:createTable()
	table.Empty(self.table)
	
	for _, p in ipairs(player.GetAll()) do
		local plyt = {}
		self.table[p:SteamID()] = plyt
			
		plyt.pos = p:GetPos()
		plyt.ang = p:EyeAngles()
		plyt.team = p:Team()
		plyt.ents = {}
		
		if p.rp_ents then
			for _, e in ipairs(p.rp_ents) do
				if IsValid(e) and self.important_entities[e:GetClass()] then
					local et = {
						class = e:GetClass(),
						pos = e:GetPos(),
						ang = e:GetAngles(),
						fields = {},
					}
					
					for field, _ in pairs(self.important_fields) do
						local val = e[field]
						if val then
							et.fields[field] = val
						end
					end
					
					table.insert(plyt.ents, et)
				end
			end
		end
	end
	
	return self.table
end

function save:save()
	file.Write('save.dat', util.TableToJSON(self:createTable()))
	print('[save] player data has been saved')
end

function save:load()
	if file.Exists('save.dat', 'DATA') then
		self.table = util.JSONToTable(file.Read('save.dat'))
	end
end

function save:loadPlayer(ply)
	local plyt = save.table[ply:SteamID()]
	
	if plyt then
    	ply:ChangeTeam(plyt.team, true)
    	ply:SetPos(plyt.pos)
    	ply:SetAngles(plyt.ang)
    	
    	for _, et in ipairs(plyt.ents) do
    		local id = et.fields.buy_table_id
    		local rp_ent = GAMEMODE.BuyEntities[id]
    		
    		local e = ents.Create(et.class)
    		e:SetPos(et.pos)
    		e:SetAngles(et.ang)
    		rp_ent.spawn(e, ply)
    		e:Spawn()
    		
    		for key, val in pairs(et.fields) do
    			e[key] = val
    			
    			local func = self.important_fields[key]
    			if isstring(func) then
    				e[func](e, val)
    			end
    		end
    		
    		e.rp_owner = ply
			if e.Setowning_ent then
				e:Setowning_ent(ply)
			end
			
			ply.rp_ents = ply.rp_ents or {}
			table.insert(ply.rp_ents, e)
			
			local cvarname = 'buyents_' .. id
			local count = ply:GetCSVar(csvarname, 0)
			ply:SetCSVar(cvarname, count + 1)
    	end
	end
	
	print('[save] loaded player', ply)
end

hook.Add('InitPostEntity', 'SaveLoad', function()
	save:load()
	
	local wait = 2
	timer.Create('RPSave', 80, 0, function()
		if wait > 0 then
			wait = wait - 1
		else
			save:save()
		end
	end)
end)

hook.Add("PlayerFullyLoaded", "SaveLoadPlayer", function(ply)
	save:loadPlayer(ply)
end)
