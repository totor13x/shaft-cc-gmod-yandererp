util.AddNetworkString('MPP_Msg')
util.AddNetworkString('MPP_FrundenAdd')
net.Receive("MPP_FrundenAdd",function(l,p)
	p.MPPFriends = p.MPPFriends or {}
	p.MPPFriends[net.ReadEntity()] = true
end)

util.AddNetworkString('MPP_FrundenRemove')
net.Receive("MPP_FrundenRemove",function(l,p)
	p.MPPFriends = p.MPPFriends or {}
	p.MPPFriends[net.ReadEntity()] = nil
end)

MPP.own = function(ply, ent)
	ent:SetNWEntity('MPPOwner', ply)
end

local ENTITY = FindMetaTable("Entity")

function ENTITY:CPPISetOwner(ply)
	MPP.own(ply, self)
end

MPP.check_propblock = function(ent)
	local check = false
	local center = ent:LocalToWorld(ent:OBBCenter())

	for _, v in ipairs(ents.FindInSphere(center, ent:BoundingRadius())) do
		if v:IsPlayer() then
			local pos = v:GetPos()
			local trace = {start = pos, endpos = pos, filter = v}
			local tr = util.TraceEntity(trace, v)

			if tr.Entity == ent then
				check = v
				break
			end
		end
	end

	return check
end

MPP.ghost = function(ent, disablemotion)
	if not IsValid(ent) then return end
	if MPP.conf.noghost[ent:GetClass()] then return end

	ent.MPPData = ent.MPPData or {}

	local gr = ent:GetCollisionGroup()
	if gr != COLLISION_GROUP_WORLD then ent.MPPData.collisiongroup = gr end
	ent:SetCollisionGroup(COLLISION_GROUP_WORLD)

	if ent.MPPData.ghosted then return end

	local c = ent:GetColor()
	ent.MPPData.alpha = c.a
	c.a = 180

	ent.MPPData.rendermode = ent:GetRenderMode()

	ent:SetRenderMode(RENDERMODE_TRANSCOLOR) 
	ent:SetColor(c) 

	ent.MPPData.ghosted = true
end

MPP.unghost = function(ent)
	ent.MPPData = ent.MPPData or {}

	ent:SetCollisionGroup(ent.MPPData.collisiongroup or COLLISION_GROUP_PASSABLE_DOOR)

	if not ent.MPPData.ghosted then return end

	local c = ent:GetColor()
	c.a = ent.MPPData and ent.MPPData.alpha or 255

	ent:SetColor(c)
	ent:SetRenderMode(ent.MPPData.rendermode or RENDERMODE_NORMAL)

	ent.MPPData.ghosted = false
end

hook.Add('PhysgunDrop', 'MPP', function(ply, ent)
	if ent:IsPlayer() then
		if ply:KeyDown(IN_ATTACK2) then
			ent:Lock()
			local ed = EffectData()
			ed:SetEntity(ent)
			ed:SetOrigin(ent:GetShootPos())
			util.Effect('phys_freeze', ed, nil, true)
			util.Effect('entity_remove', ed, nil, true)
		else
			ent:UnLock()	
		end
		return
	end

	if MPP.bypass(ply, ent) then return end

	local phys = ent:GetPhysicsObject()
	if IsValid(phys) and phys:GetVelocity():LengthSqr() > 2500 then
		phys:EnableMotion(false)
		MPP.ghost(ent)
	elseif MPP.check_propblock(ent) then
		GAMEMODE:Error(ply, 'blocking_player')
		MPP.ghost(ent)
	else
		MPP.unghost(ent)
	end
end)

hook.Add('OnPhysgunFreeze', 'MPP', function(wep, phys, ent, ply)
	if MPP.bypass(ply, ent) then return end

	timer.Simple(0, function() 
		if IsValid(ent) then 
			if ent.MPPData and not ent.MPPData.ghosted then
				ent:SetCollisionGroup(COLLISION_GROUP_NONE)
			end
		end
	end)
end)

MPP.spawned = function(ply, mdl, ent)
	MPP.own(ply, ent)

	if MPP.bypass(ply, ent) then return end

	ent:SetCollisionGroup(COLLISION_GROUP_PASSABLE_DOOR)

	if ply.MPP_antispam and ply.MPP_antispam > CurTime() then
		ply.MPP_antispam_count = ply.MPP_antispam_count + 1
		GAMEMODE:Notify(ply, 'object_frozen')
		MPP.ghost(ent)
		local phys = ent:GetPhysicsObject()
		if IsValid(phys) then phys:EnableMotion(false) end
	else
		ply.MPP_antispam_count = 0
	end

	ply.MPP_antispam = CurTime() + MPP.conf.ghost_spam_rate  
end

hook.Add('PlayerSpawnedProp', 'MPP', function(ply, mdl, ent)
	MPP.spawned(ply, mdl, ent)
	if MPP.bypass(ply, ent) then ent.CanDamage = true return end

	if MPP.check_blocked(mdl) then
		GAMEMODE:Notify(ply, 'object_blocked')
		ent:Remove()
		return
	end

	if ent:GetModelRadius() > 200 then
		ent:Remove() 
		GAMEMODE:Error(ply, 'prop_too_large') 
		return 
	end

	if ply:GetCount('props') >= 20 and not ply:IsPremium() then ent:Remove() ply:LimitHit('props') return end
	
	ent:AddCallback('PhysicsCollide', function(ent, data)
		if data.HitEntity:IsPlayer() then
			local phys = ent:GetPhysicsObject()
			if IsValid(phys) and phys:IsMotionEnabled() then
				timer.Simple(0, function()
					MPP.ghost(ent)
				end)
			end
			return 
		end
		
		if not MPP.conf.damage_whitelist[data.HitEntity:GetClass()] then
			timer.Simple(0, function()
				if not IsValid(ent) then return end
				--constraint.NoCollide(ent, data.HitEntity, 0, 0)
				local phys = ent:GetPhysicsObject()
				if IsValid(phys) and phys:IsMotionEnabled() then
					MPP.ghost(ent)
				end
			end)
		end
	end)
end)

hook.Add('PlayerSpawnedEffect', 	'MPP', MPP.spawned)
hook.Add('PlayerSpawnedNPC', 		'MPP', function(ply, ent)
	MPP.spawned(ply, nil, ent)
end)
hook.Add('PlayerSpawnedRagdoll',	'MPP', MPP.spawned)
hook.Add('PlayerSpawnedSENT', 		'MPP', function(ply, ent)
	MPP.spawned(ply, nil, ent)
end)
hook.Add('PlayerSpawnedSWEP', 		'MPP', function(ply, ent)
	MPP.spawned(ply, nil, ent)
end)
hook.Add('PlayerSpawnedVehicle', 	'MPP', function(ply, ent)
	MPP.spawned(ply, nil, ent)
end)

hook.Add('PlayerSpawnNPC', 'MPP', MPP.q_spawn_permission)
hook.Add('PlayerSpawnSENT', 'MPP', MPP.q_spawn_permission)
hook.Add('PlayerSpawnSWEP', 'MPP', MPP.q_spawn_permission)
hook.Add('PlayerGiveSWEP', 'MPP', MPP.q_spawn_permission)
hook.Add('PlayerSpawnVehicle', 'MPP', MPP.q_spawn_permission)

hook.Add('PlayerSpawnObject', 'MPP', function(ply, model)
	if ply.LS_Banned then return false end
	if MPP.bypass(ply) then return true end
	if MPP.check_blocked(model) then
		GAMEMODE:Notify(ply, 'object_blocked')
		return false
	end

	if not ply:Alive() then
		return false
	end

	if ply.MPP_antispam_count and ply.MPP_antispam_count >= MPP.conf.remove_after then
		if ply.MPP_antispam < CurTime() then
			ply.MPP_antispam_count = 0
		else
			GAMEMODE:Error(ply, 'spawning_objects_too_fast')
			
			ply.MPP_antispam = CurTime() + MPP.conf.ghost_spam_rate
			return false
		end
	end

	return true
end)

hook.Add('PlayerShouldTakeDamage', 'MPP', function(ply, att)
	if att.CanDamage then return end
	local isplayer = ply:IsPlayer()
	if isplayer and att:IsVehicle() then return false end

	local entclass = att:GetClass()

	//if entclass == 'worldspawn' and ply.KilledByProp and CurTime() - ply.KilledByProp < 0.2 then
		//return false
	//end

	if isplayer and not MPP.conf.damage_whitelist[entclass] then
		MPP.ghost(att)
		local phys = att:GetPhysicsObject()
		if IsValid(phys) then
			phys:EnableMotion(false)
		end
		return false
	end
end)

local cantdamagewith = {
	['weapon_physcannon'] = true,
	['prop_physics'] = true,
}
hook.Add('EntityTakeDamage', 'MPP', function(ply, dmginfo)
	if IsValid(ply) and ply:IsPlayer() then
		local att = dmginfo:GetAttacker()
		local inflictor = dmginfo:GetInflictor()
		
		if IsValid(att) and att:IsPlayer() and IsValid(inflictor) and cantdamagewith[inflictor:GetClass()] then
			return true
		end
	end
end)

hook.Add('PlayerDisconnected', 'MPPRemove', function(ply)
	for _, v in ipairs(ents.GetAll()) do
		if v:GetNWEntity('MPPOwner', false) == ply then
			SafeRemoveEntity(v)
		end
	end
end)

hook.Add('OnPhysgunReload', 'MPPPhysgunR', function(pg, ply)
	local e = ply:GetEyeTrace().Entity
	return IsValid(e) and MPP.canTouch(ply, e)
end)

hook.Add('OnCrazyPhysics', 'MPPCrazy', function(ent)
	timer.Simple(0, function()
		MPP.ghost(ent)
	end)
end)

if undo and not undo.mpp then
	local AddEntity, SetPlayer, Finish =  undo.AddEntity, undo.SetPlayer, undo.Finish
	local Undo = {}
	local UndoPlayer
	function undo.AddEntity(ent, ...)
		if type(ent) ~= "boolean" and IsValid(ent) then table.insert(Undo, ent) end
		AddEntity(ent, ...)
	end

	function undo.SetPlayer(ply, ...)
		UndoPlayer = ply
		SetPlayer(ply, ...)
	end

	function undo.Finish(...)
		if IsValid(UndoPlayer) then
			for _, v in pairs(Undo) do
				v:SetNWEntity('MPPOwner', UndoPlayer)
			end
		end
		Undo = {}
		UndoPlayer = nil

		Finish(...)
	end
	
	undo.mpp = true
end