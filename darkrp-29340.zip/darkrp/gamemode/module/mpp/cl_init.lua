MPP = MPP or {}

local mpp_hud_text
local mpp_hud_color
local ScrW, ScrH = ScrW(), ScrH()
hook.Add('HUDPaint', 'MPP', function()
    if mpp_hud_text then
        surface.SetFont('Trebuchet18')
        surface.SetTextColor(mpp_hud_color)
        local tw, th = surface.GetTextSize(mpp_hud_text)

        surface.SetDrawColor(0, 0, 0, 196)
        surface.DrawRect(0, ScrH/2 - th/2, tw + 10, th)

        surface.SetTextPos(4, ScrH/2 - th/2)
        surface.DrawText(mpp_hud_text)
    end
end)

timer.Create('MPPInfo', 0.25, 0, function()
    mpp_hud_text = nil
    local lp = LocalPlayer()
    if IsValid(lp) then
        local ent = lp:GetEyeTrace().Entity

        if IsValid(ent) then
            mpp_hud_color = MPP.canTouch(lp, ent) and Color(32, 255, 96) or Color(255, 32, 96)
            local owner = MPP.owner(ent)

            if MPP.check_blocked(ent) then
                mpp_hud_text = 'blocked'
            elseif IsValid(owner) then
                if owner:IsPlayer() then
                    mpp_hud_text = owner:GetName()
                else
                    mpp_hud_text = owner:GetClass()
                end
            else
                mpp_hud_text = 'world'
            end
        end
    end
end)

sql.Query("CREATE TABLE MPPFriends (SteamID string)")

function MPP:AddFriend(e)
    sql.Query(string.format('INSERT INTO MPPFriends VALUES ("%s")', e:SteamID()))
    LocalPlayer().MPPFriends = LocalPlayer().MPPFriends or {}
    LocalPlayer().MPPFriends[e] = true
    net.Start("MPP_FrundenAdd")
        net.WriteEntity(e)
    net.SendToServer()
    if IsValid(self.Panel) then
        self.Panel:AddFriend(e:SteamID())
    end
end

function MPP:RemoveFriend(e)
    sql.Query(string.format('DELETE FROM MPPFriends WHERE SteamID = "%s"', e:SteamID()))
    LocalPlayer().MPPFriends = LocalPlayer().MPPFriends or {}
    LocalPlayer().MPPFriends[e] = nil
    net.Start("MPP_FrundenRemove")
        net.WriteEntity(e)
    net.SendToServer()
    if IsValid(self.Panel) then
        self.Panel:RemoveFriend(e:SteamID())
    end
end

for i = 0, 1 do
    local befriend = i == 0

    properties.Add(befriend and "mpp_friend" or "mpp_unfriend", {
        Order = 1337 + i,
        MenuLabel = befriend and "Share Props" or "Stop Sharing Props",
        MenuIcon = befriend and "icon16/user_add.png" or "icon16/user_delete.png",
        Filter = function(s,e,p)
            if not IsValid(e) or not e:IsPlayer() then return false end

            if LocalPlayer().MPPFriends and LocalPlayer().MPPFriends[e] then 
                return not befriend
            else
                return befriend
            end
        end,
        Action = function(s,e)
            if befriend then
                MPP:AddFriend(e)
            else
                MPP:RemoveFriend(e)
            end
        end
    })
end

local update = function(pl)
    local lp = LocalPlayer()
    lp.MPPFriends = lp.MPPFriends or {}
    if not lp.MPPFriends[pl] then
        local val = sql.QueryValue('SELECT 1 FROM MPPFriends WHERE SteamID = "' .. pl:SteamID() .. '"') and true or nil
        lp.MPPFriends[pl] = val
        if val then
            net.Start("MPP_FrundenAdd")
                net.WriteEntity(pl)
            net.SendToServer()
        end
    end
end

hook.Add("InitPostEntity", "MPP",function()
    for i, pl in ipairs(player.GetAll()) do
        update(pl)
    end
end)

hook.Add('PlayerConnect', 'MPP', function(pl)
    update(pl)
end)

do -- q menu
	local DButts = {}

	local function Paint(self,w,h)
		surface.SetDrawColor(64,64,64)
		surface.DrawOutlinedRect(0,0,w,h)
	end

	local function DButt(parent,steam,id)
		local A = vgui.Create("DButton",parent)
		local B = vgui.Create("DButton",parent)
		table.insert(DButts,{A,B})
		A:SetPos(5,id*25)
		A:SetSize(A:GetWide()*3,22)
		A:SetText(steam)
		A.Paint = Paint
		A.DoClick = function()
			gui.OpenURL("https://steamcommunity.com/profiles/"..util.SteamIDTo64(steam))
		end
		
		B:SetPos(B:GetWide()*3+10,id*25)
		B:SetSize(B:GetWide()*1.5,22)
		B:SetText("Remove")
		B.Paint = Paint
		B.DoClick = function() 
			local ply = player.GetBySteamID(steam)
			
			if ply then
				LocalPlayer().MPPFriends = LocalPlayer().MPPFriends or {} 
				LocalPlayer().MPPFriends[ply] = nil 
				net.Start("MPP_FrundenRemove") 
				net.WriteEntity(ply) 
				net.SendToServer() 
			end
			
			sql.Query(string.format('DELETE FROM MPPFriends WHERE SteamID = "%s"', steam)) 
			
			MPP.Panel:RemoveFriend(steam)
		end
		
	end

	local menu_create = function()	
		spawnmenu.AddToolMenuOption( "Utilities", "MPP", "MPP", "Prop Protection", "", "", function(pnl)
			local allowed = sql.Query('SELECT * FROM MPPFriends') or {}
			MPP = MPP or {}
			MPP.Panel = pnl
			local function AllRem()
				for k,v in ipairs(DButts) do
					v[1]:Remove()
					v[2]:Remove()
				end
			end
			local function IterButt()
				for k,v in ipairs(allowed) do
					DButt(pnl,v.SteamID,k)
				end
			end
			IterButt()
			function pnl:AddFriend(steam) -- u don't have any so u have to code them
				table.insert(allowed,{["SteamID"] = steam})
				AllRem()
				IterButt()
			end
			function pnl:RemoveFriend(steam)
				for k,v in ipairs(allowed) do 
					if v.SteamID==steam then
						table.remove(allowed,k)
					end
				end
				AllRem()
				IterButt()
			end
		end)
	end
	hook.Add( "PopulateToolMenu", "MPP", menu_create)
end