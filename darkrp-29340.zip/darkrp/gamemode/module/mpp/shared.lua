MPP = MPP or {}

MPP.conf = {
	blocked_models = {},
	blocked_models_folders = {},
	blocked_classes = {},
	tools_whitelist = {},
	damage_whitelist = {},
	allowed_properties = {},
	ghost_spam_rate = 1.5,
	remove_after = 3,
}

MPP.world_permission = function(ply)
	return false
end

MPP.blocked_permission = function(ply)
	return false
end

MPP.q_spawn_permission = function(ply)
	return false
end

MPP.compare_players = function(ply1, ply2)
	return ply1:GetUserAccess() > ply2:GetUserAccess()
end

MPP.bypass = function(ply)
	return false
end

MPP.owner = function(ent)
	return ent:GetNWEntity('MPPOwner')
end

MPP.check_blocked = function(t)
	if isstring(t) then
		t = string.lower(t)
		t = string.Replace(t, '\\', '/')
		return MPP.conf.blocked_models[t] or MPP.conf.blocked_classes[t]
	elseif isentity(t) then
		local mdl = string.lower(t:GetModel())
		return MPP.conf.blocked_models[mdl] or MPP.conf.blocked_classes[mdl]
	end

	return false
end

MPP.canTouch = function(ply, ent)
	if MPP.bypass(ply) then return true end

	local owner = MPP.owner(ent)
	if owner == ply or (owner.MPPFriends and owner.MPPFriends[ply]) then
		return true	
	end
	
	if IsValid(owner) then
		return MPP.compare_players(ply, owner)
	elseif MPP.check_blocked(ent) then
		return MPP.blocked_permission(ply)
	else
		return MPP.world_permission(ply)
	end
end

hook.Add('PhysgunPickup', 'MPP', function(ply, ent)
	if MPP.bypass(ply) then return true end
	
	if ent:GetClass() == 'player' then
		return MPP.compare_players(ply, ent)
	end
	if MPP.canTouch(ply, ent) then
		if SERVER then MPP.ghost(ent) end
		return true
	else
		return false
	end
end)

local toolrestricted_cd = 0
hook.Add('CanTool', 'MPP', function(ply, trace, tool)
	if MPP.bypass(ply) then return true end
	if not MPP.conf.tools_whitelist[tool] and not MPP.blocked_permission(ply) then
		if CLIENT and CurTime() > toolrestricted_cd then
			GAMEMODE:Error('tool_blocked')
			toolrestricted_cd = CurTime() + 1
		end
		return false
	end

	local ent = trace.Entity
	if IsValid(ent) then
		return MPP.canTouch(ply, ent)
	end
end)

hook.Add('CanProperty', 'MPP', function(ply, prop, ent)
	if MPP.bypass(ply) or (MPP.canTouch(ply, ent) and MPP.conf.allowed_properties[prop]) or MPP.conf.allowed_properties_allents[prop] then
		return true
	else
		return false
	end
end)

local disallow_hook = function()
	return false
end

hook.Add('CanDrive', 'MPP', disallow_hook)
hook.Add('GravGunPunt', 'MPP', disallow_hook)

include(GM.ConfigFolder .. 'mpp.lua')

local ENTITY = FindMetaTable("Entity")
function ENTITY:CPPIGetOwner()
    local Owner = self:GetNWEntity('MPPOwner', nil)
    return Owner, IsValid(Owner) and Owner:UniqueID() or nil
end

CPPI = true