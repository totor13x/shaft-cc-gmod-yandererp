-- fix from players deleting world props

function constraint.GetAllConstrainedEntities(ent)
	return {ent}
end