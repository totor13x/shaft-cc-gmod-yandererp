hook.Add('InitPostEntity', 'ToolMenu', function()
	if LocalPlayer():IsSuperAdmin() then return end

	if not spawnmenu._AddToolMenuOption then
		spawnmenu._AddToolMenuOption = spawnmenu.AddToolMenuOption
		spawnmenu.AddToolMenuOption = function(tab, category, class, name, cmd, config, cpanel, table)
			if tab == 'Utilities' or MPP.conf.tools_whitelist[class] then
				return spawnmenu._AddToolMenuOption(tab, category, class, name, cmd, config, cpanel, table)
			end
		end
	end

	if not spawnmenu._AddToolCategory then
		spawnmenu._AddToolCategory = spawnmenu.AddToolCategory
		spawnmenu.AddToolCategory = function(tab, RealName, PrintName)
			if RealName ~= 'Poser' then
				spawnmenu._AddToolCategory(tab, RealName, PrintName)	
			end
		end
	end

	RunConsoleCommand('spawnmenu_reload')
end)