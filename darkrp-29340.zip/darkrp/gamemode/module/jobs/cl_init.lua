net.Receive('OnPlayerChangedTeam', function()
	local ent = net.ReadEntity()
	if IsValid(ent) then
		hook.Call('OnPlayerChangedTeam', GAMEMODE, ent, net.ReadInt(16), net.ReadInt(16))
	end
end)

hook.Add('OnPlayerChangedTeam', 'NotifyChangeJob', function(ply, from, to)
	local ed = EffectData()
	ed:SetEntity(ply)
	ed:SetOrigin(ply:WorldSpaceCenter())
	util.Effect('cball_explode', ed)
	util.Effect('propspawn', ed)

	GAMEMODE:Notify(L('became', ply:GetName(), team.GetName(to)))
end)

GM.preferModel = function(i)
	net.Start('rp_prefer_model')
		net.WriteUInt(i, 7)
	net.SendToServer()
end

local update_job_players = function()
	timer.Simple(0.5, function()
		if IsValid(GAMEMODE.F4Menu) then
			local teams = {}
			for _, p in ipairs(player.GetAll()) do
				local t = p:Team()
				teams[t] = teams[t] and teams[t] + 1 or 1
			end
			for k, v in pairs(GAMEMODE.F4Menu.job_items) do
				v.count = teams[k] or 0
			end
		end
	end)
end

gameevent.Listen("player_disconnect")
hook.Add('OnPlayerChangedTeam', 'update_job_players', update_job_players)
hook.Add('player_disconnect', 'update_job_players', update_job_players)

hook.Add('f4menu_onload', 'job_tab', function(f4)
	f4:AddTab(L'jobs', function(p)
		f4.job_items = {}

		local jobs_page = vgui.Create('f4_select_page', p)
		jobs_page:SetSize(p:GetSize())
		jobs_page.button_click = function(self, i)
			RunConsoleCommand('rp', 'job', i)
		end
		jobs_page.item_created = function(item, i)
			if i == LocalPlayer():Team() then
				item:DoClick() 
			end

			f4.job_items[i] = item
		end
		jobs_page.model_select = function(i)
			GAMEMODE.preferModel(i)
		end

		jobs_page.setup_camera = function(pm)
			pm:SetCamPos(Vector(120, 0, 36))
			pm:SetLookAt(Vector(0, 0, 36))
			pm:SetFOV(30)
		end
		jobs_page.items_table = GAMEMODE.Jobs
		jobs_page.button_text = L"change_job"

		jobs_page:Create()
		update_job_players()
	end)
end)

GM:DescribeCommand('demote', L'demote_player', {L'player', L'reason'})

net.Receive('f4_unlockeditems', function()
	LocalPlayer().f4_unlockeditems = net.ReadTable()
	if GAMEMODE.F4Menu and GAMEMODE.F4Menu.job_items then
		for k, v in pairs(GAMEMODE.F4Menu.job_items) do
			if LocalPlayer().f4_unlockeditems[v.name] then
				v:SetAlpha(255)
			end
		end
	end
end)