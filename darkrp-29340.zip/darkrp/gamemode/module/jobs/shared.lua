local default_job = {
	name = 'noname',
	desc = L"no_desc",
	weapons = {},
	max = 0,
	color = color_white,
	model = "models/player/police.mdl",
	can_become = function(ply)
		return true
	end,
	salary = 100,
	category = 'Default',
	vote = nil,
	spawnpoints = nil,
}

GM.Jobs = {}

function GM:CreateJob(t)
	local jobtable = table.Copy(default_job)
	table.Merge(jobtable, t)

	local id = #self.Jobs + 1
	team.SetUp(id, jobtable.name, jobtable.color)

	jobtable.salary = math.floor(jobtable.salary)
	self.Jobs[id] = jobtable

	return id
end

function GM.teamByName(name)
	if name then
		for i, job in ipairs(GAMEMODE.Jobs) do 
			if job.name:find(name) then
				return i
			end
		end
	end
end

function DarkRP.createJob(Name, colorOrTable, model, Description, Weapons, command, maximum_amount_of_this_class, Salary, admin, Vote, Haslicense, NeedToChangeFrom, CustomCheck, spawnpoints)
	local tableSyntaxUsed = not IsColor(colorOrTable)

	local CustomTeam = tableSyntaxUsed and colorOrTable or
		{color = colorOrTable, model = model, description = Description, weapons = Weapons, command = command,
			max = maximum_amount_of_this_class, salary = Salary, admin = admin or 0, vote = tobool(Vote), hasLicense = Haslicense,
			NeedToChangeFrom = NeedToChangeFrom, customCheck = CustomCheck, spawnpoints = spawnpoints,
		}
	CustomTeam.name = Name

	CustomTeam.desc = CustomTeam.description
	CustomTeam.can_become = CustomTeam.customCheck


	return (GM or GAMEMODE):CreateJob(CustomTeam)
end

GM.ChatTeams = GM.ChatTeams or {}
GM.ChatTeamsJobs = GM.ChatTeamsJobs or {}
function GM:AddChatTeam(name, t)
	GM.ChatTeams[name] = t
	for _, v in ipairs(t) do
		GM.ChatTeamsJobs[v] = name
	end
end

hook.Call('RP_CustomJobs', GM, GM)

if GM.Settings.default_jobs then
	include(GM.ConfigFolder .. 'jobs.lua')
end

GM.DefaultTeam = GM.DefaultTeam or 1

local _Player = FindMetaTable('Player')
function _Player:GetJobTable()
	return GAMEMODE.Jobs[self:Team()] or default_job
end

function _Player:IsMayor()
	return self:GetJobTable().mayor
end

function _Player:IsPolice()
	return self:GetJobTable().police
end