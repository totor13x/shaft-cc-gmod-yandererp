util.AddNetworkString('OnPlayerChangedTeam')

local meta = FindMetaTable('Player')
function meta:ChangeTeam(id, force, vote_bypass)
	local current_team = self:Team()

	if not force then
		local job = GAMEMODE.Jobs[id]
		if not job then
			GAMEMODE:Error(self, {"wrong_argument", id})
			return
		end

		if job.unlockprice then
			if not self.f4_unlockeditems then
				return
			end
			
			if not self.f4_unlockeditems[job.name] then
				if not self:CanAfford(job.unlockprice) then
					GAMEMODE:Error(self, 'cant_afford')
				else
					self:AddMoney(-job.unlockprice)
					self.f4_unlockeditems[job.name] = true
					sql.Query(string.format('INSERT INTO f4_unlockeditems (steamid, item) VALUES (%s, %s)', SQLStr(self:SteamID()), SQLStr(job.name)))
					net.Start('f4_unlockeditems')
						net.WriteTable(self.f4_unlockeditems)
					net.Send(self)

					GAMEMODE:Notify(self, {'bought', job.name})
				end
				return
			end
		end

		if id == current_team then
			GAMEMODE:Error(self, {"you_already", job.name})
			return
		end

		if not job.can_become(self) then
			GAMEMODE:Error(self, {"cant_become", job.name})
			if job.CustomCheckFailMsg then GAMEMODE:Error(self, job.CustomCheckFailMsg) end
			return
		end

		if job.max > 0 then
			local players_with_job = 0
			for _, p in ipairs(player.GetAll()) do
				if p:Team() == id then
					players_with_job = players_with_job + 1
				end
			end

			if players_with_job >= job.max then
				GAMEMODE:Error(self, {"limit_reached", job.name})
				return
			end
		end

		if self.last_job_change then
			local diff = (self.last_job_change + GAMEMODE.Settings.job_change_cooldown) - CurTime()
			if diff > 0 then
				GAMEMODE:Error(self, {"wait_for", math.ceil(diff)})
				return
			end
		end

		if job.vote and not vote_bypass then
			if self.job_voting then
				GAMEMODE:Error(self, "vote_in_progress")
				return
			end

			self.job_voting = true
			GAMEMODE:Vote(L('wants_to_become', self:GetName(), job.name), function(yes)
				self.job_voting = nil
				if not IsValid(self) then return end

				if yes then
					self:ChangeTeam(id, false, true)
				else
					GAMEMODE:Error(self, L('players_voted_against', job.name))
					self.last_job_change = CurTime()
				end
			end)

			return
		end
	end

	self.last_job_change = CurTime()

	self:SetTeam(id)

	self:StripWeapons()
	self:StripAmmo()

	if GAMEMODE.Settings.respawn_on_job_change then
		self:ExitVehicle()
		self:Spawn()
	end

	if self:InVehicle() then
		self:ExitVehicle()
	end

	hook.Call('PlayerLoadout', GAMEMODE, self)
	hook.Call('PlayerSetModel', GAMEMODE, self)
	hook.Call("OnPlayerChangedTeam", GAMEMODE, self, current_team, id)
	net.Start('OnPlayerChangedTeam')
		net.WriteEntity(self)
		net.WriteInt(current_team, 16)
		net.WriteInt(id, 16)
	net.Broadcast()
end

GM:AddCommand('job', function(ply, args)
	if not GAMEMODE.Settings.can_use_job_command then
		GAMEMODE:Error(self, "disabled")
		return 
	end
	
	local id = tonumber(args[1])

	ply:ChangeTeam(id)
end)

GM:AddCommand('demote', function(demoter, args)
	local ply = GAMEMODE.FindEntity(args[1])
	local reason = args[2]

	if demoter.last_demoter and demoter.last_demoter + 300 > CurTime() then 
		return GAMEMODE:Error(demoter, {'wait', math.ceil(demoter.last_demoter + 300 - CurTime())}) 
	end

	if not reason then 
		return GAMEMODE:Error(demoter, {'wrong_argument', 'reason'}) 
	end

	if IsValid(ply) and ply:IsPlayer() then
		if ply:Team() == GAMEMODE.DefaultTeam then 
			return GAMEMODE:Error(demoter, {'unable', 'demote'})
		end
		
		demoter.last_demoter = CurTime()
		GAMEMODE:Vote(L('demote_vote', demoter:GetName(), ply:GetName()) .. '\n' .. reason, function(yes)
			if not IsValid(ply) then return end

			if yes then
				hook.Call('OnPlayerDemoted', GAMEMODE, demoter, ply, reason)
				ply:ChangeTeam(GAMEMODE.DefaultTeam, true)
			else
				GAMEMODE:Error(player.GetAll(), L('players_voted_against_demote', ply:GetName()))
			end
		end)
	end
end)

util.AddNetworkString('rp_prefer_model')
net.Receive('rp_prefer_model', function(len, ply)
	ply.rp_preferred_model = net.ReadUInt(7)
end)

timer.Create('rp_salary', GM.Settings.salary_delay, 0, function()
	for k, v in ipairs(player.GetAll()) do
		local job = GAMEMODE.Jobs[v:Team()]
		local money = job.salary
		
		local hk = hook.Call('PlayerSalary', GAMEMODE, v, money)
		if hk == true then
			continue
		elseif isnumber(hk) then
			money = hk
		end

		v:AddMoney(money)
		GAMEMODE:Notify(v, L('youve_been_paid', GAMEMODE.formatMoney(money)))
	end
end)

hook.Add('OnPlayerDemoted', 'Demote', function(demoter, ply, reason)
	GAMEMODE:ChatPrint(Color(255, 85, 85), L'demote_tag', Color(220, 220, 220), L('demote', demoter:GetName(), ply:GetName(), reason))
end)

if not sql.TableExists('f4_unlockeditems') then
	sql.Query('CREATE TABLE f4_unlockeditems (steamid string, item string)')
end

util.AddNetworkString('f4_unlockeditems')
hook.Add('PlayerFullyLoaded', 'UnlockedF4Items', function(ply)
	local t = sql.Query('SELECT item FROM f4_unlockeditems WHERE steamid = ' .. SQLStr(ply:SteamID()))
		
	ply.f4_unlockeditems = {}
	
	if t and #t > 0 then
		for i, v in ipairs(t) do
			ply.f4_unlockeditems[v.item] = true
		end
	end

	net.Start('f4_unlockeditems')
		net.WriteTable(ply.f4_unlockeditems)
	net.Send(ply)
end)