hook.Remove("PostDrawEffects", "RenderWidgets")
hook.Remove("PlayerTick", "TickWidgets")

timer.Create('FlexScale', 10, 0, function()
	for k, v in ipairs(player.GetAll()) do
		v:SetFlexScale(0)
	end
end)