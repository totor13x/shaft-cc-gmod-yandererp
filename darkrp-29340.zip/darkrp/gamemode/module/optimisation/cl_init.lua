hook.Add('PreRender', 'optimisation', function()
	render.SetShadowsDisabled(true)
end)

hook.Add('InitPostEntity', 'optimisation', function()
	local cmdlist = {
		r_shadows = { 0, GetConVarNumber },
		r_shadowrendertotexture = { 0, GetConVarNumber },
		r_shadowmaxrendered = { 0, GetConVarNumber },
		mat_shadowstate = { 0, GetConVarNumber },
		cl_phys_props_enable = { 0, GetConVarNumber },
		cl_phys_props_max = { 0, GetConVarNumber },
		props_break_max_pieces = { 0, GetConVarNumber },
		r_propsmaxdist = { 0, GetConVarNumber },
		r_drawmodeldecals = { 0, GetConVarNumber },
		cl_threaded_bone_setup = { 1, GetConVarNumber },
		cl_threaded_client_leaf_system = { 1, GetConVarNumber },
		r_threaded_client_shadow_manager = { 1, GetConVarNumber },
		r_threaded_particles = { 1, GetConVarNumber },
		r_threaded_renderables = { 1, GetConVarNumber },
		r_queued_ropes = { 1, GetConVarNumber },
		studio_queue_mode = { 1, GetConVarNumber },
		mat_queue_mode = { -1, GetConVarNumber },
		cl_showhints = { 0, GetConVarNumber },
		cl_drawworldtooltips = { 1, GetConVarNumber },
		gmod_mcore_test = { 1, GetConVarNumber },
		r_3dsky = { 1, GetConVarNumber },
		vfire_enable_lights = { 0, GetConVarNumber },
		pp_sunbeams = { 1, GetConVarNumber },
		cl_drawspawneffect = { 0, GetConVarNumber },
		easychat_tick_sound = { 1, GetConVarNumber },
	}

	local detours = {}

	for k,v in pairs(cmdlist) do
		detours[k] = v[2](k)
		RunConsoleCommand(k, v[1])
	end

	hook.Add('ShutDown', 'optimisation', function()
		for k, v in pairs(detours) do
			RunConsoleCommand(k, v)
		end
	end)

	--matproxy.Call = function() end
	--matproxy.Init = function() end
	--matproxy.ShouldOverrideProxy = function() end

	timer.Create('clear_junk', 60, 0, function()
		for k, v in ipairs(ents.FindByClass("class C_ClientRagdoll")) do
			v:Remove()
		end
		
		for k, v in ipairs(ents.FindByClass("class C_PhysPropClientside")) do
			if not v.mdi then v:Remove() end
		end

		RunConsoleCommand('r_cleardecals')
	end)

	--if not surface.DefaultCreateFont then
	--	surface.DefaultCreateFont = surface.CreateFont 
	--	surface.CreateFont = function(...) for i = 1, 2 do surface.DefaultCreateFont(...) end end
	--end

	local math = math
	local meta = FindMetaTable("Player")
	local entity = FindMetaTable("Entity")

	function meta:__index(key)
		return meta[key] or entity[key] or entity.GetTable(self)[key]
	end

	local mathmin = math.min
	local mathmax = math.max
	local WaterLevel = entity.WaterLevel
	local IsOnGround = entity.IsOnGround
	local SetPlaybackRate = entity.SetPlaybackRate
	local InVehicle = meta.InVehicle
	local GetVehicle = meta.GetVehicle
	local GetMoveType = entity.GetMoveType

	function GAMEMODE:UpdateAnimation( ply, velocity, maxseqgroundspeed )
		local len = velocity:Length()
		local movement = 1.0

		if ( len > 0.2 ) then
			movement = ( len / maxseqgroundspeed )
		end

		local rate = mathmin( movement, 2 )

		if ( WaterLevel(ply) >= 2 ) then
			rate = mathmax( rate, 0.5 )
		elseif ( !IsOnGround(ply) && len >= 1000 ) then
			rate = 0.1
		end

		SetPlaybackRate( ply, rate )
	end

	function GAMEMODE:CalcMainActivity( ply, velocity )

		ply.CalcIdeal = ACT_MP_STAND_IDLE
		ply.CalcSeqOverride = -1

		--self:HandlePlayerLanding( ply, velocity, ply.m_bWasOnGround )

		if ( --self:HandlePlayerNoClipping( ply, velocity ) ||
			self:HandlePlayerDriving( ply ) ||
			--self:HandlePlayerVaulting( ply, velocity ) ||
			self:HandlePlayerJumping( ply, velocity ) ||
			self:HandlePlayerSwimming( ply, velocity ) ||
			self:HandlePlayerDucking( ply, velocity ) ) then

		else

			local len2d = velocity:Length2DSqr()
			if ( len2d > 22500 ) then ply.CalcIdeal = ACT_MP_RUN elseif ( len2d > 0.25 ) then ply.CalcIdeal = ACT_MP_WALK end

		end

		ply.m_bWasOnGround = IsOnGround(ply)
		ply.m_bWasNoclipping = ( GetMoveType(ply) == MOVETYPE_NOCLIP && !InVehicle(ply) )

		return ply.CalcIdeal, ply.CalcSeqOverride

	end

	hook.Remove('InitPostEntity', 'optimisation')
end)

function GM:CalcView(ply, pos, angles, fov, znear, zfar)
	local farz = self.Settings.zfar or 2000
	if farz == 0 then farz = zfar end

	local view = {}

	view.origin = pos
	view.angles = angles
	view.fov = fov
	view.zfar = farz

	return view
end

halo.Add = function() end
halo.Render = function() end
hook.Remove("PostDrawEffects", "RenderHalos")

hook.Add('NetworkEntityCreated', 'LightOptimise', function(ent)
	if ent:GetClass() == 'gmod_light' then
		timer.Simple(0.5, function()
			local cd = 0
			
			function ent:Think()
				if not self:GetOn() or LocalPlayer():GetPos():DistToSqr(self:GetPos()) > 300000 or cd > CurTime() then 
					return 
				end
		
				cd = CurTime() + 2
		
				local noworld = self:GetLightWorld()
				local dlight = DynamicLight( self:EntIndex(), noworld )
		
				if ( dlight ) then
		
					local c = self:GetColor()
		
					local size = self:GetLightSize()
					local brght = self:GetBrightness()
					-- Clamp for multiplayer
					if ( !game.SinglePlayer() ) then
						size = math.Clamp( size, 0, 1024 )
						brght = math.Clamp( brght, 0, 6 )
					end
		
					dlight.Pos = self:GetPos()
					dlight.r = c.r
					dlight.g = c.g
					dlight.b = c.b
					dlight.Brightness = brght
					dlight.Decay = 0
					dlight.Size = size
					dlight.DieTime = CurTime() + 3
		
					dlight.noworld = noworld
					dlight.nomodel = self:GetLightModels()
		
				end
			end
		end)
	end
end)