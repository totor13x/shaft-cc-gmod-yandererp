local optimisation = function()
  --
end

hook.Add('PostCleanupMap', 'optimisation', optimisation)
hook.Add('PostGamemodeLoaded', 'optimisation', optimisation)