local isMayor = function()
	return LocalPlayer():IsMayor()
end

timer.Simple(1, function() -- crap fix to put to the bottom of the list
	GAMEMODE:DescribeCommand('lockdown', 'Начать комендантский час', nil, isMayor)
	GAMEMODE:DescribeCommand('unlockdown', 'Закончить комендантский час', nil, isMayor)
	GAMEMODE:DescribeCommand('broadcast', 'Оповестить город', {'Трансляция'}, isMayor)
	GAMEMODE:DescribeCommand('lottery', 'Начать лотерею', {'Стоимость билета'}, isMayor)
end)

local tag = 'Lockdown'

surface.CreateFont(tag, {size = ( ScrW() ) / 35 })
surface.SetFont(tag) -- for correct positioning

local text = L'lockdown'
local w, h = surface.GetTextSize(text)
local x, y = ScrW() / 2 - w / 2, ScrH() - h

local function Paint()
	surface.SetTextPos(x, y)
	surface.SetTextColor(HSVToColor(355, 0.9, math.Clamp((1 + math.sin(CurTime() * 2)) / 2, 0.5, 0.9)))
	surface.SetFont(tag)
	surface.DrawText(text)
end

local function Stop()
	hook.Remove('HUDPaint', tag)
end

local function Start()
	sound.Play('ambient/alarms/warningbell1.wav', LocalPlayer():GetPos(), 60)
	hook.Add('HUDPaint', tag, Paint)
end

net.Receive(tag,function()
	if net.ReadBool() then
		Start()
	else
		Stop()
	end
end)