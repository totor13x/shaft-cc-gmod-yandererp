local tag = 'Lockdown'
util.AddNetworkString(tag)

local Cooldown = 0
local Delay = 10 * 60 --How long lockdown will last in seconds - _-
GM.LockDown = false

local function Send(ply, bool)
	Cooldown = CurTime()
	net.Start(tag)
	net.WriteBool(bool)
	net.Send(ply)
end

local function Stop()
	if GAMEMODE.LockDown then
		GAMEMODE.LockDown = false
		Send(player.GetAll(), false)

		GAMEMODE:ChatPrint(Color(255, 255, 0), L'lockdown_end')

		hook.Remove('PlayerFullyLoaded', tag)
	end
end

local function Start()
	GAMEMODE.LockDown = true
	Send(player.GetAll(), true)
	timer.Simple(Delay, Stop)

	GAMEMODE:ChatPrint(Color(255, 255, 0), L'lockdown_start')

	hook.Add('PlayerFullyLoaded', tag, function(ply)
		Send(ply, true)
	end)
end

GM:AddCommand('lockdown', function(ply)
	if not ply:IsMayor() then
		GAMEMODE:Error(ply, 'not_allowed')
		return
	end

	if not GAMEMODE.LockDown then
		Start()
	end
end)

GM:AddCommand('unlockdown', function(ply) 
	if not ply:IsMayor() then
		GAMEMODE:Error(ply, 'not_allowed')
		return
	end

	if GAMEMODE.LockDown then
		Stop()
	end
end)

local cooldown = 0
GM:AddCommand('lottery', function(mayor, _, arg)
	if not mayor:IsMayor() then
		GAMEMODE:Error(mayor, 'not_allowed')
		return
	end
	
	if CurTime() < cooldown then
		GAMEMODE:Error(mayor, 'Лотерею нельзя проводить так часто!')
		return
	end
	
	local text = "Мэр " .. mayor:GetName() .. " запускает лотерею!"
	GAMEMODE:Notify(player.GetAll(), text)
	GAMEMODE:ChatPrint(text)
	
	cooldown = CurTime() + 600
	
	arg = tonumber(arg)
	if not arg or arg > 10000 or arg < 50 then 
		GAMEMODE:Error(mayor, 'Стоимость участия в лотерее: 100-10000!')
		return 
	end

	hook.Call('PlayerStartedLottery', GAMEMODE, mayor, arg)
	
	GAMEMODE:Lottery(function(ply, amt)
		if ply:IsMayor() then 
			GAMEMODE:Error(ply, 'Мэр не может участвовать!')
			return false 
		end 
		
		if not ply:canAfford(amt) then 
			GAMEMODE:Error(ply, 'У вас не хватает денег чтобы участвовать в лотерее')
			return false 
		end 
		
		ply:addMoney(-amt)
		return true
	end, function(ply, amt)
		local winamt = math.floor(amt * 0.8)
		ply:addMoney(winamt)
		ply:ChatPrint('Вы получили ' .. winamt .. ' йен после вычета комиссии')
		local com = math.floor(amt * 0.02)
		mayor:addMoney(com)
		mayor:ChatPrint('Вы получили ' .. com .. ' йен с комиссии')
	end, arg)
end)

local mayor_color = Color(128, 128, 255)
GM:AddCommand('broadcast', function(ply, _, str)
	if not ply:IsMayor() then
		GAMEMODE:Error(mayor, 'not_allowed')
		return
	end

	hook.Call('PlayerBroadcast', GAMEMODE, ply, str)

	GAMEMODE:ChatPrint(
		mayor_color, '[Оповещение от мэра] ',
		ply,
		color_white, ': ' .. str
	)
end)

hook.Add('PlayerDeath', 'MayorDeath', function(ply, inflictor, attacker)
	if ply:IsMayor() then
		if IsValid(attacker) and attacker ~= ply and attacker:IsPolice() then 
			attacker:ChangeTeam(GAMEMODE.DefaultTeam, true)
			GAMEMODE:Wanted(L'president', attacker, L'killing_mayor')
		end
		
		ply:ChangeTeam(GAMEMODE.DefaultTeam, true)	
	end
end)