timer.Simple(0.8, function() -- crap fix
GAMEMODE:DescribeCommand('wanted', 'Объявить в розыск', {L'player', L'reason'}, function() 
	local tm = LocalPlayer():Team() 
	return tm == TEAM_MAYOR or tm == TEAM_POLICE_CHIEF 
end)
end)