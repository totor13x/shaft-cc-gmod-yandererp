function GM:Wanted(ply_name, target, reason)
	target.wanted = true
	target:SetNWString('wanted_reason', reason)
	GAMEMODE:ChatPrint(Color(80, 110, 255), L'police', Color(255, 255, 255), L('wanted', ply_name, target:GetName()), Color(255, 150, 150), '"' .. reason .. '".')

	timer.Create(target:SteamID() .. 'wanted_timer', GAMEMODE.Settings.wanted_time * 60, 1, function()
		GAMEMODE:NotWanted(target)
	end)
end

function GM:NotWanted(target) 
	if target and target.wanted and IsValid(target) then
		target.wanted = nil
		target:SetNWString('wanted_reason', '')
		GAMEMODE:ChatPrint(Color(80, 110, 255), L'police', Color(255, 255, 255), L('not_wanted', target:GetName()))
	end
end

GM:AddCommand('wanted', function(ply, args, argstr) 
	local target = GAMEMODE.FindEntity(args[1])
	
	if not target:IsPolice() then
		GAMEMODE:Error(ply, 'not_allowed')
		return
	end

	if not IsValid(target) or not target:IsPlayer() or target:IsPolice() then
		GAMEMODE:Error(ply, L('wrong_argument', args[1]))
		return
	end
	
	hook.Call('PlayerWanted', GAMEMODE, target, ply)

	GAMEMODE:Wanted(ply:GetName(), target, string.sub(argstr, #args[1] + 2) or L'no_reason')
end)
