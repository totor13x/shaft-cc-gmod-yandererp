local database_table = "rp_doors_" .. game.GetMap()

if not sql.TableExists(database_table) then
	sql.Query('CREATE TABLE ' .. database_table .. ' (id int, grp string)')
end

local doorid = function(ent)
	ent.doorid = ent.doorid or math.floor(ent:GetPos().x + ent:GetPos().y + ent:GetPos().z)
	return ent.doorid
end

local function doors()
	for _, class in ipairs(table.GetKeys(GAMEMODE.door_classes)) do
		for _, ent in ipairs(ents.FindByClass(class)) do
			local id = doorid(ent)
			local group = sql.QueryValue('SELECT grp FROM ' .. database_table .. ' WHERE id = ' .. id)
			if group then
				ent:SetNWBool('door_canbuy', false)
				if GAMEMODE.DoorGroups[group] then
					ent:SetNWString('door_group', group)
				end
			else
				ent:SetNWBool('door_canbuy', true)
			end
		end
	end
end

hook.Add('PostCleanupMap', 'doors', doors)
hook.Add('InitPostEntity', 'doors', doors)

GM:AddCommand('door', function(ply, args)
	local ent = ply:GetEyeTrace().Entity

	if IsValid(ent) and GAMEMODE.isDoor(ent) and ent:GetNWBool('door_canbuy') then
		if ent:GetPos():DistToSqr(ply:GetPos()) > 10000 then
			GAMEMODE:Error(ply, 'distance_too_big')
			return
		end

		local owner = ent:GetNWEntity('door_owner')
		local cost = GAMEMODE.Settings.door_cost
		if not IsValid(owner) then
			local doors_count = 0
			for _, class in ipairs(table.GetKeys(GAMEMODE.door_classes)) do
				for _, ent in ipairs(ents.FindByClass(class)) do
					if ent:GetNWEntity('door_owner') == ply then
						doors_count = doors_count + 1
					end
				end
			end

			if doors_count >= GAMEMODE.Settings.max_doors then
				GAMEMODE:Error(ply, {'limit_reached', 'doors'})
				return
			end

			if ply:CanAfford(cost) then
				ent:SetNWEntity('door_owner', ply)
				GAMEMODE:Notify(ply, {'door_bought', DarkRP.formatMoney(cost)})
				ply:AddMoney(-cost)
			else
				GAMEMODE:Error(ply, 'cant_afford')
			end
		elseif owner == ply then
			local money = math.floor(cost/2)
			ent:SetNWEntity('door_owner', NULL)
			GAMEMODE:Notify(ply, {'door_sold', DarkRP.formatMoney(money)})
			ply:AddMoney(money)
			ent:Fire('Unlock')
		end
	end
end)

GM:AddCommand('doorgroup', function(ply, args, argstr)
	if not ply:IsSuperAdmin() then
		GAMEMODE:Error(ply, 'not_allowed')
		return
	end

	local ent = ply:GetEyeTrace().Entity

	local group = GAMEMODE.DoorGroups[argstr]
	if IsValid(ent) and GAMEMODE.isDoor(ent) and group then
		ent:SetNWBool('door_canbuy', false)
		ent:SetNWEntity('door_owner', NULL)
		ent:SetNWString('door_group', argstr)
		ent:Fire('Unlock')
		
		local id = doorid(ent)
		local group = sql.Query('SELECT * FROM ' .. database_table .. ' WHERE id = ' .. id)
		if group then
			sql.Query('UPDATE ' .. database_table .. ' SET grp = ' .. SQLStr(argstr) .. ' WHERE id = ' .. id)
		else
			sql.Query('INSERT INTO ' .. database_table .. ' (id, grp) VALUES (' .. id .. ', ' .. SQLStr(argstr) .. ')')
		end
	end
end)

GM:AddCommand('doordisallow', function(ply, args)
	if not ply:IsSuperAdmin() then
		GAMEMODE:Error(ply, 'not_allowed')
		return
	end

	local ent = ply:GetEyeTrace().Entity

	if IsValid(ent) and GAMEMODE.isDoor(ent) and ent:GetNWBool('door_canbuy') then
		ent:SetNWBool('door_canbuy', false)
		ent:SetNWEntity('door_owner', NULL)
		ent:SetNWString('door_group', '')
		ent:Fire('Unlock')
		local id = doorid(ent)
		local group = sql.Query('SELECT * FROM ' .. database_table .. ' WHERE id = ' .. id)
		if group then
			sql.Query('UPDATE ' .. database_table .. ' SET grp = "" WHERE id = ' .. id)
		else
			sql.Query('INSERT INTO ' .. database_table .. ' (id, grp) VALUES (' .. id .. ', "")')
		end
	end
end)

GM:AddCommand('doorallow', function(ply, args)
	if not ply:IsSuperAdmin() then
		GAMEMODE:Error(ply, 'not_allowed')
		return
	end

	local ent = ply:GetEyeTrace().Entity

	if IsValid(ent) and GAMEMODE.isDoor(ent) and not ent:GetNWBool('door_canbuy') then
		ent:SetNWBool('door_canbuy', true)
		ent:SetNWString('door_group', '')
		ent:Fire('Unlock')
		
		sql.Query('DELETE FROM ' .. database_table .. ' WHERE id = ' .. doorid(ent))
	end
end)