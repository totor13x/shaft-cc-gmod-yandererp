GM.door_classes = {
	['func_door'] = true,
	['func_door_rotating'] = true,
	['prop_door_rotating'] = true,
	['func_movelinear'] = true,
}

GM.isDoor = function(ent)
	return GAMEMODE.door_classes[ent:GetClass()]
end

GM.DoorGroups = {}
function GM:AddDoorGroup(name, ...)
	self.DoorGroups[name] = {...}
end

AddDoorGroup = function(...)
	(GM or GAMEMODE):AddDoorGroup(...)
end