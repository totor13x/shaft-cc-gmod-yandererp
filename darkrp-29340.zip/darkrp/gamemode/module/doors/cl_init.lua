local hud_draw = function(self)
    if not self:GetNWBool('door_canbuy') then 
        local group = self:GetNWString('door_group')
        if group != '' then
            return group
        end

        return
    end
    
    local owner = self:GetNWEntity('door_owner')
    if not IsValid(owner) then
        return L'door_can_buy'
    end

    if owner == LocalPlayer() then
        return {owner:GetName(), L'door_sell'}
    else
        return owner:GetName()
    end
end

local function doors()
    timer.Simple(1, function()
        for _, class in ipairs(table.GetKeys(GAMEMODE.door_classes)) do
            for _, ent in ipairs(ents.FindByClass(class)) do
                ent.RPHUDDraw = hud_draw
            end
        end
    end)
end

hook.Add('PostCleanupMap', 'doors', doors)
hook.Add('InitPostEntity', 'doors', doors)

hook.Add('NetworkEntityCreated', 'doors', function(ent)
	if GAMEMODE.door_classes[ent:GetClass()] then
		ent.RPHUDDraw = hud_draw
	end
end)