net.Receive('prop_damage', function(len, ply)
	local ent = net.ReadEntity()
	local hp = net.ReadUInt(20)
	local maxhp = net.ReadUInt(20)
	
	function ent:RPHUDDraw()
		local stars = math.ceil((hp / maxhp) * 10)
		return {hp .. ' / ' .. maxhp, string.rep('⦾', stars) .. string.rep('○', 10 - stars)}
	end
	timer.Create('prop_damage_removehud' .. ent:EntIndex(), 2, 1, function()
		ent.RPHUDDraw = function()
		end
	end)
end)