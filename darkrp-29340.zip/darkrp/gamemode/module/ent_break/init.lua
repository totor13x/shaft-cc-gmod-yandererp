local function prop_health_calc(ent)
	return math.Clamp(math.ceil(math.sqrt(ent:GetPhysicsObject():GetMass() * 1000)), 100, 2500)
end

local ENTITY = FindMetaTable('Entity')

function ENTITY:MakeBreakable(t)
    if not IsValid(self:GetPhysicsObject()) then return end

    t = t or {}

    t.health = t.health or prop_health_calc(self)
    t.maxhealth = t.maxhealth or t.health

    self.breakable = t
end

util.AddNetworkString('prop_damage')
hook.Add('PlayerSpawnedProp', 'PropSetHealth', function(ply, mdl, ent)
	if ent:GetClass() == "prop_physics" and ent:Health() == 0 then 
		ent:MakeBreakable({
			ondamage = function(ent, att)
				if att:IsPlayer() then
					local t = ent.breakable
					net.Start('prop_damage')
						net.WriteEntity(ent)
						net.WriteUInt(t.health, 20)
						net.WriteUInt(t.maxhealth, 20)
					net.Send(att)	
				end
			end
		})
	end
end)

hook.Add('EntityTakeDamage', 'PropTakeDamage', function(ent, dmginfo)
    local t = ent.breakable
    if istable(t) then
		local damage = math.Clamp(dmginfo:GetDamage(), 10, t.health)
		
		t.health = t.health - damage

		local att = dmginfo:GetAttacker()
		
		if t.ondamage then 
			t.ondamage(ent, att)
		end

		if not t.nocolor then
			local color = ent:GetColor()
			local hue, saturation = ColorToHSV(Color(color.r, color.g, color.b))
			ent:SetColor(HSVToColor(hue, saturation, t.health / t.maxhealth))
		end
		
		--if type(dmginfo:GetAttacker()) == 'Player' then 
		--	dmginfo:GetAttacker():PrintMessage(HUD_PRINTCENTER, mL('Прочность: ', 'Durability: ') .. ent.PropHealth .. ' / ' .. ent.MaxPropHealth)
		--end
		
		local effectdata = EffectData()
		effectdata:SetOrigin(ent:GetPos() + ent:OBBCenter())
		if t.health <= 0 then
			if t.onbreak then 
				t.onbreak(ent, att)
			end

			if t.explode then
				ent:Ignite(1000)
				util.Effect("Explosion", effectdata)
			else
				util.Effect("HunterDamage", effectdata)
			end
            
			ent:Remove()
		end
	end
end)