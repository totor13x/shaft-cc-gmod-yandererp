local enabled = false
local changed = 0

hook.Add('PlayerButtonDown', 'Third', function(me, butt)
	if (butt == KEY_LALT and input.IsKeyDown(KEY_LSHIFT)) 
		or 
		(butt == KEY_LSHIFT and input.IsKeyDown(KEY_LALT))
	then
		if SysTime() - changed > 0.2 then
			enabled = not enabled
			changed = SysTime()
		end
	end
end)

local t = {}
local e = FindMetaTable('Entity')

hook.Add('CalcView', 'Third', function(me, orig, ang, fov, znear, zfar)
	if enabled then
		local fwd = ang:Forward()
		util.TraceLine({
			start = orig, 
			endpos = orig - fwd * (me:InVehicle() and 200 or 155), 
			mask = MASK_SOLID_BRUSHONLY,
			output = t
		})

		local farz = GAMEMODE.Settings.zfar or 2000
		if farz == 0 then
			farz = zfar
		end

		return {origin = t.HitPos + fwd * 45, angles = ang, zfar = farz, drawviewer = true}
	end
end)