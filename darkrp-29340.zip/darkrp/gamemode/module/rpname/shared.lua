local PLAYER = FindMetaTable('Player')

if not PLAYER.RealName then
    PLAYER.RealName = PLAYER.GetName
    PLAYER.RealNick = PLAYER.GetName
    
    function PLAYER:GetName()
        return self:GetNWString('rpname')
    end

    PLAYER.Nick = PLAYER.GetName
    PLAYER.Name = PLAYER.GetName
end