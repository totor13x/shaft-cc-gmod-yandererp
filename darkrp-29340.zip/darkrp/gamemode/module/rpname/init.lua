if not sql.TableExists('rpname') then
	sql.Query('CREATE TABLE rpname (SteamID string, Name string)')
end

local cyrillic = {
[1072] = true,
[1073] = true,
[1074] = true,
[1075] = true,
[1076] = true,
[1077] = true,
[1105] = true,
[1078] = true,
[1079] = true,
[1080] = true,
[1081] = true,
[1082] = true,
[1083] = true,
[1084] = true,
[1085] = true,
[1086] = true,
[1087] = true,
[1088] = true,
[1089] = true,
[1090] = true,
[1091] = true,
[1092] = true,
[1093] = true,
[1094] = true,
[1095] = true,
[1096] = true,
[1097] = true,
[1098] = true,
[1099] = true,
[1100] = true,
[1101] = true,
[1102] = true,
[1103] = true,
[1040] = true,
[1041] = true,
[1042] = true,
[1043] = true,
[1044] = true,
[1045] = true,
[1025] = true,
[1046] = true,
[1047] = true,
[1048] = true,
[1049] = true,
[1050] = true,
[1051] = true,
[1052] = true,
[1053] = true,
[1054] = true,
[1055] = true,
[1056] = true,
[1057] = true,
[1058] = true,
[1059] = true,
[1060] = true,
[1061] = true,
[1062] = true,
[1063] = true,
[1064] = true,
[1065] = true,
[1066] = true,
[1067] = true,
[1068] = true,
[1069] = true,
[1070] = true,
[1071] = true,
[32] = true,
}

function GM:ChangeRPName(ply, argstr)
	local name = sql.QueryValue('SELECT Name FROM rpname WHERE SteamID = ' .. SQLStr(ply:SteamID()))
	if name then
		sql.Query('UPDATE rpname SET Name = ' .. SQLStr(argstr) .. ' WHERE SteamID = ' .. SQLStr(ply:SteamID()))
	else
		sql.Query('INSERT INTO rpname (SteamID, Name) VALUES (' .. SQLStr(ply:SteamID()) .. ', ' .. SQLStr(argstr) .. ')')
	end

	ply:SetNWString('rpname', argstr)
end

local function rpname(ply, args, argstr)
	if not isstring(argstr) then
		GAMEMODE:Error(ply, {'wrong_argument', argstr and tostring(argstr) or 'nil'})
		return
	end

	local len = utf8.len(argstr)

	if len < 2 or len > 32 then
		GAMEMODE:Error(ply, 'name_invalid_length')
		return
	end

	for k, c in utf8.codes(argstr) do
		if (c < 65 or c > 122 or (c > 90 and c < 97)) and not cyrillic[c] then
			GAMEMODE:Error(ply, 'name_invalid_symbol' .. '(' .. utf8.char(c) .. ')')
			return
		end
	end

	GAMEMODE:ChangeRPName(ply, argstr)
	GAMEMODE:Notify(ply, 'RP имя изменено!')
end

local function admin_rpname(ply, args, argstr)
	if ply:IsSuperAdmin() then
		local target = GAMEMODE.FindEntity(args[1])

		if not IsValid(target) then 
			GAMEMODE:Error(ply, L('wrong_argument', args[1]))
			return 
		end

		argstr = argstr:sub(args[1]:len() + 2, argstr:len())

		GAMEMODE:ChangeRPName(target, argstr)
		GAMEMODE:Notify(ply, 'RP имя изменено!')
	end
end
hook.Add('PlayerInitialSpawn', 'RPName', function(ply)
	local name = sql.QueryValue('SELECT Name FROM rpname WHERE SteamID = ' .. SQLStr(ply:SteamID()))

	ply:SetNWString('rpname', name or ply:RealName())
end)

GM:AddCommand('name',  rpname)
GM:AddCommand('rpname',  rpname)
GM:AddCommand('forcerpname', admin_rpname)
GM:AddCommand('changerpname', admin_rpname)
