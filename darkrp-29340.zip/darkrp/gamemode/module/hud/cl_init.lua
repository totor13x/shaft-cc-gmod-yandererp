local hide = {
	["CHudHealth"] = true,
	["CHudBattery"] = true
}

function GM:HUDShouldDraw(name)
	if hide[name] then return false end
	return true
end

local ScrW, ScrH = ScrW(), ScrH()
local bar_wide = 256
local bar_tall = 26

local x, y, w, h, hp, maxhp, hunger, lp, aim_ent
local aim_alpha = 0

local can_hear = {}
local chat_opened = false 
local voice_speaking = false

local blur
local blur_intensity = 0
local drawblur = function(x, y, w, h, alpha)
	if not blur then
		blur = Material("pp/blurscreen")
	end
	
	local new_intensity = math.min(math.Round(alpha/25, 1), 4)
	if blur_intensity ~= new_intensity then
		blur_intensity = new_intensity
		blur:SetFloat("$blur", blur_intensity)
		blur:Recompute()
	end

	surface.SetDrawColor(255, 255, 255, alpha)
	surface.SetMaterial(blur)
	render.SetScissorRect(x, y, x + w, y + h, true)
	surface.DrawTexturedRect(0, 0, ScrW, ScrH)
	render.SetScissorRect( 0, 0, 0, 0, false )	
end

GM.custom_hud = GM.custom_hud or {}

local meta = FindMetaTable('Player')
local GetActiveWeapon = meta.GetActiveWeapon
hook.Add('HUDPaint', 'HUD', function()
	if not IsValid(lp) then return end

	local wep = GetActiveWeapon(lp)
	if IsValid(wep) and wep:GetClass() == 'gmod_camera' then
		return
	end

	if GAMEMODE.custom_hud.main then
		GAMEMODE.custom_hud.main(lp)
	else
		hp = lp:Health()
		maxhp = lp:GetMaxHealth()

		x, y, w, h = bar_tall, ScrH - bar_tall * 2, bar_wide * math.Clamp(hp/maxhp, 0, 1), bar_tall
		surface.SetDrawColor(16, 24, 32, 200)
		surface.DrawRect(x - 1, y - 1, bar_wide + 2, h + 2)
		surface.SetDrawColor(140, 32, 64)
		surface.DrawRect(x, y, w, h)

		hunger = lp:GetCSVar('Hunger', 0)
		x, y, w, h = bar_tall, ScrH - bar_tall * 3.5, bar_wide * (hunger/100), bar_tall

		surface.SetDrawColor(16, 24, 32, 200)
		surface.DrawRect(x - 1, y - 1, bar_wide + 2, h + 2)
		surface.SetDrawColor(140, 100, 32)
		surface.DrawRect(x, y, w, h)

		--if lp.GetMoney then
		surface.SetFont('Trebuchet24')
		surface.SetTextColor(32, 200, 64)
		surface.SetTextPos(bar_tall, ScrH - 128)
		surface.DrawText(GAMEMODE.formatMoney(lp:GetMoney()))
		--end
	end

	-- entity

	if IsValid(aim_ent) and aim_alpha > 0 then
		local text, pos = aim_ent:RPHUDDraw()
		if text then
			surface.SetFont('nunito24b')
			surface.SetTextColor(230, 230, 230, aim_alpha)
			pos = pos or aim_ent:WorldSpaceCenter() + Vector(0, 0, 10)

			local screen_vec = pos:ToScreen()
			screen_vec.x = math.floor(screen_vec.x)
			screen_vec.y = math.floor(screen_vec.y)
			local color = Color(58, 66, 78, math.min(160, aim_alpha))

			if isstring(text) then
				local tw, th = surface.GetTextSize(text)
				local x, y = screen_vec.x - tw/2, screen_vec.y - th/2
				tw = tw + 8

				drawblur(x - 4, y - 4, tw + 8, th + 8, aim_alpha)
				draw.RoundedBox(4, x - 4, y - 4, tw + 8, th + 8, color)

				surface.SetTextPos(x, y)
				surface.DrawText(text)
			elseif istable(text) then
				local full_w, full_h = 0, 0
				local tw, th
				local drawtext = {}
				for i, line in ipairs(text) do
					if istable(line) then
						drawtext[i] = line
					else
						tw, th = surface.GetTextSize(line)
						if tw > full_w then
							full_w = tw + 8
						end

						full_h = full_h + th

						drawtext[i] = screen_vec.x - tw/2
					end
				end

				local x, y = screen_vec.x - full_w/2, screen_vec.y - full_h/2

				drawblur(x - 4, y - 4, full_w + 8, full_h + 8, aim_alpha)
				draw.RoundedBox(4, x - 4, y - 4, full_w + 8, full_h + 8, color)

				local i = 0
				for k, dt in ipairs(drawtext) do
					if istable(dt) then
						surface.SetTextColor(dt.r, dt.g, dt.b, aim_alpha)
					else
						surface.SetTextPos(dt, y + th * i)
						surface.DrawText(text[k])
						i = i + 1
					end
				end
			end
			aim_alpha = aim_alpha - FrameTime() * 300
		end
	end

	-- chat can hear
	if chat_opened or voice_speaking then
		local x, y = chat.GetChatBoxPos()
		local w, h = chat.GetChatBoxSize()

		surface.SetFont('ChatFont')
		local text = #can_hear > 0 and L'players_can_hear' or L'noone_can_hear'

		-- player list

		local tw, th = surface.GetTextSize(text)
		
		surface.SetDrawColor(32, 32, 32, 220)
		surface.DrawRect(x, y - th - 8, tw + 8, th + 8)
		surface.SetTextPos(x + 4, y - th - 4)
		surface.SetTextColor(220, 220, 220)
		surface.DrawText(text)
		
		surface.SetTextColor(240, 240, 240)
		for i, ply in ipairs(can_hear) do
			surface.SetTextPos(x + 4, y - (i + 1) * th - 8)
			surface.DrawText(ply)
		end
	end
end)

timer.Create('hud_aim_ent', 0.1, 0, function()
	local lp = LocalPlayer()
	if IsValid(lp) then
		local ent = lp:GetEyeTrace().Entity
		if ent and ent.RPHUDDraw and ent:GetPos():DistToSqr(lp:EyePos()) < 250000 then
			aim_ent = ent
			aim_alpha = 400
		end
	end
end)

function GM:HUDDrawTargetID()
end

function GM:DrawDeathNotice()
end

do

	local _Player = FindMetaTable('Player')
	local _Entity = FindMetaTable('Entity')
	local team_GetColor = team.GetColor
	local team_GetName = team.GetName
	
	local Team, GetNWInt, GetNWString, GetShootPos = _Player.Team, _Entity.GetNWInt, _Entity.GetNWString, _Player.GetShootPos
	
	local height_rphud = Vector(0, 0, 15)
	local wanted_color = Color(255, 150, 150)
	local name_color = Color(220, 220, 220)
	function _Player:RPHUDDraw()
		local tm = Team(self)
		local t = {self:GetName(), team_GetColor(tm), team_GetName(tm)}
	
		local afktime = GetNWInt(self, "WentAFK", 0)
		if afktime > 0 then
			table.insert(t, 1, 'AFK - ' .. GAMEMODE.secondsToClock(math.floor(CurTime() - afktime)))
		end
		
		local wanted_reason = GetNWString(self, 'wanted_reason')
		if wanted_reason ~= '' then
			table.insert(t, 1, wanted_color)
			table.insert(t, 2, 'В розыске!')
			table.insert(t, 3, name_color)
		end
	
		return t, GetShootPos(self) + height_rphud
	end

end

local distances = {
	{
		cmd = '/yell ',
		distance = 302500
	},
	{
		cmd = '/y ',
		distance = 302500
	},
	{
		cmd = '/whisper ',
		distance = 8100
	},
	{
		cmd = '/w ',
		distance = 8100
	},
}

timer.Create('canhear_calculate', 1, 0, function()
	lp = LocalPlayer()

	if IsValid(lp) then
		local distance = voice_speaking and 250000 or 90000

		if chatgui and chatgui.Chat and chatgui.Chat.ChatText then
			local text = chatgui.Chat.ChatText:GetText()

			for i, info in ipairs(distances) do 
				if isstring(text) and text:find(info.cmd) then
					distance = info.distance
				end
			end
		end

		can_hear = {}
		for k, v in ipairs(player.GetAll()) do
			if v != lp and v:GetPos():DistToSqr(lp:GetPos()) < distance and not v:GetNWBool('ls_hidden') then
				table.insert(can_hear, v:GetName())
			end
		end
	end
end)

hook.Add('StartChat', 'CanHear', function()
	chat_opened = true
end)

hook.Add('FinishChat', 'CanHear', function()
	chat_opened = false
end)

hook.Add('PlayerStartVoice', 'CanHear', function(ply)
	if ply == LocalPlayer() then
		voice_speaking = true
	end
end)

hook.Add('PlayerEndVoice', 'CanHear', function(ply)
	if ply == LocalPlayer() then
		voice_speaking = false
	end
end)