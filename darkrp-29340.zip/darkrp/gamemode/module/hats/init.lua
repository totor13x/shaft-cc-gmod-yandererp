AddCSLuaFile(GM.ModuleFolder .. 'hats/hats.lua')
include(GM.ModuleFolder .. 'hats/hats.lua')