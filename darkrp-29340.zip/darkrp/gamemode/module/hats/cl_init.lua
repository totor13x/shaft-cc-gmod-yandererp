include(GM.ModuleFolder .. 'hats/hats.lua')

local validplayermodel, att_id, att, pos, ang, addpos, hatang, ent, centhat, hatents

local function createModelEnt(t)
	local m = ClientsideModel(t.model)
	m.name = t.name
	m:SetNoDraw(true)
	if t.scale then m:SetModelScale(t.scale, 0) end
	
	return m
end

local function renderhat(ply, hat)
	validplayermodel = false
	
	if isentity(ply) then
		att_id = ply:LookupAttachment('eyes')
		if att_id then 
			att = ply:GetAttachment(att_id)
			if att then
				pos = att.Pos
				ang = att.Ang
				validplayermodel = true
			end
		end
	else
		if not IsValid(centhat) then
			centhat = ClientsideModel('models/props_combine/breenbust.mdl')
			centhat:SetNoDraw(true)
			centhat:SetMaterial('models/debug/debugwhite')
			centhat:SetPos(Vector(-4.22, 2.11, -7.37))
			centhat:SetAngles(Angle(4.92, 0, 0))
			centhat:SetModelScale(0.87, 0)
		end
		centhat:DrawModel()
	end
	
	if not validplayermodel then
		pos = Vector(0, 0, 0)
		ang = Angle()
	end
	
	addpos = hat.pos
	addpos = Vector(addpos.x, addpos.y, addpos.z)
	
	ply.hatents = ply.hatents or {}
	hatents = ply.hatents

	ent = hatents[hat]
	if not IsValid(ent) then
		ent = createModelEnt(hat)
		hatents[hat] = ent
		return ent
	end

	local customize = ply.hat_customize
	if customize then
		addpos:Add(Vector(customize[1], customize[2], customize[3]))
		if ent.custom_scale != customize[4] then
			ent:SetModelScale((hat.scale or 1) * customize[4], 0)
			ent.custom_scale = customize[4]
		end
	end
	
	addpos:Rotate(ang)
	
	pos:Add(addpos)

	hatang = hat.ang
	ang:RotateAroundAxis(ang:Right(), hatang.x)
	ang:RotateAroundAxis(ang:Up(), hatang.y)
	ang:RotateAroundAxis(ang:Forward(), hatang.z)

	ent:SetPos(pos)
	ent:SetAngles(ang)
	ent:DrawModel()
end

GM.RenderHat = renderhat

hook.Add("PostPlayerDraw", "Hats", function(ply)
	if not IsValid(ply) or not ply:Alive() or ply:GetPos():DistToSqr(EyePos()) > 90000 then return end
	
	local inv = ply.Inventory
	if inv then
		local hat = inv[-1]
		if hat and hat.hat then
			renderhat(ply, hat)
		end
	end
end)