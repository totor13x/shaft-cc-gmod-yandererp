local mat = Material('particle/particle_glow_03_additive')
local clr = Color(255, 255, 255, 200)
local dist = 150
local cnt = 4
local speed = 200
local snowstart = 1600
local snowend = -209
local size = 2
local mask = MASK_BLOCKLOS

local enabled = false

local snow
local rand = {}
local randU = 0
local collision = {}
local limitMax = true

local first = true
function ls_snow(enable, color, distance, count, flakespeed, sStart, sEnd, material, ssize, smask, limit, no_reinit)
	if not enable then 
		enabled = false
		return
	end
	
	enabled = true
	
	clr = IsColor(color) and color or clr
	dist = isnumber(distance) and distance or dist
	cnt = isnumber(count) and count or cnt
	speed = isnumber(flakespeed) and flakespeed or speed
	snowstart = isnumber(sStart) and sStart or snowstart
	snowend = isnumber(sEnd) and sEnd or snowend
	mat = material and material or mat
	size = isnumber(ssize) and ssize or size
	mask = isnumber(smask) and smask or mask
	limitMax = tobool(limit)
	
	if not no_reinit or first then
		first = false
		snow = nil
		rand = {}
		collision = {}
		for f = -cnt, cnt do
			rand[f] = {}
			for r = -cnt, cnt do
				rand[f][r] = {}
				for u = -cnt, cnt do
					rand[f][r][u] = VectorRand() * dist
				end
			end
		end
	end
end

local setmat = render.SetMaterial
local drawsprite = render.DrawSprite
local function draw_flake(pos)
	if !istable(mat) then setmat(mat) else setmat(mat[ (math.floor(pos.x) % #mat) + 1 ]) end
	drawsprite(pos, size, size, clr)
end

local lastZ = 0

local cd = 0

local trace_out = {}
hook.Add('Think', 'snow', function()
	if not enabled then return end
	
	local st = SysTime()
	if cd > st then
		return
	end
	
	cd = st + 0.03
	
	local pos = LocalPlayer():EyePos()
	local posx = math.floor(pos.x / dist)
	pos.x = posx * dist
	
	local posy = math.floor(pos.y / dist)
	pos.y = posy * dist
	
	local posz = math.floor(pos.z / dist)
	pos.z = posz * dist
	
	local z = (-st * speed) % dist
	if z > lastZ then
		randU = randU + 1
		for f = -cnt, cnt do
			for r = -cnt, cnt do
				rand[f][r][cnt + randU] = VectorRand() * dist
				rand[f][r][-cnt + randU - 1] = nil
			end
		end
	end

	for f = -cnt, cnt do
		local rf = rand[f + posx]
		if not rf then 
			rand[f + posx] = {} 
			rf = rand[f + posx]
		end
		
		for r = -cnt, cnt do
			local rr = rf[r + posy]
			if not rr then 
				rf[r + posy] = {} 
				rr = rf[r + posy]
			end
			
			for u = -cnt, cnt do
				if not rr[u + randU + posz] then
					rr[u + randU + posz] = VectorRand() * dist
				end
			end
		end
	end
	
	lastZ = z
	
	snow = {}
	
	for f = -cnt, cnt do
		snow[f] = {}
		local fv = f * dist
		for r = -cnt, cnt do
			snow[f][r] = {}
			local rv = r * dist
			
			for u = -cnt, cnt do
				snow[f][r][u] = pos + Vector(fv, rv, u * dist + z) + rand[f + posx][r + posy][u + randU + posz]
				
				local vec = snow[f][r][u]
				local cn = vec.x * 10000 + vec.y
				if not collision[cn] then
					util.TraceLine({
						start = Vector(vec.x, vec.y, snowstart),
						endpos = Vector(vec.x, vec.y, snowend),
						mask = mask,
						output = trace_out
					})
					collision[cn] = trace_out.HitPos.z
				end
			
				if vec.z < collision[cn] then
					snow[f][r][u].z = collision[cn]	
				elseif vec.z > snowstart and limitMax then
					snow[f][r][u].z = snowstart
				end
			end
		end
	end
end)

hook.Add('PostDrawOpaqueRenderables', 'snow', function()
	if not snow or not enabled then return end
	for f = -cnt, cnt do
		for r = -cnt, cnt do
			for u = -cnt, cnt do
				draw_flake(snow[f][r][u])
			end
		end
	end
end)