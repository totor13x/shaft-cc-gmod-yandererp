util.AddNetworkString('playsound')

function GM:PlaySound(snd)
	net.Start('playsound')
		net.WriteString(snd)
	net.Broadcast()
end