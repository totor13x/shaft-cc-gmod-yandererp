net.Receive('playsound', function()
	surface.PlaySound(net.ReadString())
end)