GM:AddCommand('buy', function(ply, args)
	if not GAMEMODE.Settings.can_use_buy_command then
		GAMEMODE:Error(ply, "disabled")
		return 
	end

	local id = tonumber(args[1])
	local ent = GAMEMODE.BuyEntities[id]

	if not ent then
		GAMEMODE:Error(ply, {"wrong_argument", args[1]})
		return
	end

	local can_buy = hook.Run('PlayerCanBuyEntity', ply, ent)
	if not can_buy then
		GAMEMODE:Error(ply, {"cant_buy", ent.name})
		return
	end

	local csvarname = 'buyents_' .. id
	local count = ply:GetCSVar(csvarname, 0)
	if ent.max > 0 and count >= ent.max then
		GAMEMODE:Error(ply, {"limit_reached", ent.name})
		return 
	end

	if ply.last_entity_bought then
		local diff = (ply.last_entity_bought + GAMEMODE.Settings.entity_buy_cooldown) - CurTime()
		if diff > 0 then
			GAMEMODE:Error(ply, {"wait_for", math.ceil(diff)})
			return
		end
	end

	ply.last_entity_bought = CurTime()

	if not ply:CanAfford(ent.price) then
		GAMEMODE:Error(ply, "cant_afford")
		return 
	end

	ply:AddMoney(-ent.price)

	GAMEMODE:Notify(ply, {'bought', ent.name})

	local pos = GAMEMODE.playerDropPos(ply)

	local e = ents.Create(ent.class)
	e:SetPos(pos)
	e:SetModel(ent.model)
	ent.spawn(e, ply)
	e:Spawn()
	e.buy_table_id = id
	e.rp_owner = ply
	if e.Setowning_ent then
		e:Setowning_ent(ply)
	end

	local phys = e:GetPhysicsObject()
	if phys then
		phys:Wake()
		--phys:EnableMotion(true)
	end


	ply.rp_ents = ply.rp_ents or {}
	table.insert(ply.rp_ents, e)

	ply:SetCSVar(csvarname, count + 1)

	hook.Call('playerBoughtCustomEntity', GAMEMODE, ply, ent, e, ent.price)
end)

hook.Add('PlayerDisconnected', 'rp_ents_clear', function(p)
	if p.rp_ents then
		for k, v in ipairs(p.rp_ents) do
			v:Remove()
		end
	end
end)

hook.Add('EntityRemoved', 'rp_ents_clear', function(e)
	local ply = e.rp_owner
	if ply and ply.rp_ents then
		table.RemoveByValue(ply.rp_ents, e)

		if e.buy_table_id then
			local csvarname = 'buyents_' .. e.buy_table_id
			ply:SetCSVar(csvarname, ply:GetCSVar(csvarname, 1) - 1)
		end
	end
end)

hook.Add('OnPlayerChangedTeam', 'update_f4_entities', function(p, from, to)
	if p.rp_ents then
		for k, v in ipairs(p.rp_ents) do
			if not hook.Run('PlayerCanBuyEntity', p, GAMEMODE.BuyEntities[v.buy_table_id]) then
				v:Remove()
			end
		end
	end
end)