local default_ent = {
	name = 'Entity',
	class = 'sent_ball',
	desc = L"no_desc",
	max = 1,
	model = "models/maxofs2d/cube_tool.mdl",
	can_buy = function(ply)
		return true
	end,
	price = 100,
	category = 'Default',
	spawn = function(ent)end
	-- jobs = {} or TEAM_***,
}

GM.BuyEntities = {}

function GM:CreateBuyEntity(t)
	local enttable = table.Copy(default_ent)
	table.Merge(enttable, t)

	local id = #self.BuyEntities + 1
	self.BuyEntities[id] = enttable

	return id
end

function DarkRP.createEntity(name, entity, model, price, max, command, classes, CustomCheck)
	local tableSyntaxUsed = type(entity) == "table"

	local tblEnt = tableSyntaxUsed and entity or
		{class = entity, model = model, price = price, max = max,
		cmd = command, jobs = classes, can_buy = CustomCheck}
	tblEnt.name = name
	tblEnt.class = tblEnt.ent
	tblEnt.jobs = tblEnt.jobs or tblEnt.allowed
	if tblEnt.customCheck then
		tblEnt.can_buy = tblEnt.customCheck
	end

	return (GM or GAMEMODE):CreateBuyEntity(tblEnt)
end

function DarkRP.createShipment(name, model, entity, price, Amount_of_guns_in_one_shipment, Sold_separately, price_separately, noshipment, classes, shipmodel, CustomCheck)
	local tableSyntaxUsed = type(model) == "table"

	price = tonumber(price)
	local shipmentmodel = shipmodel or "models/Items/item_item_crate.mdl"

	local customShipment = tableSyntaxUsed and model or
		{model = model, entity = entity, price = price, amount = Amount_of_guns_in_one_shipment,
		seperate = Sold_separately, pricesep = price_separately, noship = noshipment, allowed = classes,
		shipmodel = shipmentmodel, customCheck = CustomCheck, weight = 5}

	customShipment.name = name
	customShipment.shipmodel = customShipment.shipmodel or shipmentmodel

	DarkRP:CreateBuyEntity({
		name = name,
		class = 'spawned_shipment',
		max = 1,
		model = customShipment.model,
		spawn = function(e, ply)
			e.SID = ply.SID
			e:SetModel(customShipment.shipmodel)
			e.wepclass = customShipment.entity
			e:SetWModel(customShipment.model)
			e:SetWName(name)
			e:SetCount(customShipment.amount)
			e:Spawn()
			e:SetPlayer(ply)
		end,
		price = customShipment.price,
		jobs = customShipment.allowed,
		category = L'shipments',
	})

	util.PrecacheModel(customShipment.model)
end

function GM:PlayerCanBuyEntity(ply, ent)
	if not ent then return true end
	if ent.can_buy and not ent.can_buy(ply) then
		return false
	end

	if ent.jobs then
		if istable(ent.jobs) then
			if not table.HasValue(ent.jobs, ply:Team()) then
				return false
			end
		elseif ent.jobs != ply:Team() then
			return false
		end
	end
	
	return true
end

if GM.Settings.default_entities then
	include(GM.ConfigFolder .. 'entities.lua')
end

hook.Add('PostGamemodeLoaded', 'BuyEntities', function()
	hook.Remove('PostGamemodeLoaded', 'BuyEntities')
	hook.Call('RP_CustomEnts', GAMEMODE)
end)