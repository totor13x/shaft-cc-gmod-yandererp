local update_avaliable_ents = function()
    local f4 = GAMEMODE.F4Menu
    if IsValid(f4) and f4.ent_items then
    	local parents = {}
        for i, item in ipairs(f4.ent_items) do
            local can_buy = hook.Run('PlayerCanBuyEntity', LocalPlayer(), GAMEMODE.BuyEntities[i])
            
            local cat = item:GetParent()
            parents[cat] = parents[cat] or 0
            
            if not can_buy then
                item:Hide()
            else
                item:Show()
                
                
                parents[cat] = parents[cat] + 1
            end

            local parent = item:GetParent():GetParent()
            parent:PositionItems()
            parent:InvalidateLayout()
        end
        
        for k, v in pairs(parents) do
	        if v == 0 then
	        	k:GetParent():Hide()
	        else
	        	k:GetParent():Show()
	        end
        end
    end
end

hook.Add('f4menu_onload', 'entities_tab', function(f4)
    f4:AddTab(L'entities', function(p)
        f4.ent_items = {}

        local ents_page = vgui.Create('f4_select_page', p)
        ents_page:SetSize(p:GetSize())
        ents_page.button_click = function(self, i)
            RunConsoleCommand('rp', 'buy', i)
        end
        ents_page.item_created = function(item, i)
            if i == 1 then
                item:DoClick() 
            end

            item.count = LocalPlayer():GetCSVar('buyents_' .. i, 0)

            f4.ent_items[i] = item

            local can_buy = hook.Run('PlayerCanBuyEntity', LocalPlayer(), GAMEMODE.BuyEntities[i])
            if not can_buy then
                item:Hide()
            end
        end
        ents_page.setup_camera = function(pm)
            pm:SetCamPos(Vector(100, 0, 30))
            pm:SetLookAt(Vector(0, 0, 10))
            pm:SetFOV(30)
        end
        ents_page.items_table = GAMEMODE.BuyEntities
        ents_page.button_text = L"buy"

        ents_page:Create()
        
        update_avaliable_ents()
    end)
end)

hook.Add('OnPlayerChangedTeam', 'update_f4_entities', function(ply)
    if ply == LocalPlayer() then
        timer.Simple(0.5, function() update_avaliable_ents() end)
    end
end)

hook.Add('CSVarChanged', 'update_f4_entities', function(csvar, old, new)
    if csvar:sub(1, 8) == 'buyents_' then
        local id = tonumber(csvar:sub(9))
        if id then
            local f4 = GAMEMODE.F4Menu

            if IsValid(f4) and f4.ent_items then
                local item = f4.ent_items[id]
                if item then
                    item.count = new
                end
            end
        end
    end
end)
