util.AddNetworkString('rp_chatprint')
util.AddNetworkString('rp_chatprint_complex')
util.AddNetworkString('rp_notifications')
util.AddNetworkString('rp_notifications_complex')
util.AddNetworkString('AddText') //

function GM:Notify(ply, str, notify_type)
	if istable(str) then
		net.Start('rp_notifications_complex')
			net.WriteUInt(notify_type or 0, 3)
			net.WriteTable(str)
		net.Send(ply)
	else
		net.Start('rp_notifications')
			net.WriteUInt(notify_type or 0, 3)
			net.WriteString(str)
		net.Send(ply)
	end
end

function GM:Error(ply, str)
	self:Notify(ply, str, 1)
end

function GM:Hint(ply, str)
	self:Notify(ply, str, 3)
end

function GM:ChatPrint(...)
	self:ChatPrintTo(player.GetAll(), ...)
end

function GM:ChatPrintTo(players, ...)
	local t = {...}
	if #t > 1 then
		net.Start('rp_chatprint_complex')
			net.WriteTable(t)
		net.Send(players)
	else
		net.Start('rp_chatprint')
			net.WriteString(tostring(t[1]))
		net.Send(players)
	end
end

