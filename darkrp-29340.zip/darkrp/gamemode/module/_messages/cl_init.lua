net.Receive('rp_notifications', function()
	local notify_type = net.ReadUInt(3)
	local str = net.ReadString()
	
	GAMEMODE:Notify(L(str), notify_type)
end)

net.Receive('rp_notifications_complex', function()
	local notify_type = net.ReadUInt(3)
	local t = net.ReadTable()
	local str = t[1]
	table.remove(t, 1)

	for k, v in ipairs(t) do
		t[k] = L(v)
	end

	GAMEMODE:Notify(L(str, unpack(t)), notify_type)
end)

function GM:Notify(str, notify_type)
	notification.AddLegacy(str, notify_type or NOTIFY_GENERIC, 5)
	surface.PlaySound("buttons/button15.wav")
end

function GM:Error(str)
	self:Notify(str, 1)
end

function GM:Hint(str)
	self:Notify(str, 3)
end

net.Receive('rp_chatprint', function()
	local str = net.ReadString()
	
	chat.AddText(color_white, L(str))
end)

net.Receive('rp_chatprint_complex', function()
	local t = net.ReadTable()
	for k, v in ipairs(t) do
		if isstring(v) then
			t[k] = L(v)
		end
	end

	chat.AddText(unpack(t))
end)