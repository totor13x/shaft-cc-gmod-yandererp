surface.CreateFont( "ScoreboardDefault", {
	font	= "Helvetica",
	size	= 22,
	weight	= 800,
	extended = true
} )

surface.CreateFont( "ScoreboardDefaultTitle", {
	font	= "Nunito Black",
	size	= 32,
	weight	= 900,
	extended = true,
} )

local premium_mat = Material('icon16/star.png')
local admin_mats = {
	['#admin'] = Material('icon16/user_green.png'),
	['@admin'] = Material('icon16/user_orange.png'),
	['admin'] = Material('icon16/user_red.png'),
	['superadmin'] = Material('icon16/user_gray.png'),
}

--
-- This defines a new panel type for the player row. The player row is given a player
-- and then from that point on it pretty much looks after itself. It updates player info
-- in the think function, and removes itself when the player leaves the server.
--

local mouse_pressed

local PLAYER_LINE = {
	Init = function( self )

		self.AvatarButton = self:Add( "DButton" )
		self.AvatarButton:Dock( LEFT )
		self.AvatarButton:SetSize( 32, 32 )
		self.AvatarButton.DoClick = function() self.Player:ShowProfile() end

		self.Avatar = vgui.Create( "AvatarImage", self.AvatarButton )
		self.Avatar:SetSize( 32, 32 )
		self.Avatar:SetMouseInputEnabled( false )

		self.Name = self:Add( "DLabel" )
		self.Name:Dock( LEFT )
		self.Name:SetWidth( 250 )
		self.Name:SetFont( "ScoreboardDefault" )
		self.Name:SetTextColor( Color( 240, 240, 240 ) )
		self.Name:DockMargin( 8, 0, 0, 0 )
		self.Name:SetMouseInputEnabled( false )

		self.Team = self:Add( "DLabel" )
		self.Team:Dock( FILL )
		self.Team:SetFont( "ScoreboardDefault" )
		self.Team:SetTextColor( Color( 240, 240, 240 ) )
		self.Team:DockMargin( 0, 0, 0, 0 )
		self.Team:SetContentAlignment( 5 )
		self.Team:SetMouseInputEnabled( false )

		self.Mute = self:Add( "DImageButton" )
		self.Mute:SetSize( 32, 32 )
		self.Mute:Dock( RIGHT )

		self.Ping = self:Add( "DLabel" )
		self.Ping:Dock( RIGHT )
		self.Ping:SetWidth( 50 )
		self.Ping:SetFont( "ScoreboardDefault" )
		self.Ping:SetTextColor( Color( 240, 240, 240 ) )
		self.Ping:SetContentAlignment( 5 )
		self.Ping:SetMouseInputEnabled( false )

		self.Money = self:Add( "DLabel" )
		self.Money:Dock( RIGHT )
		self.Money:SetWidth( 140 )
		self.Money:SetFont( "ScoreboardDefault" )
		self.Money:SetTextColor( Color( 240, 240, 240 ) )
		self.Money:SetContentAlignment( 5 )
		self.Money:SetMouseInputEnabled( false )

		self:Dock( TOP )
		self:DockPadding( 3, 3, 3, 3 )
		self:SetHeight( 32 + 3 * 2 )
		self:DockMargin( 2, 0, 2, 2 )
		self:SetMouseInputEnabled( true )
	end,

	Setup = function( self, pl )

		self.Player = pl

		self.Avatar:SetPlayer( pl )

		self:Think( self )

		--local friend = self.Player:GetFriendStatus()
		--MsgN( pl, " Friend: ", friend )

	end,

	Think = function( self )
		if ( !IsValid( self.Player ) ) then
			self:SetZPos( 9999 ) -- Causes a rebuild
			self:Remove()
			return
		end

		if ( self.PName == nil || self.PName != self.Player:Nick() ) then
			self.PName = self.Player:Nick()
			self.Name:SetText( self.PName )
		end
		
		if ( self.PTeam == nil || self.PTeam != self.Player:Team() ) then
			self.PTeam = self.Player:Team()
			self.Team:SetText( team.GetName( self.Player:Team() ) )
		end
		
		local money = self.Player:GetMoney() + self.Player:GetNWInt('bank_money', 0)
		if ( self.NumMoney == nil || self.NumMoney != money ) then
			self.NumMoney = money
			self.Money:SetText( DarkRP.formatMoney( money ) )
		end

		if ( self.NumPing == nil || self.NumPing != self.Player:Ping() ) then
			self.NumPing = self.Player:Ping()
			self.Ping:SetText( self.NumPing )
		end

		--
		-- Change the icon of the mute button based on state
		--
		if ( self.Muted == nil || self.Muted != self.Player:IsMuted() ) then

			self.Muted = self.Player:IsMuted()
			if ( self.Muted ) then
				self.Mute:SetImage( "icon32/muted.png" )
			else
				self.Mute:SetImage( "icon32/unmuted.png" )
			end

			self.Mute.DoClick = function() self.Player:SetMuted( !self.Muted ) end

		end

		--
		-- Connecting players go at the very bottom
		--
		if ( self.Player:Team() == TEAM_CONNECTING ) then
			self:SetZPos( 32000 + self.Player:EntIndex() )
			return
		end

		--
		-- This is what sorts the list. The panels are docked in the z order,
		-- so if we set the z order according to kills they'll be ordered that way!
		-- Careful though, it's a signed short internally, so needs to range between -32,768k and +32,767
		--
		self:SetZPos(self.Player:Team())

		if mouse_pressed == self and not self:IsHovered() then
			mouse_pressed = nil
		end

	end,

	Paint = function( self, w, h )

		if ( !IsValid( self.Player ) ) then
			return
		end

		--
		-- We draw our background a different colour based on the status of the player
		--

		local color = team.GetColor( self.Player:Team() )
		
		local r, g, b = color.r - 64, color.g - 64, color.b - 64

		draw.RoundedBox( 4, 0, 0, w, h, Color( r, g, b, self.Player:Alive() and 255 or 200 ) )
		
		local movePlayerName = 8
		local tooltip = false
		
		if self.Player:GetNWBool('Premium') then
			movePlayerName = 26
			
			surface.SetDrawColor(240, 240, 240, 200)
			surface.SetMaterial(premium_mat)
			surface.DrawTexturedRect(40, 11, 16, 16)
			tooltip = 'Premium'
		end
		
		local ug = self.Player:GetUserGroup()
		local admin_mat = admin_mats[ug]
		if admin_mat then
			surface.SetDrawColor(240, 240, 240, 200)
			surface.SetMaterial(admin_mat)
			surface.DrawTexturedRect(32 + movePlayerName, 11, 16, 16)
			
			movePlayerName = movePlayerName + 18
			
			tooltip = (tooltip and tooltip .. ' / ' or '') .. ug
		end
		
		if movePlayerName != self.NameMoved then
			self.Name:DockMargin( movePlayerName, 0, 0, 0 )
			self.Name:SetWide(250 - movePlayerName + 8)
			self.NameMoved = movePlayerName
			self.Name:InvalidateParent()
			
			self:SetTooltip(tooltip)
		end

	end,

	OnMousePressed = function(self)

		mouse_pressed = self
		
	end,

	OnMouseReleased = function( self )
		
		if mouse_pressed != self then return end

		if GAMEMODE.UserGroups then
			local m = DermaMenu()
			
			local useraccess = LocalPlayer():GetUserAccess()
			for k, v in ipairs(GAMEMODE.UserGroups.functions) do
				if useraccess < v.access or not v.args or v.args[1][1] != 'player' then
					continue
				end

				m:AddOption(v.name, function()
					local i = 2

					local args_query_and_run
					local finalargs = {}
					args_query_and_run = function(s)
						gui.EnableScreenClicker(false)

						if s then
							table.insert(finalargs, s)
						end

						if not v.args[i] then
							RunConsoleCommand('rp', v.cmd, self.Player:SteamID(), unpack(finalargs))
							return
						end

						local argtype = v.args[i][1]
						if argtype == 'string' then
							Derma_StringRequest(v.args[i][2], L'provide' .. ' ' .. v.args[i][2], '', args_query_and_run, function() gui.EnableScreenClicker(false) end)
						elseif argtype == 'number' or argtype == 'minutes' then
							gui.EnableScreenClicker(true)

							local f = vgui.Create('DFrame')
							f:SetSize(500, 160)
							f:Center()
							f:SetTitle(L'provide' .. ' ' .. v.args[i][2])
							f:MakePopup()
							
							function f:OnRemove()
								gui.EnableScreenClicker(false)
							end

							local num = vgui.Create('DNumSlider', f)
							num:SetPos(10, 10)
							num:SetSize(480, 100)
							num:SetText(argtype == 'minutes' and "permanent" or v.args[i][2])
							num:SetMin(0)
							num:SetMax(10080)
							num:SetDecimals(0)
							
							if argtype == 'minutes' then
								num.OnValueChanged = function(num, new)
									num:SetText(GAMEMODE.minutesToClock(new))
								end
							end

							local btn = vgui.Create('DButton', f)
							btn:SetPos(10, 110)
							btn:SetSize(480, 40)
							btn:SetText('OK')
							btn.DoClick = function()
								f:Close()
								args_query_and_run(math.ceil(num:GetValue()))
							end
						end

						i = i + 1
					end

					args_query_and_run()
				end)
			end

			m:Open()
		end

	end,
}

--
-- Convert it from a normal table into a Panel Table based on DPanel
--
PLAYER_LINE = vgui.RegisterTable( PLAYER_LINE, "DPanel" )

--
-- Here we define a new panel table for the scoreboard. It basically consists
-- of a header and a scrollpanel - into which the player lines are placed.
--
local SCORE_BOARD = {
	Init = function( self )

		self.Header = self:Add( "Panel" )
		self.Header:Dock( TOP )
		self.Header:SetHeight( 100 )

		self.Name = self.Header:Add( "DLabel" )
		self.Name:SetFont( "ScoreboardDefaultTitle" )
		self.Name:SetTextColor( Color( 255, 255, 255, 255 ) )
		self.Name:Dock( TOP )
		self.Name:SetHeight( 40 )
		self.Name:SetContentAlignment( 5 )
		self.Name:SetExpensiveShadow( 2, Color( 0, 0, 0, 200 ) )

		--self.NumPlayers = self.Header:Add( "DLabel" )
		--self.NumPlayers:SetFont( "ScoreboardDefault" )
		--self.NumPlayers:SetTextColor( Color( 255, 255, 255, 255 ) )
		--self.NumPlayers:SetPos( 0, 100 - 30 )
		--self.NumPlayers:SetSize( 300, 30 )
		--self.NumPlayers:SetContentAlignment( 4 )

		self.Scores = self:Add( "DScrollPanel" )
		self.Scores:Dock( FILL )

	end,

	PerformLayout = function( self )

		self:SetSize( 800, ScrH() - 200 )
		self:SetPos( ScrW() / 2 - 400, 100 )

	end,

	Paint = function( self, w, h )

		--draw.RoundedBox( 4, 0, 0, w, h, Color( 0, 0, 0, 200 ) )

	end,

	Think = function( self, w, h )

		self.Name:SetText( GetHostName() )

		--
		-- Loop through each player, and if one doesn't have a score entry - create it.
		--
		local plyrs = player.GetAll()
		for id, pl in pairs( plyrs ) do

			if ( IsValid( pl.ScoreEntry ) ) then continue end

			pl.ScoreEntry = vgui.CreateFromTable( PLAYER_LINE, pl.ScoreEntry )
			pl.ScoreEntry:Setup( pl )

			self.Scores:AddItem( pl.ScoreEntry )

		end

	end
}

SCORE_BOARD = vgui.RegisterTable( SCORE_BOARD, "EditablePanel" )

--[[---------------------------------------------------------
	Name: gamemode:ScoreboardShow( )
	Desc: Sets the scoreboard to visible
-----------------------------------------------------------]]
function GM:ScoreboardShow()

	if ( !IsValid( g_Scoreboard ) ) then
		g_Scoreboard = vgui.CreateFromTable( SCORE_BOARD )
	end

	if ( IsValid( g_Scoreboard ) ) then
		g_Scoreboard:Show()
		g_Scoreboard:MakePopup()
		g_Scoreboard:SetKeyboardInputEnabled( false )
	end
	
end

--[[---------------------------------------------------------
	Name: gamemode:ScoreboardHide( )
	Desc: Hides the scoreboard
-----------------------------------------------------------]]
function GM:ScoreboardHide()

	if ( IsValid( g_Scoreboard ) ) then
		g_Scoreboard:Hide()
	end
	
end

--[[---------------------------------------------------------
	Name: gamemode:HUDDrawScoreBoard( )
	Desc: If you prefer to draw your scoreboard the stupid way (without vgui)
-----------------------------------------------------------]]
function GM:HUDDrawScoreBoard()
end