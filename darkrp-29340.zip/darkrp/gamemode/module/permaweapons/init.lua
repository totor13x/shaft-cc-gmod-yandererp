if not sql.TableExists('rp_permweps') then
	sql.Query('CREATE TABLE rp_permweps (SteamID string, Weapon string)')
end

local player = FindMetaTable('Player')
perma_weps = perma_weps or {}


function player:AddPermWeapon(weapon)
	local ent = ents.Create(weapon)
	if IsValid(ent) then
		ent:Remove()
		sql.Query(string.format('INSERT INTO rp_permweps VALUES ("%s", %s)', self:SteamID(), SQLStr(weapon)))
			
		if not perma_weps[self] then
			perma_weps[self] = {}
		end
		
		table.insert(perma_weps[self], weapon)

        self:Give(weapon)
	end
end

function player:GetPermWeapons()
	return perma_weps[self]
end

function player:RemovePermWeapon(weapon)
	local weapon = SQLStr(weapon)

	local p = sql.Query(string.format('SELECT * FROM rp_permweps WHERE SteamID = "%s" AND Weapon = %s', self:SteamID(), weapon))
	if p then
		sql.Query(string.format('DELETE FROM rp_permweps WHERE SteamID = "%s" AND Weapon = %s', self:SteamID(), weapon))
			
		table.RemoveByValue(perma_weps[self], weapon)
	end
end

hook.Add('canDropWeapon', 'PermWeapon', function(ply, ent) 
	local permaprops = ply:GetPermWeapons() 
	if permaprops and table.HasValue(permaprops, ent:GetClass()) then 
		return false 
	end
end)

hook.Add('PlayerLoadout', 'PermWeapon', function(ply)
	if perma_weps[ply] then
		for k, v in ipairs(perma_weps[ply]) do
			ply:Give(v)	
		end
	end
end)

hook.Add('PlayerInitialSpawn', 'PermWeapon', function(ply)
	local p = sql.Query(string.format('SELECT Weapon FROM rp_permweps WHERE SteamID = "%s"', ply:SteamID()))
	if p then
		perma_weps[ply] = {}
		for k, v in ipairs(p) do
			table.insert(perma_weps[ply], v.Weapon)	
		end
	end
end)

hook.Add('PlayerDisconnected', 'PermWeapon', function(ply)
	perma_weps[ply] = nil
end)