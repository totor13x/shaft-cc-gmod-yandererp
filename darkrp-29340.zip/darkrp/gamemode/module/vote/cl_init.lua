local votes = {}

local PANEL = {}

function PANEL:Init()
    self.button_yes = vgui.Create('DButton', self)
    self.button_yes:SetText(L"yes" .. ' (F7)')
    self.button_yes.DoClick = function(btn)
        self:SendAnswer(true)
    end
    
    self.button_no = vgui.Create('DButton', self)
    self.button_no:SetText(L"no"  .. ' (F8)')
    self.button_no.DoClick = function(btn)
        self:SendAnswer(false)
    end

    self.label = vgui.Create("DLabel", self)
    self.label:SetFont("GModNotify")
    self.label:SetWrap(true)
    self.label:SetTextColor(Color(220, 220, 220))
end

function PANEL:PerformLayout(w, h)
    self.button_yes:SetPos(0, h - 42)
    self.button_yes:SetSize(w/2, 42)

    self.button_no:SetPos(w/2, h - 42)
    self.button_no:SetSize(w/2, 42)

    self.label:SetPos(8, 8)
    self.label:SetSize(w - 16, h - 42 - 16)
end

local global_key_pressed = false
function PANEL:Paint(w, h)
    local pw = w * (30 - (CurTime() - self.time))/30

    if pw <= 0 then
        self:Remove()
        return
    end

    surface.SetDrawColor(48, 49, 54)
    surface.DrawRect(0, 0, pw, h)

    surface.SetDrawColor(54, 54, 54)
    surface.DrawRect(pw, 0, w - pw, h)

    if votes[1] == self then
        local yes = input.IsKeyDown(KEY_F7)
        local no = input.IsKeyDown(KEY_F8)
        
        if yes or no then
            if not global_key_pressed then 
                self:SendAnswer(yes)
                global_key_pressed = true
            end
        else
            global_key_pressed = false
        end
    end

    return true
end

function PANEL:SendAnswer(ans)
    net.Start('rp_vote')
        net.WriteUInt(self.id, 16)
        net.WriteBool(ans)
    net.SendToServer()

    self:Remove()
end

function PANEL:SetText(text)
    self.label:SetText(text)
end

function PANEL:SetID(id)
    self.id = id
end

function PANEL:SetStartTime(time)
    self.time = time
end

vgui.Register("rp_vote", PANEL, "Panel")

--

local function move(i)
    votes[i]:MoveTo(12 + (i-1) * 316, 160, 0.6, 0, -5)
end

net.Receive('rp_vote', function()
    local id = net.ReadUInt(16)
    local question = net.ReadString()
    local time = net.ReadFloat()

    local p = vgui.Create('rp_vote')
    p:SetPos(-300, 160)
    p:SetSize(300, 120)
    p:SetText(question)
    p:SetID(id)
    p:SetStartTime(time)

    table.insert(votes, 1, p)

    for i = 1, #votes do
        move(i)
    end

    function p:OnRemove()
        local k = table.RemoveByValue(votes, p)
        if k then
            for i = k, #votes do
                move(i)
            end
        end
    end
end)