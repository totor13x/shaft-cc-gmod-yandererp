local voting = {}
local counter = 0

util.AddNetworkString('rp_vote')
function GM:Vote(text, func, players)
    counter = counter + 1
    
    local id = counter
    players = players or player.GetAll()
    net.Start('rp_vote')
        net.WriteUInt(id, 16)
        net.WriteString(text)
        net.WriteFloat(CurTime())
    net.Send(players)

    voting[id] = {0, 0, func, ['voted'] = {}, players = players}

    timer.Create('rp_vote_' .. id, 30, 1, function()
        GAMEMODE:EndVote(id)
    end)

    return id
end

function GM:EndVote(id)
    local vote = voting[id]
    if not vote then return end

    vote[3](vote[1] > vote[2])

    timer.Remove('rp_vote_' .. id)

    voting[id] = nil
end

net.Receive('rp_vote', function(len, ply)
    local id = net.ReadUInt(16)
    local yeah = net.ReadBool()

    local vote = voting[id]

    if vote then
        if not vote.voted[ply] and table.HasValue(vote.players, ply) then
            local i = yeah and 1 or 2
            vote[i] = vote[i] + 1

            if vote[i] == #vote.players then
                GAMEMODE:EndVote(id)
            end

            vote.voted[ply] = true
        end
    end
end)