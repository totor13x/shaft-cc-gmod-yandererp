if not sql.TableExists('money') then
    sql.Query('CREATE TABLE money (stm string, m int)')
end

local meta = FindMetaTable('Player')
function meta:SetMoney(m)
    m = tonumber(m)
    if not m then error('invalid amount') end

    m = math.floor(m)

    self:SetNWInt('money', m)

    sql.Query('UPDATE money SET m = ' .. m .. ' WHERE stm = ' .. SQLStr(self:SteamID()))
end

function meta:AddMoney(m)
    self:SetMoney(self:GetMoney() + m)
end

meta.addMoney = meta.AddMoney

hook.Add('PlayerAuthed', 'rp_money', function(ply)
    local query = sql.QueryRow( 'SELECT * FROM money WHERE stm = ' .. SQLStr(ply:SteamID()))
    local money = query and query.m or false
    if money then 
        ply:SetMoney(money)
    else
        local m = GAMEMODE.Settings.start_money or 0
        sql.Query('INSERT INTO money(stm, m) VALUES (' .. SQLStr(ply:SteamID()) .. ', ' .. m .. ')')
        ply:SetMoney(m)
    end
end)

function GM.createMoneyBag(pos, amount)
    local moneybag = ents.Create('spawned_money')
    moneybag:SetPos(pos)
    moneybag:SetAmount(math.min(amount, 2147483647))
    moneybag:Spawn()
    moneybag:Activate()

    return moneybag
end

GM:AddCommand('dropmoney', function(ply, args)
    local amt = tonumber(args[1])

    if not amt or amt < 1 then
        GAMEMODE:Error(ply, {"wrong_argument", args[1]})
        return
    end

    amt = math.min(amt, GAMEMODE.Settings.give_money_max or 2147483647)

    if amt > ply:GetMoney() then
        GAMEMODE:Error(ply, "not_enough")
        return
    end

    if ply.last_entity_bought then
        local diff = (ply.last_entity_bought + GAMEMODE.Settings.entity_buy_cooldown) - CurTime()
        if diff > 0 then
            GAMEMODE:Error(ply, {"wait_for", math.ceil(diff)})
            return
        end
    end

    ply.last_entity_bought = CurTime()

    ply:AddMoney(-amt)

    GAMEMODE:Notify(ply, {'dropped', DarkRP.formatMoney(amt)})

    local pos = GAMEMODE.playerDropPos(ply)

    GAMEMODE.createMoneyBag(pos, amt)
end)

GM:AddCommand('give', function(ply, args)
    local amt = tonumber(args[1])

    if not amt or amt < 1 then
        GAMEMODE:Error(ply, {"wrong_argument", args[1]})
        return
    end

    amt = math.min(amt, GAMEMODE.Settings.give_money_max or 2147483647)

    local other = ply:GetEyeTrace().Entity
    if not IsValid(other) or not other:IsPlayer() then
        GAMEMODE:Error(ply, "must_be_looking_player")
        return
    end

    if amt > ply:GetMoney() then
        GAMEMODE:Error(ply, "not_enough")
        return
    end

    if ply.last_money_give then
        local diff = (ply.last_money_give + GAMEMODE.Settings.money_give_cooldown) - CurTime()
        if diff > 0 then
            GAMEMODE:Error(ply, {"wait_for", math.ceil(diff)})
            return
        end
    end

    ply.money_give_cooldown = CurTime()

    ply:AddMoney(-amt)
    other:AddMoney(amt)

    local moneystr = DarkRP.formatMoney(amt)
    GAMEMODE:Notify(ply, {'have_given', moneystr, other:GetName()})
    GAMEMODE:Notify(other, {'were_given', moneystr, ply:GetName()})
end)

hook.Add('PlayerDeath', 'rp_drop_money', function(victim, inflictor, attacker)
    if GAMEMODE.Settings.drop_money_on_death and victim:GetMoney() > 0 then
        local amt = math.Clamp(victim:GetMoney() * GAMEMODE.Settings.drop_money_on_death_portion, 10, 250)
        if amt > victim:GetMoney() then
            amt = victim:GetMoney()
        end

        victim:AddMoney(-amt)
        GAMEMODE.createMoneyBag(victim:GetPos(), amt)
    end
end)