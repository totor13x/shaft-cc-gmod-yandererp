function GM.formatMoney(n)
    local negative = n < 0

    n = tostring(math.abs(n))
    local sep = sep or ","
    local dp = string.find(n, "%.") or #n + 1

    for i = dp - 4, 1, -3 do
        n = n:sub(1, i) .. sep .. n:sub(i + 1)
    end

    if GAMEMODE.Settings.currency_right then
        n = n .. GAMEMODE.Settings.currency
    else
        n = GAMEMODE.Settings.currency .. n
    end

    return (negative and "-" or "") .. n
end

local meta = FindMetaTable('Player')
function meta:GetMoney()
    return self:GetNWInt('money', 0)
end

function meta:CanAfford(amt)
    return self:GetMoney() >= amt
end

meta.canAfford = meta.CanAfford