GM:DescribeCommand('give', L'give', {L'amount'})
GM:DescribeCommand('dropmoney', L'dropmoney', {L'amount'})