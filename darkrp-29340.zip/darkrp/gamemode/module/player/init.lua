local meta = FindMetaTable('Player')

-- csvars
do
	util.AddNetworkString('gm_playervar')

	function meta:SetCSVar(var, val)
		self._CSVars = self._CSVars or {}
		self._CSVars[var] = val

		net.Start('gm_playervar')
			net.WriteString(var)
			net.WriteType(val)
		net.Send(self)
	end
end

function meta:ChatPrint(text)
	GAMEMODE:ChatPrintTo(self, text)
end

function GM:PlayerSpawn(ply)
	ply:SetRunSpeed(GAMEMODE.Settings.run_speed)
	ply:SetWalkSpeed(GAMEMODE.Settings.walk_speed)

	player_manager.SetPlayerClass(ply, "player_darkrp")
	player_manager.RunClass(ply, "Spawn")

	hook.Call("PlayerLoadout", self, ply)
	hook.Call("PlayerSetModel", self, ply)

	local playerClass = baseclass.Get("player_darkrp")
	ply:SetDuckSpeed(playerClass.DuckSpeed)
	ply:SetUnDuckSpeed(playerClass.UnDuckSpeed)
	ply:SetJumpPower(playerClass.JumpPower)
	ply:SetAvoidPlayers(true)

	local ent, pos = hook.Call("PlayerSelectSpawn", self, ply)
	ply:SetPos(pos or ent:GetPos())
end

function GM:PlayerInitialSpawn(ply)
	self.Sandbox.PlayerInitialSpawn(self, ply)
		ply:SetTeam(GAMEMODE.DefaultTeam)
end

function GM:PlayerLoadout(ply)
	--self.Sandbox.PlayerLoadout(self, ply)

	for _, wep in ipairs(self.Settings.default_weapons) do
		ply:Give(wep, true)
	end

	for _, wep in ipairs(ply:GetJobTable().weapons) do
		ply:Give(wep, true)
	end

	ply:SwitchToDefaultWeapon()
end

function GM:PlayerSetModel(ply)
	local job = ply:GetJobTable()

	if istable(job.model) then
		local preference
		if ply.rp_preferred_model then 
			preference = job.model[ply.rp_preferred_model]
		end

		ply:SetModel(preference or job.model[1])
	else
		ply:SetModel(job.model)
	end

	ply:SetupHands()
end

function GM:PlayerSelectSpawn(ply)
	local spawn = self.Sandbox.PlayerSelectSpawn(self, ply)

	local pos = nil 

	local job = GAMEMODE.Jobs[ply:Team()]
	if job.spawnpoints then
		pos = istable(job.spawnpoints) and job.spawnpoints[math.random(#job.spawnpoints)] or job.spawnpoints
	end

	if ply.IsArrested and ply:IsArrested() then
		pos = GAMEMODE:GetJailPos()
	end

	return spawn, pos
end

function GM:GetFallDamage(ply, speed)
	return math.max(0, math.ceil(0.2418*speed - 141.75))
end

-- chat and voice
do
	local can_hear = {}
	for i = 1, 128 do
		local t = {}
		for j = 1, 128 do
			t[j] = false
		end

		can_hear[i] = t
	end

	local ent_meta = FindMetaTable('Entity')
	local entIndex = ent_meta.EntIndex
	local getPos = ent_meta.GetPos
	local current, index = 1

	hook.Add('Think', 'can_hear', function()
		local plys = player.GetAll()
		
		if current > #plys then
			current = 1
		end

		local ply = plys[current]

		if not IsValid(ply) then
			return
		end

		local pos = ply:GetPos()
		local t = can_hear[entIndex(ply)]

		for i, other_ply in ipairs(plys) do
			index = entIndex(other_ply)
			if pos:DistToSqr(getPos(other_ply)) < 90000 then
				t[index] = true
			else
				t[index] = false
			end
		end

		current = current + 1
	end)

	function GM:PlayerCanSeePlayersChat(str, isteam, listener, speaker)
		if not IsValid(speaker) or not IsValid(listener) then return true end
		
		if isteam then
			local lTeam = listener:Team()
			local sTeam = speaker:Team()
			return lTeam == sTeam or (self.ChatTeamsJobs[lTeam] and self.ChatTeamsJobs[lTeam] == self.ChatTeamsJobs[sTeam] or false)
		end

		return listener:GetPos():DistToSqr(speaker:GetPos()) < 90000
	end

	function GM:PlayerCanHearPlayersVoice(listener, speaker)
		return can_hear[entIndex(listener)][entIndex(speaker)], true
	end

	local ooc = function(ply, _, str)

		if not ply:IsChatMuted() then
			GAMEMODE:ChatPrint(
				color_white, '[OOC] ', 
				team.GetColor(ply:Team()), ply, 
				color_white, ': ' .. str
			)
		end
	end

	GM:AddCommand('ooc', ooc)
	GM:AddCommand('/', ooc)

	GM:AddCommand('advert', function(ply, _, str)
		if not ply:IsChatMuted() then
			GAMEMODE:ChatPrint(
				Color(255, 128, 0), '[Advert] ', 
				ply, 
				Color(255, 255, 255), ': ' .. str
			)
		end
	end)
end

util.AddNetworkString('hand_sparks')
function GM:PlayerSwitchFlashlight(ply, enabled)
	net.Start('hand_sparks', true)
		net.WriteEntity(ply)
	net.SendPVS(ply:GetShootPos())
	return true
end

function GM:PlayerSetHandsModel(pl, ent)
	local playermodel = player_manager.TranslateToPlayerModelName(pl:GetModel())
	local info = player_manager.TranslatePlayerHands(playermodel)

	if info then
		ent:SetModel(info.model)
		ent:SetSkin(info.skin)
		ent:SetBodyGroups(info.body)
	end
end

util.AddNetworkString('PlayerFullyLoaded')
net.Receive('PlayerFullyLoaded', function(len, ply)
	if not ply.PlayerFullyLoaded then
		ply.PlayerFullyLoaded = true
		hook.Call('PlayerFullyLoaded', GAMEMODE, ply)
	end
end)

do -- connect / disconnect
	local con_cd = {}

	gameevent.Listen('player_connect')
	hook.Add('player_connect', 'AnnounceConnection', function(data)
		if con_cd[data.address] and con_cd[data.address] > SysTime() then
			return
		end
		con_cd[data.address] = SysTime() + 5

		local ip = string.sub(data.address, 0, (string.find(data.address, ':') or #data.address) - 1)
		print(data.name .. ' ' .. data.networkid .. ' connected')

		http.Fetch('http://ip-api.com/json/' .. ip, function(json)
			local tbl = util.JSONToTable(json)
			print(data.name .. ':')
			if tbl then
				PrintTable(tbl)
			end
			GAMEMODE:ChatPrint(Color(127, 255, 127), "⮞ ", Color(200, 200, 200), data.name, Color(127, 255, 127), ' присоединился', Color(200, 200, 200), tbl and tbl.country and (' из ' .. tbl.country) or '')
			GAMEMODE:PlaySound('npc/turret_floor/ping.wav')
		end,
		function() 
			GAMEMODE:ChatPrint(Color(127, 255, 127), "⮞ ", Color(200, 200, 200), data.name, Color(127, 255, 127), ' присоединился к серверу')
			GAMEMODE:PlaySound('npc/turret_floor/ping.wav')
		end)
	end)


	gameevent.Listen('player_disconnect')
	hook.Add('player_disconnect', 'AnnounceDisconnection', function(data)
		if con_cd[data.networkid] and con_cd[data.networkid] > SysTime() then
			return
		end
		con_cd[data.networkid] = SysTime() + 5
		
		print(data.name .. ' ' .. data.networkid .. ' disconnected (' .. data.reason .. ')')
		GAMEMODE:ChatPrint(Color(255, 127, 127), "⮞ ", Color(200, 200, 200), data.name, Color(255, 127, 127), ' вышел', Color(200, 200, 200),' [' .. data.reason .. ']')
		GAMEMODE:PlaySound('ambient/materials/smallwire_pluck3.wav')
	end)
end

GM:AddCommand('roll', function(ply)
	local c = math.random(100)
	for _, p in ipairs(player.GetAll()) do
		if p:GetPos():DistToSqr(ply:GetPos()) < 62500 then
			GAMEMODE:ChatPrintTo(p, HSVToColor(c % 365, 1, 1),'[ROLL] ', ply, Color(225, 225, 225), L('roll', c))
		end
	end
end)

local function yell(ply, args, argstr)
	for i, ply_n in ipairs(player.GetAll()) do 
		if ply:GetPos():DistToSqr(ply_n:GetPos()) < 302500 then
			GAMEMODE:ChatPrintTo(ply_n, Color(255, 100, 60), L'yell', ply, Color(230, 230, 230), ': ', argstr)	
		end
	end
end

local function whisper(ply, args, argstr) 
	for i, ply_n in ipairs(player.GetAll()) do 
		if ply:GetPos():DistToSqr(ply_n:GetPos()) < 8100 then
			GAMEMODE:ChatPrintTo(ply_n, Color(140, 255, 120), L'whisper', ply, Color(230, 230, 230), ': ', argstr)	
		end
	end
end

GM:AddCommand('yell', yell)
GM:AddCommand('y', yell)

GM:AddCommand('whisper', whisper)
GM:AddCommand('w', whisper)
