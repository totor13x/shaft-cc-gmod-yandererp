_CSVars = _CSVars or {}

net.Receive('gm_playervar', function()
	local csvar = net.ReadString()
	local new = net.ReadType()

	local old = _CSVars[csvar]
	_CSVars[csvar] = new

	hook.Call('CSVarChanged', GAMEMODE, csvar, old, new)
end)

hook.Add('InitPostEntity', '_CSVars', function()
	LocalPlayer()._CSVars = _CSVars
end)

function GM:OnPlayerChat(ply, text, isteam, isdead)
	local t = {}
	--local t_chathud = {}

	local function insert(item)
		table.insert(t, item)
		--table.insert(t_chathud, item)
	end

	local plyvalid = IsValid(ply)
		local premium = not plyvalid or ply:IsPremium()

	if plyvalid then
		if isteam then
			insert(Color(64, 228, 96))
			local tmchat = self.ChatTeamsJobs[ply:Team()]
			insert(tmchat and string.format('[%s] ', tmchat) or '[Команда] ')
		end

		if isdead then
			insert(Color(255, 64, 96))
			insert('[Мёртв] ')
		end

		insert(ply)
		insert(color_white)
	else
		insert(Color(128, 128, 128))
		insert('Консоль')

		insert(color_white)
	end

	insert(':')

	if premium then
		insert(ply:GetNWVector('ChatColor', Vector(1, 1, 1)):ToColor())
	end

	insert(' ' .. text)

	chat.AddText(unpack(t))

	return true
end

net.Receive('hand_sparks', function()
	local ply = net.ReadEntity()
	local pos
	local ed = EffectData()

	if ply and IsValid(ply) then
		if ply == LocalPlayer() then
			local vm = ply:GetViewModel()
			local obj = vm:LookupAttachment("muzzle")
			pos = obj > 0 and vm:GetAttachment(obj).Pos or ply:EyePos() + ply:GetAimVector() * 20
		else
			local obj = ply:LookupAttachment("anim_attachment_rh")
			pos = obj > 0 and ply:GetAttachment(obj).Pos or ply:GetShootPos()
		end
		ed:SetOrigin(pos)

		util.Effect('inflator_magic', ed)
	end
end)

GM:DescribeCommand('advert', 'Advert', {'Text'})
GM:DescribeCommand('ooc', 'OOC', {'Text'})

hook.Add('InitPostEntity', 'PlayerFullyLoaded', function()
	net.Start('PlayerFullyLoaded')
	net.SendToServer()
end)

hook.Add('InitPostEntity', 'flashlight', function()
local LocalPlayer = LocalPlayer
local DynamicLight = DynamicLight
local IsValid = IsValid
local plymeta = FindMetaTable('Player')
local GetEyeTrace = plymeta.GetEyeTrace
local GetShootPos = plymeta.GetShootPos
local FlashlightIsOn = plymeta.FlashlightIsOn
local GetAimVector = plymeta.GetAimVector

local entmeta = FindMetaTable('Entity')
local GetPos = entmeta.GetPos
local player = player

local ipairs = ipairs
	
local cooldown = 0
hook.Add('Think', 'flashlight', function()
	if cooldown > SysTime() then return end
	
	cooldown = SysTime() + 0.06
	
	for _, ply in ipairs(player.GetAll()) do
		if IsValid(ply) and FlashlightIsOn(ply) and GetPos(ply):DistToSqr(GetPos(LocalPlayer())) < 250000 then
			local dlight = DynamicLight(ply:EntIndex() + 1337)
			if dlight then
				local tr = GetEyeTrace(ply)
				local pos = tr.HitPos + tr.HitNormal * 10
				
				local shootpos = GetShootPos(ply)
				if pos:DistToSqr(shootpos) > 22500 then
					pos = shootpos + GetAimVector(ply) * 150
				end
				
				dlight.brightness = Sky.timeOfDay == 1 and 6 or 4
				dlight.dietime = CurTime() + 0.15
				dlight.pos = pos
				dlight.size = 200
				dlight.r = 255
				dlight.g = 255
				dlight.b = 255
			end
		end
	end
end)

hook.Remove('InitPostEntity', 'flashlight')
end)