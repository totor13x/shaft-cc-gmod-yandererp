local meta = FindMetaTable('Player')
function meta:GetCSVar(var, default)
	return self._CSVars and self._CSVars[var] or default
end

local player = {}

player.DisplayName = 'Base Player Class'
player.WalkSpeed = -1
player.RunSpeed = -1
player.DuckSpeed = 0.1
player.UnDuckSpeed = 0.1
player.TeammateNoCollide = false
player.StartHealth = -1

local over = {
	'Loadout',
	'SetModel',
	'ShouldDrawLocal',
	'CreateMove',
	'CalcView',
	'GetHandsModel',
	'StartMove',
	'FinishMove'
}

for i, func in ipairs(over) do
	player[func] = function() end	
end

player_manager.RegisterClass('player_darkrp', player, 'player_sandbox')

do -- pdata fix collision
	function util.GetPData( steamid, name, default )
		name = Format( "%s[%s]", steamid, name )
		local val = sql.QueryValue( "SELECT value FROM playerpdata WHERE infoid = " .. SQLStr( name ) .. " LIMIT 1" )
		if ( val == nil ) then return default end

		return val
	end

	function util.SetPData( steamid, name, value )
		name = Format( "%s[%s]", steamid, name )
		sql.Query( "REPLACE INTO playerpdata ( infoid, value ) VALUES ( " .. SQLStr( name ) .. ", " .. SQLStr( value ) .. " )" )
	end

	function util.RemovePData( steamid, name )
		name = Format( "%s[%s]", steamid, name )
		sql.Query( "DELETE FROM playerpdata WHERE infoid = " .. SQLStr( name ) )
	end

	function meta:GetPData( name, default )
		name = Format( "%s[%s]", self:SteamID(), name )
		local val = sql.QueryValue( "SELECT value FROM playerpdata WHERE infoid = " .. SQLStr( name ) .. " LIMIT 1" )
		if ( val == nil ) then return default end

		return val
	end

	function meta:SetPData( name, value )
		name = Format( "%s[%s]", self:SteamID(), name )
		return sql.Query( "REPLACE INTO playerpdata ( infoid, value ) VALUES ( " .. SQLStr( name ) .. ", " .. SQLStr( value ) .. " )" ) ~= false
	end

	function meta:RemovePData( name )
		name = Format( "%s[%s]", self:SteamID(), name )
		return sql.Query( "DELETE FROM playerpdata WHERE infoid = " .. SQLStr( name ) ) ~= false
	end
end

function meta:getEyeSightHitEntity(searchDistance, hitDistance, filter)
	searchDistance = searchDistance or 100
	hitDistance = (hitDistance or 15) * (hitDistance or 15)

	filter = filter or function(p) return p:IsPlayer() and p ~= self end

	self:LagCompensation(true)

	local shootPos = self:GetShootPos()
	local entities = ents.FindInSphere(shootPos, searchDistance)
	local aimvec = self:GetAimVector()

	local smallestDistance = math.huge
	local foundEnt

	for _, ent in pairs(entities) do
		if not IsValid(ent) or filter(ent) == false then continue end

		local center = ent:GetPos()

		-- project the center vector on the aim vector
		local projected = shootPos + (center - shootPos):Dot(aimvec) * aimvec

		if aimvec:Dot((projected - shootPos):GetNormalized()) < 0 then continue end

		-- the point on the model that has the smallest distance to your line of sight
		local nearestPoint = ent:NearestPoint(projected)
		local distance = nearestPoint:DistToSqr(projected)

		if distance < smallestDistance then
			local trace = {
				start = self:GetShootPos(),
				endpos = nearestPoint,
				mask = MASK_SOLID,
				filter = {self, ent}
			}
			local traceLine = util.TraceLine(trace)
			if traceLine.Hit then continue end

			smallestDistance = distance
			foundEnt = ent
		end
	end

	self:LagCompensation(false)

	if smallestDistance < hitDistance then
		return foundEnt, math.sqrt(smallestDistance)
	end

	return nil
end