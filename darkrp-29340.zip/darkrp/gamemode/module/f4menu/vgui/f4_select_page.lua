local item_h = 64

local PANEL = {}

function PANEL:Init()
end

function PANEL:Create()
	local p = self
	local w = p:GetWide()
	local inner_h = p:GetTall()
	local cat_list = vgui.Create('DCategoryList', p)
	cat_list:SetPos(0, 0)
	cat_list:SetSize(w * 0.7, inner_h)
	cat_list.Paint = function()
		return true	
	end
	
	local sbar = cat_list:GetVBar()
	sbar:SetHideButtons(true)
	sbar:SetWide(2)

	local main_panel = vgui.Create('Panel', p)
	main_panel:SetSize(w - cat_list:GetWide(), inner_h)
	main_panel:SetPos(cat_list:GetWide(), 0)
	main_panel.name = ''
	function main_panel:Paint(w, h)
		surface.SetTextColor(240, 240, 240)
		surface.SetFont('nunito24')
		local tw, th = surface.GetTextSize(self.name)
		surface.SetTextPos(w/2 - tw/2, 16)
		surface.DrawText(self.name)
	end

	local richtext = vgui.Create("RichText", main_panel)
	richtext:SetPos(8, 50)
	richtext:SetSize(main_panel:GetWide() - 16, 100)
	richtext:InsertColorChange(240, 240, 240, 240)
	richtext:SetVerticalScrollbarEnabled(true)
	function richtext:PerformLayout()
		self:SetFontInternal("nunito18")
		self:SetFGColor(Color(240, 240, 240, 240))
	end

	local pm = vgui.Create('DModelPanel', main_panel)
	pm:SetPos(0, 150)
	pm:SetSize(main_panel:GetWide(), inner_h - 300)
	p.setup_camera(pm)
	pm.Angles = Angle(0, 0, 0)

	function pm:DragMousePress()
		self.PressX, self.PressY = gui.MousePos()
		self.Pressed = true
	end

	function pm:DragMouseRelease() self.Pressed = false end

	function pm:LayoutEntity( ent )
		if ( self.bAnimated ) then self:RunAnimation() end

		if ( self.Pressed ) then
			local mx, my = gui.MousePos()
			self.Angles = self.Angles - Angle( 0, ( self.PressX or mx ) - mx, 0 )

			self.PressX, self.PressY = gui.MousePos()
		end

		ent:SetAngles( self.Angles )
	end

	local button = vgui.Create('DButton', main_panel)
	button:SetSize(main_panel:GetWide() - 32, 46)
	button:SetPos(16, inner_h - 64)
	button.Paint = function(self, w, h)
		draw.RoundedBox(8, 0, 0, w, h, self:IsHovered() and Color(255, 114, 167) or Color(204, 92, 135))

		local text
		local unlockprice = p.items_table[p.picked_index].unlockprice
		if unlockprice and not LocalPlayer().f4_unlockeditems[p.items_table[p.picked_index].name] then
			text = L('unlock_for', GAMEMODE.formatMoney(unlockprice))
		else
			text = p.button_text
		end

		draw.SimpleText(text, 'nunito24b', w/2, h/2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		
		return true
	end
	
	button.DoClick = function()
		if p.button_click then
			p:button_click(p.picked_index)
		end
	end

	local models_scroll
	if p.model_select then
		models_scroll = vgui.Create("DHorizontalScroller", main_panel)
		models_scroll:SetPos(0, inner_h - 150)
		models_scroll:SetSize(main_panel:GetWide(), 64)
		models_scroll:SetOverlap(-4)
	end

	local item_w = cat_list:GetWide()/2

	local function item_click(self)
		local job = p.items_table[self.itemindex]
		local models = job.model
		local model = models

		if p.model_select then
			models_scroll:Clear()
			models_scroll:InvalidateLayout()
			if istable(models) then
				for i = 1, #models do
					local icon = vgui.Create('SpawnIcon', models_scroll)
					icon:SetSize(64, 64)
					icon:SetModel(models[i])
					models_scroll:AddPanel(icon)

					function icon:DoClick()
						pm:SetModel(models[i])

						p.model_select(i)
					end
				end

				model = models[1]
			end
		end

		pm:SetModel(model)
		function pm.Entity:GetPlayerColor() return LocalPlayer():GetPlayerColor() end
		pm.Angles = Angle(0, 0, 0)
		pm.Entity:SetAngles(pm.Angles)
		--pm.Entity:ResetSequence(pm.Entity:LookupSequence('taunt_laugh'))

		main_panel.name = job.name
		richtext:SetText(job.desc)

		p.picked_index = self.itemindex
	end

	local cats = {}
	for i, v in ipairs(p.items_table) do
		if not cats[v.category] then
			local collapse_cat = cat_list:Add(v.category)
			local cont = vgui.Create('Panel')
			cont:Dock(FILL)
			collapse_cat.cont = cont
			collapse_cat:SetContents(cont)
						collapse_cat:SetAnimTime(0.5)
			cats[v.category] = collapse_cat

			function collapse_cat:PositionItems()
				local items = cont:GetChildren()

				local i = 0
				for k, item in ipairs(items) do
					if item:IsVisible() then
						item:SetPos((i % 2) != 0 and item_w or 0, math.floor(i/2) * item_h)
						i = i + 1
					end
				end
			end

			function collapse_cat:Paint(w, h)
				draw.RoundedBox(4, 0, 0, w, 20, self:GetExpanded() and Color(255, 114, 167) or Color(204, 92, 135))
			end
		end

		local cat = cats[v.category]
		--cat.pos_i = cat.pos_i and cat.pos_i + 1 or 0

		local item = vgui.Create('f4_item_block', cat.cont)
		--item:SetPos((cat.pos_i % 2) != 0 and item_w or 0, math.floor(cat.pos_i/2) * item_h)
		item:SetSize(item_w, item_h)
		item:SetModel(istable(v.model) and v.model[1] or v.model)
		item.color = v.color and ColorAlpha(v.color, 128) or Color(96, 96, 96, 128)
		item.name = v.name
		item.price = v.salary or v.price
		item.max = v.max
		item.count = 0
		item.itemindex = i
		item.DoClick = item_click
		if v.unlockprice and not LocalPlayer().f4_unlockeditems[v.name] then
			item.unlockprice = v.unlockprice
			item:SetAlpha(32)
		end

		if p.item_created then p.item_created(item, i) end
	end

	for k, v in pairs(cats) do
		v:PositionItems()
	end
end

function PANEL:Paint()
end

vgui.Register("f4_select_page", PANEL, "Panel")