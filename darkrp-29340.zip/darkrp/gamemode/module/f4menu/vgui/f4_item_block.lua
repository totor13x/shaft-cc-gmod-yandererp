local PANEL = {}

function PANEL:Init()
	self.color = color_white
	
	local icon = vgui.Create('ModelImage', self)
	icon:SetPos(4, 4)
	icon:SetMouseInputEnabled(false)

	self.icon = icon
end

function PANEL:SetModel(mdl)
	self.icon:SetModel(mdl)
end

function PANEL:PerformLayout(w, h)
	self.icon:SetSize(h - 8, h - 8)
end

function PANEL:Paint(w, h)
	if self:IsHovered() then draw.RoundedBox(4, 2, 2, w - 8, h - 4, Color(255, 255, 255, 64)) end
	--draw.RoundedBox(4, 2, 2, w - 8, h - 4, Color(51, 60, 70))
	draw.RoundedBox(4, 2, 2, w - 8, h - 4, self.color)

	surface.SetFont('nunito24b')
	surface.SetTextColor(240, 240, 240)

	if self.name then
		surface.SetTextPos(h + 16, 4)
		surface.DrawText(self.name)
	end

	if self.price then
		surface.SetTextPos(h + 16, h/2)
		surface.DrawText(GAMEMODE.formatMoney(self.price))
	end

	if self.count then
		self.max = self.max or 0

		local text = self.count .. '/' .. (self.max == 0 and '∞' or self.max)

		local tw, th = surface.GetTextSize(text)
		surface.SetTextPos(w - tw - 20, h/2 - th/2)
		surface.DrawText(text)
	end

	return true
end

vgui.Register("f4_item_block", PANEL, "DButton")