include(GM.ModuleFolder .. 'f4menu/vgui/f4_item_block.lua')
include(GM.ModuleFolder .. 'f4menu/vgui/f4_select_page.lua')

local w, h, tab_h = math.min(1200, ScrW()), math.min(800, ScrH()), 40
local item_h = 64 -- убрать
local inner_h = h - tab_h - 24
local colors = {
	header = Color(204, 92, 135),
	bg = Color(51, 60, 70),--Color(132, 64, 115),
	bg2 = Color(58, 66, 78),
	hover = Color(255, 114, 167),--Color(255, 145, 211),
	text = Color(255, 255, 255, 255),
}


if IsValid(GM.F4Menu) then 
	GM.F4Menu:Remove()
end

local create_f4menu = function()
	if IsValid(GAMEMODE.F4Menu) then 
		GAMEMODE.F4Menu:Show() 
		return
	end

	local f4 = vgui.Create('DFrame')
	f4:SetSize(w, h)
	f4:Center()
	f4:MakePopup()
	f4:SetTitle(L"menu")
	f4:SetDraggable(false)
	f4.btnMaxim:Hide()
	f4.btnMinim:Hide()
	f4:SetDeleteOnClose(false)
	function f4:OnKeyCodePressed(code)
		if code == KEY_F4 then
			f4:Hide()
		end
	end
	function f4:Paint(w, h)
		draw.RoundedBoxEx(4, 0, 0, w, 24, colors.header, true, true)
		draw.RoundedBoxEx(4, 0, 24, w, h-24, colors.bg, false, false, true, true)
	end
	
	function f4.btnClose:Paint(w, h)
		if self:IsHovered() then
			draw.RoundedBox(4, 0, 0, w, h, colors.hover)
		end
		draw.SimpleTextOutlined('r', 'marlett', w/2, h/2, colors.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
	end

	GAMEMODE.F4Menu = f4

	local tabs_panel = vgui.Create('Panel', f4)
	tabs_panel:SetSize(w, tab_h)
	tabs_panel:SetPos(0, 24)
	tabs_panel.Paint = function() end

	f4.categories = {
		--[[{L'commands', function(p)
			local b = vgui.Create('DButton', p)
			b:Dock(FILL)
		end},]]
	}

	function f4:CreateTabs()
		tabs_panel:Clear()

		local wide = w / #self.categories

		local selected_tab
		for i, tab in ipairs(self.categories) do
			local name = tab[1]
			local func = tab[2]

			local tab = vgui.Create('DButton', tabs_panel)
			tab:SetSize(wide, tab_h)
			tab:SetPos((i-1) * wide)
			tab._Paint = tab.Paint
			tab.Paint = function(self, w, h)
				draw.RoundedBox(0, 0, 0, w, h, colors.bg2)
				local hover = self:IsHovered()
				if selected_tab == self or hover then
					surface.SetDrawColor(hover and colors.hover or Color(200, 200, 200))
					surface.DrawRect(0, h - 4, w, 4)
				end
				
				draw.SimpleText(name, 'nunito20', w/2, h/2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				return true
			end

			local p = vgui.Create('Panel', f4)
			p:SetSize(w, inner_h)
			p:SetPos(0, 24 + tab_h)
			p.Paint = function(self, w, h) end

			func(p)

			p:Hide()

			tab.panel = p

			function tab:DoClick()
				/*for _, b in ipairs(tabs_panel:GetChildren()) do
					b.Depressed = false
					b:PerformLayout()
					b.panel:Hide()
				end

				timer.Simple(0, function()
					if IsValid(self) then
						self.Depressed = true 
						self:PerformLayout()
					end
				end)*/

				if selected_tab then
					selected_tab.panel:Hide()
				end

				selected_tab = self
				self.panel:Show()
			end

			if i == 1 then tab:DoClick() end
		end
	end

	function f4:AddTab(name, func, position)
		table.insert(self.categories, position or (#self.categories) + 1, {name, func})
		--self:CreateTabs()
	end

	hook.Call('f4menu_onload', GAMEMODE, f4)

	f4:CreateTabs()
end

GM.ShowSpare2 = create_f4menu

net.Receive('ShowSpare2', function(len, ply)
	hook.Call('ShowSpare2', GAMEMODE)
end)