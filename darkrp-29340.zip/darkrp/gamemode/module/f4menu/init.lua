local location = GM.ModuleFolder .. 'f4menu/vgui/'
local files = file.Find(location .. '*', 'LUA')

for _, f in ipairs(files) do
    AddCSLuaFile(location .. f)
end

util.AddNetworkString('ShowSpare2')
function GM:ShowSpare2(ply)
    net.Start('ShowSpare2')
    net.Send(ply)
end