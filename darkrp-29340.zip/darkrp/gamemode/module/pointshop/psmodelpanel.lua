local PANEL = {}

AccessorFunc( PANEL, "vCamPos",			"CamPos" )
AccessorFunc( PANEL, "fFOV",			"FOV" )
AccessorFunc( PANEL, "vLookatPos",		"LookAt" )
AccessorFunc( PANEL, "aLookAngle",		"LookAng" )
AccessorFunc( PANEL, "colAmbientLight",	"AmbientLight" )

function PANEL:Init()

	self.LastPaint = 0
	self.DirectionalLight = {}
	self.FarZ = 4096

	self:SetCamPos( Vector(25, 20, 10) )
	self:SetLookAt( Vector(0, 0, 5) )
	self:SetFOV( 40 )

	self:SetText( "" )

	self:SetAmbientLight( Color( 50, 50, 50 ) )

	self:SetDirectionalLight( BOX_TOP, Color( 255, 255, 255 ) )
	self:SetDirectionalLight( BOX_FRONT, Color( 255, 255, 255 ) )

end

function PANEL:SetDirectionalLight( iDirection, color )
	self.DirectionalLight[ iDirection ] = color
end

function PANEL:Draw(w, h)

	local curparent = self
	local leftx, topy = self:LocalToScreen( 0, 0 )
	local rightx, bottomy = self:LocalToScreen( w, h )
	while ( curparent:GetParent() != nil ) do
		curparent = curparent:GetParent()

		local x1, y1 = curparent:LocalToScreen( 0, 0 )
		local x2, y2 = curparent:LocalToScreen( curparent:GetWide(), curparent:GetTall() )

		leftx = math.max( leftx, x1 )
		topy = math.max( topy, y1 )
		rightx = math.min( rightx, x2 )
		bottomy = math.min( bottomy, y2 )
		previous = curparent
	end

	render.SetScissorRect( leftx, topy, rightx, bottomy, true )

	local e = self:DrawModel()
	
	if IsValid(e) then 
		self.Entity = e 
	end

	render.SetScissorRect( 0, 0, 0, 0, false )

end

function PANEL:OnRemove()
	local e = self.Entity
	timer.Simple(1, function() if IsValid(e) then e:Remove() end end)
end

function PANEL:DrawModel()
end

function PANEL:LayoutEntity()
end

function PANEL:Paint( w, h )

	local x, y = self:LocalToScreen( 0, 0 )
	
	self:LayoutEntity(self.Entity)

	local ang = self.aLookAngle
	if ( !ang ) then
		ang = ( self.vLookatPos - self.vCamPos ):Angle()
	end

	cam.Start3D( self.vCamPos, ang, self.fFOV, x, y, w, h, 5, self.FarZ )

	render.SuppressEngineLighting( true )
	render.SetLightingOrigin( vector_origin )
	render.ResetModelLighting( self.colAmbientLight.r / 255, self.colAmbientLight.g / 255, self.colAmbientLight.b / 255 )
	render.SetColorModulation( 1, 1, 1 )
	render.SetBlend( self:GetAlpha() / 255 )

	for i = 0, 6 do
		local col = self.DirectionalLight[ i ]
		if ( col ) then
			render.SetModelLighting( i, col.r / 255, col.g / 255, col.b / 255 )
		end
	end

	self:Draw(w, h)

	render.SuppressEngineLighting( false )
	cam.End3D()

	self.LastPaint = RealTime()

end

derma.DefineControl( "PSModelPanel", "Pointshop Preview Panel", PANEL, "DButton" )