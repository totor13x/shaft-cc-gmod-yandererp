include(GM.ModuleFolder .. 'pointshop/psmodelpanel.lua')

pointshop.owned = pointshop.owned or {}

local settings_mat = Material('icon64/playermodel.png')

local colors = {
	header = Color(204, 92, 135),
	bg = Color(51, 60, 70),--Color(132, 64, 115),
	bg2 = Color(58, 66, 78),
	hover = Color(255, 114, 167),--Color(255, 145, 211),
	text = Color(255, 255, 255, 255),
}

local psw, psh = 800, 570
local item_w, item_h = 128, 144

local panelPaint = function(self, w, h)
	draw.RoundedBox(4, 0, 0, w, h, colors.bg2)
end

local dmodel_mousecontrol = function(self, rotatecamera)
	local _camPos = self:GetCamPos()
	local _lookAt = self:GetLookAt()
	self.CamDistance = 65
	self.Angles = Angle(0, 0, 0)
	
	function self:DragMousePress()
		self.PressX, self.PressY = gui.MousePos()
		self.Pressed = true
	end
		
	function self:DragMouseRelease() 
		self.Pressed = false 
	end
	
	function self:LayoutEntity(ent)
		if self.Pressed then
			local mx, my = gui.MousePos()
			self.Angles = self.Angles - Angle(0, ((self.PressX or mx) - mx)/2.5, 0)
		
			self.CamZ = math.Clamp((self.CamZ or 0) + ((self.PressY or my) - my)*(self.CamDistance/400), -100, 100)
			
			self.PressX, self.PressY = gui.MousePos()
		end
		
		local cpos = _camPos + Vector(self.CamDistance, 0, -(self.CamZ or 0))
		if rotatecamera then
			cpos:Rotate(-self.Angles)	
		elseif IsValid(ent) then 
			ent:SetAngles(self.Angles) 
		end
		
		self:SetCamPos(cpos)
		self:SetLookAt(_lookAt + Vector(0, 0, -(self.CamZ or 0)))
	end
	
	function self:OnMouseWheeled(delta)
		self.CamDistance = math.Clamp(self.CamDistance - delta * 4, 5, 100)
	end
end

local open = function()
	if IsValid(pointshop.f) then
		pointshop.f:Show()
		pointshop.pm:SetModel(LocalPlayer():GetModel())
		return
	end

	local lp = LocalPlayer()
	
	local chosen_item
	
	local f = vgui.Create('DFrame')
	f:SetSize(psw, psh)
	f:Center()
	f:MakePopup()
	f:SetTitle("LampServ Pointshop 3")
	f:SetDraggable(true)
	f.btnMaxim:Hide()
	f.btnMinim:Hide()
	f:SetDeleteOnClose(false)
	function f:OnKeyCodePressed(code)
		if code == KEY_F2 then
			f:Hide()
		end
	end

	function f:Paint(w, h)
		draw.RoundedBoxEx(4, 0, 0, w, 24, colors.header, true, true)
		draw.RoundedBoxEx(4, 0, 24, w, h-24, colors.bg, false, false, true, true)
	end
	pointshop.f = f
	
	function f.btnClose:Paint(w, h)
		if self:IsHovered() then
			draw.RoundedBox(4, 0, 0, w, h, colors.hover)
		end
		draw.SimpleTextOutlined('r', 'marlett', w/2, h/2, colors.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
	end
	
	local pts_p = vgui.Create('DPanel', f)
	pts_p:SetSize(158, 32)
	pts_p:SetPos(psw - 238, 32)
	pts_p.Paint = function(self, w, h)
		panelPaint(self, w, h)
		draw.SimpleText("★", "Trebuchet24", 8, h/2, colors.text, nil, TEXT_ALIGN_CENTER)
		draw.SimpleText(lp:GetCSVar('points', 0), "nunito18", w - 8, h/2, colors.text, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	end
	
	local bdonate = vgui.Create('DButton', f)
	bdonate:SetSize(64, 32)
	bdonate:SetPos(psw - 72, 32)
	bdonate.Paint = function(self, w, h)
		draw.RoundedBox(4, 0, 0, w, h, self:IsHovered() and colors.hover or colors.header)
		draw.SimpleText("+", "DermaLarge", 23, 0, colors.text)
		return true	
	end
	function bdonate:DoClick()
		f:Hide()
		RunConsoleCommand('ls_shop')
	end
	
	local bbuy = vgui.Create('DButton', f)
	bbuy:SetSize(230, 32)
	bbuy:SetPos(psw - 238, 530)
	bbuy.alpha = 64
	bbuy.Paint = function(self, w, h)
		local text = 'Купить'
		local color = colors.header
		if chosen_item then
			self.alpha = Lerp(FrameTime() * 10, self.alpha, 255)
			if self:IsHovered() then color = colors.hover end

			local name = chosen_item.v.name
			if pointshop.owned[name] then
				if lp.pointshop_equipped[name] then
					text = 'Убрать'
				else
					text = 'Взять'
				end
			end
		end

		draw.RoundedBox(4, 0, 0, w, h, ColorAlpha(color, self.alpha))
		draw.SimpleText(text, "nunito24b", w/2, h/2 - 2, ColorAlpha(colors.text, self.alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		return true	
	end
	function bbuy:DoClick()
		if chosen_item then
			local name = chosen_item.v.name
			if not pointshop.owned[name] then
				net.Start('pointshop_buy')
					net.WriteUInt(chosen_item.itemindex, 16)
				net.SendToServer()
			else
				net.Start('pointshop_equip')
					net.WriteUInt(chosen_item.itemindex, 16)
				net.SendToServer()
			end
		end
	end
	
	local cat_list
	local pm
	local custp
	local function toggle_customize_settings()
		if custp:IsVisible() then
			custp:Hide()
			cat_list:Show()
		else
			custp:Show()
			cat_list:Hide()
		end	
	end
	
	-- player model
	do 
		local pl_p = vgui.Create('DPanel', f)
		pl_p:SetSize(230, 450)
		pl_p:SetPos(psw - 238, 72)
		pl_p.Paint = panelPaint
		
		pm = vgui.Create('DModelPanel', pl_p)
		pm:Dock(FILL)
		pm:SetModel(lp:GetModel())
		pm.Entity.hat_customize = {0, 0, 0, 1}
		pm:SetCamPos(Vector(0, 0, 43))
		pm:SetLookAt(Vector(0, 0, 38))
		pm:SetFOV(40)
		function pm.Entity:GetPlayerColor() return lp:GetPlayerColor() end
		function pm:PostDrawModel(ent)
			local model = lp:GetModel() 
			if not self.forcemodel and self:GetModel() != model then
				self:SetModel(model)
				 
			end
			
			if not self.Entity.hat_customize then
				self.Entity.hat_customize = {0, 0, 0, 1}
			end

			for _, name in ipairs(table.GetKeys(lp.pointshop_equipped)) do
				item = pointshop.items_byname[name]
				rend = item.render
				if rend then
					rend(ent, item)
				end
			end

			if chosen_item and chosen_item.v.render then
				chosen_item.v.render(ent, chosen_item.v)
			end
		end
		
		local customize_btn = vgui.Create('DButton', pm)
		customize_btn:SetSize(64, 64)
		customize_btn:SetPos(pl_p:GetWide() - 72, 8)
		function customize_btn:Paint(w, h)
			if self:IsHovered() or custp:IsVisible() then
				surface.SetDrawColor(200, 200, 200)
			else
				surface.SetDrawColor(255, 255, 255)
			end
			surface.SetMaterial(settings_mat)
			surface.DrawTexturedRect(0, 0, w, h)
			
			return true
		end
		
		customize_btn.DoClick = toggle_customize_settings

		-- remove cents
		
		dmodel_mousecontrol(pm)
		pointshop.pm = pm
	end

	cat_list = vgui.Create('DCategoryList', f)
	cat_list:SetPos(8, 32)
	cat_list:SetSize(546, psh-40)
	cat_list.Paint = function()
		return true	
	end
	
	local sbar = cat_list:GetVBar()
	sbar:SetHideButtons(true)
	sbar:SetWide(2)
	
	local function item_click(self)
		if chosen_item and chosen_item.v and chosen_item.v.preview_close then
			chosen_item.v:preview_close(pm)
		end
		
		chosen_item = self
		
		if self.v.preview_open then
			self.v:preview_open(pm)
		end
	end
	
	local function item_paint(self, w, h)
		local name = self.v.name
		draw.RoundedBox(4, 0, 0, w, h, (chosen_item == self or self:IsHovered()) and colors.hover or (pointshop.owned[name] and colors.header or colors.bg2))
		draw.SimpleText(name, "nunito18", w/2, h - 22, colors.text, TEXT_ALIGN_CENTER)
		
		surface.SetDrawColor(colors.bg)
		surface.DrawRect(8, 8, w - 16, h - 32)
		
		return true
	end

	local function item_drawmodel(self)
		if self.v.render then
			self.v.render(self, self.v)
		end
	end
	
	local function item_paintover(self, w, h)
		if self.modelset then
			self:SetModel(self.v.model)
			self.modelset = nil
		end
		
		if self.v.paint then
			self.v.paint(self, w, h)
		end
	
		local parent = self:GetParent()
		if parent:IsHovered() or chosen_item == parent then
			self.price_y = Lerp(FrameTime() * 5, self.price_y, 0)
		else
			self.price_y = Lerp(FrameTime() * 5, self.price_y, -22)
		end
		
		local name = self.v.name
		local equipped = LocalPlayer().pointshop_equipped[name]
		if equipped then
			draw.RoundedBox(4, w - 16, 8, 8, 8, colors.header)
		end
		
		if not pointshop.owned[name] then
			draw.RoundedBoxEx(8, w/2 - 30, math.ceil(self.price_y), 60, 20, colors.hover, false, false, true, true)
			draw.SimpleText("★ " 
				.. self.v.price, "nunito18", w/2, math.ceil(self.price_y), colors.text, TEXT_ALIGN_CENTER)
		end
	end

	local cats = {}
	for i, v in ipairs(pointshop.items) do
		 if not cats[v.category] then
			local collapse_cat = cat_list:Add(v.category)
			local cont = vgui.Create('Panel')
			cont:Dock(FILL)
			collapse_cat.cont = cont
			collapse_cat:SetContents(cont)
			collapse_cat:SetAnimTime(0.5)
			collapse_cat:SetExpanded(false)
			
			cats[v.category] = collapse_cat

			function collapse_cat:PositionItems()
				local items = cont:GetChildren()

				local i = 0
				for k, item in ipairs(items) do
					if item:IsVisible() then
						item:SetPos((i % 4) * (item_w + 8) + 4, math.floor(i/4) * (item_h + 8) + 4)
						i = i + 1
					end
				end
			end
			
			function collapse_cat:Paint(w, h)
				draw.RoundedBox(4, 0, 0, w, 20, self:GetExpanded() and colors.hover or colors.header)
			end
		end

		if v.hidden and v:hidden(LocalPlayer()) then
			continue
		end

		local cat = cats[v.category]
		--cat.pos_i = cat.pos_i and cat.pos_i + 1 or 0

		local item = vgui.Create('DButton', cat.cont)
		item:SetSize(item_w, item_h)
		item.v = v
		item.itemindex = i
		item.DoClick = item_click
		item.Paint = item_paint
		
		local dmodel = vgui.Create((v.model and not v.render) and 'DModelPanel' or 'PSModelPanel', item)
		dmodel:SetPos(8, 8)
		dmodel:SetSize(item_w - 16, item_h - 32)
		dmodel:SetMouseInputEnabled(false)
		dmodel.v = v
		dmodel.PaintOver = item_paintover
		if not v.model or v.render then
			dmodel.DrawModel = item_drawmodel
		else
			dmodel.modelset = true
		end
		dmodel.price_y = -20
	end

	for k, v in pairs(cats) do
		v:PositionItems()
	end
	
	custp = vgui.Create('DPanel', f)
	custp:SetPos(8, 32)
	custp:SetSize(546, psh-40)
	custp:Hide()
	
	function custp:Paint(w, h)
		panelPaint(self, w, h)
	end
	
	local function addNum(name, min, max, func, dec)
		local num = vgui.Create('DNumSlider', custp)
		num:SetSize(400, 80)
		num:Dock(TOP)
		num:SetMin(min)
		num:SetMax(max)
		num:SetValue(0)
		num:SetText(name)
		
		if dec then
			num:SetDecimals(dec)
		end
		
		num.OnValueChanged = function()
			func(num:GetValue())
		end
	end

	addNum('Pos X', -10, 10, function(v)
		pm.Entity.hat_customize[1] = v
	end)
	
	addNum('Pos Y', -10, 10, function(v)
		pm.Entity.hat_customize[2] = v
	end)
	
	addNum('Pos Z', -10, 10, function(v)
		pm.Entity.hat_customize[3] = v
	end)
	addNum('Scale', 0.5, 2, function(v)
		pm.Entity.hat_customize[4] = v
	end)
	
	local savecustomize = vgui.Create('DButton', custp)
	savecustomize:SetSize(230, 32)
	savecustomize:SetPos(custp:GetWide()/2 - 115, custp:GetTall() - 40)
	savecustomize.Paint = function(self, w, h)
		local color = colors.header
		if self:IsHovered() then color = colors.hover end
		
		draw.RoundedBox(4, 0, 0, w, h, color)
		draw.SimpleText('Сохранить', "nunito24b", w/2, h/2 - 2, colors.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		return true	
	end
	function savecustomize:DoClick()
		toggle_customize_settings()
		net.Start('hat_customize')
			net.WriteFloat(pm.Entity.hat_customize[1])
			net.WriteFloat(pm.Entity.hat_customize[2])
			net.WriteFloat(pm.Entity.hat_customize[3])
			net.WriteFloat(pm.Entity.hat_customize[4])
		net.SendToServer()

		file.Write('ls_pointshop_customize.txt', table.concat(pm.Entity.hat_customize, ' '))
	end
end

concommand.Add('pointshop', open)

GM.ShowTeam = open

local newhat_f
concommand.Add('pointshop_newhat', function(ply)
	if ply:IsSuperAdmin() then
		if IsValid(newhat_f) then
			newhat_f:Show()
			return
		end

		Derma_StringRequest(
			"Create a new hat", 
			"Input the MODEL name of a new hat",
			"models/props_junk/watermelon01.mdl",
			function(model)
			Derma_StringRequest(
			"Create a new hat", 
			"Now type in the name of that hat",
			"My hat",
			function(hatname)
				local hat = {
					pos = Vector(0, 0, 0),
					ang = Angle(0, 0, 0),
					model = model,
					scale = 1,
					name = hatname,
					price = 1,
				}
				
				local f = vgui.Create('DFrame')
				f:SetSize(1000, 500)
				f:Center()
				f:MakePopup()
				f:SetTitle("Create a new hat")
				f:SetDraggable('true')
				f.btnMaxim:Hide()
				f.btnMinim:Hide()
				f:SetDeleteOnClose(false)
				newhat_f = f
				
				local dmodel = vgui.Create('PSModelPanel', f)
				dmodel:Dock(RIGHT)
				dmodel:SetSize(300, 400)
				dmodel.DrawModel = function(self)
					GAMEMODE.RenderHat(self, hat)
				end
				dmodel_mousecontrol(dmodel, true)
				
				local pm = vgui.Create('DModelPanel', f)
				pm:SetSize(300, 400)
				pm:Dock(RIGHT)
				pm:SetModel(LocalPlayer():GetModel())
				pm:SetCamPos(Vector(0, 0, 43))
				pm:SetLookAt(Vector(0, 0, 38))
				pm:SetFOV(40)
				function pm:PostDrawModel(ent)
					GAMEMODE.RenderHat(ent, hat)
				end
				-- remove cents
				
				dmodel_mousecontrol(pm)
				
				local function addNum(name, min, max, func, dec)
					local num = vgui.Create('DNumSlider', f)
					num:SetSize(400, 50)
					num:Dock(TOP)
					num:SetMin(min)
					num:SetMax(max)
					num:SetValue(0)
					num:SetText(name)
					
					if dec then
						num:SetDecimals(dec)
					end
					
					num.OnValueChanged = function()
						func(hat, num:GetValue())	
					end
				end

				local function addBtn(name, func)
					local b = vgui.Create('DButton', f)
					b:SetText(name)
					b:Dock(TOP)
					b.DoClick = func
				end
	
				addNum('Pos X', -50, 50, function(h, v)
					h.pos.x = v
				end)
	
				addNum('Pos Y', -50, 50, function(h, v)
					h.pos.y = v
				end)
	
				addNum('Pos Z', -50, 50, function(h, v)
					h.pos.z = v
				end)
	
				addNum('Ang X', -180, 180, function(h, v)
					h.ang.x = v
				end)
	
				addNum('Ang Y', -180, 180, function(h, v)
					h.ang.y = v
				end)
				
				addNum('Ang Z', -180, 180, function(h, v)
					h.ang.z = v
				end)
	
				addNum('Scale', -5, 5, function(h, v)
					h.scale = v
			
					if IsValid(dmodel.hatent) then
						dmodel.hatent:SetModelScale(h.scale, 0)
					end
					
					if IsValid(pm.Entity.hatent) then
						pm.Entity.hatent:SetModelScale(h.scale, 0)
					end
				end)
	
				addNum('Price', 0, 1000, function(h, v)
					h.price = v
				end, 0)
	
				addBtn('Print to console', function()
					local h = hat
					print('{')
					print(string.format('\tname = "%s",', hatname))
					print(string.format('\tmodel = "%s",', model))
					print(string.format('\tang = Angle(%s, %s, %s),', math.Round(h.ang.x, 2), math.Round(h.ang.y, 2), math.Round(h.ang.z, 2)))
					print(string.format('\tpos = Vector(%s, %s, %s),', math.Round(h.pos.x, 2), math.Round(h.pos.y, 2), math.Round(h.pos.z, 2)))
					if h.scale and h.scale != 1 and h.scale != 0 then print(string.format('\tscale = %s,', math.Round(h.scale, 2))) end
					print(string.format('\tprice = %s,', math.floor(h.price)))
					print('},')
				end)
				addBtn('Spawn This Hat', function()
					if hat.scale == 0 then hat.scale = 1 end
					net.Start('pointshop_spawnhat')
						net.WriteTable(hat)
					net.SendToServer()
				end)
				addBtn("Done (don't save)", function()
					f:Remove()
				end)
			end)
		end)
	end
end)

net.Receive('pointshop_items', function()
	pointshop.owned[net.ReadString()] = true
end)

net.Receive('pointshop_items_t', function()
	pointshop.owned = net.ReadTable()
end)

net.Receive('pointshop_equipped', function()
	net.ReadEntity().pointshop_equipped[net.ReadString()] = net.ReadBit() == 1 and true or nil
end)

net.Receive('pointshop_equipped_t', function()
	net.ReadEntity().pointshop_equipped = net.ReadTable()
end)

local item, rend
hook.Add('PostPlayerDraw', 'pointshop', function(ply)
	if ply:Alive() and ply:GetPos():DistToSqr(EyePos()) < 90000 then
		if ply.pointshop_equipped then
			for _, name in ipairs(table.GetKeys(ply.pointshop_equipped)) do
				item = pointshop.items_byname[name]
				rend = item.render
				if rend then
					rend(ply, item)
				end
			end
		end
	end
end)

hook.Add('InitPostEntity', 'hat_customize', function()
	local str = file.Read('ls_pointshop_customize.txt')

	if str then
		local cust = string.Split(str, ' ')
		local x, y, z, scale = tonumber(cust[1]), tonumber(cust[2]), tonumber(cust[3]), tonumber(cust[4])

		if x and y and z and scale then
			net.Start('hat_customize')
				net.WriteFloat(x)
				net.WriteFloat(y)
				net.WriteFloat(z)
				net.WriteFloat(scale)
			net.SendToServer()
		end
	end
end)

net.Receive('hat_customize', function()
	local ply = net.ReadEntity()
	local x, y, z, scale = net.ReadFloat(), net.ReadFloat(), net.ReadFloat(), net.ReadFloat()
	
	ply.hat_customize = {x, y, z, scale}
end)