pointshop = pointshop or {}
pointshop.items = {}

for i, hat in ipairs(GM.Hats) do
	local item = table.Copy(hat)
	item.category = hat.a and 'Accessories' or 'Hats'
	item.render = GM.RenderHat
	
	table.insert(pointshop.items, item)
end

table.insert(pointshop.items, {
	category = 'Hats',
	paint = function(self, w, h)
		draw.SimpleText("new", "nunito24b", w/2, h/2, HSVToColor(CurTime() * 15, 1, 1), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end,
	name = 'Add a Hat (admin)',
	price = 0,
	buy = function(self, ply)
		ply:ConCommand('pointshop_newhat')
	end,
	disposable = true
})

hook.Call('PointshopItems', GAMEMODE, pointshop.items)

pointshop.items_byname = {}
for k, v in ipairs(pointshop.items) do
	pointshop.items_byname[v.name] = v
end

local meta = FindMetaTable('Player')

function meta:GetPoints()
	return tonumber(self:GetCSVar('points', 0))
end