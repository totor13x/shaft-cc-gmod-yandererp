AddCSLuaFile(GM.ModuleFolder .. 'pointshop/psmodelpanel.lua')

if not sql.TableExists('pointshop_points') then
	sql.Query('CREATE TABLE pointshop_points (steamid string, points int)')
end

if not sql.TableExists('pointshop_items') then
	sql.Query('CREATE TABLE pointshop_items (steamid string, item string)')
end

if not sql.TableExists('pointshop_equipped') then
	sql.Query('CREATE TABLE pointshop_equipped (steamid string, item string)')
end

util.AddNetworkString('pointshop_spawnhat')
util.AddNetworkString('pointshop_buy')
util.AddNetworkString('pointshop_equip')
util.AddNetworkString('pointshop_items')
util.AddNetworkString('pointshop_items_t')
util.AddNetworkString('pointshop_equipped')
util.AddNetworkString('pointshop_equipped_t')
util.AddNetworkString('hat_customize')

net.Receive('pointshop_buy', function(len, ply)
	local i = net.ReadUInt(16)
	local item = pointshop.items[i]

	if item then
		if not item.disposable and ply:HasPointshopItem(item.name) then
			GAMEMODE:Error(ply, 'You already own this item')
			return 
		end

		local pts = ply:GetPoints()
		if pts >= item.price then
			ply:AddPoints(-item.price)

			ply:AddPointshopItem(item.name)
		else
			GAMEMODE:Error(ply, "You don't have enough points!")
		end
	end
end)

net.Receive('pointshop_equip', function(len, ply)
	local i = net.ReadUInt(16)
	local item = pointshop.items[i]

	if ply:HasPointshopItem(item.name) then
		local equipped = ply:PointshopEquipped(item.name)
		
		if item.equip then
			item:equip(ply, not equipped)
		end
		
		net.Start('pointshop_equipped')
		net.WriteEntity(ply)
		net.WriteString(item.name)
		if equipped then
			ply.pointshop_equipped[item.name] = nil
			sql.Query(string.format('DELETE FROM pointshop_equipped WHERE steamid = %s AND item = %s', SQLStr(ply:SteamID()), SQLStr(item.name)))
			net.WriteBit(false)
		else
			ply.pointshop_equipped[item.name] = true
			sql.Query(string.format('INSERT INTO pointshop_equipped (steamid, item) VALUES (%s, %s)', SQLStr(ply:SteamID()), SQLStr(item.name)))
			net.WriteBit(true)
		end
		net.Broadcast()
	end
end)

net.Receive('pointshop_spawnhat', function(len, ply)
	if ply:IsSuperAdmin() then
	local t = net.ReadTable()
	local e = ents.Create('spawned_hat')
	e:SetPos(ply:GetEyeTrace().HitPos + Vector(0, 0, 20))
	e:Spawn()
	e:SetHat(t)
	end
end)

local meta = FindMetaTable('Player')

function meta:SetPoints(points)
	self:SetCSVar('points', points)
	sql.Query(string.format('UPDATE pointshop_points SET points = %s WHERE steamid = %s', points, SQLStr(self:SteamID())))
end

function meta:AddPoints(points)
	self:SetPoints(self:GetPoints() + points)
end

function meta:HasPointshopItem(item)
	local yes = sql.QueryValue(string.format('SELECT 1 FROM pointshop_items WHERE steamid = %s and item = %s', SQLStr(self:SteamID()), SQLStr(item))) -- self.pointshop_items[item]
	return tobool(yes)
end

function meta:PointshopEquipped(item)
	local yes = self.pointshop_equipped[item]--sql.QueryValue(string.format('SELECT 1 FROM pointshop_equipped WHERE steamid = %s and item = %s', SQLStr(stm), SQLStr(item)))
	return tobool(yes)
end

function meta:AddPointshopItem(itemname)
	local item = pointshop.items_byname[itemname]

	if not item then
		return
	end

	if item.buy then
		item:buy(self)
	end

	if not item.disposable then
		sql.Query(string.format('INSERT INTO pointshop_items (steamid, item) VALUES (%s, %s)', SQLStr(self:SteamID()), SQLStr(item.name)))
		self.pointshop_items[item.name] = true
		net.Start('pointshop_items')
			net.WriteString(item.name)
		net.Send(self)
		
		--local current_items = self:GetCSVar('pointshop_items', false)
		--self:SetCSVar('pointshop_items', current_items and ('\n' .. item.name) or item.name)
	end
end

hook.Add('PlayerAuthed', 'pointshop', function(ply, stm)
	local points = sql.QueryValue('SELECT points FROM pointshop_points WHERE steamid = ' .. SQLStr(stm))

	if not points then
		sql.Query(string.format('INSERT INTO pointshop_points (steamid, points) VALUES (%s, 0)', SQLStr(stm)))
		points = 0
	end

	ply:SetCSVar('points', points)

	ply.pointshop_items = {}
	ply.pointshop_equipped = {}

	local query = sql.Query('SELECT item FROM pointshop_items WHERE steamid = ' .. SQLStr(stm))
	if query then
		for k, v in ipairs(query) do
			ply.pointshop_items[v.item] = true
		end
	end

	net.Start('pointshop_items_t')
		net.WriteTable(ply.pointshop_items)
	net.Send(ply)

	local query = sql.Query('SELECT item FROM pointshop_equipped WHERE steamid = ' .. SQLStr(stm))
	if query then
		for k, v in ipairs(query) do
			ply.pointshop_equipped[v.item] = true
		end
	end

	net.Start('pointshop_equipped_t')
		net.WriteEntity(ply)
		net.WriteTable(ply.pointshop_equipped)
	net.Broadcast()

	-- equip items
end)

hook.Add('PlayerFullyLoaded', 'pointshop_send', function(ply)
	net.Start('pointshop_items_t')
		net.WriteTable(ply.pointshop_items)
	net.Send(ply)

	net.Start('pointshop_equipped_t')
		net.WriteEntity(ply)
		net.WriteTable(ply.pointshop_equipped)
	net.Broadcast()

	for k, v in ipairs(player.GetAll()) do
		if ply ~= v then
			net.Start('pointshop_equipped_t')
				net.WriteEntity(v)
				net.WriteTable(v.pointshop_equipped)
			net.Send(ply)
		end

		if v.hat_customize then
			local x, y, z, scale = v.hat_customize[1], v.hat_customize[2], v.hat_customize[3], v.hat_customize[4]
			net.Start('hat_customize')
				net.WriteEntity(v)
				net.WriteFloat(x)
				net.WriteFloat(y)
				net.WriteFloat(z)
				net.WriteFloat(scale)
			net.Send(ply)
		end
	end
end)

net.Receive('hat_customize', function(len, ply)
	local x, y, z, scale = math.Clamp(net.ReadFloat(), -10, 10), math.Clamp(net.ReadFloat(), -10, 10), math.Clamp(net.ReadFloat(), -10, 10), math.Clamp(net.ReadFloat(), 0.5, 2)
	timer.Create('hat_customize' .. ply:EntIndex(), 1, 1, function()
		ply.hat_customize = {x, y, z, scale}
		
		net.Start('hat_customize')
			net.WriteEntity(ply)
			net.WriteFloat(x)
			net.WriteFloat(y)
			net.WriteFloat(z)
			net.WriteFloat(scale)
		net.Broadcast()
	end)
end)