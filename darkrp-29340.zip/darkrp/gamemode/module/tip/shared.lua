if SERVER then
	util.AddNetworkString('mg_tip')
	function GM:Tip(clr, text, voice, snd, top, ply)
		net.Start('mg_tip')
			net.WriteColor(isstring(clr) and color_white or clr)
			net.WriteString(isstring(clr) and clr or text)
			net.WriteBool(voice or false)
			net.WriteString(snd or 'lampoviy_server/tip.ogg')
			net.WriteBool(top or false)
		if ply then
			net.Send(ply)
		else
			net.Broadcast()
		end
	end
else
	surface.CreateFont('MG_Tip', {
		font = 'Obelix Pro Italic',
		extended = true,
		size = 24,
	})

	local tipAlpha = 0
	local tipPos = 0
	local tipColor = color_white
	local tipText = ''
	local tipTop = false
	
	local function urlEncode( str )
	   if ( str ) then
	      str = string.gsub( str, "\n", "\r\n" )
	      str = string.gsub( str, "([^%w ])",
	         function (c) return string.format( "%%%02X", string.byte(c) ) end )
	      str = string.gsub( str, " ", "+" )
	   end
	   return str
	end

	
	function GM:Tip(clr, text, voice, snd, top)
		tipAlpha = 2500
		tipColor = clr
		tipText = text
		tipPos = -200
		tipTop = top
		
		surface.PlaySound(snd or 'lampoviy_server/tip.ogg')
		if voice then
			sound.PlayURL('http://translate.google.com/translate_tts?ie=UTF-8&total=1&idx=0&textlen=32&client=tw-ob&q=' .. urlEncode(text) .. '&tl=ru-ru', 'mono', function(snd)
				if IsValid(snd) then snd:Play() end
				snd = nil
			end)
		end
	end

	net.Receive('mg_tip', function()
		GAMEMODE:Tip(net.ReadColor(), net.ReadString(), net.ReadBool(), net.ReadString(), net.ReadBool())
	end)
	
	hook.Add('HUDPaint', 'MGTip', function()
		if tipAlpha > 0 then
			local ypos = 64
			if tipPos < ypos then
				tipPos = Lerp(FrameTime() * 4, tipPos, ypos)
			end
			
			surface.SetFont('MG_Tip')
			local w, h = surface.GetTextSize(tipText)
			local x, y = ScrW()/2, (tipTop and 0 or ScrH()) + math.ceil(tipPos) * (tipTop and 1 or -1)

			draw.RoundedBox(8, x - w/2 - 8, y - (tipTop and 0 or h) - 8, w + 16, 40, Color(0, 0, 0, math.Clamp(tipAlpha, 0, 255)))

			draw.SimpleText(tipText, 'MG_Tip', x, y, ColorAlpha(tipColor, tipAlpha), TEXT_ALIGN_CENTER, tipTop and TEXT_ALIGN_TOP or TEXT_ALIGN_BOTTOM)
			tipAlpha = tipAlpha - FrameTime()*500
		end
	end)
end