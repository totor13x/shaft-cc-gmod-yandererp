function GM:ShowTeam()
end

GM.RandomPosition = function(ent, frst_pos, scnd_pos)
	local trace, rand
	local i = 0
	repeat
		i = i + 1
		if i >= GAMEMODE.Settings.randompos_limit then
			print('GM.RandomPosition was unable to find suitable pos!')
			debug.Trace()
			
			return
		end

		rand = Vector()
		rand.x = math.random(frst_pos.x, scnd_pos.x)
		rand.y = math.random(frst_pos.y, scnd_pos.y)
		rand.z = math.random(frst_pos.z, scnd_pos.z)
		
		trace = util.TraceHull({
			start = rand,
			endpos = rand,
			mins = ent:OBBMins() * 1.5,
			maxs = ent:OBBMaxs() * 1.5
		})
	until (trace.Hit == false and trace.HitNonWorld == false and trace.HitTexture ~= 'TOOLS/TOOLSINVISIBLE' and trace.HitTexture ~= 'TOOLS/TOOLSSKYBOX')

	return trace.HitPos
end
