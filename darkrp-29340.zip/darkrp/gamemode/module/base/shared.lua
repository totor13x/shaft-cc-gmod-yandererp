GM.playerDropPos = function(ply)
	local st = ply:EyePos()
	local ed = ply:GetEyeTrace().HitPos
    local tr = util.TraceLine {
        start =  st,
        endpos = st + (ed - st):GetNormalized() * 100,
        filter = ply
    }

    return tr.HitPos
end

function Say(text)
    RunConsoleCommand('say', text)
end

GM.secondsToClock = function(time)
    time = math.ceil(time)

    local s = time % 60
    local m = ((time - s) / 60) % 60
    local h = math.floor(time / 60 / 60)
    
    return (h < 10 and '0' or '') .. h .. ':' .. (m < 10 and '0' or '') .. m .. ':' .. (s < 10 and '0' or '') .. s
end

GM.minutesToClock = function(time)
    time = math.ceil(time)

    local min = time % 60
    local hour = math.floor(time / 60) % 60
    local days = math.floor(time / 60 / 60)
    
    return days .. 'd ' .. hour .. 'h ' .. min .. 'm'
end

--https://github.com/Metastruct/luadev/blob/master/lua/autorun/easylua.lua#L120
local _R = debug.getregistry()

local function compare(a, b)

	if a == b then return true end
	if a:find(b, nil, true) then return true end
	if a:lower() == b:lower() then return true end
	if a:lower():find(b:lower(), nil, true) then return true end

	return false
end

local function comparenick(a, b)
	local MatchTransliteration = GLib and GLib.UTF8 and GLib.UTF8.MatchTransliteration
	if not MatchTransliteration then return compare (a, b) end

	if a == b then return true end
	if a:lower() == b:lower() then return true end
	if MatchTransliteration(a, b) then return true end

	return false
end

local function compareentity(ent, str)
	if ent.GetName and compare(ent:GetName(), str) then
		return true
	end

	if ent:GetModel() and compare(ent:GetModel(), str) then
		return true
	end

	return false
end

GM.FindEntity = function(str)
	if not str then return NULL end

	str = tostring(str)

	-- unique id
	local ply = player.GetByUniqueID(str)
	if ply and ply:IsPlayer() then
		return ply
	end

	-- steam id
	if str:find("STEAM") then
		for key, _ply in ipairs(player.GetAll()) do
			if _ply:SteamID() == str then
				return _ply
			end
		end
	end

	if str:sub(1,1) == "_" and tonumber(str:sub(2)) then
		str = str:sub(2)
	end

	if tonumber(str) then
		ply = Entity(tonumber(str))
		if ply:IsValid() then
			return ply
		end
	end

	-- ip
	if SERVER then
		if str:find("%d+%.%d+%.%d+%.%d+") then
			for key, _ply in ipairs(player.GetAll()) do
				if _ply:IPAddress():find(str) then
					return _ply
				end
			end
		end
	end
	-- search in sensible order

	-- search exact
	for _,ply in ipairs(player.GetAll()) do
		if ply:Nick()==str then
			return ply
		end
	end

	-- Search bots so we target those first
	for key, ply in ipairs(player.GetBots()) do
		if comparenick(ply:Nick(), str) then
			return ply
		end
	end

	-- search from beginning of nick
	for _,ply in ipairs(player.GetHumans()) do
		if ply:Nick():lower():find(str,1,true)==1 then
			return ply
		end
	end

	-- Search normally and search with colorcode stripped
	for key, ply in ipairs(player.GetAll()) do
		if comparenick(ply:Nick(), str) then
			return ply
		end

		if _G.UndecorateNick and comparenick( UndecorateNick( ply:Nick() ), str) then
			return ply
		end
	end

	-- search RealName
	if _R.Player.RealName then
		for _, ply in ipairs(player.GetAll()) do
			if comparenick(ply:RealNick(), str) then
				return ply
			end
		end
	end

	if not me or not isentity(me) or not me:IsPlayer() then
		for key, ent in ipairs(ents.GetAll()) do
			if compareentity(ent, str) then
				return ent
			end
		end
	else
		local tr = me:GetEyeTrace()
		local plpos = tr and tr.HitPos or me:GetPos()
		local closest,mind = nil,math.huge
		for key, ent in ipairs(ents.GetAll()) do
			local d = ent:GetPos():DistToSqr(plpos)
			if d < mind and compareentity(ent, str) then
				closest = ent
				mind = d
			end
		end
		if closest then
			return closest
		end
	end

	do -- class

		local _str, idx = str:match("(.-)(%d+)$")
		if idx then
			idx = tonumber(idx)
			str = _str
		else
			str = str
			idx = (me and me.easylua_iterator) or 0

			if me and isentity(me) and me:IsPlayer() then

				local tr = me:GetEyeTrace()
				local plpos = tr and tr.HitPos or me:GetPos()
				local closest,mind = nil,math.huge
				for key, ent in ipairs(ents.GetAll()) do
					local d = ent:GetPos():DistToSqr(plpos)
					if d < mind and compare(ent:GetClass(), str) then
						closest = ent
						mind = d
					end
				end
				if closest then
					return closest
				end
			end

		end

		local found = {}

		for key, ent in ipairs(ents.GetAll()) do
			if compare(ent:GetClass(), str) then
				table.insert(found, ent)
			end
		end

		return found[math.Clamp(idx%#found, 1, #found)] or NULL
	end
end