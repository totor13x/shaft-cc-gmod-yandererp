-- source: https://github.com/FPtje/DarkRP/blob/fd95cf68e6a01a1b0522c4a989d4512fc0fb202d/gamemode/modules/base/cl_gamemode_functions.lua

local FKeyBinds = {
    ["gm_showhelp"] = "ShowHelp",
    ["gm_showteam"] = "ShowTeam",
    ["gm_showspare1"] = "ShowSpare1",
    ["gm_showspare2"] = "ShowSpare2"
}

function GM:PlayerBindPress(ply, bind, pressed)
    self.Sandbox.PlayerBindPress(self, ply, bind, pressed)

    if pressed then
        local bnd = string.match(string.lower(bind), "gm_[a-z]+[12]?")
        if bnd and FKeyBinds[bnd] then
            hook.Call(FKeyBinds[bnd], GAMEMODE)
            return true
        end
    end
end

hook.Add("ChatText", "_", function(index, name, text, typ)
	--if typ == "joinleave" or typ == "teamchange" then return true end
	return typ ~= 'none'
end)

local enablescreenclicker = false

hook.Add('ShowSpare1', 'Mouse', function()
    enablescreenclicker = not enablescreenclicker
    gui.EnableScreenClicker(enablescreenclicker)
end)

surface.CreateFont('nunito24b', {
	font = 'Nunito Black',
	size = 24,
	weight = 900,
	extended = true,
})

surface.CreateFont('nunito24', {
	font = 'Nunito',
	size = 24,
	weight = 500,
	extended = true,
})

surface.CreateFont('nunito22', {
	font = 'Nunito',
	size = 22,
	extended = true,
})

surface.CreateFont('nunito20', {
	font = 'Nunito',
	size = 20,
	extended = true,
})

surface.CreateFont('nunito18', {
	font = 'Nunito',
	size = 18,
	extended = true,
})

surface.CreateFont('nunito16', {
	font = 'Nunito',
	size = 16,
	extended = true,
})

surface.CreateFont('nunito14', {
	font = 'Nunito',
	size = 14,
	extended = true,
})

surface.CreateFont('nunito12', {
	font = 'Nunito',
	size = 12,
	extended = true,
})

surface.CreateFont('nunito24s', {
	font = 'Nunito',
	size = 24,
	weight = 500,
	extended = true,
	shadow = true
})

surface.CreateFont('nunito32s', {
	font = 'Nunito',
	size = 32,
	weight = 500,
	extended = true,
	shadow = true
})

surface.CreateFont('nunito32', {
	font = 'Nunito',
	size = 32,
	weight = 500,
	extended = true,
})