hook.Add('PlayerSpawn', 'rp_hunger', function(ply)
    ply:SetCSVar('Hunger', 100)
end)

timer.Create('rp_hunger', 10, 0, function()
    for _, ply in ipairs(player.GetAll()) do
        local hunger =  ply:GetCSVar('Hunger', 0)
        if hunger <= 0 then
            ply:TakeDamage(GAMEMODE.Settings.hunger_damage, ply, ply)
        else
            ply:SetCSVar('Hunger', math.Clamp(hunger - (ply:IsPremium() and GAMEMODE.Settings.hunger_premium_starve or GAMEMODE.Settings.hunger_starve), 0, 100))
        end
    end
end)