local function Open() 
	local f = file.Read('sperm.dat', 'DATA')
	return f and util.JSONToTable(util.Decompress( f )) or {}
end

local function Round(v)
	v.x = math.Round(v.x) v.y = math.Round(v.y) v.z = math.Round(v.z)
	return v
end

local function Col(v)
	for i, k in ipairs({'r', 'g', 'b'}) do
		if v[k] ~= 255 then
			return v
		end
	end
	return nil
end

Perm = { 
	props = Open(),
	spawned = {}
}

function Perm:Update()
	file.Write('sperm.dat', util.Compress( util.TableToJSON(self.props) ))
	self.props = Open()
end

function Perm:Add(ent, spawn)
	local t = {
		ang = Round(ent:GetAngles()),
		class = ent:GetClass() ~= 'prop_physics' and ent:GetClass() or nil,
		color = Col(ent:GetColor()),
		material = ent:GetMaterial() ~= '' and ent:GetMaterial() or nil,
		model = ent:GetModel(),
		pos = Round(ent:GetPos()),
		spawn = spawn
	}
	table.insert(self.props, t)
	table.insert(self.spawned, ent)
	self:Update()
end

function Perm:Remove(ent)
	local i = table.KeyFromValue(self.spawned, ent)
	if i then
		table.remove(self.props, i)
		table.remove(self.spawned, i)
		//ent:Remove()
		self:Update()
	end
end

local function Autism()
	Perm.spawned = {}
	for i, t in ipairs(Perm.props) do
		local ent = ents.Create(t.class and t.class or 'prop_dynamic')
		if not IsValid(ent) then
			print('no entity: ' .. t.class)
			continue
		end
		ent:SetPos(t.pos)
		ent:SetAngles(t.ang)
		ent:SetModel(t.model)
		ent:Spawn()

		table.insert(Perm.spawned, ent)

		local phys = ent:GetPhysicsObject()

		if not IsValid(phys) or not phys:IsMoveable() then
			ent:PhysicsInit(SOLID_VPHYSICS)
			ent:SetSolid(SOLID_VPHYSICS)
			ent:SetMoveType(MOVETYPE_NONE)

			phys = ent:GetPhysicsObject()
		end

		if IsValid(phys) then
			phys:EnableMotion(false)
		end

		if t.color then
			ent:SetColor(t.color)
		end

		if t.material then
			ent:SetMaterial(t.material)
		end

		if t.spawn  then
			local f = CompileString( [[ local ent = ({...})[1] ]] .. t.spawn, 'Perm')
			if not isfunction(f) then print(f)
			else print(pcall(f, ent)) end
		end	
	end
end

hook.Add('InitPostEntity', 'Perm', Autism)
hook.Add('PostCleanupMap', 'Perm', Autism)