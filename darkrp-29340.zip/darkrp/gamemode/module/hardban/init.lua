local q = sql.Query
local qv = sql.QueryValue
local qs = SQLStr
local sf = string.format

local r

if not sql.TableExists('hardban') then
	q('CREATE TABLE hardban (data, why, id)')
end

local function find(data)
	return qv('SELECT id FROM hardban WHERE data = ' .. qs(data))
end

local function info(data)
	return q('SELECT * FROM hardban WHERE data = ' .. qs(data) .. ' OR id = ' .. qs(data))
end

local function why(data)
	return qv('SELECT why FROM hardban WHERE data = ' .. qs(data) .. ' OR id = ' .. qs(data))
end

local function cleanip(ip)
	return ip:sub(0, ip:find(':') - 1)
end

util.AddNetworkString('RPVarsT')

local function ban(self, data, reason, id, nofind)
	if not nofind and isstring(data) then
		for _, p in ipairs(player.GetAll()) do
			if p:SteamID() == data or data:find(cleanip(p:IPAddress())) then
				data = p
				break
			end
		end
	end

	if type(data) == 'Player' then
		if data.nowhardbanning then
			return
		end

		data.nowhardbanning = true

		GAMEMODE:ChatPrint(Color(96, 96, 96), data:SteamID() .. ' ' .. qs(data:GetName()) .. ' has been hardbanned')
		GAMEMODE:DiscordEmbed({
			title = '**hardban ' .. data:SteamID() .. '**',
			color = 16711680,
			fields = {
				{name = 'reason', value = reason},
			}
		}, 'anticheat', data)
		
		id = id or data:GetName()
		string.Replace(id, '"', '')
		
		self(data:SteamID(), reason, id, true)
		self(cleanip(data:IPAddress()), reason, id, true)
		
		if data.steam_family then
			ban(data.steam_family, 'main', id)	
		end
		
		net.Start('RPVarsT')
		net.Send(data)
		
		timer.Simple(5, function()
			if IsValid(data) then
				data:Kick('hardban: ' .. (reason or 'no reason') .. '\n(*￣Ｏ￣)ノ')	
			end
		end)
		
		return
	end
	
	reason = reason or ''
	
	if self.why(data) == reason then
		return
	end
	
	q('DELETE FROM hardban WHERE data = ' .. qs(data))
	q(sf('INSERT INTO hardban VALUES ("%s", "%s", "%s")', data, reason, id or os.time()))
end

local function unban(data)
	q('DELETE FROM hardban WHERE id = ' .. qs(find(data)) .. ' OR id = ' .. qs(data))
	GAMEMODE:ChatPrint(Color(96, 96, 96), data .. ' has been unhardbanned')
end

hardban = {
	find = find,
	info = info,
	why = why,
	unban = unban,
}

setmetatable(hardban, {
	__call = ban
})

concommand.Add('hardban', function(p, _, args)
	if not IsValid(p) or p:IsSuperAdmin() then
		hardban(unpack(args))
	end
end)

concommand.Add('unhardban', function(p, _, _, args)
	if not IsValid(p) or p:IsSuperAdmin() then
		hardban.unban(args)
	end
end)

concommand.Add('hardban_info', function(p, _, _, args)
	if not IsValid(p) or p:IsAdmin() then
		PrintTable(hardban.info(args))
	end
end)

util.AddNetworkString("hochu_hard")

net.Receive('hochu_hard', function(_, ply)
	local stm = net.ReadString()
	
	local id = find(stm)
	if id then
		hardban(ply, 'alt', id)
	end
end)

hook.Add('CheckPassword', 'hardban', function(stm, ip)
	stm = util.SteamIDFrom64(stm)
	ip = cleanip(ip)

	local ipban = find(ip)
	local stmban = find(stm)
	
	if ipban and not stmban then
		hardban(stm, 'alt steam', ipban)
	end
	
	if stmban and not ipban then
		hardban(ip, 'new ip', stmban)	
	end
	
	if ipban or stmban then
		return false, [[

hardban
(｡･ω･)ﾉﾞ
]]
	end
end)

hook.Add("PlayerAuthed", "hardban", function(p)
	timer.Simple(10, function()
		if IsValid(ply) then 
			http.Fetch(
			string.format("http://api.steampowered.com/IPlayerService/IsPlayingSharedGame/v0001/?key=%s&format=json&steamid=%s&appid_playing=4000",
				'B58D153443A405163360282F9111B169',
				ply:SteamID64()
			),
		
			function(body)
				local body = util.JSONToTable(body)
				if not body or not body.response or not body.response.lender_steamid then
					return
				end
				local lender = body.response.lender_steamid
				if lender ~= "0" then
					local steamid = util.SteamIDFrom64(lender)
					
					local ban = hardban.find(steamid)
					if ban then
						hardban(ply, 'family alt', ban)
					end
					
					ply.steam_family = steamid
				end
			end)
		end
	end)
end)