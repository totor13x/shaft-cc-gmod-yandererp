hook.Add('RP_CustomJobs', '_', function()

DarkRP.Jobs = {}

local normalsalary = 10

local PLAYER = FindMetaTable('Player')

local school_staff = {}
local _teachers = {}
local teacher = function(subject, model, desc, cmd, spawn) 
	local tm = DarkRP.createJob(subject, {
		color = Color(25, 128, 255),
		model = model,
		description = desc,
		weapons = {"arrest_stick", "unarrest_stick", "stunstick", "weaponchecker", "maxmol_mark"},
		command = cmd,
		max = 1,
		salary = normalsalary * 5,
		admin = 0,
		vote = false,
		category = "Взрослые",
		adult = true,
		police = true,
		spawnpoints = spawn or default_spawns
	})

	_teachers[tm] = true
	
		table.insert(school_staff, tm)
	return tm
end

local teachers = {'models/corpseparty/yuuya/yuuya.mdl', 'models/corpseparty/yui/yui.mdl', 'models/madfather/alfred/alfred.mdl'}

function PLAYER:IsTeacher()
	return _teachers[self:Team()] or false
end

function PLAYER:IsStudent()
	return not self:GetJobTable().adult
end

TEAM_TEACHER_MATH = teacher('Учитель математики',
	teachers,
	[[Как вычислить дискриминант квадратного уравнения? А площадь параллелограмма? Станьте учителем математики - царицы наук - и поведайте своим ученикам, что пифагоровы штаны во все стороны равны.
Вы не должны грубить ученикам и применять грубую силу в воспитательных целях. Вы обязаны по окончании урока поставить всем присутствовавшим ученикам оценки.]],
	'teacher_math',
	Vector(520, 53, 60)
)
 
TEAM_TEACHER_BIO = teacher('Учитель биологии',
   teachers,
	[[Вам выпадет роль поведать юным умам, как устроено их тело и как размножаются цветы и прочие живые организмы…
Вы не должны грубить ученикам и применять грубую силу в воспитательных целях. Вы обязаны по окончании урока поставить всем присутствовавшим ученикам оценки.]],
	'teacher_bio',
	Vector(520, 443, 60)
)

/*
TEAM_TEACHER_RUS = teacher('Учитель японского',
	teachers,
	[[Вооружитесь азбукой, терпением и желанием научить молодежь правильно и грамотно излагать свои мысли.]],
	'teacher_rus'
)*/
 
TEAM_TEACHER_CHEM = teacher('Учитель химии',
	'models/player/dewobedil/persona5/tae_takemi/doctor_p.mdl',
	[[Заставьте ваших учеников вызубрить всю таблицу Менделеева, выучить все виды спиртов и соединений; химия - наука тонкая. 
Вы не должны грубить ученикам и применять грубую силу в воспитательных целях. Вы обязаны по окончании урока поставить всем присутствовавшим ученикам оценки.]],
	'teacher_chem',
	Vector(2393, 1746, 60)
)

TEAM_TEACHER_FOREIGN = teacher('Учитель иностранного',
	teachers,
	[["London is the capital of Great Britain...". Знание иностранного в наше время очень важно, и вам, как учителю иностранного, выпала роль научить забугорным языкам ваших учеников.
Вы не должны грубить ученикам и применять грубую силу в воспитательных целях. Вы обязаны по окончании урока поставить всем присутствовавшим ученикам оценки.]],
	'teacher_foreign',
	Vector(2391, 1341, 60)
)

/*
TEAM_TEACHER_PHYS = teacher('Учитель физики',
	teachers,
	[[Любые два тела притягиваются друг к другу с силой прямо пропорциональной произведению масс тела и обратно пропорциональной квадрату расстояния между ними... Вам, как учителю физики, придется научить молодежь закону всемирного тяготения, закону Гука и прочим физическим премудростям, ибо на планете ничего без физики не происходит.]],
	'teacher_phys'
)*/
 
TEAM_TEACHER_ICT = teacher('Учитель информатики',
	teachers,
	[[Что такое информация? Как сложить два числа на языке Pascal? Каково назначение входов на задней стороне системного блока? Научите своих учеников всем азам и тонкостям владения компьютером.
Вы не должны грубить ученикам и применять грубую силу в воспитательных целях. Вы обязаны по окончании урока поставить всем присутствовавшим ученикам оценки.]],
	'teacher_ict',
	Vector(1819, -41, 180)
)
 
/*TEAM_TEACHER_CULTURE = teacher('Учитель культуры', 
	teachers,
	[[Расскажите и покажите своим студентам, что такое пост-модернизм в живописи, научите их выразить все, что у них на душе на холсте бумаги.]],
	'teacher_culture'
)
 
TEAM_TEACHER_LITERATURE = teacher('Учитель литературы', 
	teachers,
	[[Как правильно писать стихотворения? Почему Гоголь сжег второй том "Мёртвых душ"? Заставьте молодежь знать классику, заставьте их выучить всего Пушкина, это ваш долг, как учителя литературы. .]],
	'teacher_literature'
)*/
 
TEAM_TEACHER_SPORT = teacher('Учитель физкультуры',
	'models/corpseparty/yuuya/yuuya.mdl',
	[[В здоровом теле - здоровый дух. Ваша обязанность, как учителя физкультуры, держать растущее поколение в хорошем физическом состоянии. 
Вы не должны грубить ученикам и применять грубую силу в воспитательных целях. Вы обязаны по окончании урока поставить всем присутствовавшим ученикам оценки.]],
	'teacher_sport',
	Vector(3023, 509, 72)
)

TEAM_TEACHER_HISTORY = teacher('Учитель истории',
	teachers,
	[[Великая депрессия в США? Эра пиратства? Развал СССР? Возьмите на себя роль учителя истории и преподавайте её ученикам..
Вы не должны грубить ученикам и применять грубую силу в воспитательных целях. Вы обязаны по окончании урока поставить всем присутствовавшим ученикам оценки.]],
	'teacher_history',
	Vector(2395, 960, 60)
)

TEAM_TEACHER_GEOGRAPHY = teacher('Учитель географии',
	teachers,
	[[Вам выпадает чудесная роль поведать школьникам всё о нашей самой любимой третьей планете от Солнца, отличить Южную Корею от Северной и прочие такие важные для жизни знания.
Вы не должны грубить ученикам и применять грубую силу в воспитательных целях. Вы обязаны по окончании урока поставить всем присутствовавшим ученикам оценки.]],
	'teacher_geography',
	Vector(2028, 17, 60)
)

local default_spawns = {
Vector(1257, -683, 8),
Vector(1344, -681, 8),
Vector(1437, -679, 8),
Vector(1529, -677, 8),
Vector(1658, -675, 8),
Vector(1656, -561, 8),
Vector(1551, -563, 8),
Vector(1440, -565, 8),
Vector(1318, -568, 8),
Vector(1315, -451, 8),
Vector(1440, -448, 8),
Vector(1576, -446, 8),
Vector(1675, -444, 8),
Vector(1673, -357, 8),
Vector(1584, -359, 8),
Vector(1467, -361, 8),
Vector(1337, -363, 8),
Vector(1249, -343, 8),
}
local boys_spawns = default_spawns

local girls_spawns = default_spawns

local cp_spawns = default_spawns

TEAM_SHKOLNIK = DarkRP.createJob("Школьник", {
	color = Color(20, 150, 20, 255),
	model = {
		"models/corpseparty/sakutaro/sakutaro.mdl",
		"models/corpseparty/satoshi/satoshi.mdl",
		"models/fzone96/senpai.mdl",
		"models/player/koyomi_araragi.mdl",
	},
	description = [[Ты – школьник. Посещай уроки, кушай в буфете, копи деньги.
Постарайся не стать возлюбленным Яндере, ведь она пойдёт на всё, чтобы получить тебя.
Проявлять агрессию в качестве инициатора строго запрещено.]],
	weapons = {'weapon_fists'},
	command = "schoolguy",
	max = 0,
	salary = normalsalary,
	admin = 0,
	vote = false,
	hasLicense = false,
	candemote = false,
	category = "Школьники",
	spawnpoints = boys_spawns,
})

TEAM_FEMINE = DarkRP.createJob("Школьница", {
	color = Color(183, 46, 114, 255),
	model = {
		"models/player/dewobedil/uiharu_kazari/default_p.mdl",
		"models/player/dewobedil/saten_ruiko/default_p.mdl",
		"models/player/dewobedil/misaka_mikoto/summer_p.mdl",
		"models/player/dewobedil/misaka_mikoto/winter_p.mdl",
		"models/player/dewobedil/shirai_kuroko/summer_p.mdl",
		"models/player/dewobedil/shirai_kuroko/winter_p.mdl",
		"models/corpseparty/ayumi/ayumi.mdl",
		"models/corpseparty/mayu/mayu.mdl",
		"models/corpseparty/naomi/naomi.mdl",
		"models/corpseparty/seiko/seiko.mdl",
		"models/corpseparty/tohko/tohko.mdl",
	},
	description = [[Ты - обычная школьница, посещай уроки и гуляй сколько влезет.
Яндере может покалечить тебя, узнав, что ты гуляешь с её возлюбленным.
Мирная профессия, не может проявлять агрессию в качестве инициатора.]],
	weapons = {},
	command = "schoolgirl",
	max = 0,
	salary = normalsalary,
	admin = 0,
	vote = false,
	hasLicense = false,
	category = "Школьники",
	spawnpoints = girls_spawns,
})

/*
TEAM_SENPAI = DarkRP.createJob("Сенпай", {
	color = Color(69, 119, 0, 255),
	model = {
		"models/fzone96/senpai.mdl",
	},
	description = [[Сенпай – мечта всех школьниц, добрый, отзывчивый и дружелюбный. Осторожно, возможно за тобой следит твоя яндере~
Проявлять агрессию в качестве инициатора строго запрещено.]],
	weapons = {'weapon_fists'},
	command = "senpai",
	max = 1,
	salary = normalsalary,
	admin = 0,
	vote = false,
	hasLicense = false,
	category = "Школьники",
	spawnpoints = boys_spawns,
})*/

TEAM_YANDERE = DarkRP.createJob("Яндере", {
	color = Color(109, 0, 0, 255),
	model = "models/player/shi/yandere_chan.mdl",
	description = [[Яндере - самая преданная девушка из всех. Заставь сенпая полюбить только тебя и никого более. Даже если придётся убить всех на своем пути...
Не может убивать конкуренток при свидетелях и когда шкала любви не находится на пределе, не может проявлять агрессию в качестве инициатора.]],
	weapons = {'weapon_fists', 'yandere'},
	command = "yandere",
	max = 1,
	salary = normalsalary,
	admin = 0,
	vote = false,
	hasLicense = false,
	category = "Школьники",
	spawnpoints = girls_spawns,
	unlockprice = 1500,
})

TEAM_HIKKY = DarkRP.createJob("Хикикомори", {
	color = Color(17, 9, 74, 255),
	model = "models/player/tomoko_pl.mdl",
	description = [[Вы отказались от социальной жизни и стараетесь отгородиться от мира. Не ходите на уроки, сидите в общежитии и делайте что-нибудь, главное - старайтесь не выходить на улицу!
Мирная профессия, не может проявлять агрессию в качестве инициатора.]],
	weapons = {},
	command = "Hikky",
	max = 0,
	salary = normalsalary,
	admin = 0,
	vote = false,
	hasLicense = false,
	category = "Школьники",
	spawnpoints = {
Vector(2358, 3604, 100),
Vector(2357, 3498, 100),
Vector(2360, 3887, 100),
},
})

TEAM_HULIGAN = DarkRP.createJob("Хулиган", {
	color = Color(63, 63, 63, 255),
	model = "models/corpseparty/yoshiki/yoshiki.mdl",
	description = [[Хулиганы держатся вместе, они избивают других школьников, грабят их, грубят учителям, курят в туалетах... Много чего еще, это и так все знают.
Может инициировать конфликты. Запрещено убивать взрослых, даже если вся ваша толпа вооружена.]],
	weapons = {'weapon_fists'},
	command = "huligan",
	max = 6,
	salary = normalsalary,
	admin = 0,
	vote = false,
	hasLicense = false,
	category = "Школьники",
	spawnpoints = boys_spawns,
})

local clubhead = function(subject, model, desc, cmd, membmodel, membdesc, weps, spawn, wepshead) 
	return DarkRP.createJob("Глава " .. subject, {
		color = Color(255, 93, 0),
		model = model,
		description = desc,
		weapons = wepshead or weps,
		command = 'headclub_' .. cmd,
		max = 1,
		salary = normalsalary * 2,
		admin = 0,
		vote = true,
		category = "Клубы",
		spawnpoints = spawn,
		unlockprice = 1000,
	}),
	membmodel and DarkRP.createJob("Член " .. subject, {
		color = Color(76, 113, 234, 255),
		model = membmodel,
		description = membdesc,
		weapons = weps,
		command = "member_" .. cmd,
		max = 3,
		salary = normalsalary,
		admin = 0,
		category = "Клубы",
		spawnpoints = spawn,
	}) or nil
end

/*
TEAM_CLUB_GAME = clubhead('Игрового клуба', 
	"models/player/dewobedil/no_game_no_life/shiro/default_p.mdl", 
	[[Управляйте своим игровым клубом и ищите новых любителей игровой индустрии. Можете сделать свою игру и выставлять её на школьной ярмарке!]],
	'headclub_game',
	nil, nil, nil

)*/

TEAM_CLUB_MUSIC, TEAM_CLUBMEMBER_MUSIC = clubhead('Музыкального клуба', 
	"models/player/lty/lty_player.mdl", 
	[["Тортики или жизнь!". Разучивайте песни, настраивайте инструменты и, самое главное, кушайте тортики со своим клубом настоящих музыкантов! Вы можете воспроизводить музыку в микрофон, при этом вас нельзя мутить, но не стоит этим злоупотреблять, ведь клубная деятельность – превыше всего.
Мирная профессия, не может проявлять агрессию.]],
	'headclub_music',
	"models/player/dewobedil/danganronpa/kaede_akamatsu/default_p.mdl",
	[[Музыка – это то, чем вы живете? Тогда добро пожаловать! Разучивайте песни и осваивайте музыкальные инструменты! Вы можете воспроизводить музыку в микрофон, при этом тебя нельзя мутить, но не стоит этим злоупотреблять, ведь клубная деятельность – превыше всего.
Мирная профессия, не может проявлять агрессию.]],
	nil,
	{
Vector(453, 1095, 60),
Vector(455, 999, 60),
Vector(456, 900, 60),
Vector(547, 899, 60),
Vector(549, 1005, 60),
Vector(550, 1104, 60),
	}
)

TEAM_CLUB_CULT, TEAM_CLUBMEMBER_CULT = clubhead('Оккультного клуба', 
	'models/player/dewobedil/gundam_tanaka/default_p.mdl', 
	[[Управляйте своим оккультным клубом и пробуйте вызывать демона и прочие вещи, которые делают сектанты. Жертвоприношение разрешено, только если жертва сама выбрала эту судьбу.
Мирная профессия, не может проявлять агрессию.]],
	'headclub_cult',
	"models/player/dewobedil/danganronpa/himiko_yumeno/default_p.mdl",
	[[Оккультизм – очень интересная и увлекательная вещь, особенно если вы увлекаетесь изучением паранормальных явлений. Присоединяйтесь к нам, если хотите пощекотать нервишки, вызывая демона! Жертвоприношение разрешено, только если жертва сама выбрала эту судьбу.
Мирная профессия, не может проявлять агрессию.]],
	nil,
	{
Vector(2008, 1938, 60),
Vector(1894, 1939, 60),
Vector(1762, 1940, 60),
Vector(1761, 1842, 60),
Vector(1896, 1841, 60),
Vector(2007, 1841, 60),
	}
)

/*TEAM_CLUB_THEATRE = clubhead('Театрального клуба', 
	'models/player/dewobedil/celestia_ludenberg/default_p.mdl', 
	[["Грация и искусство!" - девиз вашего клуба. Покажите всем настоящую театральную игру вместе со своим клубом!]],
	'headclub_theatre'
)*/

TEAM_CLUB_SAD, TEAM_CLUBMEMBER_SAD = clubhead('клуба садоводства', 
	'models/player/dewobedil/mmd/chell/default_p.mdl', 
	[[Набирайте новых садоводов в свой клуб и становитесь самыми зелёными учениками этой школы! Никто не знает о том, что вы на самом деле занимаетесь производством не совсем легальных растений и их торговлей.
Мирная профессия, не может проявлять агрессию.]],
	'headclub_sad',
	{'models/player/dewobedil/vocaloid/megurine_luka/default_p.mdl', 'models/player/shi/kurisu_shi.mdl'}, 
	[[Вы – самый настоящий любитель флоры! Ухаживайте за цветами, выращивайте новые растения, следите за тем, чтобы все они были вовремя политы. Никто не знает о том, что вы на самом деле занимаетесь производством не совсем легальных растений и их торговлей.
Мирная профессия, не может проявлять агрессию.]],
	{'zwf_cable', 'zwf_shoptablet', 'zwf_wateringcan'},
	{
Vector(1433, 4085, 50),
Vector(1425, 3917, 50),
Vector(1426, 3708, 50),
	}
)

TEAM_CLUB_BAKER, TEAM_CLUBMEMBER_BAKER = clubhead('Кулинарного клуба', 
	'models/player/dewobedil/touhou/junko/default_p.mdl', 
	[[Набирайте новых пекарей в свой клуб и становитесь самыми крутыми поварами этой школы!
Мирная профессия, не может проявлять агрессию.]],
	'headclub_baker',
	{'models/player/dewobedil/maid_dragon/kanna/default_p.mdl', 'models/player/dewobedil/hyperdimension_neptunia/plutia/default_p.mdl'}, 
	[[Если вы любите выпекать кексы, то вы обратились в нужное место! Станьте участником самого «вкусного» клуба в школе. 
Мирная профессия, не может проявлять агрессию.]],
	nil,
	{
Vector(919, 1968, 60),
Vector(922, 1890, 60),
Vector(921, 1784, 60),
Vector(1050, 1885, 60),
Vector(1051, 1987, 60),
Vector(1051, 1781, 60),
	}
)

TEAM_CLUB_JOJO, TEAM_JOJOMEMBER_CLUB = clubhead('клуба качков',
	'models/player/jojo3/jtr.mdl',
	[[Вы - глава самого мускулистого и самого обаятельного клуба в школе. Докажите всем, что вы лучшие.
Мирная профессия, не может проявлять агрессию в качестве инициатора.]],
	'jojo',
	{"models/player/jojo2/csr.mdl", "models/player/jojo2/jsp.mdl"},
	[[Вы - член самого мускулистого и самого обаятельного клуба в школе. Докажите всем, что вы лучшие.
Мирная профессия, не может проявлять агрессию в качестве инициатора.]],
	{'weapon_fists', 'weapon_dumbbell'},
	{
Vector(1789, 8, 314),
Vector(1895, -1, 314),
Vector(1997, 1, 314),
	}
)

/*
TEAM_GOODGUY = DarkRP.createJob("Отличник", {
	color = Color(35, 133, 32, 255),
	model = {
		"models/player/koyomi_araragi.mdl",
	},
	description = [[У него можно списать контрольную. Сделает все что хочешь за деньги.
Мирная профессия, не может проявлять агрессию. Больше всего он боится хулиганов и получить по лицу, поэтому пойдет на все, чтобы избежать конфликта.]],
	weapons = {'weapon_fists'},
	command = "onlygoodguy",
	max = 1,
	salary = normalsalary,
	admin = 0,
	vote = false,
	hasLicense = false,
	category = "Школьники",
	spawnpoints = boys_spawns,
})*/

TEAM_BARIGA = DarkRP.createJob("Сомнительный ученик", {
	color = Color(173, 173, 173, 255),
	model = {
		"models/player/dewobedil/nagito_komaeda/default_p.mdl",
		"models/player/dewobedil/durarara/izaya_orihara/default_p.mdl",
	},
	description = [[Ты продаешь ученикам все самое запрещенное. Будь осторожен: тебя могут поймать за торговлей.
Проявлять агрессию в качестве инициатора строго запрещено, не может вступать в преступные группировки. Вы обязаны отдать товар после его оплаты.]],
	weapons = {},
	command = "bariga",
	max = 3,
	salary = normalsalary,
	admin = 0,
	vote = false,
	hasLicense = false,
	category = "Школьники",
	spawnpoints = boys_spawns,
})

/*
TEAM_GOODGIRL = DarkRP.createJob("Отличница", {
	color = Color(200, 200, 62, 255),
	model = "models/player/dewobedil/saten_ruiko/default_p.mdl",
	description = [[Ты должна посещать все уроки, получать лучшие оценки и отшивать всех парней.
Мирная профессия, не может проявлять агрессию.]],
	weapons = {},
	command = "onlygoodgirl",
	max = 1,
	salary = normalsalary,
	admin = 0,
	vote = false,
	hasLicense = false,
	category = "Школьники",
	spawnpoints = girls_spawns,
})*/

TEAM_MEDIC = DarkRP.createJob("Медсестра", {
	color = Color(70, 40, 100, 255),
	model = {
		'models/player/luka_nurse.mdl',
		'models/player_compa.mdl',
	},
	description = [[Вы лечите детей и учителей, выписываете справки и освобождения от занятий физкультурой. Вы можете работать только на территории школы. Запрещено требовать деньги за лечение.
Мирная профессия, не может проявлять агрессию, не может вступать в преступные группировки.]],
	weapons = {"weapon_medkit"},
	command = "medic",
	max = 2,
	salary = normalsalary * 3,
	admin = 0,
	vote = false,
	hasLicense = false,
	medic = true,
	category = "Взрослые",
	spawnpoints = {
Vector(901, 29, 8),
Vector(1003, 26, 8),
Vector(1001, -42, 8),
Vector(906, -39, 8),
},
	adult = true,
})

TEAM_PSYCHO = DarkRP.createJob("Школьный психолог", {
	color = Color(104, 247, 104, 255),
	model = {
		"models/player/dewobedil/persona5/tae_takemi/default_p.mdl",
		"models/hesyr/ikari/ikari.mdl"
	},
	description = [[Подростковый возраст никогда не был простым у любого из нас. Проводи беседы с учениками, направляй их молодые умы в нужное русло и не позволь им свихнуться в этой школе.
У тебя есть успокоительное, ты можешь давать его ученикам и усмирять им Яндере.
Мирная профессия, не может проявлять агрессию.]],
	weapons = {},
	command = "psycho",
	max = 2,
	admin = 0,
	vote = false,
	salary = normalsalary * 2,
	category = "Взрослые",
	spawnpoints = {
Vector(536, 685, 335),
Vector(536, 574, 335),
Vector(535, 461, 335)},
	adult = true,
	unlockprice = 500,
})

TEAM_ZTM_TRASHMAN = DarkRP.createJob("Уборщик", {
	color = Color(120, 80, 33, 255),
	model = {
		"models/player/dewobedil/mikan_tsumiki/default_p.mdl",
		"models/player/shi/rom_maid.mdl",
	   -- "models/humans/group02/player/tale_05.mdl",
	},
	description = [[Чистота! Твоя работа - держать город в чистоте, а иначе не получишь зарплату. Нельзя проводить уборку во время урока, чтобы не мешать учебному процессу.
Мирная профессия, не может проявлять агрессию.]],
	weapons = {"ztm_trashcollector"},
	command = "cleaner",
	max = 3,  
	salary = normalsalary * 1.5,
	admin = 0,
	vote = false,
	hasLicense = false,
	category = "Взрослые",
	spawnpoints = {
Vector(2297, 1861, 60),
Vector(2300, 1954, 60),
Vector(2389, 1960, 60),
Vector(2387, 1853, 60),
Vector(2481, 1850, 60),
Vector(2476, 1955, 60),
	},
	adult = true,
	unlockprice = 2000,
})

TEAM_COOK = DarkRP.createJob("Повар", {
	color = Color(238, 99, 99, 144),
	model = {
		"models/player/dewobedil/maid_dragon/tohru/default_p.mdl",
		"models/player/shi/maql.mdl",
	},
	description = [[Кормите школьников и учителей в буфете.
Вы можете купить микроволновку и готовить в ней кашу:
/buymicrowave
Вы можете поменять цену продуктов, смотря на микроволновку:
/price <цена>
Мирная профессия, не может проявлять агрессию.]],
	weapons = {"weapon_hl2pan"},
	command = "cook",
	max = 2,
	salary = normalsalary * 1.5,
	admin = 0,
	vote = false,
	hasLicense = false,
	cook = true,
	category = "Взрослые",
	spawnpoints = {
Vector(1262, 63, 170),
Vector(1259, -57, 170),
Vector(1261, -187, 170),
	},
		adult = true,
})

TEAM_HALFDIRECTOR = DarkRP.createJob("Заместитель директора", {
	color = Color(196, 0, 0, 255),
	model = "models/player/dewobedil/danganronpa/togami/default_p.mdl",
	description = [[Вы - заместитель директора по дисциплинарной части.
Разбирайтесь с нарушениями и не давайте ученикам торговать всякой нелегальной херней. Вы можете исполнять полномочия директора в момент его отсутствия.
У вас есть возможность наказать нарушителя.]],
	weapons = {"arrest_stick", "unarrest_stick", 'door_ram', "stunstick", "weaponchecker"},
	command = "halfdirector",
	max = 1,
	salary = normalsalary * 5,
	admin = 0,
	vote = true,
	hasLicense = false,
	mayor = true,
	category = "Взрослые",
	spawnpoints = Vector(529, 884, 320),
	adult = true,
	police = true,
	unlockprice = 1000,
})

TEAM_DIRECTOR = DarkRP.createJob("Директор", {
	color = Color(196, 0, 0, 255),
	model = {"models/player_phoenix.mdl", "models/custom/maes_hughes.mdl"},
	description = [[Вы управляете всей школой. У вас есть возможность сделать объявление по всей школе, а также дать разрешение на строительство на территории школы. Следите за поведением школьников и учителей с помощью камер. Однако учтите, что ваша власть не безгранична: вы обязаны подчиняться приказам мэра!
Мирная профессия, не может проявлять агрессию.]],
	weapons = {"arrest_stick", "unarrest_stick", 'door_ram', "stunstick", "weaponchecker"},
	command = "director",
	max = 1,
	salary = normalsalary * 5,
	admin = 0,
	vote = true,
	hasLicense = false,
	mayor = true,
	category = "Взрослые",
	spawnpoints = Vector(529, 1073, 320),
	adult = true,
	police = true,
	unlockprice = 2000,
})

TEAM_LIBRARY = DarkRP.createJob("Библиотекарь", {
	color = Color(255, 165, 0, 255),
	model = "models/player/dewobedil/danganronpa/tsumugi_shirogane/default_p.mdl",
	description = [[Вы – настоящий книжный червь, наслаждающийся чтением в полной тишине. Следите за тем, чтобы книги были сданы в срок, а также за тем, чтобы никто не нарушал идеальную тишину в библиотеке!
Мирная профессия, не может проявлять агрессию.]],
	weapons = {"arrest_stick", "unarrest_stick", "stunstick", "weaponchecker"},
	command = "library",
	max = 1,
	salary = normalsalary * 2,
	admin = 0,
	vote = false,
	category = "Взрослые",
	spawnpoints = {
Vector(1317, 46, 280),
Vector(1581, 41, 280),
	},
	adult = true,
	police = true,
})

TEAM_TEACH_COMENDANT = DarkRP.createJob("Комендант общежития", { 
	color = Color(188, 226, 40, 255), 
	model = "models/anfrien/2017/skullgirls/zone_tan_(filia)_pm.mdl", --http://steamcommunity.com/sharedfiles/filedetails/?id=950775038
	description = [[Вы следите за общежитием и не даёте школьникам творить беспредел ночью.
У вас есть возможность наказать нарушителя.]], 
	weapons = {"arrest_stick", "unarrest_stick", "stunstick", "door_ram"}, 
	command = "teach_comendant", 
	max = 1,
	salary = normalsalary * 2.5,
	admin = 0,
	category = "Взрослые",
	vote = true,
	candemote = true,
	hasLicense = true,
	spawnpoints = Vector(3255, 3918, 110),
	adult = true,
	police = true,
})

TEAM_BAR = DarkRP.createJob("Управляющий кафе", {
	color = Color(255, 165, 0, 255),
	model = "models/player/dewobedil/danganronpa/kaito_momota/default_p.mdl",
	description = [[Недалеко от бара находится прекрасное кафе, в котором готовят пиццу. Ты – владелец этого кафе, следи за своими сотрудниками и готовь самую вкусную пиццу в этом городе! Вы не можете находиться на территории школы без разрешения директора.
Мирная профессия, не может проявлять агрессию в качестве инициатора.]],
	weapons = {"stunstick", "weaponchecker"},
	command = "barman",
	max = 1,
	salary = normalsalary * 3,
	admin = 0,
	vote = false,
	category = "Взрослые",
	spawnpoints = Vector(3215, -2169, 8),
	adult = true,
})

TEAM_WAITER = DarkRP.createJob("Официант", {
	color = Color(255, 165, 0, 255),
	model = {"models/player/dewobedil/sharo_kirima/maid_p.mdl", "models/player/dewobedil/chino_kafuu/maid_p.mdl"},
	description = [[Приготов, подай… И получи зарплату! Вы только закончили учёбу и нашли свою первую работу.
Мирная профессия, не может проявлять агрессию.]],
	weapons = {"stunstick", "weaponchecker"},
	command = "waiter",
	max = 4,
	salary = normalsalary * 2,
	admin = 0,
	vote = false,
	category = "Взрослые",
	spawnpoints = {
Vector(2822, -2346, 8),
Vector(2932, -2347, 8),
Vector(3088, -2350, 8),
Vector(3226, -2358, 8),
Vector(3361, -2357, 8),
},
	adult = true,
})

TEAM_ADMIN = DarkRP.createJob("Модератор", {
	color = Color(255, 196, 64, 255),
	model = {"models/player/mitchiri.mdl"},
	description = [[Модератор. Да, так просто.]],
	weapons = {"weapon_knife"},
	command = "admin",
	max = 0,
	salary = 0,
	admin = 0,
	vote = false,
	hasLicense = true,
	candemote = false,
	hobo = false,
	customCheck = function( ply ) return ply:GetUserGroup() ~= 'user' and ply:GetUserGroup() ~= 'Premium' end,
	customCheckFailMsg = "Ты должен быть модером что бы стать им!",
	category = "Premium профессии",
	spawnpoints = default_spawns,
	adult = true,
})

hook.Add('PlayerNoClip', 'TEAM_ADMIN', function(ply)
	if ply:Team() == TEAM_ADMIN then
		return true
	end
end)

TEAM_MUSIC = DarkRP.createJob("Вокалоид", {
-- прямо с криминальных убежал к нам.
	color = Color(128, 128, 256, 255),
	model = "models/player/dewobedil/vocaloid/appearance_miku/default_p.mdl",
	description = [[Устраивай концерты в школе или общаге.
Ты можешь петь, включать музыку в микрофон, при этом тебя нельзя мутить. А ещё ты можешь купить музыкальный проигрыватель, рояль, гитару и барабаны.
Мирная профессия, не может проявлять агрессию.]],
	command = "music",
	max = 3,
	salary = normalsalary * 1.5,
	admin = 0,
	vote = false,
	hasLicense = false,
	candemote = true,
	hobo = false,
	customCheck = function( ply ) return ply:IsPremium() end,
	customCheckFailMsg = "Ты должен быть Premium что бы стать им!",
	category = "Premium профессии",
	spawnpoints = default_spawns,
})

TEAM_DOG = DarkRP.createJob("Собака", {
	color = Color(255, 196, 64, 255),
	model = {
	"models/player_amaterasuclosedmouth.mdl",
	"models/player_chibiterasu.mdl",
	},
	description = [[Собака. Гав-гав.
Не может писать в чат и говорить в микрофон, а также ставить пропы. Не имеет права кусать людей без причины.]],
	weapons = {"bark"},
	command = "dog",
	max = 3,
	salary = 0,
	admin = 0,
	vote = false,
	hasLicense = false,
	candemote = true,
	hobo = false,
	customCheck = function( ply ) return ply:IsPremium() end,
	customCheckFailMsg = "Ты должен быть Premium что бы стать им!",
	category = "Premium профессии",
	spawnpoints = default_spawns,
	adult = true,
})

TEAM_INFOCHAN = DarkRP.createJob("Инфо-чан", {
	color = Color(236, 0, 0, 255),
	model = "models/player/tfa_p5_futaba.mdl",
	description = [[Главный источник информации школы. С лёгкостью достаёшь любые запрещенные предметы и обладаешь всей информацией об учениках и учителях.
Мирная профессия, не может проявлять агрессию.]],
	weapons = {""},
	command = "infochan",
	max = 1,
	salary = normalsalary,
	admin = 0,
	vote = false,
	hasLicense = false,
	candemote = true,
	hobo = false,
	customCheck = function( ply ) return ply:IsPremium() end,
	customCheckFailMsg = "Ты должен быть Premium что бы стать им!",
	category = "Premium профессии",
	spawnpoints = default_spawns
})

TEAM_GRAFFITY = DarkRP.createJob("Вандал", {
	color = Color(0, 255, 168, 255),
	model = "models/player/dewobedil/vocaloid/appearance_miku/stroll_p.mdl",
	description = [[В твоем распоряжении баллончик с краской. Рисуй что угодно.
Не может проявлять агрессию в качестве инициатора.]],
	command = "graffity",
	weapons = {"weapon_spraymhs", 'weapon_fists'},
	max = 1,
	salary = normalsalary,
	admin = 0,
	vote = false,
	hasLicense = false,
	candemote = true,
	hobo = false,
	customCheck = function( ply ) return ply:IsPremium() end,
	customCheckFailMsg = "Ты должен быть Premium что бы стать им!",
	category = "Premium профессии",
	spawnpoints = default_spawns
})

TEAM_PHOTOSERVICE = DarkRP.createJob("Виабу с принтером", {
	color = Color(196, 196, 255),
	model = "models/kayn.mdl",
	description = [[Имеет в распоряжении принтер и может печатать твоих любимых лолей по URL!
Мирная профессия, не может проявлять агрессию.]],
	weapons = {},
	command = "photoweeb",
	max = 1,
	salary = normalsalary * 2,
	admin = 0,
	vote = false,
	hasLicense = false,
	candemote = true,
	hobo = false,
	customCheck = function( ply ) return ply:IsPremium() end,
	customCheckFailMsg = "Ты должен быть Premium что бы стать им!",
	category = "Premium профессии",
	spawnpoints = default_spawns
})

TEAM_BLOGGER = DarkRP.createJob("Стример", {
	color = Color(255, 92, 119, 255),
	model = "models/player/dewobedil/vocaloid/kizuna_ai/default_p.mdl",
	description = [[У тебя есть камера, с помощью которой ты можешь стримить.
Мирная профессия, не может проявлять агрессию.]],
	command = "streamer",
	weapons = {"news_camera"},
	max = 1,
	salary = normalsalary * 2,
	admin = 0,
	vote = false,
	hasLicense = false,
	candemote = true,
	hobo = false,
	customCheck = function( ply ) return ply:IsPremium() end,
	customCheckFailMsg = "Ты должен быть Premium что бы стать им!",
	category = "Premium профессии",
	spawnpoints = default_spawns
})
TEAM_LITCLUB_MONIKA = DarkRP.createJob("Моника", { 
	color = Color(226, 128, 49, 255),
	model = "models/player/ddlc__monika.mdl", --http://steamcommunity.com/sharedfiles/filedetails/?id=1209719142
	description = [[Глава литературного клуба со странным поведением. Управляйте своим клубом и радуйтесь жизни.
Мирная профессия, не может проявлять агрессию.]], 
	weapons = {}, 
	command = "monika", 
	max = 1,
	salary = normalsalary,
	admin = 0,
	vote = false,
	hasLicense = false,
	candemote = true,
	customCheck = function( ply ) return ply:IsPremium() end,
	customCheckFailMsg = "Ты должен быть Premium что бы стать им!",
	Premium = true,
	category = "Premium профессии",
	spawnpoints = default_spawns
	})
	
   TEAM_LITCLUB_SAYORI = DarkRP.createJob("Сайори", {
	color = Color(188, 221, 68, 255),
	model = "models/player/ddlc__sayori.mdl", --http://steamcommunity.com/sharedfiles/filedetails/?id=1265297763
	description = [[Вице-Президент литературного клуба и очень весёлая девушка. Помогайте главе с клубом и набирайте новых участников.
Мирная профессия, не может проявлять агрессию.]],
	weapons = {},
	command = "sayori",
	max = 1,
	salary = normalsalary,
	admin = 0, 
	vote = false,
	hasLicense = false,
	candemote = true,
	customCheck = function( ply ) return ply:IsPremium() end,
	customCheckFailMsg = "Ты должен быть Premium что бы стать им!",
	Premium = true,
	category = "Premium профессии",
	spawnpoints = default_spawns
		
	})
	TEAM_LOLI = DarkRP.createJob("Лоли", {
	color = Color(234, 125, 194, 255),
	model = {
		-- "models/cyanblue/kemonofriends/tsuchinoko/tsuchinoko.mdl",
		"models/player/dewobedil/chino_kafuu/winter_p.mdl",
		"models/player/dewobedil/chino_kafuu/default_p.mdl"
	},
	description = [[Вы обычная лоли, которая любит, когда её гладят по голове, а также своих старших братиков. 
Мирная профессия, не может проявлять агрессию.]], --http://steamcommunity.com/sharedfiles/filedetails/?id=1237820249
	weapons = {},
	command = "loli",
	max = 0,
	salary = normalsalary,
	admin = 0,
	vote = false,
	hasLicense = false,
	candemote = true,
	customCheck = function( ply ) return ply:IsPremium() end,
	customCheckFailMsg = "Ты должен быть Premium что бы стать им!",
	Premium = true,
	category = "Premium профессии",
	spawnpoints = default_spawns
	})

/*
TEAM_LITCLUB_MEMBER = DarkRP.createJob("Член Литературного клуба", {
	color = Color(34, 68, 119, 255),
	model = {
	"models/cyanblue/persona4/tohruadachi/tohruadachi.mdl",
	},
	description = [[Ты член литературного клуба. Пиши стихи, делись с другими членами клуба, пейте чай.]],
	weapons = {'weapon_fists'},
	command = "litclub_member",
	max = 6,
	salary = normalsalary,
	admin = 0,
	vote = false,
	hasLicense = false,
	candemote = false,
	category = "Школьники",
	spawnpoints = default_spawns
})*/

TEAM_CLUB_AIKIDO, TEAM_CLUBMEMBER_AIKIDO = clubhead('клуба Айкидо',
	'models/player/dewobedil/kancolle/kamikaze/default_p.mdl',
	[[Обладая чёрным поясом девятого дана, решилась открыть свой собственный клуб, чтобы продемонстрировать другим ученикам образцовую технику и глубочайшие духовные качества бойца.
- Имеет коробку с деревянной катаной.
ОСОБЕННОСТЬ ПРОДАЖИ ОРУЖИЯ: По школьному уставу не имеет права продавать Катану человеку, не входящему в Клуб.
Мирная профессия, не может проявлять агрессию.]],
	'aikido',
	'models/player/miku_kimono.mdl',
	[[Только начинает изучать базовые техники стиля Айкидо без оружия. После сдачи экзамена имеет право взять в руки Боккэн - деревянный меч для тренировок.
Мирная профессия, не может проявлять агрессию.]], {},
	default_spawns
)

TEAM_PAINT_HEAD, TEAM_PAINT = clubhead('клуба рисования',
	'models/player/luo_tianyi.mdl',
	[[Вы с самого детства любите рисовать и само понятие творчество, каждый день, рисуя мангу или интересные картины, вы мечтали о клубе, который мог бы Вам подойти, и вот пришёл день, когда вы основали свой собственный клуб рисования.
Мирная профессия, не может проявлять агрессию.]],
	'paint',
	'models/player/shi/tenno.mdl',
	[[И вот настал тот день, когда ты стал членом клуба рисования.
Покажи всем насколько велик твой талант и не подведи товарищей клуба, дай волю своей фантазии!
Мирная профессия, не может проявлять агрессию.]], {}, {
Vector(1419, 1912, 8),
Vector(1494, 1911, 8),
Vector(1606, 1901, 8),
Vector(1599, 1817, 8),
Vector(1487, 1813, 8),
Vector(1383, 1810, 8),
}
)

TEAM_SOVIET_PRESIDENT = DarkRP.createJob("Президент школьного совета", {
	color = Color(48, 213, 200, 255),
	model = "models/player/dewobedil/kancolle/murasame/default_p.mdl",
	description = [[Следи за всей деятельностью школьных клубов, направляй клубы в нужное русло и не давай им нарушать школьный устав!
Мирная профессия, не может проявлять агрессию.]],
	weapons = {},
	command = "soviet_president",
	max = 1,
	vote = true,
	admin = 0,
	salary = normalsalary * 2,
	category = "Клубы",
	unlockprice = 1000,
	spawnpoints = {Vector(967, 1968, 280)},
})

/*
TEAM_CINEMA = DarkRP.createJob("Работник кинотеатра", {
	color = Color(29, 230, 255, 255),
	model = 'models/player/dewobedil/danganronpa/rantaro_amami/default_p.mdl',
	description = [[Вы работаете в местном кинотеатре и принимаете заказы на показ роликов. Имеет право требовать деньги за сеанс кинофильма.
Мирная профессия, не может проявлять агрессию.]],
	weapons = {},
	command = "cinema",
	max = 1,
	salary = normalsalary * 1.5,
	category = "Городские профессии",
	admin = 0,
	vote = false,
	hasLicense = false,
	candemote = true,
	spawnpoints = {
		Vector(3024, -1396, 45),
		Vector(3022, -1300, 45),
		Vector(3019, -1190, 45),
		Vector(2897, -1190, 45),
		Vector(2895, -1309, 45),
		Vector(2898, -1428, 45),
		Vector(2775, -1426, 45),
		Vector(2756, -1259, 45),
		Vector(2752, -1125, 45),
	},
		adult = true,
})

TEAM_SUPERMARKET = DarkRP.createJob("Продавец продуктов", {
	color = Color(255, 77, 0, 255),
	model = 'models/player/shi/maql.mdl',
	description = [[Твоя работа - сидеть в супермаркете и продавать людям продукты!
Мирная профессия, не может проявлять агрессию.]],
	weapons = {},
	command = "supermarket",
	max = 1,
	salary = normalsalary * 2,
	category = "Городские профессии",
	admin = 0,
	vote = false,
	candemote = true,
	cook = true,
	spawnpoints = {
		Vector(980, -1430, 53),
		Vector(819, -1423, 53),
		Vector(609, -1415, 53),
		Vector(423, -1408, 53),
	},
		adult = true,
})

TEAM_BARTENDER = DarkRP.createJob("Бармен", {
	color = Color(171, 56, 95, 255),
	model = "models/cyanblue/persona4/yu_narukami/yunarukami.mdl",
	description = [[В центре города открылся новый бар. Ты продаешь выпивку в этом баре.
Мирная профессия, не может проявлять агрессию в качестве инициатора.]],
	weapons = {'stunstick'},
	command = "bartender",
	max = 1,
	salary = normalsalary * 2,
	admin = 0,
	vote = false,
	hasLicense = false,
	candemote = true,
	hobo = false,
	category = "Городские профессии",
	spawnpoints = {
		Vector(776, 1095, 84),
		Vector(774, 1193, 84),
		Vector(771, 1333, 84),
	},
		adult = true,
})

TEAM_BUS_DRIVER = DarkRP.createJob("Водитель автобуса", {
	color = Color(212, 96, 38),
	model = "models/player/dewobedil/kancolle/amatsukaze/default_p.mdl",
	description = [[Вся твоя жизнь посвящена вождению автобуса. Никогда не оставляй свое дело. Бери автобус на автобусной станции и веди его строго по маршруту.
Мирная профессия, не может проявлять агрессию.]],
	weapons = {"stunstick"},
	command = "bus_driver",
	max = 1,
	salary = normalsalary * 2,
	admin = 0,
	vote = false,
	candemote = true,
	hobo = false,
	category = "Городские профессии",
	spawnpoints = default_spawns,
	adult = true,
})*/

TEAM_GUARD = DarkRP.createJob("Охранник", {
	color = Color(29, 21, 188, 255),
	model = {
		"models/player/miku_cop_p.mdl",
		"models/kemono_friends/shoebill/shoebill.mdl",
		"models/player/rokiahi_p.mdl",
		"models/player/benci_p.mdl",
	},
	description = [[Ты охранник. Следи за хулиганами, докладывай все директору. Следит за тем, чтобы ночью в школе не было посторонних. 
Является мирной профессией, но не стоит его злить.]],
	weapons = {"arrest_stick", "unarrest_stick", "stunstick", "door_ram", "weaponchecker", 'maxmol_taser'},
	command = "guard",
	max = 5,
	salary = normalsalary * 3,
	admin = 0,
	vote = false,
	hasLicense = true,
	category = "Взрослые",
	spawnpoints = default_spawns,
	adult = true,
	police = true,
})

TEAM_FIRE = DarkRP.createJob("Пожарный", {
	color = Color(255, 90, 32, 255),
	model = "models/cyanblue/fate/astolfo/astolfo.mdl",
	description = [[Ты - пожарный патруль школы.
У тебя есть огнетушитель. Используй его по назначению.
Мирная профессия, не может проявлять агрессию.]],
	weapons = {"door_ram", 'weapon_extinguisher_infinite'},
	command = "fire",
	max = 3,
	salary = normalsalary * 2.5,
	admin = 0,
	vote = false,
	hasLicense = false,
	category = "Взрослые",
	spawnpoints = cp_spawns,
	adult = true,
})

/*
TEAM_NURCE = DarkRP.createJob("Доктор", {
	color = Color(252, 108, 133, 255),
	model = "models/player/luka_nurse.mdl",
	description = [[Ты – городской доктор. Лечи людей, сохраняй жизни. Вы можете требовать деньги за лечение.
Мирная профессия, не может проявлять агрессию, МОЖЕТ вступать в преступные группировки, и нести за это наказание]],
	weapons = {'weapon_medkit'},
	command = "doctor",
	max = 1,
	vote = false,
	admin = 0,
	salary = normalsalary * 3,
	category = "Городские профессии",
	spawnpoints = default_spawns,
	adult = true,
})*/

/*
TEAM_GUARD_CIVIL = DarkRP.createJob("Охранник", {
	color = Color(29, 21, 188, 255),
	model = {
		"models/player/miku_cop_p.mdl"
	},
	description = [[Городской охранник может устроиться на работу и выполнять указания начальства. Вас могут нанять в качестве охраны частного лица. 
Мирная профессия, не может проявлять агрессию в качестве инициатора.]],
	weapons = {"stunstick", "door_ram", "weaponchecker"},
	command = "guard_civil",
	max = 3,
	salary = normalsalary * 3,
	admin = 0,
	vote = false,
	category = "Городские профессии",
	spawnpoints = default_spawns,
		adult = true,
})*/

TEAM_POLICE = DarkRP.createJob("Полицейский", {
	color = Color(29, 21, 188, 255),
	model = {
		"models/jazzmcfly/tanya/tanya.mdl",
		"models/player/dewobedil/kancolle/akitsu_maru/default_p.mdl",
		"models/player/dewobedil/kancolle/u511/default_p.mdl",
	},
	description = [[Вас вызвали в школу, потому что появляются слухи о росте преступности среди школьников.
Патрулируй школу и территорию. Арестовывай преступников и верши правосудие. Разрешено использовать огнестрельное оружие только при крайней необходимости! Убегающего от вас преступника можно остановить электрошокером. Вы не можете знать, что школьник является преступником, пока не увидите совершенное преступление.
/wanted <имя>, чтобы объявить человека в розыск.]],
	weapons = {"arrest_stick", "unarrest_stick", "stunstick", "door_ram", "weaponchecker", "sci_fi_pistol", 'maxmol_taser'},
	command = "cp",
	max = 5,
	salary = normalsalary * 3,
	admin = 0,
	vote = true,
	hasLicense = true,
	category = "Взрослые",
	spawnpoints = cp_spawns,
	adult = true,
	police = true,
	unlockprice = 800,
})

TEAM_PRISONGUARD = DarkRP.createJob("Смотритель тюрьмы", {
	color = Color(128, 64, 255),
	model = {
		"models/player/rokiahi_gasmask_p.mdl",
		"models/player/benci_mask_p.mdl"
	},
	description = [[Следи, чтобы никто не сбегал из тюрьмы.
Является мирной профессией, но не стоит его злить.]],
	weapons = {"arrest_stick", "unarrest_stick", "stunstick", "weaponchecker", 'weapon_taser'},
	command = "prisonguard",
	max = 3,
	salary = normalsalary * 2.5,
	admin = 0,
	vote = true,
	hasLicense = true,
	category = "Взрослые",
	spawnpoints = {
Vector(696, 1746, -420),
Vector(691, 1928, -420),
Vector(936, 1836, -420),
Vector(1168, 1825, -420),
},
	adult = true,
	police = true,
})
/*
TEAM_POLICE_CHIEF = DarkRP.createJob("Шеф полиции", {
	color = Color(29, 21, 160, 255),
	model = {
		"models/player/dewobedil/kancolle/u511/default_p.mdl"
	},
	description = [[За тобой управление всей полицией города! Закон должен быть соблюден! Вы руководите всеми спец. операциями, обязаны следить за своими сотрудниками, а также слушать приказы мэра. Вы не можете находиться на территории школы без ведома директора или приказа мэра.
/wanted <имя>, чтобы объявить человека в розыск.]],
	weapons = {"arrest_stick", "unarrest_stick", "stunstick", "door_ram", "weaponchecker", "sci_fi_pistol", 'maxmol_taser'},
	command = "chief",
	max = 1,
	salary = normalsalary * 3,
	admin = 0,
	vote = true,
	hasLicense = true,
	chief = true,
	category = "Городские профессии",
	spawnpoints = cp_spawns,
	adult = true,
	police = true,
})


TEAM_MAYOR = DarkRP.createJob("Мэр", {
	color = Color(196, 0, 0, 255),
	model = "models/custom/maes_hughes.mdl",
	description = [[Судьба всего города в ваших руках! Станьте достойным правителем!
Вы отдаёте приказы Шефу полиции, а также можете сами объявлять преступников в розыск (/wanted <имя>, чтобы объявить человека в розыск)
Вы вправе находиться на территории школы без ведома директора. 
При наличии веской причины вы можете запретить майнинг, однако требуется введение комендантского часа (/lockdown, чтобы начать/закончить комендантский час) для проверки на майнеры.
Есть возможность провести лотерею - (lottery) и оповестить город (/broadcast).
Вы даете разрешение на строительство на территории города]],
	weapons = {"arrest_stick", "unarrest_stick", "stunstick", "weaponchecker"},
	command = "mayor",
	max = 1,
	salary = normalsalary * 3.5,
	admin = 0,
	vote = true,
	hasLicense = false,
	mayor = true,
	police = true,
	category = "Городские профессии",
	spawnpoints = {
		Vector(1950, 2320, 140),
		Vector(1952, 2189, 140),
		Vector(1954, 2054, 140),
	},
	adult = true,
})*/

TEAM_DIRECTOR_KID = DarkRP.createJob("Дочь директора", {
	color = Color(255, 41, 77, 255),
	model = "models/player/renri_yamine.mdl",
	description = [[Будучи дочкой директора является самой популярной девочкой в школе. Свою популярность обрела из-за своего жёсткого характера и похабного отношения к учёбе. При этом весь дневник заполнен пятёрками, ведь при любой полученной двойке она жалуется отцу.
Мирная профессия, не может проявлять агрессию в качестве инициатора.]],
	weapons = {'weapon_fists'},
	command = "director_kid",
	max = 1,
	salary = normalsalary * 2,
	customCheck = function( ply ) return ply:IsPremium() end,
	customCheckFailMsg = "Ты должен быть Premium что бы стать им!",
	Premium = true,
	admin = 0,
	category = "Premium профессии",
	spawnpoints = default_spawns
})

TEAM_CHANGE = DarkRP.createJob("Ученик по обмену", {
	color = Color(240, 152, 22, 255),
	model = "models/yuki/dualdestinies/apollo/player_apollo.mdl",
	description = [[Приехал в эту школу по программе обмена. До этого учился в одной из самых худших школ страны, в которой был известен из-за хамского поведения и частых вымогательств у учеников.
Может инициировать конфликты. Запрещено убивать взрослых, даже если вся ваша толпа вооружена.]],
	weapons = {'weapon_fists', 'weapon_hl2brokenbottle'},
	command = "changestudent",
	max = 1,
	salary = normalsalary * 1.5,
	customCheck = function( ply ) return ply:IsPremium() end,
	customCheckFailMsg = "Ты должен быть Premium что бы стать им!",
	Premium = true,
	admin = 0,
	category = "Premium профессии",
	spawnpoints = default_spawns
})

TEAM_MAIL = DarkRP.createJob("Журналист", {
	color = Color(92, 0, 0, 255),
	model = "models/player/dewobedil/persona4/marie/default_p.mdl",
	description = [[Являешься главным источником информации в городе. Всегда находишься в гуще события, берёшь интервью, а также обладаешь секретами и информацией о многих жителях города.
Мирная профессия, не может проявлять агрессию.]],
	weapons = {'weapon_fists'},
	command = "mail",
	max = 1,
	vote = false,
	admin = 0,
	salary = normalsalary * 2,
	customCheck = function( ply ) return ply:IsPremium() end,
	customCheckFailMsg = "Ты должен быть Premium что бы стать им!",
	Premium = true,
	admin = 0,
	category = "Premium профессии",
	spawnpoints = default_spawns,
		adult = true,
})

TEAM_NATSUKI = DarkRP.createJob("Нацуки", {
	color = Color(172, 91, 108, 255),
	model = {"models/player/ddlc__natsuki.mdl"},
	description = [[Один из ключевых членов литературного клуба 
Читай мангу и критикуй Юри.
Мирная профессия, не может проявлять агрессию.]],
	weapons = {},
	command = "natsuki",
	max = 1,
	salary = normalsalary,
	admin = 0,
	vote = false,
	hasLicense = false,
	candemote = true,
	customCheck = function( ply ) return ply:IsPremium() end,
	customCheckFailMsg = "Ты должен быть Premium что бы стать им!",
	Premium = true,
	category = "Premium профессии",
	spawnpoints = default_spawns
})

TEAM_YURI = DarkRP.createJob("Юри", {
	color = Color(98, 27, 214, 255),
	model = {"models/player/ddlc__yuri.mdl"},
	description = [[Ключевой член литературного клуба. 
Читай книги и критикуй Нацуки.
Мирная профессия, не может проявлять агрессию.]],
	weapons = {},
	command = "yuri",
	max = 1,
	salary = normalsalary,
	admin = 0,
	vote = false,
	hasLicense = false,
	candemote = true,
	customCheck = function( ply ) return ply:IsPremium() end,
	customCheckFailMsg = "Ты должен быть Premium что бы стать им!",
	Premium = true,
	category = "Premium профессии",
	spawnpoints = default_spawns
})

TEAM_ZFRUITSLICER = DarkRP.createJob("Смузимейкер", {
	color = Color(0, 128, 255, 255),
	model = {
		'models/pacagma/sao/llenn_v2/llenn_v2_player.mdl'
	},
	description = [[Продаёт самый вкусный смузи! Также может сделать необычный смузи с различными эффектами. 
Мирная профессия, не может проявлять агрессию.]],
	weapons = {'zfs_knife'},
	command = "FruitSlicer",
	max = 2,
	salary = normalsalary,
	customCheck = function( ply ) return ply:IsPremium() end,
	customCheckFailMsg = "Ты должен быть Premium что бы стать им!",
	admin = 0,
	vote = false,
	adult = true,
	category = "Premium профессии",
	hasLicense = false
})

TEAM_YAKUZA = DarkRP.createJob("Преступник", {
	color = Color(96, 96, 96, 255),
	model = {
		'models/cyanblue/persona5/akira_kurusu/akirakurusu.mdl', 'models/player/dewobedil/celestia_ludenberg/default_p.mdl'
	},
	description = [[Вы – член школьной преступной группировки. Вы можете собираться в группу из трех и более людей, устраивать вооруженные ограбления как школьников, так и взрослых, однако действовать вы можете только в присутствии Главы Преступников, не можете нападать на более чем одного человека, и не должны быть никем замечены. Вы можете убивать и грабить, а также играть в азартные игры и заниматься другими нелегальными делами (продажа наркотиков, оружия). 
Вы можете нанять Хулигана для выполнения задания.]],
	weapons = {},
	command = "yakuza",
	max = 3,
	salary = normalsalary,
	admin = 0,
	vote = false,
	category = "Школьники",
	spawnpoints = default_spawns,
})

TEAM_YAKUZA_BOSS = DarkRP.createJob("Глава преступников", {
	color = Color(40, 40, 40, 255),
	model = 'models/cyanblue/persona4/tohruadachi/tohruadachi.mdl',
	description = [[Вы руководите опаснейшей группировкой этой школы. Все вооруженные ограбления и убийства группировкой могут проходить только в вашем присутствии.
В группе из трех или более людей вы можете устраивать ограбления как школьников, так и взрослых, однако не можете нападать на более чем одного человека, и не должны быть никем замечены.]],
	weapons = {},
	command = "yakuzaboss",
	max = 1,
	salary = normalsalary,
	admin = 0,
	vote = false,
	category = "Школьники",
	spawnpoints = default_spawns,
	unlockprice = 2500,
})

TEAM_SMUGGLER = DarkRP.createJob("Контрабандист", {
	color = Color(250, 210, 1, 255),
	model = 'models/player_kokichioumabeta.mdl',
	description = [[Вы торгуете нелегальным оружием. Будь осторожен: вас не должны поймать за торговлей.
Не может проявлять агрессию в качестве инициатора.]],
	weapons = {},
	command = "smuggler",
	max = 1,
	salary = normalsalary,
	admin = 0,
	vote = false,
	category = "Школьники",
	spawnpoints = default_spawns,
	unlockprice = 1000,
})

TEAM_NARKOMAN = DarkRP.createJob('Торч',{
	color = Color(0, 128, 255, 255),
	model = "models/player/dewobedil/danganronpa/hajime_hinata/default_p.mdl",
	description = [[Вари мет и пытайся не спалить свою лабораторию.
Имеет право на защиту своей лаборатории и производимого им мета.]],
	weapons = {"zmlab_extractor"},
	command = "narkoman",
	max = 2,
	salary = 10,
	admin = 0,
	vote = false,
	category = "Школьники",
	spawnpoints = default_spawns,
	unlockprice = 2000,
})

if CLIENT then
local mat = CreateMaterial('yakuza_wall', "VertexLitGeneric", {
	["$basetexture"] = "TILE/CEILINGTILEA",
	["$model"] = 1,
})
end

table.insert(school_staff, TEAM_GUARD)
table.insert(school_staff, TEAM_DIRECTOR)
table.insert(school_staff, TEAM_HALFDIRECTOR)
table.insert(school_staff, TEAM_ZTM_TRASHMAN)
table.insert(school_staff, TEAM_TEACH_COMENDANT)
table.insert(school_staff, TEAM_MEDIC)
table.insert(school_staff, TEAM_COOK)
table.insert(school_staff, TEAM_LIBRARY)
table.insert(school_staff, TEAM_PSYCHO)

local police_jobs = {TEAM_POLICE, TEAM_PRISONGUARD}
local school_head = {TEAM_DIRECTOR, TEAM_HALFDIRECTOR, TEAM_GUARD}

AddDoorGroup("Для работников школы", unpack(school_staff))
AddDoorGroup("Кабинет директора", unpack(school_head))
AddDoorGroup("Кафе", TEAM_BAR, TEAM_WAITER)
AddDoorGroup("Бар", TEAM_BARTENDER)
AddDoorGroup("Мэрия", TEAM_MAYOR, TEAM_POLICE, TEAM_POLICE_CHIEF)
AddDoorGroup("Полицейский участок", unpack(police_jobs))
AddDoorGroup("Кинотеатр", TEAM_CINEMA)
AddDoorGroup("Тюрьма", unpack(police_jobs))
AddDoorGroup("Продуктовый магазин", TEAM_SUPERMARKET)
AddDoorGroup("Общежитие", TEAM_TEACH_COMENDANT)
AddDoorGroup("Библиотека", TEAM_LIBRARY, TEAM_LITCLUB_MONIKA, TEAM_LITCLUB_SAYORI, TEAM_LITCLUB_MEMBER)
AddDoorGroup("Медкабинет", TEAM_MEDIC, unpack(school_head))
AddDoorGroup("Комната уборщика", TEAM_ZTM_TRASHMAN, unpack(school_head))
AddDoorGroup("Кабинет психолога", TEAM_PSYCHO, unpack(school_head))
AddDoorGroup("Столовая", TEAM_COOK, unpack(school_head))

AddDoorGroup("Кабинет биологии", unpack(school_staff))
AddDoorGroup("Кабинет математики", unpack(school_staff))
AddDoorGroup("Кабинет химии", unpack(school_staff)) 
AddDoorGroup("Кабинет информатики", unpack(school_staff))
AddDoorGroup("Кабинет иностранного языка", unpack(school_staff))
AddDoorGroup("Кабинет истории", unpack(school_staff))
AddDoorGroup("Кабинет географии", unpack(school_staff))

AddDoorGroup("Клуб Айкидо", TEAM_CLUB_AIKIDO, TEAM_CLUBMEMBER_AIKIDO, TEAM_SOVIET_PRESIDENT, unpack(school_head))
AddDoorGroup("Музыкальный клуб", TEAM_CLUB_MUSIC, TEAM_CLUBMEMBER_MUSIC, TEAM_SOVIET_PRESIDENT, unpack(school_head))
AddDoorGroup("Кулинарный клуб", TEAM_CLUB_BAKER, TEAM_CLUBMEMBER_BAKER, TEAM_SOVIET_PRESIDENT, unpack(school_head))
AddDoorGroup("Клуб рисования", TEAM_PAINT, TEAM_PAINT_HEAD, TEAM_SOVIET_PRESIDENT, unpack(school_head))
AddDoorGroup("Клуб садоводства", TEAM_CLUB_SAD, TEAM_CLUBMEMBER_SAD, TEAM_SOVIET_PRESIDENT, unpack(school_head))
AddDoorGroup("Оккультный клуб", TEAM_CLUB_CULT, TEAM_CLUBMEMBER_CULT, TEAM_SOVIET_PRESIDENT, unpack(school_head))
AddDoorGroup("Качалка", TEAM_CLUB_JOJO, TEAM_JOJOMEMBER_CLUB, TEAM_SOVIET_PRESIDENT, unpack(school_head))
AddDoorGroup("Школьный совет", TEAM_SOVIET_PRESIDENT, unpack(school_head))

AddDoorGroup("Якудза", TEAM_YAKUZA, TEAM_YAKUZA_BOSS)

DarkRP:AddChatTeam('Школьный состав', school_staff)
DarkRP:AddChatTeam('Полиция', police_jobs)
DarkRP:AddChatTeam('Кафе', {TEAM_BAR, TEAM_WAITER})

DarkRP.DefaultTeam = TEAM_SHKOLNIK

/*GAMEMODE.CivilProtection = {
	[TEAM_PRISONGUARD] = true,
	[TEAM_MAYOR] = true,
	[TEAM_RKN] = true,
	[TEAM_POLICE] = true,
	[TEAM_POLICE_CHIEF] = true,
}*/

end)
