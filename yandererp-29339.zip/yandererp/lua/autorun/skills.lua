local function provesti_urok(ply)
	if ply:IsTeacher() and ply:IsInClass() then
		for i, ply_n in ipairs(player.GetAll()) do 
			if ply_n ~= ply and not ply_n:GetJobTable().adult and ply_n:IsInClass() then
				return true
			end
		end
	end
end

ls_skills = {
['Привет'] = { 
  desc = 'Начни играть на сервере!',
  pos = {0, 0},
	check = function(ply)
		return ply:TimeConnected() > 120
	end,
	reward = function(ply)
		ply:AddPifs(5)
	end,
	reward_text = '5₱ (F6)'--'Премиум на 2 дня',
},
['Стать учителем'] = { 
	pos = {2, -77},
	desc = 'Возьмите профессию учителя',
	need = {'Привет',},
	check = function(ply) 
		return ply:IsTeacher()
	end
},
['Плохой учитель'] = { 
	pos = {112, -142},
	desc = 'Выпить на рабочем месте',
	need = {'Стать учителем',}
},
['Не тому ты учишь...'] = {
	pos = {255, -139},
	desc = 'Прогулять рабочий день',
	need = {'Плохой учитель',}
},
['Тиран'] = { 
	pos = {412, -159},
	desc = 'Избить ученика',
	need = {'Не тому ты учишь...',}
},
['Ужасный учитель'] = { 
	pos = {547, -228},
	desc = 'Вас уволил директор за систематические нарушения',
	need = {'Тиран',}
},
['Стать учителем Математики'] = { 
	pos = {-404, -208},
	desc = 'Провести урок за учителя Математики',
	need = {'Стать учителем',},
	check = function(ply) 
		if GetCurrentSchoolSubject() == 'Математика' and ply:Team() == TEAM_TEACHER_MATH then
			return provesti_urok(ply)
		end
	end
},
['Стать учителем Биологии'] = { 
	pos = {-322, -252},
	desc = 'Провести урок за учителя Биологии',
	need = {'Стать учителем',},
	check = function(ply) 
		if GetCurrentSchoolSubject() == 'Биология' and ply:Team() == TEAM_TEACHER_BIO then
			return provesti_urok(ply)
		end
	end
},
['Стать учителем Иностранного'] = { 
	pos = {-229, -283},
	desc = 'Провести урок за учителя Иностранного',
	need = {'Стать учителем',},
	check = function(ply) 
		if GetCurrentSchoolSubject() == 'Иностранный' and ply:Team() == TEAM_TEACHER_FOREIGN then
			return provesti_urok(ply)
		end
	end
},
['Стать учителем Химии'] = { 
	pos = {-128, -303},
	desc = 'Провести урок за учителя Химии',
	need = {'Стать учителем',},
	check = function(ply) 
		if GetCurrentSchoolSubject() == 'Химия' and ply:Team() == TEAM_TEACHER_CHEM then
			return provesti_urok(ply)
		end
	end
},
['Стать учителем Информатики'] = { 
	pos = {0, -310},
	desc = 'Провести урок за учителя Информатики',
	need = {'Стать учителем',},
	check = function(ply) 
		if GetCurrentSchoolSubject() == 'Информатика' and ply:Team() == TEAM_TEACHER_ICT then
			return provesti_urok(ply)
		end
	end
}, 
['Стать учителем Физры'] = { 
	pos = {155, -302},
	desc = 'Провести урок за учителя Физры',
	need = {'Стать учителем',},
	check = function(ply) 
		if GetCurrentSchoolSubject() == 'Физра' and ply:Team() == TEAM_TEACHER_SPORT then
			return provesti_urok(ply)
		end
	end
}, 
['Сколько будет 2+2?'] = { 
	pos = {-534, -276},
	desc = 'Поставить оценки десяти ученикам',
	need = {'Стать учителем Математики',}
},
['Вам не сбежать'] = {
	pos = {-278, 58},
	desc = 'Стать смотрителем тюрьмы',
	need = {'Привет',},
	check = function(ply)
		return ply:Team() == TEAM_PRISONGUARD
	end
},
['Вы свободны...'] = {
	pos = {-437, 94},
	desc = 'Освободить 5 игроков (на это должна быть причина)',
	need = {'Вам не сбежать',}
},
 ['Город будет в безопасности'] = {
	pos = {-642, 156},
	desc = 'Стать полицейским',
	need = {'Вы свободны...',},
	check = function(ply)
		return ply:Team() == TEAM_POLICE
	end
},
['Вы арестованы!'] = {
	pos = {-890, 189},
	desc = 'Арестовать 10 преступников',
	need = {'Город будет в безопасности',}
},
['Не двигаться!'] = {
	pos = {-787, 285},
	desc = 'Ударить электрошокером четырех преступников',
	need = {'Город будет в безопасности',}
},
['Ура, повышение!'] = {
	pos = {-971, 376},
	desc = 'Стать шефом полиции',
	need = {'Вы арестованы!','Не двигаться!',},
	check = function(ply)
		return ply:Team() == TEAM_POLICE_CHIEF
	end
},
['Нарушил - неси ответственность!'] = {
	pos = {-1205, 447},
	desc = 'Арестовать 15 преступников',
	need = {'Ура, повышение!',}
},
['Далеко собрался?'] = {
	pos = {-1096, 528},
	desc = 'Ударить электрошокером 15 преступников',
	need = {'Ура, повышение!',}
},
['Розыскивается преступник...'] = {
	pos = {-966, 575},
	desc = 'Объявить розыск 5 преступников',
	need = {'Ура, повышение!',}
},
['Наш город станет лучшим!'] = {
	pos = {-1257, 691},
	desc = 'Стать мэром города',
	need = {'Нарушил - неси ответственность!','Далеко собрался?','Розыскивается преступник...',},
	check = function(ply)
		return ply:Team() == TEAM_MAYOR
	end
},
['Кому же повезет?'] = {
	pos = {-1445, 768},
	desc = 'Запустить лотерею 5 раз',
	need = {'Наш город станет лучшим!',}
},
['Прямой эфир с мэром города'] = {
	pos = {-1298, 851},
	desc = 'Оповестить город о текущей ситуации в нем (/broadcast)',
	need = {'Наш город станет лучшим!',}
},
['Первый раз в первый класс!'] = {
	pos = {-2, 147},
	desc = 'Войти первый раз в школу',
	need = {'Привет',},
	check = function(ply)
		return not ply:GetJobTable().adult and ply:GetPos():WithinAABox(Vector(368, -240, 8), Vector(2544, 2032, 560))
	end
},
['А вот и первая оценка'] = {
	pos = {54, 316},
	desc = 'Получить первую оценку',
	need = {'Первый раз в первый класс!',}
},
['Мама будет рада!'] = {
	pos = {266, 281},
	desc = 'Получить пятерку',
	need = {'А вот и первая оценка',}
},
['Обожаю уроки'] = {
	pos = {444, 229},
	desc = 'Получить 5 пятерок',
	need = {'Обожаю уроки','Мама будет рада!',}
},
['Я уже в третьем классе!'] = {
	pos = {642, 151},
	desc = 'Перейти в третий класс',
	need = {'Обожаю уроки',}
},
['Я у мамы молодец!'] = {
	pos = {841, 42},
	desc = 'Стать отличником/отличницей',
	need = {'Я уже в третьем классе!',},
	check = function(ply) 
		return ply:Team() == TEAM_GOODGUY or ply:Team() == TEAM_GOODGIRL
	end
},
['Я умный, делаю все правильно!'] = {
	pos = {963, -94},
	desc = 'Получить 15 пятерок',
	need = {'Я у мамы молодец!',}
},
['Обожаю эту цифру!'] = {
	pos = {1051, -214},
	desc = 'Перейти в пятый класс',
	need = {'Я умный, делаю все правильно!',}
},
['Скорее бы получить оценку'] = {
	pos = {1072, -340},
	desc = 'Получить 45 оценок',
	need = {'Обожаю эту цифру!',}
},
['Это лучший день в моей жизни!!!'] = {
	pos = {1093, -455},
	desc = 'Получить 25 пятерок',
	need = {'Скорее бы получить оценку',}
},
['Как же быстро летит время...'] = {
	pos = {1099, -581},
	desc = 'Перейти в девятый класс',
	need = {'Это лучший день в моей жизни!!!',}
},
['Я возглавлю студ. совет!'] = {
	pos = {1098, -697},
	desc = 'Стать президентом школьного совета',
	need = {'Как же быстро летит время...',},
	check = function(ply)
		return ply:Team() == TEAM_SOVIET_PRESIDENT
	end
},
['Я буду скучать...'] = {
	pos = {1088, -813},
	desc = 'Закончить школу',
	need = {'Я возглавлю студ. совет!',}
},
['Не может быть...'] = {
	pos = {67, 469},
	desc = 'Получить двойку',
	need = {'А вот и первая оценка',}
},
['Да мне плевать!'] = {
	pos = {43, 601},
	desc = 'Получить двойки по всем предметам',
	need = {'Не может быть...',}
},
['Ненавижу учителей и школу'] = {
	pos = {-24, 721},
	desc = 'Стать хулиганом',
	need = {'Да мне плевать!',},
	check = function(ply)
		return ply:Team() == TEAM_HULIGAN
	end
},
['Вот оно, жидкое золото'] = {
	pos = {-105, 800},
	desc = 'За хулигана купить пиво у сомнительного ученика',
	need = {'Ненавижу учителей и школу',}
},
['Ну и что?'] = {
	pos = {-145, 875},
	desc = 'Получить 5 двоек',
	need = {'Вот оно, жидкое золото',}
},
['Сяду на заднюю парту и...'] = {
	pos = {-232, 958},
	desc = 'Выпить пиво на уроке',
	need = {'Ну и что?',}
},
['Да хоть 100!'] = {
	pos = {-332, 1074},
	desc = 'Получить 15 двоек',
	need = {'Сяду на заднюю парту и...',}
},
['А ну ка, что тут у нас'] = {
	pos = {-470, 1176},
	desc = 'Купить сигареты у сомнительного ученика',
	need = {'Да хоть 100!',}
},
['Че, самый умный?'] = {
	pos = {-579, 1300},
	desc = 'Побить отличника',
	need = {'А ну ка, что тут у нас',}
},
['Допрыгался...'] = {
	pos = {-689, 1424},
	desc = 'Получить розыск',
	need = {'Че, самый умный?',}
},
['А как же мать?'] = {
	pos = {-808, 1550},
	desc = 'Попасть в тюрьму',
	need = {'Допрыгался...',}
},
['Не могу найти работу, что же делать...'] = {
	pos = {-709, 1679},
	desc = 'Купить битмайнер станцию',
	need = {'А как же мать?',}
},
['У меня есть кое-что для тебя...'] = {
	pos = {207, 580},
	desc = 'Стать сомнительным учеником',
	need = {'Не может быть...',},
	check = function(ply)
		return ply:Team() == TEAM_BARIGA
	end
},
['У меня самый лучший табак'] = {
	pos = {388, 637},
	desc = 'Продать сигареты',
	need = {'У меня есть кое-что для тебя...',}
},
['Крепкое или что-то полегче?'] = {
	pos = {294, 746},
	desc = 'Продать 10 бутылок алкоголя',
	need = {'У меня есть кое-что для тебя...',}
},
['Учитель, не хотите расслабиться?'] = {
	pos = {451, 784},
	desc = 'Продать алкоголь учителю',
	need = {'Крепкое или что-то полегче?','У меня самый лучший табак',}
},
['Всякое бывает...'] = {
	pos = {567, 884},
	desc = 'Продать алкоголь директору',
	need = {'Учитель, не хотите расслабиться?',}
},
['Клубняк'] = {
	pos = {378, 434},
	desc = 'Вступить в любой кружок',
	need = {'А вот и первая оценка',},
	check = function(ply)
		local job = ply:GetJobTable().name
		if job:find('Член') and job:find('клуб')then
			return true
		end
	end
}, 
['Музыка - это искусство'] = {
	pos = {743, 416},
	desc = 'Стать членом музыкального клуба',
	need = {'Клубняк',},
	check = function(ply)
		return ply:Team() == TEAM_CLUBMEMBER_MUSIC
	end
},
['Синтезатор - круто'] = {
	pos = {830, 270},
	desc = 'Сыграть на синтезаторе',
	need = {'Музыка - это искусство',}
},
['Смелс лайк тин спирит'] = {
	pos = {916, 360},
	desc = 'Сыграть на гитаре',
	need = {'Музыка - это искусство',}
},
['Бадабум туц тыщ ц'] = {
	pos = {971, 465},
	desc = 'Сыграть на барабанах',
	need = {'Музыка - это искусство',}
},
['Создадим лучшую группу в городе'] = {
	pos = {1138, 265},
	desc = 'Стать главой музыкального клуба',
	need = {'Синтезатор - круто','Смелс лайк тин спирит','Бадабум туц тыщ ц',},
	check = function(ply) 
		return ply:Team() == TEAM_CLUB_MUSIC
	end
},
['Надо подкачаться...'] = {
	pos = {875, 626},
	desc = 'Стать членом клуба качков',
	need = {'Клубняк',},
	check = function(ply)
		return ply:Team() == TEAM_JOJOMEMBER_CLUB
	end
},
['Рабочий кран'] = {
	pos = {1053, 644},
	desc = 'Поднять на бицепс гантель 100 раз',
	need = {'Надо подкачаться...',}
},
['Еще пару подходиков...'] = {
	pos = {1188, 596},
	desc = 'Поднять на бицепс гантель 250 раз',
	need = {'Рабочий кран',}
},
['Все сморят только на меня!'] = {
	pos = {1287, 504},
	desc = 'Стать главой клуба качков',
	need = {'Еще пару подходиков...',},
	check = function(ply) 
		return ply:Team() == TEAM_CLUB_JOJO
	end
},
['Я - машина'] = {
	pos = {1411, 412},
	desc = 'Поднять на бицепс гантель 400 раз',
	need = {'Все сморят только на меня!',}
},
['Вот они, юные математики!'] = {
	pos = {-710, -421},
	desc = 'Поставить 10 пятерок за учителя математики',
	need = {'Сколько будет 2+2?',}
},
['Из вас выйдет отличный гуманитарий!'] = {
	pos = {-597, -427},
	desc = 'Поставить 10 двоек',
	need = {'Сколько будет 2+2?',}
},
['Флора и Фауна'] = { 
	pos = {-408, -336},
	desc = 'Поставить 10 оценок за учителя Биологии',
	need = {'Стать учителем Биологии',}
},
['Do ypu speak English?'] = { 
	pos = {-245, -392},
	desc = 'Поставить 10 оценок ученикам за учителя Иностранного',
	need = {'Стать учителем Иностранного',}
},
['H2O5OH'] = { 
	pos = {-100, -404},
	desc = 'Поставить 10 оценок за учителя Химии',
	need = {'Стать учителем Химии',}
},
['1001110010'] = { 
	pos = {44, -403},
	desc = 'Поставить 10 оценок ученикам за учителя Информатики',
	need = {'Стать учителем Информатики',}
},
['Три кружочка вокруг школы'] = { 
	pos = {225, -377},
	desc = 'Поставить 10 оценок за учителя Физры',
	need = {'Стать учителем Физры',}
},
['Из вас выйдет отличный гуманитарий!'] = { 
	pos = {-597, -427},
	desc = 'Поставить 10 двоек',
	need = {'Сколько будет 2+2?',}
},
['Биологический отличник'] = {  
	pos = {-501, -434},
	desc = 'Поставить 10 пятерок за учителя Биологии',
	need = {'Флора и Фауна',}
},
['В дворники так сильно хочешь?'] = { 
	pos = {-388, -454},
	desc = 'Поставить 10 двоек за учителя Биологии',
	need = {'Флора и Фауна',}
},
['Оу, вы из англии?'] = { 
	pos = {-305, -475},
	desc = 'Поставить 10 пятерок за учителя Иностранного',
	need = {'Do ypu speak English?',}
},
['Ya znay angliskii'] = { 
	pos = {-200, -491},
	desc = 'Поставить 10 двоек за учителя Иностранного',
	need = {'Do ypu speak English?',}
},
['Менделеев, это ты?'] = { 
	pos = {-124, -496},
	desc = 'Поставить 10 пятерок за учителя Химии',
	need = {'H2O5OH',}
},
['H - Водорд, O - Кислород, C - Углерод, Я - ....'] = { 
	pos = {-36, -488},
	desc = 'Поставить 10 двоек за учителя Химии',
	need = {'H2O5OH',}
},
['Программистер'] = { 
	pos = {54, -499},
	desc = 'Поставить 10 пятерок за учителя Информатики',
	need = {'1001110010',}
},
['Bad coder'] = { 
	pos = {134, -505},
	desc = 'Поставить 10 двоек за учителя Информатики',
	need = {'1001110010',}
},
['Ай красавцы, ай молодцы!'] = { 
	pos = {238, -517},
	desc = 'Поставить 10 пятерок за учителя Физры',
	need = {'Три кружочка вокруг школы',}
},
['Может тебе вступить в клуб качков?'] = { 
	pos = {336, -567},
	desc = 'Поставить 10 двоек за учителя Физры',
	need = {'Три кружочка вокруг школы',}
},
['Открытый урок!'] = {
	pos = {-390, -868},
	desc = 'Провести открытый урок на улице',
	need = {'Вот они, юные математики!','Из вас выйдет отличный гуманитарий!','Биологический отличник','В дворники так сильно хочешь?','Оу, вы из англии?','Ya znay angliskii','Менделеев, это ты?','H - Водорд, O - Кислород, C - Углерод, Я - ....','Программистер','Bad coder','Ай красавцы, ай молодцы!','Может тебе вступить в клуб качков?',}
},
['Оценки получат все!'] = {
	pos = {-224, -871},
	desc = 'Поставить оценки 30 ученикам',
	need = {'Вот они, юные математики!','Из вас выйдет отличный гуманитарий!','Биологический отличник','В дворники так сильно хочешь?','Оу, вы из англии?','Ya znay angliskii','Менделеев, это ты?','H - Водорд, O - Кислород, C - Углерод, Я - ....','Программистер','Bad coder','Ай красавцы, ай молодцы!','Может тебе вступить в клуб качков?',}
},
['Правая рука директора'] = {
	pos = {-312, -985},
	desc = 'Стать зам. директора школы',
	need = {'Открытый урок!','Оценки получат все!',},
	check = function(ply) 
		return ply:Team() == TEAM_HALFDIRECTOR
	end
},
['Лучше бы взялись за ум'] = {
	pos = {-227, -1085},
	desc = 'Посадить 5 хулиганов в тюрьму, нарушивших школьный устав',
	need = {'Правая рука директора',}
},
['Я подменю'] = {
	pos = {-391, -1090},
	desc = 'Заменить учителя',
	need = {'Правая рука директора',},
	check = function(ply)
		if GetCurrentSchoolSubject() and ply:Team() == TEAM_HALFDIRECTOR and ply:IsInClass() then
			for k, v in ipairs(player.GetAll()) do 
				if v:IsTeacher() and v:IsInClass() then
					return
				end
			end

			return true
		end
	end
},
['Директор'] = {
	pos = {-309, -1200},
	desc = 'Стать директором школы',
	need = {'Я подменю','Лучше бы взялись за ум',}
},
['А зачем им телевизор?'] = {
	pos = {-93, -1366},
	desc = 'Купить телевизор и 5 тетрадок для школы',
	need = {'Директор',}
},
['Пока никто не видит...'] = {
	pos = {-238, -1409},
	desc = 'Выпить на рабочем месте',
	need = {'Директор',}
},
['Так так, что тут у нас'] = {
	pos = {-370, -1400},
	desc = 'Посмотреть в камеры наблюдения',
	need = {'Директор',}
},
['Такие работники нам не нужны!'] = {
	pos = {-502, -1341},
	desc = 'Увольте 5 учителей за систематические нарушения',
	need = {'Директор',}
},
['Будут плохо себя вести - поставлю 2 математики подряд!'] = {
	pos = {9, -1268},
	desc = 'Составить расписание',
	need = {'Директор',}
},
['Кто вызывал уборщика?'] = {
	pos = {-297, 249},
	desc = 'Стать уборщиком в школе',
	need = {'Привет',},
	check = function(ply)
		return ply:Team() == TEAM_ZTM_TRASHMAN
	end
},
['Гори, гори ясно!'] = {
	pos = {-531, 345},
	desc = 'Сжечь мусор',
	need = {'Кто вызывал уборщика?',}
},
['До чего дошёл прогресс'] = {
	pos = {-411, 446},
	desc = 'Переработать мусор',
	need = {'Кто вызывал уборщика?',}
},
['Поварешка и лопатка'] = {
	pos = {172, 37},
	desc = 'Стать поваром в школе',
	need = {'Привет',},
	check = function(ply)
		return ply:Team() == TEAM_COOK
	end
},
['Ну как? Вкусно?'] = {
	pos = {337, -18},
	desc = 'Приготовить еду ученикам 10 раз',
	need = {'Поварешка и лопатка',}
},
['Может он дома что-то не то съел'] = {
	pos = {343, 109},
	desc = 'Вы случайно отравили ученика',
	need = {'Поварешка и лопатка',}
},
}

local check_skill = function(sk, p)
	if not p then
		p = LocalPlayer()
	end
	
	local sks = p.ls_skills
	return sks and sks[sk]
end

local can_obtain = function(sk, p)
	if not ls_skills[sk] then return false end
	local need = ls_skills[sk].need
	local need_all = ls_skills[sk].need_all
	if not need then return true end
	
	if not p then
		p = LocalPlayer()
	end
	local can = need_all
	for k, v in ipairs(need) do
		local check = check_skill(v, p)
		if check and not need_all then
			can = true
			break
		end
		
		if not check and need_all then
			can = false
			break
		end
	end
	
	return can
end

if CLIENT then
net.Receive('ls_skills', function()
	local sk = net.ReadString()
	LocalPlayer().ls_skills = LocalPlayer().ls_skills or {}
	LocalPlayer().ls_skills[sk] = true
end)


local mat_ring = Material('gr_content/circle_glow')
local mat_shadow = Material('gr_content/ring_shadow')
local mat_circle = Material('gr_content/be_circle')

local center_x, center_y = 500, 350
local last_mx, last_my = 0, 0
local moving = false

local thicLine = function(x, y, x1, y1)
	surface.DrawLine(x, y, x1, y1)
	surface.DrawLine(x + 1, y, x1 + 1, y1)
	surface.DrawLine(x - 1, y, x1 - 1, y1)
	surface.DrawLine(x, y + 1, x1, y1 + 1)
	surface.DrawLine(x, y - 1, x1, y1 - 1)
end

if ValidPanel(ls_skills_f) then
	ls_skills_f:Remove()	
end

hook.Add("OnContextMenuOpen", "skills", function()
if ValidPanel(ls_skills_f) then
	ls_skills_f:Show()
	return
end

ls_skills_f = vgui.Create('DFrame', g_ContextMenu)
ls_skills_f:SetSize(200, 24)
ls_skills_f:SetPos(ScrW()/2 - 500, 128)
ls_skills_f:SetTitle('Прокачка')
ls_skills_f.btnMaxim:Hide()
ls_skills_f.btnMinim:Hide()
ls_skills_f:SetMouseInputEnabled(true)
local tex	= Material("pp/blury")
ls_skills_f.Paint = function(self, w, h)
	surface.SetDrawColor(255, 255, 255)
	local scrx, scry = self:ScreenToLocal(0, 0)
	surface.SetMaterial(tex)
	surface.DrawTexturedRect(scrx, scry, ScrW(), ScrH())
	draw.RoundedBoxEx(4, 0, 0, w, 24, Color(255, 114, 167), true, true)
	if self.btnClose.opened then draw.RoundedBoxEx(4, 0, 24, w, h - 24, Color(51, 60, 70, 200), false, false, true, true) end
end

function ls_skills_f.btnClose:Paint(w, h)
	draw.RoundedBox(4, 0, 0, w, h, self:IsHovered() and Color(255, 114, 167) or Color(200, 220, 255, 10))
	draw.SimpleTextOutlined(self.opened and '_' or '▢', 'Trebuchet24', w/2, self.opened and 4 or 12, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
end

function ls_skills_f.btnClose:DoClick()
	local w, h
	
	if self.opened then
		w, h = 200, 24
	else
		w, h = 1000, 700
	end
	
	ls_skills_f:SizeTo(w, h, 0.5)
	self.opened = not self.opened
end

local p = vgui.Create('EditablePanel', ls_skills_f)
p:Dock(FILL)
local zoom = 1
local mouse_clicked
local last_clicked
local hovered_skill
local mousedown_skill
local bg1 = Color(51, 60, 70)
local bg2 = Color(58, 66, 78)
local pink1 = Color(179, 80, 118)
local pink2 = Color(204, 92, 135)
local pink3 = Color(255, 114, 167)
p.Paint = function(self, w, h)
	local localx, localy = self:LocalToScreen()
	local mx, my = gui.MousePos()
	
	hovered_skill = false 
	
	for skname, v in pairs(ls_skills) do
		local pos = v.pos
		
		local x1, y1 = pos[1] * zoom, pos[2] * zoom
		if math.sqrt((mx - localx - (center_x + x1))^2 + (my - localy - (center_y + y1))^2) < 32 * zoom and not moving then
			hovered_skill = skname
		end
		
		if v.need then
			for _, n in ipairs(v.need) do
				local sk = ls_skills[n]
				local pos2 = sk.pos
				local x2, y2 = pos2[1] * zoom, pos2[2] * zoom
				local len = 32
				if not sk.need then len = 16 end
				len = len * zoom
				
				surface.SetDrawColor(0, 200, 155)
				surface.DrawLine(center_x + x1 - 32*zoom*(x1 - x2)/math.sqrt((x1 - x2)^2 + (y1 - y2)^2), 
				center_y + y1 - 32*zoom*(y1 - y2)/math.sqrt((x1 - x2)^2 + (y1 - y2)^2), 
				center_x + x2 + len*(x1 - x2)/math.sqrt((x1 - x2)^2 + (y1 - y2)^2), 
				center_y + y2 + len*(y1 - y2)/math.sqrt((x1 - x2)^2 + (y1 - y2)^2))
			end
		end
		
		surface.SetMaterial(mat_circle)
		local alpha = can_obtain(skname) and 255 or 32
		local has = check_skill(skname)
		if v.need then
			surface.SetDrawColor(ColorAlpha(has and pink1 or bg1, alpha))
			surface.DrawTexturedRect(center_x - 36 * zoom + x1, center_y - 36 * zoom + y1, 72 * zoom, 72 * zoom)
			
			surface.SetMaterial(mat_shadow)
			surface.SetDrawColor(255, 255, 255, alpha)
			surface.DrawTexturedRect(center_x - 36 * zoom + x1, center_y - 36 * zoom + y1, 72 * zoom, 72 * zoom)
			
			surface.SetDrawColor(ColorAlpha((has or mousedown_skill == skname) and pink3 or (hovered_skill == skname and pink2 or bg2), alpha))
			surface.SetMaterial(mat_ring)
			surface.DrawTexturedRect(center_x - 32 * zoom + x1, center_y - 32 * zoom + y1, 64 * zoom, 64 * zoom)
		else
			surface.SetDrawColor(ColorAlpha(has and pink2 or bg2, alpha))
			surface.DrawTexturedRect(center_x - 16 * zoom + x1, center_y - 16 * zoom + y1, 32 * zoom, 32 * zoom)
		end
	end

	local mousemove = (input.IsMouseDown(MOUSE_LEFT) and not hovered_skill and not mousedown_skill) or input.IsMouseDown(MOUSE_RIGHT)
	if mousemove and self:IsHovered() then
		self:SetCursor('crosshair')
		moving = true
		center_x, center_y = center_x + mx - last_mx, center_y + my - last_my
	else
		self:SetCursor('sizeall')
		moving = false
		if hovered_skill then -- and can unlock
			self:SetCursor('hand')
		end
	end

	mouse_clicked = false//input.IsMouseDown(MOUSE_LEFT) мышка
	
	if hovered_skill then
		local sk = ls_skills[hovered_skill]
		local pos = sk.pos
		/*if input.IsKeyDown(KEY_A) then
			pos[1] = pos[1] - 1
		end
		
		if input.IsKeyDown(KEY_D) then
			pos[1] = pos[1] + 1
		end
		
		if input.IsKeyDown(KEY_W) then
			pos[2] = pos[2] - 1
		end
		
		if input.IsKeyDown(KEY_S) then
			pos[2] = pos[2] + 1
		end
		*/
		local x, y = sk.pos[1]* zoom + 32 * zoom, sk.pos[2]* zoom - 32 * zoom
		
		if not last_clicked and mouse_clicked then
			mousedown_skill = hovered_skill
		end
		
		/*if last_clicked and not mouse_clicked and mousedown_skill == hovered_skill then -- can_obtain(skname) and 
			local needstr = ""
			if sk.need then
			for k, v in ipairs(sk.need) do
				needstr = needstr .. "'" .. v .. "',"
			end
			end
			SetClipboardText(string.format([[['%s'] = {
	pos = {%s, %s},
	desc = '%s',
	need = {%s}
},]], hovered_skill, sk.pos[1], sk.pos[2], sk.desc, needstr))

			net.Start('ls_skills')
				net.WriteString(hovered_skill)
			net.SendToServer()
		end
		
		local text
		if true then -- able to acquire
			text = 'Нажмите ЛКМ чтобы прокачать'
		else
			text = 'Не хватает'
		end*/
		draw.WordBox(4, center_x + x, center_y + y, hovered_skill, 'GModToolHelp', Color(255, 255, 255, 255), color_black)
		draw.WordBox(4, center_x + x, center_y + y + 20, isfunction(sk.desc) and sk.desc(LocalPlayer()) or sk.desc, 'GModToolHelp', Color(255, 255, 255, 255), color_black)
		--draw.WordBox(4, center_x + x, center_y + y + 40, text, 'DermaDefaultBold', Color(255, 255, 255, 255), color_black)
		--draw.WordBox(4, mx - ach_x, my + 42 - ach_y, 'Награда: ' .. t.prize[1], 'Trebuchet18', Color(255, 255, 255, 255), color_black)
		last_clicked = mouse_clicked
	end
	
	if not mouse_clicked then
		mousedown_skill = nil
	end

	last_mx, last_my = mx, my
	
	--draw.WordBox(4, 0, 0, -center_x + mx - localx .. ', ' .. -center_y + my - localy, 'DermaDefaultBold', Color(255, 255, 255, 255), color_black) -- debug
end

function p:OnMouseWheeled(delta)
	zoom = math.Clamp(zoom + delta * 0.05, 0.2, 2)
end

local lastcreated
function p:OnMousePressed(k)
	if k == MOUSE_RIGHT then
		if hovered_skill then
			if not lastcreated then return end
			ls_skills[lastcreated].need = ls_skills[lastcreated].need or {}
			
			if table.HasValue(ls_skills[lastcreated].need, hovered_skill) then
				table.RemoveByValue(ls_skills[lastcreated].need, hovered_skill)
			else
				table.insert(ls_skills[lastcreated].need, hovered_skill)
			end
		else
		
		local localx, localy = self:LocalToScreen()
		local mx, my = gui.MousePos()
		
		Derma_StringRequest(
			"Название",
			"Название",
			"",
			function( name ) 
				Derma_StringRequest(
					"Описание",
					"Описание",
					"",
					function( desc ) 
						ls_skills[name] = {
							pos = {mx - localx - center_x, my - localy - center_y},
							desc = desc
						}
						lastcreated = name
					end)
			end)
		end
	end
end

end)

net.Receive('ls_skills_effect', function()
	local p = net.ReadEntity()

	if not IsValid(p) then return end

	local ed = EffectData()
	ed:SetEntity(p)
	ed:SetOrigin(p:GetPos())
	util.Effect('entity_remove', ed)
	util.Effect('propspawn', ed)
	util.Effect('VortDispel', ed)

	--p:EmitSound('garrysmod/save_load4.wav')
	p:EmitSound('weapons/physcannon/energy_sing_flyby1.wav', 100, 50)

	for i = 1, 20 do
		local v = i * 360/20
		local c = HSVToColor(v, 1, 1)
		SpawnParticle(2, 50, 0, "particle/particle_glow_04_additive", 
			Vector(c.r, c.g, c.b), 
			p:GetPos() + Vector(0, 0, 25), 
			Angle(0, v, 0):Forward() * 100, 
			-Angle(0, v, 0):Forward() * 100 + Vector(0, 0, 16 * i), 
			0, 0)
		
		SpawnParticle(1, 0, 25, "particle/particle_ring_wave_additive", 
			Vector(c.r, c.g, c.b), 
			p:GetShootPos(), 
			Vector(0, 0, i * 25), 
			vector_origin, 
			0, 0, 255, 0)
	end
end)

end