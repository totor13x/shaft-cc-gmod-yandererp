hook.Add('RPSettings', 'Yandere', function(t)
	t.currency = '¥'
	t.default_weapons = {
		'weapon_physgun',
		'weapon_physcannon',
		'gmod_camera',
		'weapon_fists',
		'gmod_tool',
		'keys',
		'pocket',
		'maxmol_phone'
	}
	t.force_language = 'ru'
	t.default_jobs = false
	t.default_entities = false
	t.zfar = 3500
	t.roof_positions = {
		Vector(3321, 2406, 392),
		Vector(3247, 3691, 487),
		Vector(1468, -102, 560),
		Vector(-876, 23, 487),
		Vector(2302, 511, 560),
		Vector(1789, 885, -876),
	}
end)

if SERVER then
	resource.AddWorkshop('1710554579')
	resource.AddWorkshop('1224790718')
	resource.AddWorkshop('2052378189')
	resource.AddWorkshop('180601311')
	resource.AddWorkshop('1771937981')
	resource.AddWorkshop('1368123256')
	resource.AddWorkshop('647839333')
	resource.AddWorkshop('1952575596')
	resource.AddWorkshop('1407158309')
	resource.AddWorkshop('248643568')
	resource.AddWorkshop('1663617726')
end

hook.Add('PointshopItems', 'PermModels', function(items)
	
local models = {
	{'models/jazzmcfly/wrs/wrs.mdl', 'White Rock Shooter', 350},
	{'models/blueflytrap/rwby/weiss_schnee_pm_unlit.mdl', 'Weiss Schnee', 420},
	{'models/cyanblue/th06/patchouli/patchouli.mdl', 'Patchouli', 400},
	{'models/cyanblue/touhou14/shinmyoumaru/shinmyoumaru.mdl', 'Shinmyoumaru', 500},
	{'models/jazzmcfly/rwby/ren/ren.mdl', 'Ren', 300},
	{'models/jazzmcfly/rwby/ruby_ge/ruby.mdl', 'Ruby', 350},
	{'models/jazzmcfly/rwby/ruby_ge/ruby_formal.mdl', 'Ruby Formal', 350},
	{'models/mokou/mokou_pm.mdl', 'Mokou', 400},
	{'models/player/girls_frontline_ump45.mdl', 'UMP45', 500},
	{'models/player/girls_frontline_ump9.mdl', 'UMP9', 500},
	{'models/player/luka_admin.mdl', 'Luka', 380},
	{'models/player/yuuka.mdl', 'Yuuka', 480},
	{'models/player/dewobedil/danganronpa/ibuki_mioda/default_p.mdl', 'Ibuki Mioda', 350},
	{'models/player/dewobedil/danganronpa/kirumi_tojo/default_p.mdl', 'Kirumi Tojo', 380},
	{'models/player/dewobedil/sayaka_maizono/default_p.mdl', 'Sayaka Maizono', 390},
	{'models/player/dewobedil/vocaloid/appearance_miku/colorful_p.mdl', 'Miku Appearance', 480},
	{'models/player/shi/megadrive.mdl', 'Megadrive', 420},
	{'models/poop/chinatsu.mdl', 'Chinatsu', 400},
	{'models/touhou/suika_ibuki/suika_ibuki_player.mdl', 'Suika Ibuki', 415},
	{'models/player/dewobedil/underfell/sans/default_p.mdl', '76561198192887962', 99999},
	{'models/player_kokichiouma_notrack.mdl', 'Kokichiouma', 99999, 'STEAM_0:0:78219967'},
	{'models/player/group02/male_06.mdl', 'Male06', 99999, 'STEAM_0:0:78219967'},
	{'models/player/police.mdl', 'Metrocop', 99999, 'STEAM_0:0:78219967'},
	{'models/player/com/mrcompress.mdl', 'Mr Compress', 99999, 'STEAM_0:0:144738813'},
	{'models/vinrax/player/jack_player.mdl', 'Jack Skellington', 99999, 'STEAM_0:1:51910806'},
	{'models/old_joseph_eoh_pm/old_joseph_eoh_pm.mdl', 'Old Joseph', 99999, 'STEAM_0:1:118570573'},
	{'models/player/danila.mdl', 'Danila', 99999, 'STEAM_0:0:44964317'},
	{'models/player/dewobedil/mirai_akari/default_p.mdl', 'Mirai', 99999, 'STEAM_0:1:246408593'},
	{'models/captainbigbutt/vocaloid/rin_phosphorescent.mdl', 'Rin', 99999, 'STEAM_0:0:78219967'},
	{'models/player/stierlitz.mdl', 'Stierlitz', 99999, 'STEAM_0:0:44964317'},
	{'models/neet/swat_ply.mdl', 'NEET', 99999, 'STEAM_0:0:78219967'},
	{'models/narry/shrek_playermodel_v1.mdl', 'Shrek', 99999, 'STEAM_0:0:103644834'},
	{'models/konnie/jumpforce/sasuke.mdl', 'Sasuke', 99999, 'STEAM_0:0:195076268'},
}

for _, t in pairs(models) do
	table.insert(items, {
		category = 'Player Models',
		model = t[1],
		name = t[2],
		price = t[3],
		preview_open = function(self, pm)
			pm.forcemodel = true
			pm:SetModel(self.model)
		end,
		preview_close = function(self, pm)
			pm.forcemodel = false
		end,
		equip = function(self, ply, eq)
			if eq then
				ply:SetPermModel(self.model)
			else
				ply:SetPermModel()
			end
		end,
		hidden = function(self, ply)
			if t[4] and t[4] ~= ply:SteamID() then
				return true
			end
		end
	})
end

-- footsteps

local starmat = Material('icon16/star.png')
local spritemat = Material('sprites/light_glow02_add')

local paintFootstepItem = function(mat, rainbow)
	return function(self, w, h)
		self.stars = self.stars or {cooldown = 0}
		
		if self.stars.cooldown < SysTime() then
			self.stars.cooldown = SysTime() + 0.1
			if math.random(3) == 3 then
				table.insert(self.stars, {math.random(-4, w - 8), h + 16, math.random(50, 100), math.random(-100, 100)})
			end
		end
		
		local i = 0
		while i <= #self.stars do
			i = i + 1
			local v = self.stars[i]
			if not v then continue end
			
			v[2] = v[2] - FrameTime() * v[3]
			
			surface.SetMaterial(mat)
			if rainbow then
				surface.SetDrawColor(HSVToColor((SysTime() * 30) % 360, 1, 1))
				surface.DrawTexturedRect(v[1], v[2], 32, 32)
			else
				surface.SetDrawColor(255, 255, 255)
				surface.DrawTexturedRectRotated(v[1], v[2], 16, 16, (SysTime() * v[4]) % 360)
			end
			
			if v[2] < -16 then
				table.remove(self.stars, i)
				i = i - 1
			end
		end
	end
end

table.insert(pointshop.items, {
	name = 'Star Footsteps',
	category = 'Other',
	paint = paintFootstepItem(starmat),
	price = 275,
})

table.insert(pointshop.items, {
	name = 'Rainbow Footsteps',
	category = 'Other',
	paint = paintFootstepItem(spritemat, true),
	price = 275,
})

pointshop.items_byname = {}
for k, v in ipairs(pointshop.items) do
	pointshop.items_byname[v.name] = v
end

if CLIENT then
if pointshop.f then pointshop.f:Remove() end

hook.Add('PlayerFootstep', 'Star Footsteps', function(ply, pos, foot)
	local eqpd = ply.pointshop_equipped
	if not eqpd then return end
	if ply:GetNWBool('ls_hidden') then return end
	local starsteps = eqpd['Star Footsteps']
	local rainbowsteps = eqpd['Rainbow Footsteps']
	if starsteps or rainbowsteps then
		local bone = ply:LookupBone(foot == 0 and 'ValveBiped.Bip01_L_Foot' or 'ValveBiped.Bip01_R_Foot')
		if bone then pos = ply:GetBonePosition(bone) end
		for i = 1, 3 do
			if starsteps then
				local randvec = Vector(math.random(-15, 15), math.random(-15, 15), 0)
				local vel = -ply:GetVelocity()/3 + randvec
				SpawnParticle(math.random(7, 13)/10, 6, 0, 'icon16/star.png', 
					color_white, pos + randvec/5, vel, -vel + Vector(0, 0, 15), 0, math.random(-100, 100))
			end
			
			if rainbowsteps then
				local randvec = Vector(math.random(-15, 15), math.random(-15, 15), 0)
				local vel = -ply:GetVelocity()/3 + randvec
				SpawnParticle(math.random(7, 13)/10, 20, 0, 'sprites/light_glow02_add', 
					HSVToColor((SysTime() * 30) % 360, 1, 1), pos + randvec/5, vel, -vel + Vector(0, 0, 15))
			end
		end
	end
end)

end

-- music orb

	local glowMat = Material('particle/particle_glow_04_additive')

	local musorb = {}
	musorb.category = 'Other'
	musorb.name = 'Music Obr'
	musorb.price = 360
	musorb.render = function(ply, t)
		local isplayer = IsEntity(ply) and ply:IsPlayer()
		
		local orb = ply.musorb
		
		if not IsValid(orb) then
			orb = ClientsideModel('models/hunter/misc/sphere025x025.mdl', RENDERGROUP_OTHER)
			orb:SetMaterial('models/shiny')
			orb:SetRenderMode(RENDERMODE_TRANSALPHA)
			orb:SetPos(isplayer and (ply:GetPos() + Vector(0, 0, 85)) or vector_origin)
			orb:SetNoDraw(true)
			orb.particles = {}
			orb.clr = color_white
			orb.maxvol = 0
			orb.size = 0
			ply.musorb = orb
		end
		
		local pos = isplayer and (ply:GetShootPos() + Vector(0, 0, 25)) or (IsEntity(ply) and Vector(0, 0, 85) or Vector(0, 0, 5))
		orb:SetPos(orb:GetPos() + (pos - orb:GetPos())*FrameTime() * 5)
		
		orb.clr = HSVToColor(math.Clamp(orb.size * 4, 0, 360), 1, 1)
		
		local vol = isplayer and math.min(ply:VoiceVolume() * 2, 1) or math.Rand(0, 1)
		if vol > orb.maxvol then orb.maxvol = vol end
		orb.maxvol = math.Clamp(orb.maxvol - FrameTime(), 0.15, 1)
		
		if vol > orb.maxvol - 0.1 and (not orb.particlecooldown or orb.particlecooldown < SysTime()) then
			local p = SpawnParticle(4, 20, 0, 'particle/particle_glow_04', Vector(orb.clr.r, orb.clr.g, orb.clr.b), orb:GetPos(), VectorRand() * 20, Vector(0, 0, -10), 0, 0, 255, 128, true)
			table.insert(orb.particles, p)
			orb.particlecooldown = SysTime() + 0.2
		end
		
		local i = 1
		while i <= #orb.particles do
			local v = orb.particles[i]
			if IsValid(v) then
				v:Render()
				i = i + 1
			else
				table.remove(orb.particles, i)
			end
		end
	
		render.SetMaterial(glowMat)
		local size = 20 + vol * 100
		orb.size = Lerp(FrameTime()*2, orb.size, size)
		render.DrawSprite(orb:GetPos(), orb.size, orb.size, orb.clr)
		render.DrawSprite(orb:GetPos(), -orb.size, -orb.size, orb.clr)

		render.OverrideDepthEnable(true, true)
		
		render.SetColorMaterial()
		render.DrawSphere(orb:GetPos(), 6, 16, 16, orb.clr)

		render.OverrideDepthEnable(false, false)
	end
	
	table.insert(items, musorb)

end)

hook.Add('PlayerInitialSpawn', 'HourlyPoints', function(ply)
	local timername = 'HourlyPoints' .. ply:SteamID()
	timer.Create(timername, 5400, 0, function()
		if not IsValid(ply) then
			timer.Remove(timername)
			return
		end

		ply:AddPoints(1)
		GAMEMODE:Tip(Color(0, 255, 128), 'Вы получили один поинт за игру на сервере! [F2]', false, 'ambient/office/coinslot1.wav', true, ply)
	end)
end)

/*
hook.Add('PostGamemodeLoaded', 'sakura', function()
	if ls_snow then
		ls_snow(true, Color(255, 255, 255, 220), 320, 2, 40, 710, 0, {
			Material('sakura'),
			Material('sakura1'),
			Material('sakura2'),
			Material('sakura3'),
			Material('sakura4'),
			Material('sakura5'),
			Material('sakura6'),
			Material('sakura7'),
			nil
		}, 5)
	end
end)*/