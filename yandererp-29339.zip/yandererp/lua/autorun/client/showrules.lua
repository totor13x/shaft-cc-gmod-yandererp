surface.CreateFont("markup_default", {
	font = "Verdana",
	size = 16,
	weight = 600,
	antialias = true,
	shadow = true,
	prettyblur = 1,
	read_speed = 100,
	extended = true,
})

local help = function(GAMEMODE)
	if IsValid(HelpMenu) then 
		HelpMenu:Show()
		return 
	end
	
	local frame = vgui.Create('DFrame')
	frame:SetSize(886, ScrH() * 0.85)
	frame:Center()
	frame:MakePopup()
	frame:SetDraggable(true)
	frame.btnMaxim:Hide()
	frame.btnMinim:Hide()
	frame:SetTitle('Приветствуем на сервере YandereRP от LampServ.org!')
	frame:SetDeleteOnClose(false)
	HelpMenu = frame

	function frame:OnKeyCodePressed(code)
		if code == KEY_F1 then
			self:Hide()
		end
	end
	
	local panel = vgui.Create('Panel', frame)
	panel.Paint = function() end
	panel:Dock(FILL)
	
	local html = vgui.Create('DHTML', panel)
	html:SetSize(1400, frame:GetTall() - 24)
	html:OpenURL('https://lampserv.org/assets/rules/')
end

hook.Add('PostGamemodeLoaded', 'ShowRules', function()
	GAMEMODE.ShowHelp = help
end)

timer.Create('Chat_Adverts', 300, 0, function()
	chat.AddText(color_white, 'Вступи в группу сервера: ', Color(0,255,0), 'http://steamcommunity.com/groups/lampserv и получи бонус в меню наград')
	chat.AddText(color_white, 'Вступи в сообщество сервера ВКонтакте: ', Color(0,255,0), 'http://vk.com/lampserv')
	//chat.AddText(color_white, 'Чтобы получить бонус введи в чат: /vkbonus <твой айди ВКонтакте> (пример: /vkbonus maxmol1337) и следуй инструкциям')
	chat.AddText(color_white, 'Наш сайт: ', Color(0,255,0), 'http://lampserv.org')
	chat.AddText(color_white, 'Добавь сервер в избранное, чтобы вернуться в любой момент: ', Color(0,255,0), 'lampserv.org:27015')
end)

local helps = {
	'Инвентарь и Прокачка в [C]-меню',
	'Включить вид от третьего лица: [Shift] + [Alt]',
	'Чтобы открыть поинтшоп, нажми [F2]',
	'Чтобы открыть донат-меню, нажми [F6]',
	'Чтобы открыть правила, нажми [F1]',
}

local help_counter = 0

timer.Create('helps', 120, 0, function()
	GAMEMODE:Tip(color_white, helps[help_counter + 1])
		
	help_counter = (help_counter + 1) % #helps
end)