local ls_shop = {}
ls_shop.w = 1000
ls_shop.h = 600

global_topdonaters = global_topdonaters
local topdonaters = global_topdonaters
net.Receive('topdonaters', function()
	topdonaters = net.ReadTable()
	global_topdonaters = topdonaters
end)

surface.CreateFont( "ls_shop_medium", {
	font = "Tahoma",
	extended = true,
	size = 24,
	weight = 900,
	underline = false,
})

surface.CreateFont( "ls_shop_small", {
	font = "Tahoma",
	extended = true,
	size = 16,
	weight = 600,
})

net.Receive('ls_shop_update', function(len)
	local n = net.ReadInt(16)
	print(n)
	LocalPlayer().ls_shop_pifs = n
end)

local blur = Material("pp/blurscreen")
local function DrawBlur(panel, amount)
	local x, y = panel:LocalToScreen(0, 0)
	local scrW, scrH = ScrW(), ScrH()
	surface.SetDrawColor(255, 255, 255)
	surface.SetMaterial(blur)
	for i = 1, 3 do
		blur:SetFloat("$blur", (i / 3) * (amount or 6))
		blur:Recompute()
		render.UpdateScreenEffectTexture()
		surface.DrawTexturedRect(x * -1, y * -1, scrW, scrH)
	end
end

local pifs = function(m)
	return string.Comma(m) .. ls_donate.currency_symbol
end

local startPayment = function()
	if ls_shop.pay_f then
		ls_shop.pay_f:MakePopup()
		return	
	end
	
	ls_shop.pay_f = vgui.Create('DFrame')
	ls_shop.pay_f:SetSize(400, 400)
	ls_shop.pay_f:Center()
	ls_shop.pay_f:MakePopup()
	ls_shop.pay_f:SetTitle('Пополнить баланс ' .. ls_donate.currency_ru[3])
	ls_shop.pay_f.btnClose:Hide()
	ls_shop.pay_f.btnMaxim:Hide()
	ls_shop.pay_f.btnMinim:Hide()
	ls_shop.pay_f.Paint = function( s, w, h ) 
		draw.RoundedBox(0, 0, 0, w, h, Color( 50, 50, 50 ))
	end
	
	function ls_shop.pay_f:Think()
		self:MoveToFront()
	end
	
	local close = vgui.Create("DButton", ls_shop.pay_f)
	close:SetSize(42, 16)
	close:SetPos(ls_shop.pay_f:GetWide() - close:GetWide() - 4, 0)
	close.Paint = function(self, w, h)
	local bg = (self.Depressed and Color(128, 32, 32)) or (self:IsHovered() and Color(255, 0, 0)) or Color(255, 64, 64)
		draw.RoundedBoxEx(4, 0, 0, w, h, bg, false, false, true, true)
		draw.SimpleTextOutlined("r", "marlett", w/2, h/2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black )
		return true
	end
	close.DoClick = function()
		ls_shop.pay_f:Remove()
		ls_shop.pay_f = nil
	end
	
	local rt = vgui.Create("RichText", ls_shop.pay_f)
	rt:Dock(FILL)
	function rt:PerformLayout()
		self:SetFontInternal("ls_shop_small")
		self:SetBGColor(Color(32, 32, 46))
	end
	
	rt:InsertColorChange(0, 255, 196, 255)
	rt:AppendText('1 рубль = '.. pifs(1) .. ' (' .. ls_donate.currency_ru[1] .. ')\n\n')
	
	rt:InsertColorChange(255, 255, 255, 255)
	rt:AppendText([[
Чтобы пополнить баланс ]] .. ls_donate.currency_ru[3] .. [[ с кошелька ]])
	rt:InsertColorChange(255, 140, 0, 255) 
	rt:AppendText('Qiwi:\n')
	rt:InsertColorChange(255, 255, 255, 255)
	rt:AppendText([[1) Откройте в браузере: ]])
	rt:InsertColorChange(128, 128, 255, 255)
	rt:InsertClickableTextStart("OpenQiwi")
	rt:AppendText("https://qiwi.com/payment/form/99")
	rt:InsertClickableTextEnd()
	rt:InsertColorChange(255, 255, 255, 255)
	rt:AppendText('\n2) В поле "Номер Кошелька" введите: ')
	rt:InsertColorChange(255, 64, 64, 255)
	rt:AppendText('+79995559037')
	rt:InsertColorChange(255, 255, 255, 255)
	rt:AppendText('\n3) В поле "Комментарий" введите: ')
	rt:InsertColorChange(255, 64, 64, 255)
	rt:AppendText(ls_donate.code .. LocalPlayer():UniqueID())
	rt:InsertColorChange(255, 255, 255, 255)
	rt:AppendText('\n4) В поле "Сумма" введите число ' .. ls_donate.currency_ru[3] .. ', которое вы хотите получить\n5) Нажмите "Оплатить", ' .. ls_donate.currency_ru[2] .. ' поступят на ваш баланс в течение минуты.')
	rt:AppendText('\n\nЧтобы пополнить баланс ' .. ls_donate.currency_ru[3] .. ' с ')
	rt:InsertColorChange(255, 219, 77, 255) 
	rt:AppendText('БАНКОВСКОЙ КАРТЫ или Яндекс Денег')
	rt:InsertColorChange(255, 255, 255, 255)
	rt:AppendText(':\n1) Откройте в браузере: ')
	rt:InsertColorChange(128, 128, 255, 255)
	rt:InsertClickableTextStart("OpenYandex")
	rt:AppendText("https://lampserv.org/donate/yandex/?id=" .. ls_donate.code .. LocalPlayer():UniqueID())
	rt:InsertClickableTextEnd()
	rt:InsertColorChange(255, 255, 255, 255)
	rt:AppendText('\n2) В поле введите число ' .. ls_donate.currency_ru[3] .. ', которое вы хотите получить\n3) Выберите способ оплаты\n4) Нажмите "Оплатить". Следуйте инструкции на сайте Яндекса.')
	
	function rt:ActionSignal(n, v)
		if n == "TextClicked" then
			if v == "OpenQiwi" then
				gui.OpenURL("https://qiwi.com/payment/form/99")
			end

			if v == "OpenYandex" then
				gui.OpenURL("https://lampserv.org/donate/yandex/?id=" .. ls_donate.code .. LocalPlayer():UniqueID())
			end
		end
	end
end

local buyItem = function(t)
	if ls_shop.buy_f then ls_shop.buy_f:Remove() end
	
	ls_shop.buy_f = vgui.Create('DFrame')
	ls_shop.buy_f:SetSize(300, t.v.info and 180 or 96)
	ls_shop.buy_f:Center()
	ls_shop.buy_f:MakePopup()
	ls_shop.buy_f:SetTitle('Купить ' .. t.v.name)
	ls_shop.buy_f.btnClose:Hide()
	ls_shop.buy_f.btnMaxim:Hide()
	ls_shop.buy_f.btnMinim:Hide()

	function ls_shop.buy_f:Think()
		self:MoveToFront()
	end

	ls_shop.buy_f.Paint = function(s, w, h)
		draw.RoundedBox(0, 0, 0, w, h, Color( 50, 50, 50 ))
	end
	
	local close = vgui.Create("DButton", ls_shop.buy_f)
	close:SetSize(42, 16)
	close:SetPos(ls_shop.buy_f:GetWide() - close:GetWide() - 4, 0)
	close.Paint = function(self, w, h)
	local bg = (self.Depressed and Color(128, 32, 32)) or (self:IsHovered() and Color(255, 0, 0)) or Color(255, 64, 64)
		draw.RoundedBoxEx(4, 0, 0, w, h, bg, false, false, true, true)
		draw.SimpleTextOutlined("r", "marlett", w/2, h/2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black )
		return true
	end
	close.DoClick = function()
		ls_shop.buy_f:Remove()
		ls_shop.buy_f = nil
	end
	
	local pricelbl
	local btn = vgui.Create('DButton', ls_shop.buy_f)
	btn:SetText('Купить')
	btn:Dock(BOTTOM)
	btn.DoClick = function(self)
		if pricelbl.amt > LocalPlayer().ls_shop_pifs then 
			startPayment()
		end
		net.Start('ls_shop_buy')
			net.WriteString(t.v.code)
			if t.v.info == 'num' then
				net.WriteInt(ls_shop.buy_f.entry:GetValue(), 16)
			elseif t.v.info == 'text' then
				net.WriteString(ls_shop.buy_f.entry:GetValue())
			end
		net.SendToServer()
		
		ls_shop.buy_f:Remove()
		ls_shop.buy_f = nil
	end
	
	pricelbl = vgui.Create('DLabel', ls_shop.buy_f)
	pricelbl:SetSize(0, 50)
	pricelbl:SetText('Сумма: ' .. pifs(t.v.price))
	pricelbl.amt = t.v.price
	pricelbl:Dock(BOTTOM)
	
	if t.v.info == 'num' then
		local lbl = vgui.Create('DLabel', ls_shop.buy_f)
		lbl:SetSize(0, 50)
		lbl:SetText('Сколько?')
		lbl:Dock(TOP)
		
		ls_shop.buy_f.entry = vgui.Create('DNumberWang', ls_shop.buy_f)
		ls_shop.buy_f.entry:SetDecimals(0)
		ls_shop.buy_f.entry:SetSize(0, 24)
		ls_shop.buy_f.entry:Dock(TOP)
		ls_shop.buy_f.entry:SetMinMax(1, math.floor(LocalPlayer().ls_shop_pifs / t.v.price))
		ls_shop.buy_f.entry:SetValue(1)
		ls_shop.buy_f.entry.OnValueChanged = function(self, val)
			pricelbl.amt = t.v.price * val
			pricelbl:SetText('Сумма: ' .. pifs(t.v.price * val))
		end
	elseif t.v.info == 'text' then
		local lbl = vgui.Create('DLabel', ls_shop.buy_f)
		lbl:SetSize(0, 50)
		lbl:SetText('Введите текст:')
		lbl:Dock(TOP)
		
		ls_shop.buy_f.entry = vgui.Create('DTextEntry', ls_shop.buy_f)
		ls_shop.buy_f.entry:SetSize(0, 24)
		ls_shop.buy_f.e2ntry:Dock(TOP)
	end
end

surface.CreateFont('top_donates', {
	font = 'Nunito Black',
	size = 18,
	extended = true,
	weight = 900,
})
concommand.Add('ls_shop', function()
	if ls_shop.p and ValidPanel(ls_shop.p) then
		ls_shop.p:MakePopup()
		return
	end

	local p = vgui.Create('EditablePanel')
	p:SetSize(ls_shop.w, ls_shop.h)
	p:Center()
	
	p.Init = function(self)
		self.startTime = SysTime()
	end

	local t = {
		{x = ls_shop.w, y = 0},
		{x = ls_shop.w * 0.5, y = 0},
		{x = ls_shop.w * 0.8, y = ls_shop.h},
		{x = ls_shop.w, y = ls_shop.h},
	}

	p.Paint = function(self, w, h)
		DrawBlur(self, 10)
		
		surface.SetDrawColor(0, 153, 153, 180)
		surface.DrawRect(0, 0, w, h)

		surface.SetDrawColor(0, 0, 0, 64)
		surface.DrawPoly(t)
		
		surface.SetDrawColor(0, 0, 0, 128)
		surface.DrawRect(0, 0, w * 0.25, h)
		
		if topdonaters then
			DisableClipping(true)
			surface.SetDrawColor(0, 153, 153, 180)
			surface.DrawRect(w, 0, 200, 300)
			surface.SetFont('nunito24')
			surface.SetTextPos(w + 8, 8)
			surface.SetTextColor(color_white)
			surface.DrawText('Топ донатеры')
			
			for i, v in ipairs(topdonaters) do
				surface.SetFont(i == 1 and 'nunito32' or 'nunito24')
				local y = i*42 + (i > 1 and 16 or 8)
				surface.SetTextPos(w + 8, y)
				surface.DrawText(v[1])
				local _, size = surface.GetTextSize(v[1])
				surface.SetFont('top_donates')
				surface.SetTextPos(w + 8, y + size - 4)
				surface.DrawText(v[2] .. 'р.')
			end
			DisableClipping(false)
		end
	end

	p:MakePopup()
	p:SetAlpha(0)
	p:AlphaTo(255, 0.3)

	ls_shop.p = p

	--

	ls_shop.close = vgui.Create('DButton', ls_shop.p)
	ls_shop.close:SetSize(ls_shop.p:GetWide() * 0.25, 46)
	ls_shop.close:SetPos(0, 0)
	 
	ls_shop.close.Paint = function(btn, w, h)
		local bg = (btn.Depressed and Color(128, 32, 32, 128)) or (btn:IsHovered() and Color(255, 0, 0, 128)) or Color(255, 64, 64, 128)
		surface.SetDrawColor(bg)
		//draw.RoundedBoxEx(8, 0, 0, w, h, bg, false, false, false, true)
		surface.DrawRect(0, 0, w, h - 1)
		surface.SetDrawColor(64, 64, 64, 255)
		surface.DrawRect(0, h - 1, w, 1)
	
		draw.SimpleTextOutlined('r', 'marlett', w/2, h/2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
		return true
	end
	
	ls_shop.close.DoClick = function()
		ls_shop.p:Remove()
		ls_shop.p = nil
	end

	--
	
	ls_shop.bar = vgui.Create('DButton', ls_shop.p)
	ls_shop.bar:SetSize(24, 24)
	ls_shop.bar:SetPos(ls_shop.w - ls_shop.bar:GetWide() - 2, 2)
	ls_shop.bar.Paint = function(self, w, h)
		local ccc = self:IsHovered() and 0 or 64
		surface.SetDrawColor(ccc, ccc, ccc, 128)
		surface.DrawRect(0, 0, w, h / 4)
		surface.DrawRect(0, h * 0.385, w, h / 4)
		surface.DrawRect(0, h * 0.75, w, h / 4)

		return true
	end
	
	ls_shop.bar.DoClick = function()
		local dm = DermaMenu()
		dm:AddOption("Пополнить баланс", startPayment):SetIcon("icon16/add.png")
		if ls_donate.access(LocalPlayer()) then
			dm:AddOption("Все логи", 
				function() 
					net.Start('ls_shop_log')
					net.WriteInt(1, 4)
					net.SendToServer()
				end):SetIcon("icon16/book_open.png")
			dm:AddOption("Логи пополнений", 
				function() 
					net.Start('ls_shop_log')
					net.WriteInt(2, 4)
					net.SendToServer()
				end):SetIcon("icon16/book_add.png")
			dm:AddOption("Логи покупок", 
				function() 
					net.Start('ls_shop_log')
					net.WriteInt(3, 4)
					net.SendToServer()
				end):SetIcon("icon16/book_go.png")
			dm:AddOption("Доходы", 
				function() 
					net.Start('ls_shop_log')
					net.WriteInt(4, 4)
					net.SendToServer()
				end):SetIcon("icon16/chart_bar.png")
		end
		dm:Open()
	end
	
	--

	ls_shop.balance = vgui.Create('DButton', ls_shop.p)
	ls_shop.balance:SetSize(100, 24)
	ls_shop.balance:SetPos(ls_shop.w - ls_shop.balance:GetWide() - 34, 0)
	ls_shop.balance.Paint = function(self, w, h)
		draw.SimpleText(pifs(LocalPlayer().ls_shop_pifs or 0), 'ls_shop_medium', w, h/2, color_white, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		surface.SetDrawColor(255, 255, self:IsHovered() and 128 or 255, 255)
		//surface.SetMaterial(addMat)
		//surface.DrawTexturedRect(w - 24, 3, 20, 20)

		return true
	end

	ls_shop.balance.DoClick = startPayment	

	--
	
	/*if LocalPlayer():IsMaxmol() then
		ls_shop.logs = vgui.Create('DButton', ls_shop.p)
		ls_shop.logs:SetSize(128, 24)
		ls_shop.logs:SetPos(ls_shop.w - ls_shop.balance:GetWide() * 2, 0)
		ls_shop.logs.Paint = function(self, w, h)
			draw.SimpleText("Logs", 'ls_shop_medium', w - 32, h/2, color_white, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			surface.SetDrawColor(255, 255, self:IsHovered() and 128 or 255, 255)
			surface.SetMaterial(logMat)
			surface.DrawTexturedRect(w - 24, 3, 20, 20)
	
			return true
		end
	
		ls_shop.logs.DoClick = function()
			net.Start('ls_shop_log')
			net.SendToServer()
		end
	end*/
	
	--

	ls_shop.cats = vgui.Create('EditablePanel', ls_shop.p)
	ls_shop.cats:SetSize(ls_shop.p:GetWide() * 0.25, ls_shop.p:GetTall() - 46)
	ls_shop.cats:SetPos(0, 46)
	
	local cats = {}
	for k, v in ipairs(ls_donate.items) do
		if not table.HasValue(cats, v.cat) then
			table.insert(cats, v.cat)
		end
	end

	for i, cat in ipairs(cats) do
		local b = vgui.Create('DButton', ls_shop.cats)
		b:SetSize(0, 46)
		b:Dock(TOP)
		b.Paint = function(s, w, h)
			surface.SetDrawColor(0, 0, 0, s:IsHovered() and 255 or 128)
			surface.DrawRect(0, 0, w, h)
			draw.SimpleText(cat, 'ls_shop_medium', w/2, h/2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			
			return true
		end
		b.DoClick = function()
			ls_shop.items.list:Clear()
			surface.PlaySound('common/wpn_select.wav')
			for _, v in ipairs(ls_donate.items) do
				if v.cat != cat then continue end
				local item = ls_shop.items.list:Add("DButton")
				item:SetSize(512, 142)
				if not v.name or not v.price then continue end
				item.Paint = function(self, w, h)
					local clr
					if v.colorFunc then
						clr = v.colorFunc()
					else
						clr = v.color
					end
					
					if not clr then
						clr = Color(0, 64, 64, 255)
					end

					clr =  ColorAlpha(clr, self:IsHovered() and 255 or 200)

					draw.RoundedBoxEx(16, 0, 0, w * 0.5, h, clr, true, false, true, false)
					draw.RoundedBoxEx(16, w * 0.5, 0, w * 0.5, h, Color(0, 0, 0, 128), false, true, false, true)
					draw.SimpleText(v.name, 'ls_shop_medium', w * 0.25, h * 0.35, v.textColor and v.textColor or color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					draw.SimpleText(pifs(v.price), 'ls_shop_medium', w * 0.25, h * 0.65, v.textColor and v.textColor or color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					if ls_donate.sale and ls_donate.sale < 1 then
						local oldprice = math.floor(v.price / ls_donate.sale)
						if oldprice != v.price then
							local tw, th = draw.SimpleText(pifs(oldprice), 'ls_shop_medium', w * 0.25, h * 0.82, v.textColor and v.textColor or color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
							tw = tw + w * 0.05
							surface.SetDrawColor(255, 0, 0, 196)
							surface.DrawRect(w * 0.25 - tw/2, h * 0.81, tw, h * 0.04)
						end
					end
					return true
				end
				item.v = v
				item.DoClick = buyItem
				
				local lbl = vgui.Create('RichText', item)
				lbl:SetSize(item:GetWide() * 0.4, item:GetTall() * 0.8)
				lbl:SetPos(item:GetWide() * 0.55, item:GetTall() * 0.1)
				lbl:InsertColorChange(255, 255, 255, 255)
				--lbl:SetMouseInputEnabled(false)
				lbl:AppendText(isfunction(v.desc) and v.desc() or tostring(v.desc))
				function lbl:PerformLayout()
					self:SetFontInternal('ls_shop_small')
				end
			end
			
			local item = ls_shop.items.list:Add("EditablePanel")
			item:SetSize(512, 0)
		end
	
		if i == 1 then timer.Simple(0.1, b.DoClick) end
	end

	ls_shop.items = vgui.Create("DScrollPanel", ls_shop.p)
	ls_shop.items:SetSize(ls_shop.p:GetWide() * 0.75, ls_shop.p:GetTall() - 32)
	ls_shop.items:SetPos(ls_shop.p:GetWide() * 0.25, 32)
	ls_shop.items.VBar:SetVisible(false)
	ls_shop.items.VBar.Paint = function(s, w, h)
		surface.SetDrawColor(0, 196, 196, 42)
		surface.DrawRect(0, 0, w, h)
		return true
	end
	ls_shop.items.VBar.btnUp.Paint = function(s, w, h)
		surface.SetDrawColor(0, 150, 150)
		surface.DrawRect(0, 0, w, h)
		
		draw.SimpleText('↑', 'DermaDefault', w*0.45, h*0.4, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	ls_shop.items.VBar.btnDown.Paint = function(s, w, h)
		surface.SetDrawColor(0, 150, 150)
		surface.DrawRect(0, 0, w, h)
		
		draw.SimpleText('↓', 'DermaDefault', w*0.45, h*0.4, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	ls_shop.items.VBar.btnGrip.Paint = function(s, w, h)
		surface.SetDrawColor(0, 150, 150)
		surface.DrawRect(0, 0, w, h)
	end

	ls_shop.items.list = vgui.Create("DIconLayout", ls_shop.items)
	ls_shop.items.list:SetSpaceY(42)
	ls_shop.items.list:SetSpaceX(32)
	ls_shop.items.list:SetSize(ls_shop.items:GetWide() - 168, ls_shop.items:GetTall())
	ls_shop.items.list:SetPos(84, 0)
end)

hook.Add('OnPlayerChat', 'DonateMenu_Open', function(p, text)
	if p == LocalPlayer() and text:sub(0, 7) == '/donate' then
		RunConsoleCommand('ls_shop')
	end
end)

hook.Add('Think', 'ls_shop_key', function()
	if input.IsKeyDown(KEY_F6) and ls_shop.p == nil then
		RunConsoleCommand('ls_shop')
	end
end)

net.Receive('ls_shop_log', function()
	local t = net.ReadTable()
	local par = net.ReadInt(4)
	
	if par != 4 then
	
	local f = vgui.Create('DFrame')
	f:SetSize(800, 600)
	f:Center()
	f:MakePopup()
	f:SetTitle('LS Shop Logs')
	f.Paint = function(self, w, h)
		surface.SetDrawColor(32, 32, 32)
		surface.DrawRect(0, 0, w, h)	
	end
	
	local lst = vgui.Create("DListView", f)
	lst:Dock(FILL)
	lst:SetMultiSelect(false)
	lst:AddColumn("SteamID")
	lst:AddColumn("Действие")
	lst:AddColumn(ls_donate.currency_ru[2])
	lst:AddColumn('Время')
	
	local sum = 0
	for k, v in pairs(t) do
		lst:AddLine(v.SteamID, v.Item, v.Money, os.date("%d/%m/%Y - %H:%M:%S", v.Time))
		local m = tonumber(v.Money)
		if m and m > 0 then
			sum = sum + v.Money
		end
	end

	if par < 3 then lst:AddLine('', 'Всего донатов:', sum, '') end
	
	lst.OnRowSelected = function(self, index, pnl)
		gui.OpenURL('http://steamcommunity.com/profiles/' .. util.SteamIDTo64(pnl:GetColumnText(1)))	
	end
	
	else
	
	local f = vgui.Create( "DFrame" )
	f:SetSize(800, 800)
	f:Center()
	f:MakePopup()
	f:SetTitle('LS Shop Summary')
	f.Paint = function(self, w, h)
		surface.SetDrawColor(32, 32, 32)
		surface.DrawRect(0, 0, w, h)	
	end
	
	local bp = vgui.Create('EditablePanel', f)
	bp:Dock(TOP)
	bp.Paint = function(self, w, h)
		surface.SetDrawColor(0, 0, 0)
		surface.DrawRect(0, 0, w, h)
	end
	
	local charts
	local maxchart
	
	local function createCharts(countf)
		charts = {}
		maxchart = 0
		local counter = 0
		local lastT
		for k, v in pairs(t) do
			local day = countf(v.Time)
			if not lastT or day != lastT then
				lastT = day
				counter = counter + 1
			end
			
			charts[counter] = charts[counter] or {}
			charts[counter].amount = charts[counter].amount or 0
			charts[counter].date = charts[counter].date or day
			
			v.Money = tonumber(v.Money)
			if v.Money > 0 then
				charts[counter].amount = charts[counter].amount + v.Money
				if charts[counter].amount > maxchart then maxchart = charts[counter].amount end
			end
			
			if counter >= 13 then break end
		end	
	end
	
	local bd = vgui.Create('DButton', bp)
	bd:SetSize(400, 0)
	bd:Dock(LEFT)
	bd.Paint = function(self, w, h)
		surface.SetDrawColor(64, 64, self:IsDown() and 196 or (self:IsHovered() and 128 or 64))
		surface.DrawRect(0, 0, w, h)
		
		draw.SimpleText("Days", "Trebuchet24", w/2, h/2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		return true
	end
	
	bd.DoClick = function()
		createCharts(function(time)
			return os.date('%d/%m', time)
		end)
	end
	
	bd:DoClick()
	
	local bm = vgui.Create('DButton', bp)
	bm:SetText('Months')
	bm:Dock(RIGHT)
	bm:SetSize(400, 0)
	bm.Paint = function(self, w, h)
		surface.SetDrawColor(64, 64, self:IsDown() and 196 or (self:IsHovered() and 128 or 64))
		surface.DrawRect(0, 0, w, h)
		
		draw.SimpleText("Months", "Trebuchet24", w/2, h/2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		return true
	end
	
	bm.DoClick = function()
		createCharts(function(time)
			return os.date('%b', time)
		end)
	end

	local p = vgui.Create('EditablePanel', f)
	p:Dock(FILL)
	p.Paint = function(self, w, h)
		surface.SetDrawColor(32, 32, 64)
		surface.DrawRect(0, 0, w, h)
		
		surface.SetDrawColor(32, 32, 32)
		surface.DrawRect(0, h - 40, w, 40)
		
		for i, c in ipairs(charts) do
			local val = (c.amount / maxchart) * 600
			local cx, cy, cw, ch = 5 + (i-1) * 65, h - val - 40, 60, val
			local mx, my = self:LocalCursorPos()
			
			draw.SimpleText(c.date, "Trebuchet24", cx + cw / 2, h - 35, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
			if mx > cx and mx < cx + cw and my > cy and my < cy + ch then
				surface.SetDrawColor(255, 255, 255, 255)
				surface.DrawRect(cx - 2, cy - 2, cw + 4, ch + 2)
				
				draw.SimpleText(c.amount .. 'p', "Trebuchet24", cx + cw / 2, cy - 5, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
			end
			
			surface.SetDrawColor(64, 128, 255, 255)
			surface.DrawRect(cx, cy, cw, ch)
		end
	end

	end
end)

net.Receive('ls_shop_notify', function()
	local ply = net.ReadEntity()
	local item = net.ReadString()
	local some = net.ReadInt(16)
	chat.AddText(color_white, "[LS Donate] ", Color(0, 200, 200), ply:GetName() .. ' приобрел ' .. item .. (some > 1 and ': ' .. some or ''))

	ply:EmitSound('garrysmod/content_downloaded.wav', 0, 100, 0.5)
	local e = EffectData()
		e:SetOrigin(ply:GetPos())
		e:SetEntity(ply)
		util.Effect('phys_freeze', e)
		util.Effect('entity_remove', e)
end)