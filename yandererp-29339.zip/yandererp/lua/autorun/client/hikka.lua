local lp, shoulddraw

local tab = {
	[ "$pp_colour_contrast" ] = 0.9,
	[ "$pp_colour_colour" ] = 0.3,
}

local bad = 0
hook.Add("RenderScreenspaceEffects", "hikka", function()
	if shoulddraw then
		DrawColorModify(tab)
		DrawBloom(0.55 - bad/50/2, 1, 20, 20, 1, 1, 1, 1, 1)
		if bad > 0 then DrawMotionBlur(0.4, 0.8, 0.0025 * bad) end
	end
end)

local traceres = {}
hook.Add('HUDPaint', 'hikka', function()
	if shoulddraw and traceres.HitSky then
		draw.SimpleText('Вы не можете находиться на улице, вам становится плохо', 'nunito24s', 16, 180, Color(200, 0, 0))
	end
end)

local lastalcohol = 0
timer.Create('hikka', 1, 0, function()
	lp = LocalPlayer()

	if lp:GetNWInt('alcohol') > 0 then
		lastalcohol = CurTime()
	end

	shoulddraw = IsValid(lp) and lp:Team() == TEAM_HIKKY and lastalcohol + 60*5 < CurTime()
	
	if not shoulddraw then return end
	util.TraceLine({
		start = LocalPlayer():GetShootPos(),
		endpos = LocalPlayer():GetShootPos() + Vector(0, 0, 10000),
		mask = MASK_SOLID_BRUSHONLY,
		output = traceres
	})

	if traceres.HitSky then
		bad = math.min(50, bad + 2)
	else
		bad = math.max(0, bad - 4)
	end
end)