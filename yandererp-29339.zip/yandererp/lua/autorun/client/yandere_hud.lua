surface.CreateFont('lsHUD info', {font='Nunito', extended = true, size = 22, outline = false, weight = 600, antialias = true, shadow = false})
surface.CreateFont('lsHUD text', {font='Segoe UI', extended = true, size = 26, outline = false, weight = 600, antialias = true, shadow = false, italic = true})

local icon_size = 100
local posx = 12
local posy = 52
local outline = Color(0, 0, 0, 128)

local hp = 0
local eg = 0
local mon = 0

local stamina = 100
local hunger = 100

local ls_style = {}
ls_style.MainBackground =   Color(27, 36, 49)
ls_style.ButtonBG =         Color(132, 64, 115)
ls_style.ButtonOutline =    Color(191, 106, 165)
ls_style.Secondary =        Color(50, 60, 70)
ls_style.Accent =           Color(255, 114, 167)
ls_style.Header =           Color(39, 49, 66)

local bgMat
if file.Exists('ls_yandere_hud.png', 'DATA') then
	bgMat = Material('../data/ls_yandere_hud.png')
else
	http.Fetch('https://lampserv.org/assets/gmod/maxmolsuka.png', function(data)
		file.Write('ls_yandere_hud.png', data)
		timer.Simple(1, function()
			bgMat = Material('../data/ls_yandere_hud.png')
		end)
	end)
end

local heart_mat
if file.Exists('ls_yandere_hud_heart.png', 'DATA') then
	heart_mat = Material('../data/ls_yandere_hud_heart.png')
else
	http.Fetch('https://lampserv.org/assets/gmod/heart.png', function(data)
		file.Write('ls_yandere_hud_heart.png', data)
		timer.Simple(1, function()
			heart_mat = Material('../data/ls_yandere_hud_heart.png')
		end)
	end)
end

if hud_icon then hud_icon:Remove() end
hud_icon = vgui.Create('SpawnIcon')
hud_icon:SetSize(icon_size - 16, icon_size - 16)
hud_icon:SetPos(posx + 8, posy + 8)
hud_icon:SetPaintedManually(true)

local last_model

hook.Add('PostGamemodeLoaded', 'YandereHud', function()
	GAMEMODE.custom_hud.main = function(lp)
		surface.SetDrawColor(ls_style.Secondary)
		surface.DrawRect(posx + 7, posy + 8, icon_size - 16, icon_size - 16)
		
		local mdl = lp:GetModel()
		if mdl != last_model then
			hud_icon:SetModel(mdl)
			last_model = mdl
		end
		
		if IsValid(hud_icon) then hud_icon:PaintManual(hud_icon:GetSize()) end
		
		if bgMat then
			surface.SetMaterial(bgMat)
			surface.SetDrawColor(255, 255, 255)
			surface.DrawTexturedRect(0, 0, 412, 211)
		end
		
		hp = Lerp(0.1, hp, lp:Health())
		eg = Lerp(0.1, eg, lp:GetCSVar('Hunger', 0))
		mon = Lerp(0.1, mon, lp:GetMoney())
		local moneytext = GAMEMODE.formatMoney(math.Round(mon))
		surface.SetFont('lsHUD text')
		local moneybar = math.max(96, surface.GetTextSize(moneytext) + 32)
		
		draw.RoundedBoxEx(8, posx + icon_size - 8, posy + icon_size - 22, moneybar + 8, 22, ls_style.Secondary, false, true, false, true)
		
		
		local jobName = team.GetName(lp:Team())
		
		if hp >= 1 then
			draw.RoundedBoxEx(8, posx + icon_size, posy + 29, math.Clamp(hp/100, 0, 1) * 207, 16, ls_style.Accent, false, true, false, true)
			if heart_mat then
				surface.SetDrawColor(250, 250, 250, 255)
				surface.SetMaterial(heart_mat)
				local heartbeat = math.min(math.ceil(SysTime() * 2 / math.Clamp(lp:Health()/100, 0, 1)) % 5, 1)
				surface.DrawTexturedRect(posx + icon_size + 4 + heartbeat, posy + 30 + heartbeat, 14 - heartbeat * 2, 14 - heartbeat*2)
			end
		end
		
		if eg > 0 then
			draw.RoundedBoxEx(8, posx + icon_size, posy + icon_size * 0.74 - 19, math.Clamp(eg/100, 0, 1) * 187, 16, Color(124, 118, 244, 255), false, true, false, true)
		end
		
		draw.SimpleText(math.max(0, lp:Health()), "lsHUD info", posx + icon_size + 104, posy + 36, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText(math.ceil(lp:GetCSVar('Hunger', 0)), "lsHUD info", posx + icon_size + 97, posy + 62, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		local jobtext_w = draw.SimpleTextOutlined(string.upper(jobName), "lsHUD text", posx + icon_size + 114, posy + 9, team.GetColor(lp:Team()), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 0.5, outline)
		draw.SimpleTextOutlined(moneytext, "lsHUD text", posx + icon_size + moneybar/2 - 2, posy + icon_size - 12, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 0.5, outline)
	end
end)

local t = {
	['$pp_colour_addr'] = 0.02,
	['$pp_colour_addg'] = 0,
	['$pp_colour_addb'] = 0.015,
	['$pp_colour_brightness'] = 0,
	['$pp_colour_contrast'] = 1.2,
	['$pp_colour_colour'] = 1.5,
	['$pp_colour_mulr'] = 0,
	['$pp_colour_mulg'] = 0,
	['$pp_colour_mulb'] = 0,
}

hook.Add('RenderScreenspaceEffects', 'Happy Day', function()
	DrawColorModify(t)
	DrawToyTown(1, ScrH()/8)
	DrawBloom(0.8, 1.3, 9, 9, 1, 1.1, 1, 0.7, 0.8)
end)