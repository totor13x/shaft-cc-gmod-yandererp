local panel
concommand.Add('lrp_bodygroups', function(ply)
	if ValidPanel(panel) then return end
	local bgroupstbl = ply:GetBodyGroups()
	local modelpanelsize = 100
	local modelpanelws = 6
	local bgroups = {}
	local maxbgcount = 1
	
	for k, v in pairs(bgroupstbl) do
		if not v.submodels then continue end
		local count = table.Count(v.submodels)
		if count > 1 then
			table.insert(bgroups, v)
			if count > maxbgcount then
			  maxbgcount = count
			end
		end
	end
	
	if #bgroups == 0 then
		chat.AddText(Color(255, 255, 0), 'Для твоей модели это недоступно!')
		return
	end
	
	panel = vgui.Create('EditablePanel')
	panel:SetSize(maxbgcount * modelpanelsize, #bgroups * modelpanelsize)
	panel:Center()
	for k, v in pairs(bgroups) do
	  for k2, _ in pairs(v.submodels) do
		local modelpanel = vgui.Create('Panel', panel)
		modelpanel:SetPos((k2 + (maxbgcount - table.Count(v.submodels))/2) * modelpanelsize + modelpanelws, (k - 1) * modelpanelsize + modelpanelws)
		modelpanel:SetSize(modelpanelsize - modelpanelws*2, modelpanelsize - modelpanelws*2)
		modelpanel.Paint = function(s, w, h)
			surface.SetDrawColor(0, 0, 0, 128)
			surface.DrawRect(0, 0, w, h)
		end
		
		local model = vgui.Create('DModelPanel', modelpanel)
		model:SetSize(modelpanel:GetWide(), modelpanel:GetTall())
		model:SetModel(ply:GetModel())
		function model:LayoutEntity() return end
		local headpos = model.Entity:GetBonePosition(model.Entity:LookupBone('ValveBiped.Bip01_Head1'))
		model:SetLookAt(headpos)
		model:SetCamPos(headpos - Vector(-175, 0, 0))
		model:SetFOV(10)
		model.Entity:SetBodygroup(v.id, k2)
		function model:OnMousePressed(keycode)
			if keycode == MOUSE_LEFT then
				net.Start('lrp_changebodygroup')
				  net.WriteInt(v.id, 6)
				  net.WriteInt(k2, 6)
				net.SendToServer()
			
				gui.EnableScreenClicker(false)
				panel:Remove()
			end
		end

		end
	end
	
	gui.EnableScreenClicker(true)
end)