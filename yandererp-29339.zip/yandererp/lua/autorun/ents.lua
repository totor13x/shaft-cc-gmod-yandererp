local food = {
	{
		name = 'Кавун',
		desc = 'Прямиком из Африки!',
		model = 'models/props_junk/watermelon01.mdl',
		energyprice = 9
	},
	{
		name = 'Картошка',
		desc = 'Картофель - второй хлеб',
		model = 'models/props_phx/misc/potato.mdl',
		energyprice = 5
	},
	{
		name = 'Банан',
		desc = 'Сыроват, нужно бы поджарить',
		model = 'models/props/cs_italy/bananna.mdl',
		energyprice = 5
	},
	{
		name = 'Связка бананов',
		desc = 'То же, что и один. Только больше в пять раз.',
		model = 'models/props/cs_italy/bananna_bunch.mdl',
		energyprice = 7
	},
	{
		name = 'Апельсин',
		desc = 'Богат витамином C',
		model = 'models/props/cs_italy/orange.mdl',
		energyprice = 3
	},
	{
		name = 'Варёное яйцо',
		desc = 'С майонезом неплохо зайдёт',
		model = 'models/props_phx/misc/egg.mdl',
		energyprice = 5
	},
	{
		name = 'Квас',
		desc = 'Если помешать с картошкой, то получится окрошка',
		model = 'models/props_junk/garbage_plasticbottle003a.mdl',
		energyprice = 5
	},
	{
		name = 'Кефир',
		desc = 'Кисломолочный продукт',
		model = 'models/props_junk/garbage_milkcarton002a.mdl',
		energyprice = 5,
	},
	{
		name = 'Тортик',
		desc = 'от итальянского torta - "круглый хлеб',
		energyprice = 50,
		model = "models/props/cake/cakeprop.mdl"
	},
}

local alcohol = {
	{
		name = 'Пиво',
		class = 'alcohol',
		desc = 'Обязательный участник школьных вечеринок!',
		price = 55,
		model = 'models/props_junk/garbage_glassbottle003a.mdl'
	},
	{
		name = 'Виски Jack Daniels',
		class = 'alcohol_1',
		price = 250,
		model = "models/props_interiors/bottles_shelf_break12.mdl"
	},
	{
		name = 'Водка “Столичная”',
		class = 'alcohol_2',
		desc = 'Ни в коем случае не давайте махмолу!',
		price = 125,
		model = "models/props_interiors/bottles_shelf_break05.mdl"
	},
	{
		name = 'Водка Русская',
		class = 'alcohol_3',
		desc = 'Ни в коем случае не давайте махмолу!',
		price = 100,
		model = "models/props_interiors/bottles_shelf_break09.mdl"
	},
	{
		name = 'Мохито',
		class = 'alcohol_4',
		price = 200,
		model = "models/props_interiors/bottles_shelf_break08.mdl"
	},
	{
		name = 'Сидр',
		class = 'alcohol_5',
		price = 200,
		model = "models/props_interiors/bottles_shelf_break04.mdl"
	},
		{
		name = 'Вино',
		class = 'alcohol_6',
		desc = 'Сделано в Италии!',
		price = 220,
		model = "models/props_interiors/bottles_shelf_break01.mdl"
	},
		{
		name = 'Пиво Балтика',
		class = 'alcohol_7',
		price = 65,
		model = "models/props_interiors/bottles_shelf_break11.mdl"
	},
		{
		name = 'Black Bacardi',
		class = 'alcohol_8',
		price = 300,
		model = "models/props_interiors/bottles_shelf_break10.mdl"
	},
	{
		name = 'Квас Лидский',
		class = 'alcohol_9',
		price = 50,
		model = "models/props_junk/garbage_glassbottle001a.mdl"
	},
}


hook.Add('RP_CustomEnts', '_', function()
DarkRP.createEntity("Тетрадка", {
	ent = "maxmol_notebook",
	model = "models/school/notepad.mdl",
	price = 25,
	max = 5,
	cmd = "buynotebook",
	category = "Общее",
})

DarkRP.createEntity("Коробка Для Деталей", {
	ent = "lrp_detail_box",
	model = "models/props/cs_office/cardboard_box01.mdl",
	price = 100,
	max = 1,
	cmd = "buydetailbox",
	category = "Общее",
})

DarkRP.createEntity("Телевизор", {
	ent = "lrp_tv",
	model = "models/props/cs_office/tv_plasma.mdl",
	price = 150,
	max = 1,
	cmd = "buytv",
	category = "Общее",
})

--[[
DarkRP.createEntity("Кровать", {
	ent = "ls_bed",
	model = "models/props/de_inferno/bed.mdl",
	price = 2500,
	max = 1,
	cmd = "buybed",
})
]]

DarkRP.createEntity("Футбольный мяч", {
	ent = "football",
	model = "models/props_phx/misc/soccerball.mdl",
	price = 0,
	max = 1,
	cmd = "buyfootball",
	allowed = {TEAM_TEACHER_SPORT},
})


DarkRP.createShipment("Ножик", {
	model = "models/weapons/w_knife_t.mdl",
	entity = "weapon_knife",
	price = 1000,
	amount = 1,
	noship = false,
	allowed = {TEAM_BARIGA},
	category = "Оружие",
})

DarkRP.createShipment("Отмычка", {
	model = "models/weapons/w_crowbar.mdl",
	entity = "lockpick",
	price = 800,
	amount = 1,
	noship = false,
	allowed = {TEAM_BARIGA},
	category = "Оружие",
})

DarkRP.createShipment("Лазерная Указка", {
	model = "models/weapons/w_toolgun.mdl",
	entity = "laserpointer",
	price = 1200,
	amount = 1,
	noship = false,
	allowed = {TEAM_BARIGA},
	category = "Оружие",
})

DarkRP.createShipment("Взламыватель кейпадов", {
	model = "models/weapons/w_c4.mdl",
	entity = "lrp_hacking_device",
	price = 1500,
	amount = 1,
	noship = false,
	allowed = {TEAM_BARIGA},
	category = "Оружие",
})

DarkRP.createShipment("Сигарета Беломорканал", {
	model = "models/mordeciga/mordes/ciga.mdl",
	entity = "weapon_ciga_cheap",
	price = 200,
	amount = 1,
	noship = false,
	allowed = {TEAM_BARIGA},
	category = "Оружие",
})

DarkRP.createShipment("Сигарета Ява", {
	model = "models/mordeciga/mordes/ciga.mdl",
	entity = "weapon_ciga",
	price = 250,
	amount = 1,
	noship = false,
	allowed = {TEAM_BARIGA},
	category = "Оружие",
})

DarkRP.createShipment("Сигарета Captain Black", {
	model = "models/mordeciga/mordes/ciga.mdl",
	entity = "weapon_ciga_blat",
	price = 300,
	amount = 1,
	noship = false,
	allowed = {TEAM_BARIGA},
	category = "Оружие",
})

DarkRP.createShipment("Молотов", {
	model = "models/nmrih/weapons/exp_molotov/w_exp_molotov.mdl",
	entity = "weapon_nmrih_molotov",
	price = 5000,
	amount = 1,
	noship = false,
	allowed = {TEAM_SMUGGLER},
	category = "Оружие",
})

DarkRP.createShipment("P2011", {
	model = "models/weapons/p2011/w_p2011.mdl",
	entity = "mp_weapon_semipistol",
	price = 3000,
	amount = 1,
	noship = false,
	allowed = {TEAM_SMUGGLER},
	category = "Оружие",
})

DarkRP.createEntity("LRP PhotoPrint", {
	ent = "lrp_photoprint",
	model = "models/props_c17/consolebox03a.mdl",
	price = 2000,
	max = 1,
	cmd = "buyphotoprint",
	allowed = {TEAM_PHOTOSERVICE}
})

DarkRP.createEntity("Микроволновка", {
	ent = "microwave",
	model = "models/props/cs_office/microwave.mdl",
	price = 250,
	max = 1,
	cmd = "buymicrowave",
	allowed = TEAM_COOK
})

DarkRP.createEntity( "Синтезатор пианино", {
	ent = "synthesizer_piano",
	model = "models/tnf/synth.mdl",
	price = 5000,
	max = 1,
	cmd = "piano",
	allowed = {TEAM_MUSIC, TEAM_CLUB_MUSIC, TEAM_CLUBMEMBER_MUSIC},
	category = "Музыкальные инструменты",
} )

DarkRP.createEntity( "Барабаны", {
	ent = "instrument_drum",
	model = "models/yukitheater/drums.mdl",
	price = 1000,
	max = 1,
	cmd = "drums",
	allowed = {TEAM_MUSIC, TEAM_CLUB_MUSIC, TEAM_CLUBMEMBER_MUSIC},
	category = "Музыкальные инструменты",
} )

DarkRP.createShipment("Гитара", {
	model = "models/props_phx/misc/fender.mdl",
	entity = "guitar",
	price = 800,
	amount = 1,
	allowed = {TEAM_MUSIC, TEAM_CLUB_MUSIC, TEAM_CLUBMEMBER_MUSIC},
	category = "Музыкальные инструменты",
})

DarkRP.createShipment("Деревянная катана", {
	model = "models/weapons/w_katana.mdl",
	entity = "weapon_wood_katana",
	price = 200,
	amount = 1,
	allowed = {TEAM_CLUB_AIKIDO},
	category = "Клуб айкидо",
})

DarkRP.createEntity("Компьютер", {
	ent = "sent_computer",
	model = "models/props_lab/monitor01a.mdl",
	price = 100,
	max = 2,
	cmd = "computer",
	allowed = {TEAM_TEACHER_ICT},
	category = "Учебные принадлежности",
})

DarkRP.createEntity("Энергозаряды", {
	ent = "battery_ammo",
	model = "models/items/sci-fi/w_ammo.mdl",
	price = 100,
	max = 2,
	cmd = "battery_ammo",
	category = "Патроны",
})

DarkRP.createEntity("Патроны для пистолета", {
	ent = "item_ammo_pistol",
	model = "models/items/boxsrounds.mdl",
	price = 400,
	max = 2,
	cmd = "pistol_ammo",
	category = "Патроны",
})

DarkRP.createEntity("Магазинчик смузимейкера", {
	ent = "zfs_shop",
	model = "models/zerochain/fruitslicerjob/fs_shop.mdl",
	price = 400,
	max = 1,
	cmd = "buyzfs_shop",
	allowed = TEAM_ZFRUITSLICER,
	category = "Смузимейкер",
	sortOrder = 0,
})

DarkRP.createEntity("Пустое зелье", {
	ent = "spl_alchemy_potion",
	model = "models/props/alchemy/fiole_ballon01.mdl",
	price = 0,
	max = 6,
	cmd = "buyspl_alchemy_potion",
	allowed = TEAM_TEACHER_CHEM,
	category = "Учебные принадлежности",
	sortOrder = 0,
})

DarkRP.createEntity('Смесь для выпечки', {
	ent = 'zwf_muffinmix',
	model = "models/zerochain/props_weedfarm/zwf_backmix.mdl",
	price = 25,
	max = 1,
	cmd = "buyzwf_muffinmix",
	allowed = {TEAM_CLUB_BAKER, TEAM_CLUBMEMBER_BAKER},
	category = "Клуб пекарей",
	sortOrder = 0,
})

DarkRP.createEntity('Вишнёвый бонг', {
	ent = 'zwf_bong01_ent',
	model = "models/zerochain/props_weedfarm/zwf_bong01.mdl",
	price = 225,
	max = 1,
	cmd = "buyzwf_bong01_ent",
	allowed = {TEAM_CLUB_SAD, TEAM_CLUBEMBER_SAD},
	category = "Клуб садовников",
	sortOrder = 0,
})

DarkRP.createEntity('Бонг "Мечта Регги"', {
	ent = 'zwf_bong02_ent',
	model = "models/zerochain/props_weedfarm/zwf_bong02.mdl",
	price = 300,
	max = 1,
	cmd = "buyzwf_bong02_ent",
	allowed = {TEAM_CLUB_SAD, TEAM_CLUBEMBER_SAD},
	category = "Клуб садовников",
	sortOrder = 0,
})

DarkRP.createEntity('Тёмный бонг', {
	ent = 'zwf_bong03_ent',
	model = "models/zerochain/props_weedfarm/zwf_bong03.mdl",
	price = 600,
	max = 1,
	cmd = "buyzwf_bong03_ent",
	allowed = {TEAM_CLUB_SAD, TEAM_CLUBEMBER_SAD},
	category = "Клуб садовников",
	sortOrder = 0,
})

DarkRP.createShipment("Экстрактор мета", {
	model = "models/weapons/w_crowbar.mdl",
	entity = "zmlab_extractor",
	price = 500,
	amount = 1,
	allowed = TEAM_NARKOMAN,
	category = "Для варки мета",
})

DarkRP.createEntity("Комбайнер", {
	ent = "zmlab_combiner",
	model = "models/zerochain/zmlab/zmlab_combiner.mdl",
	price = 1600,
	max = 1,
	cmd = "buycombiner_zmlab",
	allowed = TEAM_NARKOMAN,
	category = "Для варки мета"
})

DarkRP.createEntity("Газовый фильтр", {
	ent = "zmlab_filter",
	model = "models/zerochain/zmlab/zmlab_filter.mdl",
	price = 200,
	max = 2,
	cmd = "buyfilter_zmlab",
	allowed = TEAM_NARKOMAN,
	category = "Для варки мета"
})

DarkRP.createEntity("Холодильник", {
	ent = "zmlab_frezzer",
	model = "models/zerochain/zmlab/zmlab_frezzer.mdl",
	price = 800,
	max = 2,
	cmd = "buyfrezzer_zmlab",
	allowed = TEAM_NARKOMAN,
	category = "Для варки мета"
})

DarkRP.createEntity("Коробка для транспортировки", {
	ent = "zmlab_collectcrate",
	model = "models/zerochain/zmlab/zmlab_transportcrate.mdl",
	price = 50,
	max = 5,
	cmd = "buycollectcrate_zmlab",
	allowed = TEAM_NARKOMAN,
	category = "Для варки мета"
})

DarkRP.createEntity("Метиламин", {
	ent = "zmlab_methylamin",
	model = "models/zerochain/zmlab/zmlab_methylamin.mdl",
	price = 200,
	max = 2,
	cmd = "buymethylamin_zmlab",
	allowed = TEAM_NARKOMAN,
	category = "Для варки мета"
})

DarkRP.createEntity("Алюминий", {
	ent = "zmlab_aluminium",
	model = "models/zerochain/zmlab/zmlab_aluminiumbox.mdl",
	price = 120,
	max = 2,
	cmd = "buyaluminium_zmlab",
	allowed = TEAM_NARKOMAN,
	category = "Для варки мета"
})

DarkRP.createEntity("Деревянный поддон", {
	ent = "zmlab_palette",
	model = "models/props_junk/wood_pallet001a.mdl",
	price = 50,
	max = 3,
	cmd = "buypalette_zmlab",
	allowed = TEAM_NARKOMAN,
	category = "Для варки мета"
})

DarkRP.createEntity("Успокоительное", {
	ent = "alcohol_psycho",
	model = "models/prop/syringe.mdl",
	price = 15,
	max = 2,
	cmd = "buyalcohol_psycho",
	allowed = TEAM_PSYCHO,
	category = "Психолог",
	desc = [[Успокоит даже самых тяжёлых учеников.
Используйте на Яндере, когда она проявляет ненормальную тягу к противоположному полу, чтобы усмирить её чувства.]],
})

DarkRP.createEntity("Школьные учебники", {
	ent = "library_textbook",
	model = "models/props_lab/binderredlabel.mdl",
	price = 0,
	max = 2,
	cmd = "buylibrary_textbook",
	allowed = TEAM_LIBRARY,
	category = "Учебные принадлежности",
	desc = [[Самые обычные школьные учебники. Нужны для того чтобы можно было учиться.]],
})

local Fruits = {}
Fruits["zfs_fruitbox_melon"] = "Арбузы"
Fruits["zfs_fruitbox_banana"] = "Бананы"
Fruits["zfs_fruitbox_coconut"] = "Кокосы"
Fruits["zfs_fruitbox_pomegranate"] = "Гранаты"
Fruits["zfs_fruitbox_strawberry"] = "Землянички"
Fruits["zfs_fruitbox_kiwi"] = "Киви"
Fruits["zfs_fruitbox_lemon"] = "Лемоны"
Fruits["zfs_fruitbox_orange"] = "Апельсины"
Fruits["zfs_fruitbox_apple"] = "Яблоки"
  
  for k, v in pairs(Fruits) do
		DarkRP.createEntity(v, {
		  ent = k,
		  model = "models/zerochain/fruitslicerjob/fs_cardboardbox.mdl",
		  price = 100,
		  max = 5,
		  cmd = "buy" .. k,
		  allowed = TEAM_ZFRUITSLICER,
		  category = "Смузимейкер"
		})
  end

for i, food in ipairs(food) do
	DarkRP:CreateBuyEntity{
		name = food.name,
		class = 'spawned_food',
		desc = food.desc,
		max = 5,
		model = food.model,
		price = food.energyprice,
		category = 'Food',
		jobs = {TEAM_COOK, TEAM_SUPERMARKET},
		spawn = function(ent)
			ent.FoodEnergy = food.energyprice * 2
		end
	}
end

for i, alcohol in ipairs(alcohol) do 
	DarkRP:CreateBuyEntity{
		name = alcohol.name,
		class = alcohol.class,
		desc = alcohol.desc or 'No description...',
		model = alcohol.model,
		max = 5,
		price = alcohol.price,
		category = 'Алкоголь',
		jobs = {TEAM_BARIGA, TEAM_BARTENDER}
	}
end

end)