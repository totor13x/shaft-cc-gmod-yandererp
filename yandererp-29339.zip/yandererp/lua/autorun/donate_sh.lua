ls_donate = {}

/*
	@ls_donate.code
	Код вашего проекта
	Не менять!
*/
ls_donate.code = "Y"


/*
	@ls_donate.access( Player )
	Функция наличия доступа для администрирования донат-системы
	Изменять только если знаете, что делаете
*/
ls_donate.access = function(ply)
	return ply:SteamID64() == '76561198022751054'
end

/*
	Название валюты доната на русском в разных формах
*/
ls_donate.currency_ru = {
    'пиф', -- ед. число, им. падеж
    'пифы', -- мн. число, им. падеж
    'пифов', -- мн. число, р. падеж
}

/*
	Символ вашей донат-валюты
*/
ls_donate.currency_symbol = '₱'

/*
    @ls_donate.items
    Все предметы магазина
    
    name        - Название предмета. То, которое отобразится в меню
    code        - Кодовое название предмета. Должно быть уникальным.
    price       - Цена в донат-валюте
    color       - Цвет блока предмета в меню
    textColor   - Цвет текста в меню
    info        - Какие дополнительные данные нужно указывать при покупке
        nil   - ничего не вводить
        "num" - число (количество)
        "text"- текст (возможно пока не работает!!!)
    cat         - Категория для меню
    desc        - Подробное описание для меню
	func		- Функция, выполняющаяся при покупке
		Аргументы:
			ply - игрок
			n 	- `info`, введенное игроком (если указано)
*/
ls_donate.items = {
	{
		name = 'Поинт',
		code = 'points',
		price = 1,
		color = color_white,
		textColor = color_black,
		info = 'num',
		cat = 'Основное',
		desc = 'Валюта, за которую приобретаются шапки, плеермодели и другое в поинт-шопе (F2)',
		func = function(ply, n)
			ply:AddPoints(n)
		end,
	},
	{
		name = '¥20000',
		code = 'money',
		price = 70,
		color = Color(0, 196, 0),
		cat = 'Основное',
		desc = 'Базовая сумма, с которой ты сможешь себе позволить дешевый транспорт или прокаченный сет битмайнеров',
		func = function(ply)
			ply:addMoney(20000)
		end,
	},
	{
		name = '¥80000',
		code = 'money2',
		price = 260,
		color = Color(0, 196, 0),
		cat = 'Основное',
		desc = 'С такой суммой, ты сможешь купить и авто, и полный сет битмайнеров, а также сохранить деньги на другие покупки',
		func = function(ply)
			ply:addMoney(80000)
		end,
	},
	{
		name = '¥220000',
		code = 'money3',
		price = 620,
		color = Color(0, 196, 0),
		cat = 'Основное',
		desc = 'Серьёзная сумма, ты станешь влиятельной персоной в городе',
		func = function(ply)
			ply:addMoney(220000)
		end,
	},
	{
		name = '¥500000',
		code = 'money4',
		price = 1150,
		color = Color(0, 196, 0),
		cat = 'Основное',
		desc = 'Ты станешь элитой города, у тебя будут яхты, тачки, наркота, пушки. Всё, что захочешь!',
		func = function(ply)
			ply:addMoney(500000)
		end,
	},
	{
		name = '¥1200000',
		code = 'money5',
		price = 2300,
		color = Color(0, 196, 0),
		cat = 'Основное',
		desc = 'Босс Якудзы.',
		func = function(ply)
			ply:addMoney(1200000)
		end,
	},
	{
		name = 'Премиум | 5 Дней',
		code = 'premium5',
		price = 50,
		color = Color(0, 200, 120),
		cat = 'Premium',
		desc = [[- Premium профессии
- Ховерборды
- Больше пропов (50 вместо 20)
- Возможность настраивать цвет своих сообщений в чате
- Возможность отправлять картинки по ссылке в чат
и другие бонусы!]],
		func = function(ply)
			local time = ply:GetPremiumTime()
			if time == 0 then
				return
			end
			
			time = time or 0
			
			ply:SetPremium(true, time + 5)
		end,
	},
	{
		name = 'Премиум | Месяц',
		code = 'premium30',
		price = 248,
		color = Color(0, 200, 120),
		cat = 'Premium',
		desc = 'Выгоднее взять на месяц',
		func = function(ply)
			local time = ply:GetPremiumTime()
			if time == 0 then
				return
			end
			
			time = time or 0
			
			ply:SetPremium(true, time + 30)
		end,
	},
	{
		name = 'Премиум | 3 Месяца',
		code = 'vip3',
		price = 498,
		color = Color(0, 200, 120),
		cat = 'Premium',
		desc = 'Почти никогда не закончится',
		func = function(ply)
			local time = ply:GetPremiumTime()
			if time == 0 then
				return
			end
			
			time = time or 0
			
			ply:SetPremium(true, time + 90)
		end,
	},
	{
		name = 'Премиум | Навсегда',
		code = 'vipforever',
		price = 748,
		color = Color(0, 200, 120),
		cat = 'Premium',
		desc = [[Главный саппортер сервера]],
		func = function(ply)
			ply:SetPremium(true, 0)
		end,
	},
	/*{
		name = 'Модер | Месяц',
		code = 'moder2',
		price = 450,
		color = Color(64, 64, 192),
		cat = 'Привилегии',
		desc = [[Базовые функции для администрирования сервера]],
		func = function(ply)
			ply:SetUserGroup('#Moderator')
		end,
	},
	{
		name = 'Админ | Месяц',
		code = 'admin2',
		price = 650,
		color = Color(255, 64, 96),
		cat = 'Привилегии',
		desc = [[Полный функционал для контроля за игроками и сервером]],
		func = function(ply)
			SetTimedStaffTeam(ply:SteamID(), '#Admin', (ply:GetStaffTeam() != '#Admin' and 0 or GetStaffTimeLeft(ply:SteamID())/60/60/24) + 30)
			ply:SetUserGroup('#Admin')
		end,
	},
	/*{
		name = 'СуперАдмин | Месяц',
		code = 'superadmin2',
		price = 890,
		color = Color(64, 196, 255),
		cat = 'Привилегии',
		desc = [[Дополнительные возможности администрирования]],
		func = function(ply)
			SetTimedStaffTeam(ply:SteamID(), '#Super Admin', (ply:GetStaffTeam() != '#Super Admin' and 0 or GetStaffTimeLeft(ply:SteamID())/60/60/24) + 30)
			ply:SetUserGroup('#Super Admin')
		end,
	},
	{
		name = 'Радужный Физган',
		code = 'rainbow_physgun',
		price = 190,
		color = color_white,
		colorFunc = function()
			return HSVToColor((SysTime() * 100) % 360, 1, 1)
		end,
		cat = 'Оружие',
		desc = 'Ваш физган будет переливаться всеми цветами радуги!',
		func = function(ply)
			--ply:AddPSItem('Rainbow Physgun')
		end,
	},*/
	{
		name = 'Ножик',
		code = 'weapon_knife',
		price = 350,
		color = Color(255, 128, 128),
		cat = 'Оружие',
		desc = 'Острый нож',
		func = function(ply)
			ply:AddPermWeapon('weapon_knife')
		end,
	},
	{
		name = 'Учебник геометрии',
		code = 'weapon_crowbar',
		price = 299,
		color = Color(255, 128, 128),
		cat = 'Оружие',
		desc = 'Кто-то с ним ломает голову, а ты будешь выламывать челюсти',
		func = function(ply)
			ply:AddPermWeapon('weapon_crowbar')
		end,
	},
	{
		name = 'Телепортер',
		code = 'teleporter',
		price = 299,
		color = Color(100, 196, 196),
		cat = 'Оружие',
		desc = 'Позволит телепортироваться на любые дистанции',
		func = function(ply)
			ply:AddPermWeapon('teleporter')
		end,
	},
	{
		name = 'Крюк-кошка',
		code = 'grappling_hook',
		price = 299,
		color = Color(255, 196, 128),
		cat = 'Оружие',
		desc = [[Не хочешь бежать через всю школу, чтобы забраться на крышу? 
Тогда Крюк-кошка определённо твой выбор!]],
		func = function(ply)
			ply:AddPermWeapon('grappling_hook')
		end,
	},
	{
		name = 'Vape',
		code = 'weapon_vape',
		price = 199,
		color = Color(255, 196, 128),
		cat = 'Оружие',
		desc = 'Пари где хочешь, ведь законом у нас это не запрещено!',
		func = function(ply)
			ply:AddPermWeapon('weapon_vape_juicy')
		end,
	},
	{
		name = 'ZAPPER',
		code = 'weapon_zapper',
		price = 450,
		color = Color(254, 221, 97),
		cat = 'Оружие',
		desc = 'Пусть он и выглядит как игрушечный пистолет, но меткий выстрел в голову заставит вашего противника отступить.',
		func = function(ply)
			ply:AddPermWeapon('weapon_zapper')
		end,
	},/*
	{
		name = 'Поцелуи',
		code = 'weapon_kiss',
		price = 420,
		color = Color(255, 192, 203),
		cat = 'Оружие',
		desc = 'Не хватает любви? Кто-то поранил тебя или может быть тебе очень хочется есть? Тогда поцелуй кого-нибудь и он не сможет устоять перед тобой, а ещё все твои проблемы моментально исчезнут!',
		func = function(ply)
			ply:AddPermWeapon('weapon_kiss')
		end,
	},*/
	{
		name = 'Лазерная указка',
		code = 'laserpointer',
		price = 199,
		color = Color(233, 30, 99),
		cat = 'Оружие',
		desc = 'Только не свети никому в глаза, а то ведь так ослепнуть можно.',
		func = function(ply)
			ply:AddPermWeapon('laserpointer')
		end,
	},
	/*{
		name = 'Admin "Magic Stick"',
		code = 'magicstick',
		price = 2999,
		color = Color(255, 153, 0),
		cat = 'Оружие',
		desc = 'я не придумал ей описания',
		func = function(ply)
			ply:AddPermWeapon('magicstick')
		end,
	},*/
	{
		name = 'Краскострел',
		code = 'spermostrel',
		price = 498,
		color = Color(220, 220, 220),
		cat = 'Оружие',
		desc = 'Залей весь город краской!',
		func = function(ply)
			ply:AddPermWeapon('spermostrel')
		end,
	},
	{
		name = 'Катана',
		code = 'weapon_mse_katana',
		price = 399,
		color = Color(24, 23, 28),
		cat = 'Оружие',
		desc = 'Настоящая самурайска катана. Только великие мастера способны обращаться с ней, ведь один точный удар в голову способен лишить человека жизни.',
		func = function(ply)
			ply:AddPermWeapon('weapon_mse_katana')
		end,
	},
	{
		name = 'Hammond P2011',
		code = 'mp_weapon_semipistol',
		price = 999,
		color = Color(24, 23, 28),
		cat = 'Оружие',
		desc = 'Полуавтоматический пистолет с хорошей точностью и уроном на расстоянии. Его встроенный «спусковой механизм» позволяет очень быстро стрелять, что полезно в ближнем бою',
		func = function(ply)
			ply:AddPermWeapon('mp_weapon_semipistol')
		end,
	},
	{
		name = 'Молотов',
		code = 'weapon_nmrih_molotov',
		price = 999,
		color = Color(105, 89, 62),
		cat = 'Оружие',
		desc = 'Гори, гори ясно',
		func = function(ply)
			ply:AddPermWeapon('weapon_nmrih_molotov')
		end,
	}
	/*{
		name = 'Сфера притяжения',
		code = 'gravity_sphere',
		price = 340,
		color = color_white,
		colorFunc = function()
			return HSVToColor((SysTime() * 150) % 360, 0.5, 0.8)
		end,
		cat = 'Разное',
		desc = 'Позволяет прыгать выше!',
		func = function(ply)
			ply:AddPSItem('Сфера притяжения')
		end,
	},
	{
		name = 'Разбан',
		code = 'unban',
		price = 150,
		color = Color(24, 23, 28),
		cat = 'Разное',
		desc = 'Надоело бегать “Забаненным”? Поздравляю, у тебя теперь есть возможность избавиться от этого клейма.',
		func = function(ply, n)
			LS_Unban(ply:SteamID())
		end,
	},
	{
		name = 'Кейс "Стартовый"',
		code = 'case',
		price = 60,
		color = Color(164, 17, 196),
		desc  = function() 
			local s = ''
			for _, t in pairs(roulette.items['Стартовый']) do 
				s = s .. '\n' .. t.name
			end 
			return 'В этом кейсе: ' .. s 
		end,
		cat = 'Кейсы',
		func = function(ply, n)
			roulette:start(ply, 'Стартовый')
		end,
	},
	{
		name = 'Кейс "Медиум"',
		code = 'case2',
		price = 168,
		color = Color(161, 22, 20),
		desc  = function() 
			local s = '' 
			for _, t in pairs(roulette.items['Медиум']) do 
				s = s .. '\n' .. t.name
			end 
			return 'В этом кейсе: ' .. s 
		end,
		cat = 'Кейсы',
		func = function(ply, n)
			roulette:start(ply, 'Медиум')
		end,
	},
	{
		name = 'Кейс "Элитный"',
		code = 'case3',
		price = 282,
		color = Color(200, 198, 24),
		desc  = function() 
			local s = '' 
			for _, t in pairs(roulette.items['Элитный']) do 
				s = s .. '\n' .. t.name
			end 
			return 'В этом кейсе: ' .. s 
		end,
		cat = 'Кейсы',
		func = function(ply, n)
			roulette:start(ply, 'Элитный')
		end,
	},
	{
		name = 'Кейс "Минск"',
		code = 'case4',
		price = 456,
		color = Color(124, 252, 0),
		desc  = function() 
			local s = '' 
			for _, t in pairs(roulette.items['Минск']) do 
				s = s .. '\n' .. t.name
			end 
			return 'В этом кейсе: ' .. s 
		end,
		cat = 'Кейсы',
		func = function(ply, n)
			roulette:start(ply, 'Минск')
		end,
	},
	{
		name = 'Кейс с модельками',
		code = 'case5',
		price = 520,
		color = Color(138, 43, 226),
		desc  = function() 
			local s = '' 
			for _, t in pairs(roulette.items['Кейс с модельками']) do 
				s = s .. '\n' .. t.name
			end 
			return 'В этом кейсе: ' .. s 
		end,
		cat = 'Кейсы',
		func = function(ply, n)
			roulette:start(ply, 'Кейс с модельками')
		end,
	},
	/*{
		name = 'Набор Новичка',
		code = 'nabor1',
		one  = true,
		price = 198,
		color = Color(96, 200, 255),
		cat = 'Наборы',
		desc = [[- VIP на 5 Дней
- 250.000 йен
- 50 поинтов
- 5 уровней к умениям
Цена по отдельности: 325 пифов
МОЖНО ПОЛУЧИТЬ ТОЛЬКО 1 РАЗ!!!]]
	},
	{
		name = 'Набор "Анимешник"',
		code = 'nabor2',
		one  = true,
		price = 499,
		color = Color(255, 200, 96),
		cat = 'Наборы',
		desc = [[- VIP на 30 Дней
- 500.000 йен
- 100 поинтов
- 10 уровней к умениям
- Vape
Цена по отдельности: 999 пифов
МОЖНО ПОЛУЧИТЬ ТОЛЬКО 1 РАЗ!!!]]
	},
	{
		name = 'Набор "Лояльность"',
		code = 'nabor3',
		one  = true,
		price = 4999,
		color = Color(102, 0, 255),
		cat = 'Наборы',
		desc = [[- СуперАдмин 90 дней
- Катана
- Admin Magic Stick
- Премиум навсегда
Цена по отдельности: 8167 пифов
МОЖНО ПОЛУЧИТЬ ТОЛЬКО 1 РАЗ!!!]],
		func = function(ply, n)
			SetTimedStaffTeam(ply:SteamID(), '#Super Admin', (ply:GetStaffTeam() != '#Super Admin' and 0 or GetStaffTimeLeft(ply:SteamID())/60/60/24) + 30)
			SetMembership(ply:SteamID(), 'Premium')
			ply:AddPermWeapon('weapon_mse_katana')
			ply:AddPermWeapon('magicstick')
		end,
	},*/
	/*{
		name = 'Драгоценные камни',
		code = 'naborgems',
		one  = false,
		price = 90,
		color = Color(255, 0, 102),
		cat = 'Наборы',
		desc = [[- Тааффеит: 1
- Пейнит: 3
- Танзанит: 4
- Берилл: 70
- Хризолит: 300]],
		func = function(ply, n)
			ply:AddGems('Тааффеит', 1)
			ply:AddGems('Пейнит', 3)
			ply:AddGems('Танзанит', 4)
			ply:AddGems('Берилл', 70)
			ply:AddGems('Хризолит', 300)
		end,
	},*/
}

/*
    @ls_donate.sale
    Размер скидки на донат

    (от 0 до 1) - цена домножается на этот коэффициент
    
    Примеры:
    1       - нет скидки
    0.75    - скидка 25%
    0.5     - скидка 50%
    0.25    - скидка 75%
*/
ls_donate.sale = 	1

-- на это можно можно забить!!!
if ls_donate.sale != 1 then
	for k, v in ipairs(ls_donate.items) do
		v.price = math.ceil(v.price * ls_donate.sale)
	end
end