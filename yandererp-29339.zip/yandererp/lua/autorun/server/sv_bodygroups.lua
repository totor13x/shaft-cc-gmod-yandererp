util.AddNetworkString('lrp_changebodygroup')

net.Receive('lrp_changebodygroup', function(len, ply)
    local bg1, bg2 = net.ReadInt(6), net.ReadInt(6)
    ply:SetBodygroup(bg1, bg2)
end)