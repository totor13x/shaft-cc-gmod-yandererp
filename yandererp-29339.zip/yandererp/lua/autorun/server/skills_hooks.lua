local meta = FindMetaTable('Player')

local default_reward = function(ply)
	ply:AddPoints(1)
end

local check_skill = function(sk, p)
	if not p then
		p = LocalPlayer()
	end
	
	local sks = p.ls_skills
	return sks and sks[sk]
end

local can_obtain = function(sk, p)
	if not ls_skills[sk] then return false end
	local need = ls_skills[sk].need
	local need_all = ls_skills[sk].need_all
	if not need then return true end
	
	if not p then
		p = LocalPlayer()
	end
	local can = need_all
	for k, v in ipairs(need) do
		local check = check_skill(v, p)
		if check and not need_all then
			can = true
			break
		end
		
		if not check and need_all then
			can = false
			break
		end
	end
	
	return can
end

local update_all_obtainable_skills = function(ply)
	ply.ls_skills_can_obtain = {}
	for k, v in pairs(ls_skills) do
		if not check_skill(k, ply) and can_obtain(k, ply) then
			table.insert(ply.ls_skills_can_obtain, k)
		end
	end
end

util.AddNetworkString('ls_skills')
util.AddNetworkString('ls_skills_effect')

if not sql.TableExists('ls_skills') then
	sql.Query('CREATE TABLE ls_skills (SteamID string, skill string)')
	PrintMessage(3, 'ls_skills reset')
end

timer.Create('ls_skills_check', 10, 0, function()
	for k, ply in ipairs(player.GetAll()) do
		if ply.ls_skills_can_obtain then
			for _, skill in ipairs(ply.ls_skills_can_obtain) do
				local skt = ls_skills[skill]
				local can = skt and skt.check
				if can and can(ply) then
					ply:AcquireSkill(skill)
				end
			end
		end
	end
end)

hook.Add('PlayerFullyLoaded', 'ls_skill', function(ply)
	ply.ls_skills = {}
	local t = sql.Query('SELECT * FROM ls_skills WHERE SteamID = ' .. SQLStr(ply:SteamID()))
	if t then
		for k, v in ipairs(t) do
			ply.ls_skills[v.skill] = true
			net.Start('ls_skills')
				net.WriteString(v.skill)
			net.Send(ply)
		end
	end

	update_all_obtainable_skills(ply)
end)

function meta:Achievement(s)
	if not check_skill(s, self) and can_obtain(s, self) then
		self:AcquireSkill(s)
	end
end

function meta:AcquireSkill(name)
	self.ls_skills = self.ls_skills or {}
	self.ls_skills[name] = true
	net.Start('ls_skills')
		net.WriteString(name)
	net.Send(self)

	local skill_table = ls_skills[name]

	net.Start('ls_skills_effect')
		net.WriteEntity(self)
	net.SendPVS(self:GetPos())
	
	sql.Query('INSERT INTO ls_skills (SteamID, skill) VALUES (' .. SQLStr(self:SteamID()) .. ', ' .. SQLStr(name) .. ')')

	GAMEMODE:ChatPrint(Color(255, 114, 167), '[Ачивки LampServ] ', self, color_white, ' получил ' .. (skill_table.reward_text or '1 поинт') .. ' за достижение "' .. name .. '"')

	if skill_table.reward then
		if isfunction(skill_table.reward) then
			skill_table.reward(self)
		end
	else
		default_reward(self)
	end

	update_all_obtainable_skills(self)
	
	if skill_table.got then
		skill_table.got(self)
	end

	hook.Call('PlayerGotSkill', GAMEMODE, self, name)
end

net.Receive('ls_skills', function(len, ply)
	local s = net.ReadString()
	if not check_skill(s, ply) and can_obtain(s, ply) then
		ply:AcquireSkill(s)
	end
end)

hook.Add('PlayerSpawn', 'ls_ach_values', function(p)
	if CLIENT and p != LocalPlayer() then return end
	
	local t = {}
	t.max_health = 100
	p.damage_melee_mul = 1
	p.damage_ranged_mul = 1
	
	if p.ls_skills then
		for sk, _ in pairs(p.ls_skills) do
			local spawn = ls_skills[sk] and ls_skills[sk].spawn
			
			if spawn then
				spawn(p)	
			end
		end
	end
end)

local melee = {
	['weapon_fists'] = true,
	['weapon_knife'] = true,
}

hook.Add("EntityTakeDamage", "EntityDamageExample", function(target, dmginfo)
	local att = dmginfo:GetAttacker()
	if att and IsValid(att) and att:IsPlayer() then
		
		local wep = dmginfo:GetInflictor()
		if IsValid(wep) then
			local melee = melee[wep:GetClass()]
			if melee then
				dmginfo:ScaleDamage(att.damage_melee_mul or 1)
			else
				dmginfo:ScaleDamage(att.damage_ranged_mul or 1)
			end
		end
	end
end)

local tag = 'Skills'

hook.Add('EntityTakeDamage', tag, function(target, dmg)
	local attacker = dmg:GetAttacker()

	if IsValid(attacker) and attacker:IsPlayer() and target and target:IsPlayer() then
		if target:IsStudent() and attacker:IsTeacher() then
			attacker:Achievement('Тиран')

			return
		end

		if (target:Team() == TEAM_GOODGUY or target:Team() == TEAM_GOODGIRL) and attacker:Team() == TEAM_HULIGAN then
			attacker:Achievement('Че, самый умный?')
		end
	end
end)

hook.Add('PlayerStartedTrashburner', tag, function(ent, ply)
	ply:Achievement('Гори, гори ясно!')
end)

hook.Add('PlayerStartedRecycler', tag, function(ent, ply) 
	ply:Achievement('До чего дошёл прогресс')
end)

hook.Add('WeaponEquip', tag, function(wep, ply)
	if wep:GetClass() == 'guitar' then
		ply:Achievement('Смелс лайк тин спирит')
	end
end)

stats = stats or {}

stats.ply_stats = stats.ply_stats or {}

function stats:AddStat(ply, stat)
	print('add_stat', ply, stat)

	self.ply_stats[ply] = self.ply_stats[ply] or {}
	self.ply_stats[ply][stat] = (self.ply_stats[ply][stat] or ply:GetPData(stat, 0)) + 1

	return self.ply_stats[ply][stat]
end

function stats:GetStat(ply, stat) 
	self.ply_stats[ply] = self.ply_stats[ply] or {}
	return self.ply_stats[ply][stat] or ply:GetPData(stat, 0)
end

function stats:EraseStat(ply, stat)
	self.ply_stats[ply] = self.ply_stats[ply] or {}
	self.ply_stats[ply][stat] = nil

	print('erase_stat', ply, stat)

	ply:RemovePData(stat)
end

timer.Create('stats_save', 600, 0, function()
	for i, ply in ipairs(player.GetAll()) do 
		if stats.ply_stats[ply] then
			for stat, count in pairs(stats.ply_stats[ply]) do 
				if v ~= 0 then
					ply:SetPData(stat, ply:GetPData(stat, 0) + count)
				end
			end
		end
	end
end)

hook.Add('PlayerDisconnected', 'Stats', function(ply)
	if stats.ply_stats[ply] then
		for stat, count in pairs(stats.ply_stats[ply]) do 
			if v ~= 0 then
				ply:SetPData(stat, ply:GetPData(stat, 0) + count)
			end
		end
	end

	stats.ply_stats[ply] = nil
end)

hook.Add('InitPostEntity', 'meh', function()
	local neutral_mark = {
		[TEAM_TEACHER_MATH] = {
			name = 'Сколько будет 2+2?', 
			stat = 'added_marks_math'
		},
		[TEAM_TEACHER_FOREIGN] = {
			name = 'Do ypu speak English?',
			stat = 'added_marks_foreign'
		},
		[TEAM_TEACHER_CHEM] = {
			name = 'H2O5OH',
			stat = 'added_marks_chem'
		},
		[TEAM_TEACHER_ICT] = {
			name = '1001110010',
			stat = 'added_marks_ict'
		},
		[TEAM_TEACHER_SPORT] = {
			name = 'Три кружочка вокруг школы',
			stat = 'added_marks_sport'
		},
		[TEAM_TEACHER_BIO] = {
			name = 'Флора и Фауна',
			stat = 'added_marks_bio'
		}
	}

	local good_mark = {
		[TEAM_TEACHER_MATH] = {
			name = 'Вот они, юные математики!', 
			stat = 'added_good_marks_math'
		},
		[TEAM_TEACHER_FOREIGN] = {
			name = 'Оу, вы из англии?',
			stat = 'added_good_marks_foreign'
		},
		[TEAM_TEACHER_CHEM] = {
			name = 'Менделеев, это ты?',
			stat = 'added_good_marks_chem'
		},
		[TEAM_TEACHER_ICT] = {
			name = 'Программистер',
			stat = 'added_good_marks_ict'
		},
		[TEAM_TEACHER_SPORT] = {
			name = 'Ай красавцы, ай молодцы!',
			stat = 'added_good_marks_sport'
		},
		[TEAM_TEACHER_BIO] = {
			name = 'Биологический отличник',
			stat = 'added_good_marks_bio'
		}
	}

	local bad_mark = {
		[TEAM_TEACHER_MATH] = {
			name = 'Из вас выйдет отличный гуманитарий!', 
			stat = 'added_bad_marks_math'
		},
		[TEAM_TEACHER_FOREIGN] = {
			name = 'Ya znay angliskii',
			stat = 'added_bad_marks_foreign'
		},
		[TEAM_TEACHER_CHEM] = {
			name = 'H - Водорд, O - Кислород, C - Углерод, Я - ....',
			stat = 'added_bad_marks_chem'
		},
		[TEAM_TEACHER_ICT] = {
			name = 'Bad coder',
			stat = 'added_bad_marks_ict'
		},
		[TEAM_TEACHER_SPORT] = {
			name = 'Может тебе вступить в клуб качков?',
			stat = 'added_bad_marks_sport'
		},
		[TEAM_TEACHER_BIO] = {
			name = 'В дворники так сильно хочешь?',
			stat = 'added_bad_marks_bio'
		}
	}
	
	local function teacher_mark_logic(teacher, table) 
		local team = teacher:Team()

		local tab = table[team]
		if tab then
			local stat = stats:AddStat(teacher, tab.stat)

			if stat >= 10 then
				teacher:Achievement(tab.name)
			end

			return stat
		else
			print('skill_hooks no teacher table', teacher:GetJobTable().name)
			return 0
		end
	end

	local student_good_mark = {
		'Мама будет рада!',
		'Обожаю уроки',
		'Я умный, делаю все правильно!'
	}

	local student_bad_mark = {
		'Не может быть...',
		'Ну и что?',
		'Да хоть 100!'
	}

	local function student_mark_logic(student, table, stat) 
		local marks = stats:AddStat(student, stat)

		student:Achievement(table[1])

		if marks >= 5 then
			student:Achievement(table[2])
		end

		if marks >= 15 then
			student:Achievement(table[3])
		end

		return marks
	end

	hook.Add('PlayerAddedMark', tag, function(teacher, student, mark)
		local teacher_marks = teacher_mark_logic(teacher, neutral_mark)
		local student_marks = stats:AddStat(student, 'got_marks')

		student:Achievement('А вот и первая оценка')

		if student_marks >= 45 then
			student:Achievement('Скорее бы получить оценку')
		end

		if teacher_marks >= 30 then
			teacher:Achievement('Оценки получат все!')
		end

		if mark == 5 then
			teacher_mark_logic(teacher, good_mark)
			local good_student_marks = student_mark_logic(student, student_good_mark, 'got_good_marks')
			if good_student_marks >= 25 then
				student:Achievement('Это лучший день в моей жизни!!!')
			end
		end
		if mark == 2 then 
			teacher_mark_logic(teacher, bad_mark)
			student_mark_logic(student, student_bad_mark, 'got_bad_marks')

			for k, v in pairs(student.SchoolMarks) do 
				if not v:find('2') then
					return
				end
			end

			student:Achievement('Да мне плевать!')
		end

		local grade = student:GetGrade()
		if grade >= 3 then
			student:Achievement('Я уже в третьем классе!')
		end
		if grade >= 5 then
			student:Achievement('Обожаю эту цифру!')
		end
		if grade >= 9 then
			student:Achievement('Как же быстро летит время...')
		end
		if grade >= 12 then
			student:Achievement('Я буду скучать...')
		end

	end)

	hook.Add('PlayerUse', tag, function(ply, ent)
		--print(ply,ent)

		if IsValid(ply) then
			local owner = ent.rp_owner

			if ent:GetClass():find('alcohol') then
				if owner and owner ~= ply and owner:Team() == TEAM_BARIGA then
					if stats:AddStat(owner, 'sold_beer') >= 10 then
						owner:Achievement('Крепкое или что-то полегче?')	
					end

					if ply:IsTeacher() then
						ply:Achievement('Плохой учитель')
						owner:Achievement('Учитель, не хотите расслабиться?')
						return
					end
					if ply:Team() == TEAM_DIRECTOR then
						ply:Achievement('Пока никто не видит...')
						owner:Achievement('Всякое бывает...')
						return
					end
					if ply:Team() == TEAM_HULIGAN then
						ply:Achievement('Вот оно, жидкое золото')

						if ply:IsInClass() and GetCurrentSchoolSubject() then
							ply:Achievement('Сяду на заднюю парту и...')	
						end
					end
				end
			end

			if ent:GetClass():find('synthesizer') and ply:Team() == TEAM_CLUBMEMBER_MUSIC then
				ply:Achievement('Синтезатор - круто')
			end

			if ent:GetClass() == 'instrument_drum' and ply:Team() == TEAM_CLUBMEMBER_MUSIC then
				ply:Achievement('Бадабум туц тыщ ц')
			end

			if ent:GetClass() == 'security_cams' and ply:Team() == TEAM_DIRECTOR then
				ply:Achievement('Так так, что тут у нас')
			end

			if ent:GetClass() == 'spawned_shipment' and ent.wepclass and ent.wepclass:find('weapon_ciga') and owner and owner ~= ply then
				ply:Achievement('А ну ка, что тут у нас')
				owner:Achievement('У меня самый лучший табак')
			end
		end
	end)

	hook.Add('PlayerUnArrested', tag, function(ply, unarrester)
		if unarrester then
			if stats:AddStat(unarrester, 'unarrested') >= 5 then
				unarrester:Achievement('Вы свободны...')
			end
		end	
	end)

	hook.Add('PlayerArrested', tag, function(ply, arrester)
		if IsValid(arrester) then
			if arrester:Team() == TEAM_POLICE or TEAM_POLICE_CHIEF then
				local stat = stats:AddStat(arrester, 'arrested')
				
				if stat >= 10 then
					arrester:Achievement('Вы арестованы!')
				end

				if stat >= 15 then
					arrester:Achievement('Нарушил - неси ответственность!')
				end
			end

			if arrester:Team() == TEAM_HALFDIRECTOR then 
				if stats:AddStat(arrester, 'badboys_arrested') >= 5 then
					arrester:Achievement('Лучше бы взялись за ум')
				end
			end
		end

		if IsValid(ply) and ply:IsStudent() then
			ply:Achievement('А как же мать?')
		end
	end)

	hook.Add('PlayerTased', tag, function(ply, taserman)
		local stat = stats:AddStat(taserman, 'tased')

		if stat >= 4 then
			taserman:Achievement('Не двигаться!')
		end

		if stat >= 15 then
			taserman:Achievement('Далеко собрался?')
		end
	end)

	hook.Add('PlayerWanted', tag, function(ply, police) 
		if police then
			if stats:AddStat(police, 'wanted') >= 5 then
				police:Achievement('Розыскивается преступник...')
			end
		end

		if ply:IsStudent() then
			ply:Achievement('Допрыгался...')
		end
	end)

	hook.Add('PlayerBroadcast', tag, function(ply)
		ply:Achievement('Прямой эфир с мэром города')
	end)

	hook.Add('PlayerStartedLottery', tag, function(ply)
		if stats:AddStat(ply, 'started_lottery') >= 5 then
			ply:Achievement('Кому же повезет?')
		end
	end)

	hook.Add('OnPlayerDemoted', tag, function(demoter, ply)
		if IsValid(ply) and IsValid(demoter) and ply:IsTeacher() and demoter:Team() == TEAM_DIRECTOR then
			ply:Achievement('Ужасный учитель')

			if stats:AddStat(demoter, 'demoted_teachers') >= 5 then
				demoter:Achievement('Такие работники нам не нужны!')
			end
		end	
	end)

	hook.Add('playerBoughtCustomEntity', tag, function(ply, tab, ent)
		if ply:Team() == TEAM_DIRECTOR then
			if ent:GetClass() == 'maxmol_notebook' then
				stats:AddStat(ply, 'bought_notebooks')
			end

			if ent:GetClass() == 'lrp_tv' then
				stats:AddStat(ply, 'bought_tvs')
			end

			if stats:GetStat(ply, 'bought_notebooks') >= 5 and stats:GetStat(ply, 'bought_tvs') then
				ply:Achievement('А зачем им телевизор?')
			end
		end

		if ent:GetClass():find('bitminer') then
			ply:Achievement('Не могу найти работу, что же делать...')
		end
	end)

	hook.Add('PlayerUseDumbbell', tag, function(ply) 
		local stat = stats:AddStat(ply, 'use_dumbbell')
		if stat >= 100 then
			ply:Achievement('Рабочий кран')
		end
		if stat >= 250 then
			ply:Achievement('Еще пару подходиков...')
		end
		if stat >= 400 then
			ply:Achievement('Я - машина')
		end
	end)

	hook.Add('PlayerMadeFood', tag, function(ent, food, ply)
		local owner = ent.rp_owner

		if owner and owner:Team() == TEAM_COOK and ply ~= owner and stats:AddStat(owner, 'sold_food') >= 10 then
			owner:Achievement('Ну как? Вкусно?')
		end
	end)

	hook.Add('PlayerGotPoisoned', tag, function(ent, ply) 
		local owner = ent.rp_owner
		if owner and owner ~= ply and owner:Team() == TEAM_COOK then
			owner:Achievement('Может он дома что-то не то съел')
		end
	end)
end)

-- override instrument_drum hooks
timer.Simple(60, function()
	local function hookchair(ply, ent)
		local inst = ent:GetOwner()

		if IsValid(inst) and inst.Base == 'gmt_instrument_base' then
			if not IsValid(inst.Owner) then
				inst:AddOwner(ply)
				return true
			else
				if inst.Owner == ply then
					return true
				end
			end

			return false
		end
	end

	hook.Add('CanPlayerEnterVehicle', 'InstrumentChairHook', hookchair)
	hook.Add('PlayerUse', 'InstrumentChairModelHook', hookchair)
end)