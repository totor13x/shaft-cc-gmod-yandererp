hook.Add('PlayerSalary', 'StudentSalary', function(ply, money)
	if not ply:IsStudent() then return money end

	local marks = ply.last_marks
	
	if marks then
		for i = 1, #marks do
			local t = marks[i]

			if not t then
				continue
			end

			if t < CurTime() - 7200 then
				table.remove(marks, i)
				i = i - 1
			end
		end
	end

	local attendance = marks and #marks or 0

	if attendance < 0.25 then
		GAMEMODE:Error(ply, "Вы не получили денег от родителей, потому что не ходите на уроки и не получаете оценки")
		return true
	elseif attendance < 0.5 then 
		GAMEMODE:Error(ply, "Вы получили только половину карманных денег, потому что прогуляли 50% занятий")
		return money * 0.5
	end
end)

hook.Add('OnPlayerChangedTeam', 'ZombieTimer', function(ply, _, tm)
	if tm == TEAM_DOG then
		ply:ConCommand('darkrp unownalldoors') // yes fuck me i kno u can block dis shit
	end

	if tm == TEAM_ADMIN then
		--ply:SendLua('gui.OpenURL("https://lampserv.org/stafflist_yan.php")')
	end
end)

hook.Add('playerBuyDoor', 'CantBuyDoor', function(ply)
	local tm = ply:Team()
	if tm == TEAM_DOG then
		return false, 'Ты не можешь покупать двери'
	end
end)

hook.Add('PlayerCanPickupWeapon', 'SpecialTeamsWeaponsDisallow', function(ply, wep)
	if ply:IsSuperAdmin() then return true end
	if ply:Team() == TEAM_DOG and wep:GetClass() ~= 'bark' then
		return false
	end
end)

hook.Add('OnPlayerChangedTeam', 'AdminGod', function(ply, old, new)
	if old == TEAM_ADMIN then
		ply:GodDisable()	
	end
end)

timer.Create('AdminGod', 5, 0, function()
	for _, p in ipairs(player.GetAll()) do
		if p:Team() == TEAM_ADMIN then
			p:GodEnable()
			p:SetHealth(p:GetMaxHealth())
			p:SetCSVar('Hunger', 100)
		end
	end
end)