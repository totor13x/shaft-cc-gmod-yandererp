local canuse = function(ply)
	return ply:GetUserAccess() >= 2
end

LS_AdminEvent = false

concommand.Add('event_start', function(p, cmd, args, str)
	if not canuse(p) then
		p:ChatPrint('[LS Events] Вы не можете проводить эвенты!')
		return
	end
	
	if LS_AdminEvent then
		p:ChatPrint('[LS Events] Идет другой ивент!')
		return
	end
	
	if not str or string.len(str) < 1 then
		p:ChatPrint('[LS Events] Вы не ввели название!')
		return
	end
	
	LS_AdminEvent = {name = str, pos = p:GetPos(), tp = true}
	
	GAMEMODE:ChatPrint(Color(139, 0, 255), '[LS Events] ', color_white, p:GetName() .. ' запсутил эвент "' .. str .. '"\nНапиши "go" в консоль или "/go" в чат, чтобы попасть на него. У тебя 60 секунд!')
	
	GAMEMODE:PlaySound('music/stingers/industrial_suspense2.wav')
	
	timer.Create('LS_AdminEvent', 60, 1, function()
		if LS_AdminEvent then 
			LS_AdminEvent.tp = false
			GAMEMODE:ChatPrint(Color(139, 0, 255), '[LS Events] ', color_white, 'Команда go больше не работает!')
		end
	end)

	GAMEMODE:DiscordEmbed({
		title = '**Запущен ивент**',
		color = 10181046,
		description = str,
		}, 'events', p)
end)

hook.Add('PostGamemodeLoaded', 'go', function()
	GAMEMODE:AddCommand("go", function(ply)
		ply:ConCommand('go')
	end)
end)

concommand.Add('event_end', function(p, cmd, args, str)
	if not canuse(p) then
		p:ChatPrint('[LS Events] You can not end events!')
		return
	end
	
	if not LS_AdminEvent then
		p:ChatPrint('[LS Events] There are no events going!')
		return
	end
	
	GAMEMODE:ChatPrint(Color(139, 0, 255), '[LS Events] ', color_white, p:GetName() ..' закончил эвент ' .. LS_AdminEvent.name .. '.')
	
	timer.Remove('LS_AdminEvent')
	
	LS_AdminEvent = false

	for _, v in ipairs(player.GetAll()) do
		if v.isonevent then
			local sp, pos = hook.Run('PlayerSelectSpawn', v)
			if pos then v:SetPos(pos) end
			v.isonevent = nil
		end
	end
end)

concommand.Add('go', function(p, cmd, args, str)
	if not LS_AdminEvent or not LS_AdminEvent.tp then
		p:ChatPrint('[LS Events] Сейчас не проводится эвент!')
		return
	end
	
	p:SetPos(LS_AdminEvent.pos)
	p.isonevent = true
end)

hook.Add('PlayerDeath', 'admin_events', function(ply)
	ply.isonevent = nil
end)