-- we use a cache file so that all workshop addons are added without delay
if file.Exists('collection_items.txt', 'DATA') then
	for k, v in pairs(util.JSONToTable(file.Read('collection_items.txt'))) do
		resource.AddWorkshop(v)
	end
end

-- find all addons in the collection, add them and save into a file
http.Fetch("https://steamcommunity.com/sharedfiles/filedetails/?id=1084999080", function(page)
	local tbl = {}
	for k in page:gmatch([[<div id="sharedfile_(.-)" class="collectionItem">]]) do
		resource.AddWorkshop(k)
		table.insert(tbl, k)
	end

	file.Write('collection_items.txt', util.TableToJSON(tbl))
end)

resource.AddFile('sound/lampoviy_server/tip.ogg')
resource.AddFile('sound/lampoviy_server/winner.ogg')

resource.AddFile('resource/fonts/nunito.ttf')
resource.AddFile('resource/fonts/nunitob.ttf')