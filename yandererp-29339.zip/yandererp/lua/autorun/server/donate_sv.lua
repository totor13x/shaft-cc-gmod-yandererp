if not file.Exists('ls_donate_qiwi_transactions.txt', 'DATA') then
	file.Write('ls_donate_qiwi_transactions.txt', '1;2;3;4;5;6;7;8;9;10;11;12;13;14;15;16;17;18;19;20;')	
end

if not sql.TableExists('ls_shop_log') then
	sql.Query('CREATE TABLE ls_shop_log (SteamID string, Item string, Money int, Time int)')
end

function shoplog(steamid, item, money)
	sql.Query('INSERT INTO ls_shop_log(SteamID, Item, Money, Time) VALUES ("' .. steamid.. '", "' .. item .. '", ' .. money .. ', ' .. os.time() .. ')')
end

util.AddNetworkString('ls_shop_buy')
util.AddNetworkString('ls_shop_update')
util.AddNetworkString('ls_shop_notify')

local meta = FindMetaTable('Player')

function meta:GetPifs()
	if not self.ls_shop_pifs then
		self.ls_shop_pifs = tonumber(self:GetPData('ls_shop_pifs', 0))	
	end
	
	return self.ls_shop_pifs
end

function meta:SetPifs(n)
	self:SetPData('ls_shop_pifs', n)
	self.ls_shop_pifs = n
	
	net.Start('ls_shop_update')
		net.WriteInt(n, 16)
	net.Send(self)
end

function meta:AddPifs(n)
	self:SetPifs(self:GetPifs() + n)	
end

net.Receive('ls_shop_buy', function(len, ply)
	local code = net.ReadString()
	
	local v
	for _, t in pairs(ls_donate.items) do
		if t.code == code then
			v = t
			break
		end
	end
	
	if not v then print('[LS Donate] ' .. ply:SteamID() .. ' tried invalid item code!') return end
	
	local some = 1
	local par
	
	if v.info == 'num' then some = net.ReadInt(16) end
	if v.info == 'text' then par = net.ReadString() end
	
	if ply:GetPifs() < v.price * some or some < 1 then
		ply:ChatPrint('У вас недостаточно ' .. ls_donate.currency_ru[3] .. '!')--mL('У вас недостаточно ' .. ls_donate.currency_ru[3] .. '!', 'You don\'t have enough ' .. ls_donate.currency_en[2] .. '!'))
		--print('[LS Donate] ' .. ply:SteamID() .. ' запросил покупку на невозможную стоимость! Позовите махмола!') 
		return
	end

	if v.one then
		if sql.QueryValue('SELECT * FROM ls_shop_log WHERE SteamID = "' .. ply:SteamID() .. '" AND Item = "' .. v.code ..  '"') then
			ply:ChatPrint('Вы можете получить ' .. v.name .. ' только один раз!')
			return
		end
	end
	
	ply:AddPifs(-v.price * some)
	v.func(ply, par and par or some)
	shoplog(ply:SteamID(), code .. (some != 1 and ': ' .. some or ''), -v.price * some)
	
	net.Start('ls_shop_notify')
		net.WriteEntity(ply)
		net.WriteString(v.name)
		net.WriteInt(some, 16)
	net.Broadcast()
end)

hook.Add('PlayerInitialSpawn', 'UpdatePifsOnLoad', function(ply)
	timer.Simple(20, function() ply:SetPifs(ply:GetPifs()) end)
end)

for k, ply in ipairs(player.GetAll()) do
	ply:SetPifs(ply:GetPifs())
end

local http_Fetch = http.Fetch
timer.Create('ls_shop_update_qiwi', 60, 0, function()
	local rows = 5
	http_Fetch('https://edge.qiwi.com/payment-history/v1/persons/+7свойномер/payments?rows=' .. rows .. '&operation=IN', function(html)
		local t = util.JSONToTable(html)
		local file_cont = file.Read('ls_donate_qiwi_transactions.txt') or ''
		for i = 1, #t.data do
			local amt = math.floor(tonumber(t.data[i].total.amount))
			local cmt = t.data[i].comment and string.Replace(t.data[i].comment, ' ', '') or '0'
			if cmt:len() < 2 then cmt = '0' end
			local id = t.data[i].txnId

			if table.HasValue(string.Split(file_cont, ';'), tostring(id)) then
				continue
			end

			if tonumber(t.data[i].total.currency) != 643 then
				for _, p in ipairs(player.GetAll()) do
					if ls_donate.code == cmt:GetChar(1) and tonumber(p:UniqueID()) == tonumber(string.sub(cmt, 2)) then
						shoplog(p:SteamID(), "Error: Qiwi Invalid Currency! (" .. t.data[i].total.currency .. ')', amt)
						file.Append('ls_donate_qiwi_transactions.txt', id .. ';')
						file_cont = file.Read('ls_donate_qiwi_transactions.txt')
						if file_cont:len() > 150 then file.Write('ls_donate_qiwi_transactions.txt', file_cont:sub(file_cont:find(';') + 1)) end
						break
					end
				end
				continue
			end
			
			for _, p in ipairs(player.GetAll()) do
				if ls_donate.code == cmt:GetChar(1) and tonumber(p:UniqueID()) == tonumber(string.sub(cmt, 2)) then
					file.Append('ls_donate_qiwi_transactions.txt', id .. ';')
					file_cont = file.Read('ls_donate_qiwi_transactions.txt')
					if file_cont:len() > 150 then file.Write('ls_donate_qiwi_transactions.txt', file_cont:sub(file_cont:find(';') + 1)) end
					p:AddPifs(amt)
					shoplog(p:SteamID(), "Qiwi: " .. t.data[i].account, amt)
					p:ChatPrint("[LS Donate] ", Color(0, 200, 200), 'Ваш баланс пополнен!')
					if IsValid(LS_DonateTree) then LS_DonateTree:AddMoney(amt) end
					
					break
				end
			end
		end
	end, function(err)
		print('[LS Donate] Qiwi Error: ' .. err)
	end, {
		['authorization'] = 'Bearer кивитокен'
	})
end)

util.AddNetworkString("ls_shop_log")

net.Receive('ls_shop_log', function(len, ply)
	local par = net.ReadInt(4)
	if ls_donate.access(ply) then
		net.Start('ls_shop_log')
			local q
			if par == 2 or par == 4 then
				q = sql.Query('SELECT * FROM ls_shop_log WHERE Money > 0 ORDER BY Time DESC LIMIT 200')
			elseif par == 3 then
				q = sql.Query('SELECT * FROM ls_shop_log WHERE Money < 0 ORDER BY Time DESC LIMIT 200')
			else
				q = sql.Query('SELECT * FROM ls_shop_log ORDER BY Time DESC LIMIT 200')
			end
			
			net.WriteTable(q)
			net.WriteInt(par, 4)
		net.Send(ply)
	end
end)

file.CreateDir('yandex')

timer.Create('YANDEX_CHECK_DONATE', 30, 0, function()
	http_Fetch('привязан к сайту' .. ls_donate.code, function(t)
		if t != '0' then
			local a = string.Explode(':', t)
			
			local s = 0
			if file.Exists('yandex/' .. a[1], 'DATA') then
				s = s + (tonumber(file.Read('yandex/' .. a[1] .. '.txt', 'DATA')) or 0)
			end
			
			file.Write('yandex/' .. a[1] .. '.txt', s + (tonumber(a[2]) or 0))
		end
	end)

	for _, p in ipairs(player.GetAll()) do
		local filen = 'yandex/' .. ls_donate.code .. p:UniqueID() .. '.txt'
		if file.Exists(filen, 'DATA') then
			local amt = tonumber(file.Read(filen, 'DATA'))
			p:AddPifs(amt)
			file.Delete(filen)
			file.Delete(filen:lower())
			shoplog(p:SteamID(), "Yandex", amt)
			GAMEMODE:ChatPrintTo(p, Color(0, 200, 200), "[LS Donate] ", color_white, 'Ваш баланс пополнен!')
			if IsValid(LS_DonateTree) then LS_DonateTree:AddMoney(amt) end
			break
		end
	end
end)

local topdonaters = {}
local filled = false
local updatedonaters = function()
	local total = {}
	local q = sql.Query('SELECT * FROM ls_shop_log WHERE Item = "Qiwi" or Item = "Yandex"')
	if q then
		for k, v in ipairs(q) do
			total[v.SteamID] = total[v.SteamID] or 0
			total[v.SteamID] = total[v.SteamID] + v.Money
		end
	end

	local sorted = {}
	for k, v in pairs(total) do
		table.insert(sorted, {k, v})
	end

	table.SortByMember(sorted, 2)
	for i = 1, 5 do
		local t = sorted[i]
		http.Fetch('https://steamcommunity.com/profiles/' .. util.SteamIDTo64(t[1]) .. '/?xml=1', function(xml)
			local _, namestart = string.find(xml, '<steamID>')
			local nameend = string.find(xml, '</steamID>')
			if namestart and nameend then
				local name = string.sub(xml, namestart + 10, nameend - 4)
				topdonaters[i][1] = name
			end

			filled = true
		end)
		
		topdonaters[i] = t
	end
end

hook.Add('PlayerInitialSpawn', 'receivetopdonaters', function()
	if not filled then
		updatedonaters()
	end
end)
if GAMEMODE then
	updatedonaters()
end

util.AddNetworkString('topdonaters')
hook.Add('PlayerFullyLoaded', 'SendTopDonaters', function(ply)
	net.Start('topdonaters')
		net.WriteTable(topdonaters)
	net.Send(ply)
end)