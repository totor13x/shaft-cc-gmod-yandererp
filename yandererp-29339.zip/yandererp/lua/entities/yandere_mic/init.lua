include 'shared.lua'

AddCSLuaFile 'shared.lua'
AddCSLuaFile 'cl_init.lua'

local speaker

function ENT:Use(_, ply, sig)
	if sig == USE_ON then
		speaker = ply
		ply:SendLua([[LocalPlayer():ConCommand('+voicerecord')]])
	elseif sig == USE_OFF and IsValid(speaker) then
		ply:SendLua([[LocalPlayer():ConCommand('-voicerecord')]])
		speaker = nil
	end
end

function ENT:Think()
	if IsValid(speaker) and speaker:GetPos():DistToSqr(self:GetPos()) > 65536 then
		speaker:SendLua([[LocalPlayer():ConCommand('-voicerecord')]])
		speaker = nil
	end
end

hook.Add("PlayerCanHearPlayersVoice", "yandere_mic", function(listener, talker)
	if speaker == talker then
		return true, false
	end
end)

function ENT:Initialize()
	self:SetModel('models/nomad/genericmic.mdl')
	self:PhysicsInitBox(Vector(-10, -10, -10), Vector(10, 10, 10))
	timer.Simple(2, function()
		self:PhysicsInitBox(Vector(-10, -10, -10), Vector(10, 10, 10))
		self:GetPhysicsObject():EnableMotion(false)
		self:SetMoveType(MOVETYPE_NONE)
	end)

	self:SetUseType(ONOFF_USE)
end