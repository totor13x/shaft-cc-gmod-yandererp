include 'shared.lua'

function ENT:RPHUDDraw()
	return {"Yandere Объявлятор", "Нажми E чтобы сделать объявление"}
end