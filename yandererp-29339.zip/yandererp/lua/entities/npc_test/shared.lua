ENT.Base = 'npc_base'
ENT.Type = 'ai'
ENT.PrintName = 'Тестовый NPC'
ENT.SpawnPoint = Vector(-2830, -4184, 45)

local function testfunc(self, faggot, ent)
	local bought_ent = ents.Create(self.class)
	if self.model then
		bought_ent:SetModel(self.model)
	end
	bought_ent:PhysicsInit(SOLID_VPHYSICS)
	bought_ent:SetPos(ent.SpawnPoint)
	bought_ent:Spawn()
end

ENT.Items = {
	{
		name = 'Пример',
		price = 50,
		class = 'prop_physics',
		model = 'models/props_borealis/bluebarrel001.mdl',
		buy = testfunc
	},
		{
		name = 'Пример1',
		price = 50,
		class = 'prop_physics',
		model = 'models/props_borealis/bluebarrel001.mdl',
		buy = testfunc
	},
		{
		name = 'Пример2',
		price = 50,
		class = 'prop_physics',
		model = 'models/props_borealis/bluebarrel001.mdl',
		buy = testfunc
	},
		{
		name = 'Пример3',
		price = 50,
		class = 'prop_physics',
		model = 'models/props_borealis/bluebarrel001.mdl',
		buy = testfunc
	},
		{
		name = 'Пример4',
		price = 50,
		class = 'prop_physics',
		model = 'models/props_borealis/bluebarrel001.mdl',
		buy = testfunc
	},
		{
		name = 'Пример5',
		price = 50,
		class = 'prop_physics',
		model = 'models/props_borealis/bluebarrel001.mdl',
		buy = testfunc
	},
		{
		name = 'Пример6',
		price = 50,
		class = 'prop_physics',
		model = 'models/props_borealis/bluebarrel001.mdl',
		buy = testfunc
	},
}