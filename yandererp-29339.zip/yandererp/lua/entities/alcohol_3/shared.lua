AddCSLuaFile()

ENT.Base = "alcohol"
ENT.Model = 'models/props_interiors/bottles_shelf_break09.mdl'
ENT.Strength = 3