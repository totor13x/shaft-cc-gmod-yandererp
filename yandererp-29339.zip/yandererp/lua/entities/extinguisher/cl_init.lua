include('shared.lua')

function ENT:RPHUDDraw()
	return {'Огнетушитель', 'Нажми Е чтобы взять в руки'}
end
