ENT.Type = 'anim'
ENT.Base = 'base_anim'
ENT.PrintName = 'Огнетушитель'
ENT.Spawnable = true
