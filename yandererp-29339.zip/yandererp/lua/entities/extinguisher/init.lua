include('shared.lua')

AddCSLuaFile('shared.lua')
AddCSLuaFile('cl_init.lua')

ENT.Delay = 60

function ENT:Initialize()
	self:SetModel('models/weapons/w_fire_extinguisher.mdl')
	self:SetUseType(SIMPLE_USE)
	self:PhysicsInit(SOLID_VPHYSICS)
	self:GetPhysicsObject():EnableMotion(false)
end

function ENT:Use(ply)
	local fire_ents = ents.FindByClass('vfire')
	
	for i, fire in ipairs(fire_ents) do 
		if fire:GetPos():DistToSqr(self:GetPos()) < 1500000 and not ply:HasWeapon('weapon_extinguisher') then
				local wep = ply:Give('weapon_extinguisher')
				function wep:Holster()
					self:Remove()
				end

				ply:SelectWeapon(wep:GetClass())

				local pos = self:GetPos()
				local ang = self:GetAngles()
				local class = self:GetClass()

				SafeRemoveEntity(self)

				timer.Simple(self.Delay / 2, function()
					local ent = ents.Create(class)
					ent:SetPos(pos)
					ent:SetAngles(ang)
					ent:Spawn()
					ent:Activate()
				end)

				timer.Simple(self.Delay, function()
					if IsValid(wep) then
						ply:StripWeapon(wep:GetClass())
					end
				end)
	
			return	
		end
	end

	GAMEMODE:Error(ply, 'Рядом нет пожара!')
end

hook.Add('canDropWeapon', 'Extinguisher', function(ply, wep)
	if wep:GetClass() == 'weapon_extinguisher' then
		return false
	end
end)
