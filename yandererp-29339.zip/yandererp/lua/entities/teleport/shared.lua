ENT.Type = 'anim'
ENT.Base = 'base_anim'

ENT.Spawnable = false
ENT.AdminSpawnable = false

ENT.Model = 'models/props_lab/hev_case.mdl'

function ENT:SetupDataTables() 
	self:NetworkVar('Bool', 0, 'Enabled')
end