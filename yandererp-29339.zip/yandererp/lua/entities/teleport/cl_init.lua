include 'shared.lua'

function ENT:Initialize()
	self.Pos = self:WorldSpaceCenter()
	self.Forward = self:GetForward()
	self.IndicatorPos = self.Pos + self:GetUp() * 37 + self.Forward * 23.5
	self.ThingyPos = self.Pos + self.Forward * 10
end

local glow = Material('sprites/light_glow02_add')
local heat = Material('sprites/heatwave')
local dunno = Material('sprites/redglow1')//Material('sprites/gmdm_pickups/light')//Material('sprites/orangeflare1')

local e = FindMetaTable('Entity')
local DrawModel, GetPos = e.DrawModel, e.GetPos
local ColorMaterial, QuadEasy, SetMaterial, Sprite = render.SetColorMaterial, render.DrawQuadEasy, render.SetMaterial, render.DrawSprite

function ENT:Draw()
	DrawModel(self)

	if GetPos(LocalPlayer()):DistToSqr(GetPos(self)) > 570025 then return end

	local enb = self:GetEnabled()
	local col = Color(not enb and 255 or 0, enb and 255 or 0, 0)
	
	ColorMaterial()
	QuadEasy(self.IndicatorPos, self.Forward, 5, 1, col)
		
	SetMaterial(glow)
	Sprite(self.IndicatorPos, 10, 5, col)
	
	if self:GetEnabled() then
		SetMaterial(dunno)
		Sprite(self.ThingyPos, 50, 100 + math.sin(CurTime()) * 50)
	
		SetMaterial(heat)
		Sprite(self.ThingyPos, 15, 35 + math.sin(CurTime() / 4) * 10)
	end
end