include 'shared.lua'

AddCSLuaFile 'shared.lua'
AddCSLuaFile 'cl_init.lua'

ENT.Cool = 0
ENT.AllowedTeams = {
	[TEAM_TEACHER_MATH] = true,
}

function ENT:Initialize()
	self:SetModel(self.Model)
	self:PhysicsInit(SOLID_VPHYSICS)
	self:GetPhysicsObject():EnableMotion(false)
	self:SetUseType(ONOFF_USE)
end

function ENT:Use(ent)
	if CurTime() - self.Cool > 10 and self.AllowedTeams[ent:Team()] then
		self:SetEnabled(not self:GetEnabled())
		self.Cool = CurTime()	
	end
end

local teslat = {
	{"m_SoundName", "DoSpark"},
	{"texture", "sprites/laserbeam.spr"},
	{"m_Color", "255 255 255"},
	{"m_flRadius", 100},
	{"beamcount_max", 4},
	{"thick_min", 1},
	{"thick_max", 2},
	{"lifetime_min", "0.1"},
	{"lifetime_max", "0.3"},
	{"interval_min", "0.1"},
	{"interval_max", "0.2"},
}

local function SpawnTesla(p)
	local tesla = ents.Create("point_tesla")
	tesla:SetPos(p)

	for k, v in ipairs(teslat) do
		tesla:SetKeyValue(v[1], v[2])
	end

	tesla:Spawn()

	timer.Simple(2, function() 
		tesla:Remove() 
	end)
	return tesla
end
--common/bass.wav
--ambient/atmosphere/garage_tone.wav -- loop
--vo/burp02.mp3
function ENT:Touch(ent)
	if self:GetEnabled() and ent:IsValid() --[[and ent:IsPlayer()]] then
		if ent:WorldSpaceCenter():WithinAABox(self:WorldSpaceCenter() - Vector(15, 15, 35), self:WorldSpaceCenter() + Vector(15, 15, 35)) then
			self:SetEnabled(false)
			self.Cool = CurTime() + 20

			local pos = GAMEMODE.RandomPosition(self, Vector(4491, -3324, 8), Vector(-1626, 4160, 364))

			ent:SetPos(pos)

			if ent:IsPlayer() then
				ent:EmitSound('vo/npc/male01/pain0'.. tostring(math.random(2, 8)) ..'.wav')
				ent:TakeDamage(math.random(10, 25))
				if math.random(10) == 1 then
					ent:Kill()
				end
			end
			
			for _, autism in ipairs({self, ent}) do
				local tesla = SpawnTesla(autism:WorldSpaceCenter())
				tesla:Fire('DoSpark', '', 0 )
				tesla:EmitSound('ambient/energy/ion_cannon_shot' .. math.random(1, 3) .. '.wav', 150, 50)
			end
		end
	end
end