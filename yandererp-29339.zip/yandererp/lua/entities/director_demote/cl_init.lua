include('shared.lua')

function ENT:RPHUDDraw()
	return {'Уволить учителя'}
end