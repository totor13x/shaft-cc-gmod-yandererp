include('shared.lua')

AddCSLuaFile('shared.lua')
AddCSLuaFile('cl_init.lua')

function ENT:CanDemote(ply)
	if ply:Team() == TEAM_DIRECTOR then
		return true
	end
end