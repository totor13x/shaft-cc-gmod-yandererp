ENT.Base = 'police_demote'
ENT.Tag = 'DirectorDemote'

function ENT:CanBeDemoted(ply) 
	if ply:IsTeacher() then 
		return true 
	end
end