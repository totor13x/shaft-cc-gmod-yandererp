AddCSLuaFile()

ENT.Base = "alcohol"
ENT.Model = 'models/props_interiors/bottles_shelf_break10.mdl'
ENT.Strength = 6