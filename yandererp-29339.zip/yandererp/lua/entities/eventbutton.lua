ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName		= "Event Button"

ENT.Spawnable = true
ENT.AdminSpawnable = true

ENT.Useable = true
ENT.StartedTimes = 0

function ENT:SetupDataTables( )
	self:NetworkVar( "Int", 0, "PushAmount" )
end

function ENT:Think()
	self.RequiredPushes = math.Clamp(math.Round(#player.GetAll() / 2), 2, 20)

	--if tonumber(os.date('%H', os.time())) == 2 and tonumber(os.date('%M', os.time())) == 58 and LS_GetCurrentEventName() != 'РЕСТАРТ' then
		--LS_SetEvent('РЕСТАРТ')
	---end
end

if ( SERVER ) then
	--AddCSLuaFile( )
	function ENT:Initialize( )
		self:SetModel( "models/maxofs2d/button_02.mdl" )
		self:PhysicsInit(SOLID_VPHYSICS)
		self:SetMoveType(MOVETYPE_VPHYSICS)
		self:SetSolid(SOLID_VPHYSICS)
		self:SetUseType( SIMPLE_USE )
		local physObj = self:GetPhysicsObject()
		if ( IsValid( physObj ) ) then
			physObj:Wake( )
			physObj:EnableMotion( false )
		end
	end

	function ENT:Use( ply )
		if not self.Useable then ply:PrintMessage(3, 'Кнопка слишком горячая! Погоди пока остынет.') return end
		self.playerButtonPushes = self.playerButtonPushes or { }
		local entIndex = self:EntIndex()
		if not ( self.playerButtonPushes[ ply:SteamID( ) ] ) then
			self.playerButtonPushes[ ply:SteamID( ) ] = CurTime( )
			self:SetPushAmount(self:GetPushAmount() + 1)
			GAMEMODE:ChatPrint(Color(255, 32, 64), '[Кнопка Событий] ', color_white, ply:Nick() .. ' нажал на Кнопку Событий')
			if ( self:GetPushAmount() >= self.RequiredPushes ) then
				ls_events:start(ls_events._[math.random(#ls_events._)].name)
				self.StartedTimes = self.StartedTimes + 1
				self.Useable = false
				timer.Create('EventButtonCoolDown', 3600, 1, function() self.Useable = true end)
				self.playerButtonPushes = { }
				self:SetPushAmount( 0 )
			else
				local reqAmt = self.RequiredPushes - self:GetPushAmount()
				GAMEMODE:ChatPrint(Color(255, 32, 64), '[Кнопка Событий] ', color_white, "Чтобы активировать случайное событие на Кнопку Событий должно нажать игроков: " .. reqAmt)
			end
		else
			GAMEMODE:ChatPrintTo(ply, Color(255, 32, 64), '[Кнопка Событий] ', color_white, 'Вы уже нажали на кнопку! Нужно, чтобы нажал кто-нибудь другой.')
		end
	end
else
	surface.CreateFont( "EventHeader", { font = "Tahoma", size = 45, weight = 750, antialiasing = true, blursize = 0 } )
	surface.CreateFont( "SmallHeader", { font = "Tahoma", size = 24, weight = 750, antialiasing = true, blursize = 0 } )

	function ENT:Initialize( )
		local minRenderBounds, maxRenderBounds = self:GetRenderBounds( )
		minRenderBounds:Mul( 5 )
		maxRenderBounds:Mul( 5 )
		self:SetRenderBounds( minRenderBounds, maxRenderBounds )
	end
	
	function ENT:Draw( flags )
		self:DrawModel( )

		if self:GetPos():DistToSqr(EyePos()) > 2000000 then return end
		
		local camPos = self:GetPos( )
		local camAng = self:GetAngles( )
		camPos = camPos + ( camAng:Up( ) * 2 ) + ( camAng:Right( ) * 60 ) + ( camAng:Forward( ) * 00)
		camAng:RotateAroundAxis( camAng:Right( ), 0 )
		camAng:RotateAroundAxis( camAng:Up( ), 0 )
		local progress = math.Round((self:GetPushAmount() / self.RequiredPushes) * 100) 
		local hsvcolor = HSVToColor((CurTime() * 150) % 360, 1, 1)
		cam.Start3D2D( camPos, camAng, 0.5 )
			draw.RoundedBox( 2, -10, -90, 20, 104, Color( 255, 255, 255, 255 ) )
			if progress > 0 then draw.RoundedBox( 2, -8, -88, 16, progress, hsvcolor) end
		cam.End3D2D( )
		camAng:RotateAroundAxis( camAng:Up( ), 180 )
		cam.Start3D2D( camPos, camAng, 0.3 )
			draw.SimpleText( "Кнопка Событий", "EventHeader", 0, -100, hsvcolor, TEXT_ALIGN_CENTER )
			--local currentEvent = LS_GetCurrentEventName() or "Никакое"
			-- CurEvent
			--draw.SimpleText( "Событие: " .. currentEvent, "SmallHeader", 0, -50, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER )
		cam.End3D2D( )
	end
end