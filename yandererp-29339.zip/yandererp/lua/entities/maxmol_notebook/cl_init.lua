include('shared.lua')

function ENT:RPHUDDraw()
	return {'Тетрадка', (IsValid(self:Getowning_ent()) and self:Getowning_ent():GetName() or ''), 'Нажми Е, чтобы открыть'}
end

net.Receive('WriteInNotebook', function()
	local ent = net.ReadEntity()
	
	local dframe = vgui.Create('DFrame')
	dframe:SetSize(420, 588)
	dframe:Center()
	dframe:SetTitle('Тетрадка')
	dframe.Paint = function(self, w, h)
		surface.SetDrawColor(Color(255, 68, 57))
		surface.DrawRect(0, 0, w, h)
	end
	
	local text = vgui.Create('DTextEntry', dframe)
	text:Dock(FILL)
	text:SetText(ent:GetBoardText())
	text:SetMultiline(true)
	if ent:Getowning_ent() != LocalPlayer() and not LocalPlayer():IsTeacher() then
		text:SetEnabled(false)
	end
	
	text.Paint = function(self, w, h)
		surface.SetDrawColor(color_white)
		surface.DrawRect(0, 0, w, h)
		
		local lineH = 14
		local curH = 0
		
		surface.SetDrawColor(Color(96, 96, 255))
		for i = 1, h/lineH do
			curH = curH + lineH
			
			surface.DrawLine(0, curH, w, curH)
		end
		
		surface.SetDrawColor(Color(255, 96, 96))
		surface.DrawLine(w - 30, 0, w - 30, h)
		
		self:DrawTextEntryText(color_black, Color(0, 0, 255), color_black)
	end
	text.OnChange = function()
		local val = text:GetValue()
		timer.Create('NotebookPreSend', 0.5, 1, function()
			if IsValid(ent) then
				net.Start('WriteInNotebook')
					net.WriteEntity(ent)
					net.WriteString(val)
				net.SendToServer()
			end
		end)
	end
	
	text.OnKeyCode = function(k)
		if k == KEY_ESCAPE then
			dframe:Close()
			dframe:Remove()
		end
	end
	
	dframe:MakePopup()
end)