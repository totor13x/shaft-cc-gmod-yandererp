AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

function ENT:Initialize()
	self:SetModel('models/school/notepad.mdl')
	
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)
	local physObj = self:GetPhysicsObject()
	if IsValid(physObj) then
		physObj:SetMass(50)
		physObj:Wake()
	end
	
	self:MakeBreakable({
		health = 50,
		nocolor = true,
	})
end

util.AddNetworkString('WriteInNotebook')
net.Receive('WriteInNotebook', function(_, ply)
	local ent = net.ReadEntity()
	local k = net.ReadString()
	
	if not IsValid(ent) or ent:GetClass() ~= 'maxmol_notebook' then
		return
	end
	
	if ent:GetPos():Distance(ply:GetShootPos()) > 500 then
		return
	end

	if ent:Getowning_ent() != ply and not ply:IsTeacher() then
		return
	end
	
	ent:SetBoardText(k)
end)

function ENT:Use(_, ply)
	if IsValid(ply) and ply:IsPlayer() then
		net.Start('WriteInNotebook')
			net.WriteEntity(self)
		net.Send(ply)
	end
end