ENT.PrintName = 'Notepad'
ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.Author = 'maxmol'

function ENT:SetupDataTables()
	self:NetworkVar('Entity', 0, 'owning_ent')
	self:NetworkVar('String', 0, 'BoardText')
end

hook.Add('InvItems', 'maxmol_notebook', function(items)
	items['maxmol_notebook'] = {
		perform = function(data)
			return {
				name = 'Тетрадка',
				model = "models/school/notepad.mdl"
			}
		end,
		getTable = function(e)
			local t = {
				BoardText = e:GetBoardText(),
			}

			return t
		end,
		spawn = function(data)
			local e = ents.Create('maxmol_notebook')
			e:SetBoardText(data.BoardText)
			
			return e
		end
	}
end)

hook.Add('canPocket', 'maxmol_notebook', function(ply, ent)
	if ent:GetClass() == 'maxmol_notebook' and ent.rp_owner != ply then
		ply:ChatPrint('Эта тетрадь не ваша!')
		return false
	end
end)