include('shared.lua')

function ENT:Think()
	if self.Sequence and self:GetSequence() ~= self.Sequence then
		self:SetSequence(self.Sequence)	
	end
	
	self:SetNextClientThink(CurTime() + 1)
end

function ENT:RPHUDDraw() 
	return {self.PrintName, 'Нажми Е чтобы открыть меню'}
end

function ENT:OpenMenu()
	local frame = vgui.Create('DFrame')
	frame:SetSize(512, math.min(600, #self.Items * 128 + 40))
	frame:Center()
	frame.btnMaxim:Hide()
	frame.btnMinim:Hide()
	frame:SetTitle(self.PrintName)
	frame:MakePopup()

	local dscroll = vgui.Create('DScrollPanel', frame)
	dscroll:Dock(FILL)

	for k, item in ipairs(self.Items) do
		local panel = dscroll:Add('DButton')
		panel:SetTall(128)
		panel:Dock(TOP)
		function panel:Paint(w, h)
			if self:IsDown() then
				surface.SetDrawColor(30, 30, 35, 255)
			elseif self:IsHovered() then
				surface.SetDrawColor(35, 35, 40, 255)
			else
				if k % 2 == 0 then
					surface.SetDrawColor(40, 40, 45, 255)
				else
					surface.SetDrawColor(45, 45, 50, 255)
				end
			end

			surface.DrawRect(0, 0, w, h)

			draw.SimpleText(item.name, "Trebuchet24", 64 + w/2, h * 0.3, Color(230, 230, 230, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			
			if item.price ~= 0 then
				draw.SimpleText(GAMEMODE.formatMoney(item.price), "schoolrp_schedule", 64 + w/2, h * 0.7, Color(230, 230, 230, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end

			return true
		end

		local ent_self = self

		function panel:DoClick()
			frame:Close()
			frame:Remove()

			net.Start('npc_buy')
			net.WriteEntity(ent_self)
			net.WriteInt(k, 8)
			net.SendToServer()
		end
	
	
		local model = vgui.Create('DModelPanel', panel)
		model:SetModel(item.model)
		model:SetSize(128, 128)
		local min, max = model.Entity:GetModelBounds()
		local campos = max * 4
		campos.z = max.z * 1.5 + 10
		model:SetCamPos(campos)
		model:SetLookAt(max + min)
		model:SetFOV(40)
		model:SetMouseInputEnabled(false)

		local old = model.Paint
		function model:Paint(w, h)
			surface.SetDrawColor(0, 0, 0, 64)
			surface.DrawRect(0, 0, w, h)
			old(self, w, h)
		end
	end
end

net.Receive("npc_openmenu", function()
	net.ReadEntity():OpenMenu() 
end)

net.Receive('npc_say', function()
	local e = net.ReadEntity()
	if IsValid(e) then
		e:Say(net.ReadString())
	end
end)

function ENT:Say(text)
	local add = {self.PrintName, color_white, ': ' .. text}
	
	EasyChat.AddText(EasyChat.GUI.RichText, Color(25, 128, 255), unpack(add))
	EasyChat.ChatHUD:AddText('<hsv=[t()*150 % 360]>', unpack(add))
end