include('shared.lua')

AddCSLuaFile('shared.lua')
AddCSLuaFile('cl_init.lua')

util.AddNetworkString("npc_openmenu")
util.AddNetworkString("npc_buy")

function ENT:Initialize()
	self:SetHullType(HULL_HUMAN)
	self:SetHullSizeNormal()
	self:SetSolid(SOLID_BBOX)

	self:CapabilitiesAdd( bit.bor(CAP_ANIMATEDFACE, CAP_TURN_HEAD))
	self:SetUseType(SIMPLE_USE)
	self:SetNPCState(NPC_STATE_IDLE)
	self:SetModel(self.Model)

	self:PhysicsInitBox(Vector(-15, -15, 0), Vector(15, 15, 75))

	self:SetAutomaticFrameAdvance( true )
	self:DropToFloor()
end

function ENT:Use(faggot)
	net.Start('npc_openmenu')
	net.WriteEntity(self)
	net.Send(faggot)
end

util.AddNetworkString('npc_say')
function ENT:Say(text, isall)
	local plys
	if not isall then
		plys = {}
		for k, ply in ipairs(player.GetAll()) do
			if ply:GetPos():DistToSqr(self:GetPos()) < 250000 then
				table.insert(plys, ply)
			end
		end
	end

	net.Start('npc_say')
		net.WriteEntity(self)
		net.WriteString(text)
	if isall then net.Broadcast()
	else net.Send(plys) end
end

function ENT:Think()
	if self.Sequence then
		local s = self:LookupSequence(self.Sequence)
		self:ResetSequence(s)
	end
	self:NextThink(CurTime() + 2)
	return true
end

net.Receive('npc_buy', function(l, ply) 
	local ent = net.ReadEntity()
	if ent.Base =='npc_base' then
		if ply:GetPos():Distance(ent:GetPos()) > 200 or not ply:Alive() then
			GAMEMODE:Error(ply, "not_allowed")
			return
		end
		
		if ent.CustomBuy then
			ent:CustomBuy(ply)
		else
			local item = ent.Items[net.ReadInt(8)]

			if item.canbuy and not item:canbuy(ply, ent) then
				GAMEMODE:Error(ply, {'cant_buy', item.name})
				return
			end

			if ply:CanAfford(item.price) then
				ply:AddMoney(-item.price)
				item:buy(ply, ent)
				GAMEMODE:Notify(ply, {'Вы купили %s', item.name})
			end
		end
	end
end)