ENT.Base = 'base_ai'
ENT.Type = 'ai'
ENT.RenderGroup = RENDERGROUP_TRANSLUCENT
ENT.PrintName = "Базовый NPC"
ENT.Model = 'models/odessa.mdl'
ENT.SpawnPoint = Vector(0, 0, 0)