AddCSLuaFile()

ENT.Base = "alcohol"
ENT.Model = 'models/props_lab/jar01b.mdl'
ENT.Strength = 0.5