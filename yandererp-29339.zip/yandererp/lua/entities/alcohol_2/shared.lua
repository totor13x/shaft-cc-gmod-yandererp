AddCSLuaFile()

ENT.Base = "alcohol"
ENT.Model = 'models/props_interiors/bottles_shelf_break05.mdl'
ENT.Strength = 2