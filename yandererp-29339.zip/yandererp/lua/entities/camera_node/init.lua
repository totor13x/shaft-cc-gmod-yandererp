include('shared.lua')

AddCSLuaFile('shared.lua')
AddCSLuaFile('cl_init.lua')

function ENT:Initialize()   
	self:SetMoveType( MOVETYPE_VPHYSICS )
	self:SetSolid( SOLID_NONE )
	self:PhysicsInitSphere(1)
	self:GetPhysicsObject():Wake()
	self:GetPhysicsObject():EnableCollisions( false )
	self:GetPhysicsObject():EnableGravity( false )
	self:GetPhysicsObject():EnableMotion( true )
	self:DrawShadow(false)
	self:SetNoDraw(true)
	self:SetNotSolid(true)
end