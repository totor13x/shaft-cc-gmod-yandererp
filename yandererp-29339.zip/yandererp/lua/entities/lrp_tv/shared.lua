ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "LS Television"
ENT.Author = "maxmol"
ENT.Spawnable = true
ENT.AdminSpawnable = true

LS_TVs = LS_TVs or {}

hook.Add('InitPostEntity', 'AddAllTVs', function()
	LS_TVs = ents.FindByClass('lrp_tv')
end)

timer.Create('superbidlo_lrptv_voice', 1, 0, function()
	local plys = player.GetAll()
	for _, ply in ipairs(plys) do
		ply.TVVoiceTo = {}
	end

	local cameraMan = GetGlobalEntity('CameraMan')

	local wep = IsValid(cameraMan) and cameraMan:GetActiveWeapon()
	if IsValid(wep) and wep:GetClass() == 'news_camera' then
		local from = {}

		for _, speaker in ipairs(plys) do
			if speaker:GetPos():DistToSqr(cameraMan:GetPos()) < 90000 then
				table.insert(from, speaker)
			end
		end

		local i = 1
		while i <= #LS_TVs do
			if not IsValid(LS_TVs[i]) then
				table.remove(LS_TVs, i)
			else
				i = i + 1
			end
		end

		for k, tv in ipairs(LS_TVs) do
			for _, ply in ipairs(plys) do
				if tv:GetPos():DistToSqr(ply:GetPos()) < 40000 then
					for _, speaker in ipairs(from) do
						speaker.TVVoiceTo[ply] = true
					end
				end	
			end
		end
	else
		for _, speaker in ipairs(plys) do speaker.TVVoiceTo = {} end
	end
end)

hook.Add('OnEntityCreated', 'LS_TVs_Add', function(ent)
	if ent:GetClass() == 'lrp_tv' then table.insert(LS_TVs, ent) end
end)