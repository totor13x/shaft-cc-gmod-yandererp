include('shared.lua')

surface.CreateFont("LRP_TV", {
	size = 31,
	weight = 500,
	antialias = true,
	shadow = false,
	font = 'Arial'
})

local recordMaterial = Material('gmod/recording.png')

function ENT:Draw( )
	
	self:DrawModel( )

	if self:GetPos():DistToSqr(EyePos()) > 250000 then return end
	
	local pos = self:LocalToWorld(Vector(6.05, -28, 35.5))
	local ang = self:LocalToWorldAngles(Angle(0, 90, 90))

	local CameraMan = GetGlobalEntity('CameraMan')
	
	cam.Start3D2D(pos, ang, 0.1)
		surface.SetDrawColor(Color(0, 0, 0))
		surface.DrawRect(0, 0, 570, 34)
	
		surface.SetFont("LRP_TV")
		surface.SetTextColor((IsValid(CameraMan) and Color(0, 255, 0) or Color(255, 0, 0)))
		surface.SetTextPos(12.5, 0)
		
		surface.SetMaterial(recordMaterial)
		surface.SetDrawColor(255, 255, 255)
		surface.DrawTexturedRect(-30, -20, 150, 75)
		
		if CurTime()%20 <= 10 and IsValid(CameraMan) then
			surface.SetTextPos(100, 0)
			surface.DrawText('Оператор: ' .. CameraMan:GetName())
		else
			surface.SetTextPos(100, 0)
			surface.DrawText('Трансляция: ' .. (IsValid(CameraMan) and '[ОНЛАЙН]' or '[ОФФЛАЙН]'))
		end
		
		surface.SetTextColor(255, 255, 0)
		local i = 1
		for k, v in pairs(player.GetAll()) do
			if v.TVVoiceTo and v.TVVoiceTo[LocalPlayer()] and v:IsSpeaking() then
				surface.SetTextPos(10, 35 + i*25)
				surface.DrawText(v:GetName())
				i = i + 1
			end
		end
	
		if i > 1 then
			surface.SetTextPos(10, 35)
			surface.DrawText('Говорят:')
		end
	cam.End3D2D()
	
end

net.Receive('lrp_tv_sendmsg', function()
	local ply = net.ReadEntity()
	local msg = net.ReadString()
	if not msg or msg == '' then return end
	chat.AddText(Color(255, 255, 0), '[LS Television] ', team.GetColor(ply:Team()), ply:GetName(), color_white, ': ' .. msg)
end)