include('shared.lua')

AddCSLuaFile('shared.lua')
AddCSLuaFile('cl_init.lua')

util.AddNetworkString('lrp_tv_sendmsg')
hook.Add('PostPlayerSay', 'LRP_TV_Broadcast', function(speaker, text, isTeam, dead)
	local cameraEnt = GetGlobalEntity('CameraMan').cameraent
	if not isTeam and not dead and IsValid(cameraEnt) and speaker:GetPos():DistToSqr(cameraEnt:GetPos()) < 90000 then
		for _, v in pairs(LS_TVs) do
			if not IsValid(v) then continue end

			local plys = {}
			for _, ply in pairs(player.GetAll()) do
				if v:GetPos():DistToSqr(ply:GetPos()) < 40000 then
					table.insert(plys, ply)
				end
			end

			if #plys ~= 0 then
				net.Start('lrp_tv_sendmsg')
					net.WriteEntity(speaker)
					net.WriteString(text)
				net.Send(plys)
			end
		end
	end
end)
local cameraEnt
hook.Add('PlayerCanHearPlayersVoice', 'LRP_TV_Broadcast_Voice', function(ply, speaker)
	if speaker.TVVoiceTo and speaker.TVVoiceTo[ply] then return true end
end)

hook.Add("SetupPlayerVisibility", "AddRTCamera", function(ply)
	local cameraEnt = GetGlobalEntity('CameraMan').cameraent
	if IsValid(cameraEnt) then
		for _, v in pairs(LS_TVs) do
			if not IsValid(v) then continue end
			if v:GetPos():DistToSqr(ply:GetPos()) < 40000 then
				AddOriginToPVS(cameraEnt:GetPos())
				break
			end
		end
	end
end)

function ENT:Initialize()
	self:SetModel("models/props_phx/rt_screen.mdl")
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	
	self:SetRenderMode(RENDERMODE_TRANSALPHA)
	
    self:MakeBreakable({health = 200})
end