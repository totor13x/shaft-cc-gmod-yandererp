if SERVER then   
	AddCSLuaFile("shared.lua")
end

ENT.Base = "alcohol"
ENT.Model = 'models/props_interiors/bottles_shelf_break01.mdl'
ENT.Strength = 9.5