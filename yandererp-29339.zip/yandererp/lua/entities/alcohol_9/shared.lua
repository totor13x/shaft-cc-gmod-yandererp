AddCSLuaFile()

ENT.Base = "alcohol"
ENT.Model = 'models/props_junk/garbage_glassbottle001a.mdl'
ENT.Strength = 0.5