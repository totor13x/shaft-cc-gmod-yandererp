ENT.Base = 'base_anim'
ENT.Type = 'anim'
ENT.PrintName = 'Машины'

function ENT:CarTable() 
	return {
		{
			name = "Peugeot RCZ",
			model = "models/r4_vehicles/peugeot/rcz.mdl",
			price = 42500,
			health = 2000,
			class = "r4_rcz",
			seats = {
				[1] = { x = 16, y = -6, z = 7 },
				[2] = { x = 16, y = 24, z = 7 },
				[3] = { x = -12, y = 24, z = 7 }
			},
		},
		{
			name = "Chevrolet Camaro SS",
			model = "models/lonewolfie/chev_camaro_68.mdl",
			price = 60000,
			health = 3000,
			class = "chev_camaro_68",
			seats = {
				[1] = { x = 19, y = 6, z = 15 },
				[2] = { x = -19, y = 37, z = 15 },
				[3] = { x = 19, y = 37, z = 15 },
			},
		},
		{
			name = 'Suzuki Kinqguard',
			model = 'models/lonewolfie/suzuki_kingquad.mdl',
			price = 12500,
			class = 'suzuki_kingquad_lw'
		},
		{
			name = "BMW 750iL E38",
			model = "models/r4_vehicles/bmw/bmwe38.mdl",
			price = 62500,
			health = 3000,
			class = "r4_bmwe38",
			seats = {
				[1] = { x = 22, y = 12, z = 15 },
				[2] = { x = -22, y = 64, z = 15 },
				[3] = { x = 22, y = 64, z = 15 },
			},
		},
		{
			name = "Porsche 944 Turbo",
			model = "models/r4_vehicles/porsche/944.mdl",
			price = 70000,
			health = 3200,
			class = "r4_944",
			seats = {
				[1] = { x = 16, y = -12, z = 14 },
				[2] = { x = -16, y = 24, z = 14 },
				[3] = { x = 16, y = 24, z = 14 },
				
			},
		},
		{
			name = "Mercedes Benz C63",
			model = "models/lonewolfie/mer_c63_amg.mdl",
			price = 80000, 
			health = 3500,
			class = "mer_c63",
			seats = {
				[1] = { x = 19, y = -8, z = 25 },
				[2] = { x = -19, y = 37, z = 25 },
				[3] = { x = 19, y = 37, z = 25 },
			},
		},
		{
			name = "Volkswagen Touareg",
			model = "models/r4_vehicles/volkswagen/r50.mdl",
			price = 110000,
			health = 3800,
			class = "r4_R50",
			seats = {
				[1] = { x = 20, y = 0, z = 23 },
				[2] = { x = -20, y = 44, z = 23 },
				[3] = { x = 20, y = 44, z = 23 },
				[4] = { x = 0, y = 44, z = 23 }
			},
		},
		{
			name = "Maserati Levante",
			model = "models/r4_vehicles/maserati/levante.mdl",
			price = 122500,
			health = 4000,
			class = "r4_levante",
			seats = {
				[1] = { x = 20, y = 0, z = 25 },
				[2] = { x = -20, y = 44, z = 25 },
				[3] = { x = 20, y = 44, z = 25 },
				[4] = { x = 0, y = 44, z = 25 }
			},
		},
		{
			name = "Bentley Bentayga",
			model = "models/r4_vehicles/bentley/bentayga.mdl",
			price = 270000,
			health = 4200,
			class = "r4_bentayga",
			seats = {
				[1] = { x = 20, y = 0, z = 25 },
				[2] = { x = -20, y = 44, z = 25 },
				[3] = { x = 20, y = 44, z = 25 },
				[4] = { x = 0, y = 44, z = 25 }
			},
		},
		{
			name = "Subaru Impreza",
			model = "models/lonewolfie/subaru_impreza_2001.mdl",
			price = 160000, 
			health = 4500,
			class = "subaru_impreza_2001_lw",
			seats = {
				[1] = { x = 17, y = 2, z = 15 },
				[2] = { x = -19, y = 37, z = 15 },
				[3] = { x = 19, y = 37, z = 15 },
			},
		},
		{
			name = "Toyota GT-86 RB",
			model = "models/steelemancars/toy_gt86rb/toy_gt86rb.mdl",
			price = 170000,
			health = 4700,
			class = "smc_toy_gt86rb"
		},
		{
			name = "Suki's S2000 2F2F",
			model = "models/ronniecars/s2000/s2000.mdl",
			price = 170000,
			health = 4800,
			class = "ronniecars_s2k",
			seats = {
				[1] = { x = 18, y = 23, z = 8 }
			},
		},
		{
			name = "Ferrari 458",
			model = "models/r4_vehicles/ferrari/458s.mdl",
			price = 250000,
			health = 5000,
			class = "r4_458s",
			seats = {
				[1] = { x = 18, y = 0, z = 8 }
			},
		},
		{
			name = "Lambo. Aventador",
			model = "models/r4_vehicles/lamborghini/lp720.mdl",
			price = 325000,
			health = 6000,
			class = "r4_lp720",
			seats = {
				[1] = { x = 20, y = -14, z = 2 }
			},
		},
		{
			name = "Aston Martin Vulcan",
			model = "models/r4_vehicles/astonmartin/vulcan.mdl",
			price = 375000,
			health = 7000,
			class = "r4_vulcan",
			seats = {
				[1] = { x = 16, y = 50, z = 2 }
			},
		}
	}
end