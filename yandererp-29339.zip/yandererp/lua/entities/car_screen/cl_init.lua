include('shared.lua')

ENT.clmodel_pos = Vector(2449, 3143, 82)
ENT.selected = 0
Vehicles = Vehicles or {} 

surface.CreateFont('ArrowFont', {
	size = 55,
	weight = 700

})

function ENT:CheckModel() 
	if not IsValid(self.clmodel) then
		local car = self.cars[1]

		self.clmodel = ClientsideModel(car.model)
		self.clmodel:SetPos(self.clmodel_pos)
		self.clmodel:SetModelScale(car.scale or 0.4)
	end
end

function ENT:Think()
	if LocalPlayer():GetPos():DistToSqr(self:GetPos()) < 200000 then
		self:CheckModel()
		self:CheckScreen()
		self.clmodel:SetAngles(Angle(0, CurTime() * 50, 0))
	end
end

local function borderlines(w, h, color)
	surface.SetDrawColor(color or Color(150, 150, 150, 255)) 
	for i = 0, w do
		if i % 8 == 0 then
			i = i + SysTime() * 20 % 8
			surface.DrawLine(i, 0, i + 4, 0)
			surface.DrawLine(w - 1, i, w - 1, i + 4)
			surface.DrawLine(w - 4 - i, h - 1, w - i, h - 1)
			surface.DrawLine(0, w - i, 0, w - i - 4)
		end
	end
end

net.Receive('car_update', function()
	local ent = net.ReadEntity()
	Vehicles[net.ReadString()] = net.ReadTable()

	if ent.buy_button then
		ent.buy_button:SetMode(Vehicles[ent.PrintName][ent.selected])
	end
end)

function ENT:CheckScreen()
	if not self.frame or not IsValid(self.frame) then
		self:CreateScreen()
	end
end

function ENT:CreateScreen()
	local ent_self = self

	for k, ent in ipairs(ents.GetAll(-1)) do 
		if ent:EntIndex() == -1 then
			ent:Remove()
		end
	end

	self.cars = self:CarTable()

	local frame = vgui.Create('DFrame')
	frame:SetSize(1044, 634)
	frame:SetPos(0, 0)
	frame:SetDraggable(false)
	frame:ShowCloseButton(false)
	frame:SetTitle('Меню Покупки')
	frame:SetPaintedManually(true)
	frame:Hide()
	frame.page = 1
	self.frame = frame


	local dscroll = vgui.Create('DPanelList', frame)
	dscroll:Dock(FILL)
	dscroll:EnableHorizontal( true )
	dscroll:SetSpacing( 1 )
	dscroll:SetPadding( 3 )
	dscroll:DockMargin(0, 0, 0, 5)
	dscroll.items = {}
	function dscroll:RemoveItems()
		for i, item in ipairs(self.items) do 
			item:Remove()
		end
	end

	local buy_button = vgui.Create('DButton', frame)
	buy_button:SetText('Выберите')
	buy_button:SetFont('Trebuchet24')
	buy_button:Dock(BOTTOM)
	buy_button:DockMargin(450, 0, 450, 10)
	buy_button:SetTall(buy_button:GetTall() * 3)
	buy_button.ent_self = ent_self
	ent_self.buy_button = buy_button
	function buy_button:SetMode(isbought)
		if isbought then
			buy_button:SetText('Заспавнить')
			function buy_button:DoClick()
				local car = ent_self.cars[ent_self.selected]
				net.Start('car_spawn')
				net.WriteEntity(ent_self)
				net.WriteInt(ent_self.selected, 8)
				net.WriteTable(ent_self.clmodel:GetColor())
				net.SendToServer()
			end
		else
			buy_button:SetText('Купить')
			function buy_button:DoClick()
				local car = ent_self.cars[ent_self.selected]
				if car then
					Derma_Query('Купить ' .. car.name .. '?', 'Покупка', 
					'Да', 
					function()
						net.Start('car_buy')
						net.WriteEntity(ent_self)
						net.WriteInt(ent_self.selected, 8)
						net.SendToServer()
					end, 
					'Нет', 
					function()

					end)
				end
			end
		end
	end

	local left_button = vgui.Create('DButton', frame)
	left_button:SetText('←')
	left_button:SetFont('ArrowFont')
	left_button:SetTall(buy_button:GetTall())
	left_button:SetWide(buy_button:GetWide())
	left_button:SetPos(frame:GetWide() / 2 - left_button:GetWide() - 82, frame:GetTall() - left_button:GetTall() - 15)
	left_button:SetContentAlignment(8)
	function left_button:DoClick()
		frame.page = math.Clamp(frame.page - 1, 1, math.ceil(#ent_self.cars / 16))
		dscroll:Populate(frame.page ~= 1 and frame.page * 16 - 16 or 1, frame.page * 16)
	end

	local right_button = vgui.Create('DButton', frame)
	right_button:SetText('→')
	right_button:SetFont('ArrowFont')
	right_button:SetTall(buy_button:GetTall())
	right_button:SetWide(buy_button:GetWide())
	right_button:SetPos(frame:GetWide() / 2 + right_button:GetWide() + 16, frame:GetTall() - right_button:GetTall() - 15)
	right_button:SetContentAlignment(8)
	function right_button:DoClick()
		frame.page = math.Clamp(frame.page + 1, 1, math.ceil(#ent_self.cars / 16)) 
		dscroll:Populate(frame.page > 1 and frame.page * 16 - 16 or 1, frame.page * 16)
	end

	function dscroll:Populate(start, end_n)
		start, end_n = start or 1, end_n or 16

		self:RemoveItems()
		for k = start, end_n/*k, item in ipairs(self.cars)*/ do
			local item = ent_self.cars[k]
				
			if not item then
				return
			end

			local panel = vgui.Create('DButton', frame)
			panel:SetTall(128)
			panel:SetWide(256)

			function panel:Paint(w, h)
				if self:IsDown() then
					surface.SetDrawColor(30, 30, 35, 255)
				elseif self.Hovered then
					surface.SetDrawColor(35, 35, 40, 255)
				else
					if k % 2 == 0 then
						surface.SetDrawColor(40, 40, 45, 255)
					else
						surface.SetDrawColor(45, 45, 50, 255)
					end
				end

				surface.DrawRect(0, 0, w, h)
				draw.SimpleText(item.name, "Trebuchet24", w/2, h * 0.3, Color(230, 230, 230, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

				if item.price ~= 0 then
					draw.SimpleText(GAMEMODE.formatMoney(item.price), "schoolrp_schedule", w/2, h * 0.7, Color(230, 230, 230, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end

				if Vehicles[ent_self.PrintName][k] then
					borderlines(w, h, Color(50, 150, 50, 255))
				end

				if k == ent_self.selected then
					borderlines(w, h)
				end

				return true
			end

			function panel:DoClick()
				if item.model and ent_self.clmodel then
					ent_self.clmodel:SetModel(item.model)
					ent_self.clmodel:SetModelScale(item.scale or 0.4)
					ent_self.clmodel:SetPos(item.pos or ent_self.clmodel_pos)
				end
				ent_self.selected = k

				buy_button:SetMode(Vehicles[ent_self.PrintName][k])
			end

			table.insert(self.items, panel)
			self:AddItem(panel)
		end
	end

	dscroll:Populate()

	local color_frame = vgui.Create('DFrame')
	color_frame:SetPos(frame.X + frame:GetWide() + 25, frame.Y)
	color_frame:SetSize(frame:GetWide() / 2, frame:GetTall())
	color_frame:SetTitle('Выбор цвета')
	color_frame:ShowCloseButton(false)
	color_frame:SetDraggable(false)
	color_frame:SetPaintedManually(true)
	color_frame:Hide()
	self.color_frame = color_frame

	local color = vgui.Create('DColorPalette', color_frame)
	color:SetButtonSize(73)
	color:Dock(FILL)
	function color:OnValueChanged(col)
		if IsValid(ent_self.clmodel) then
			ent_self.clmodel:SetColor(col)
		end
	end
end

function ENT:Initialize()
	self:CheckScreen()
end

function ENT:Draw()
	local ang = self:GetAngles()
	ang:RotateAroundAxis(self:GetUp(), 90)

	if LocalPlayer():GetPos():DistToSqr(self:GetPos()) < 200000 and self.frame and self.color_frame then
		if not self.frame:IsVisible() or not self.color_frame:IsVisible() then
			self.frame:Show()
			self.color_frame:Show()
		end

		vgui.Start3D2D(self:WorldSpaceCenter() + self:GetUp() * 1.75 - self:GetForward() * 25 + self:GetRight() * 75, ang, 0.1)
			self.frame:Paint3D2D()
			self.color_frame:Paint3D2D()
		vgui.End3D2D()
	else
		if self.frame:IsVisible() or self.color_frame:IsVisible() then
			self.frame:Hide()
			self.color_frame:Hide()
		end
	end
end

function ENT:OnRemove()
	if self.frame and self.color_frame then
		self.frame:Remove()
		self.color_frame:Remove()
	end
end

net.Receive('car_spawn', function()
	net.ReadEntity().seats = net.ReadInt(4)
end)

if IsValid(seat_panel) then
	seat_panel:Remove()
end

hook.Add('OnContextMenuOpen', 'Seat Panel', function()
	if IsValid(seat_panel) then
		seat_panel:Remove()
	end
	
	local veh = LocalPlayer():GetVehicle()
	if not IsValid(veh) or not veh.seats then
		return	
	end
	
	seat_panel = vgui.Create('DPanel')
	
	seat_panel:SetSize(150, 215)
	seat_panel:SetPos(ScrW() - seat_panel:GetWide() - 15, ScrH() / 2 - seat_panel:GetTall() / 2)
	seat_panel:MakePopup()
	function seat_panel:Paint(w, h) 
		draw.RoundedBox(16, 0, 0, w, h, Color(51, 60, 70, 255))
	end
	
	local driver_seat = vgui.Create('DButton', seat_panel)
	driver_seat:SetSize(35, 35)
	driver_seat:SetPos(20, 15)
	driver_seat:SetText('')
	function driver_seat:Paint(w, h)
		draw.RoundedBox(8, 0, 0, w, h, Color(150, 150, 150, 225))
	end
	
	local positions = {
		--{15, 15},
		{95, 15},
		{15, 165},
		{100, 165},
		{57.5, 165},
	}
	
	for i = 1, 4 do
		local seat = vgui.Create('DButton', seat_panel)
		seat:SetSize(35, 35)
		seat:SetPos(unpack(positions[i]))
		seat:SetText('')
		function seat:Paint(w, h)
			draw.RoundedBox(8, 0, 0, w, h, veh.seats >= i and Color(204, 92, 135) or Color(150, 150, 150, 225))
		end
		function seat:DoClick()
			net.Start('drop_from_seat')
			net.WriteInt(i, 4)
			net.SendToServer()
		end
		
		seat_panel['seat' .. i] = seat
	end
end)

hook.Add('OnContextMenuClose', 'Seat Panel', function()
	if IsValid(seat_panel) then
		seat_panel:Remove()
	end
end)