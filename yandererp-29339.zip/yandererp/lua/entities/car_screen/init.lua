include('shared.lua')

AddCSLuaFile('shared.lua')
AddCSLuaFile('cl_init.lua')

ENT.spawn_pos = Vector(3045, 3017, 250) -- 44
ENT.spawned_cars = {} 

Vehicles = Vehicles or {}

function ENT:Initialize()
	self:SetModel('models/hunter/plates/plate1x3.mdl')
	self:PhysicsInit(SOLID_VPHYSICS)

	self.cars = self:CarTable()

	for i, car in ipairs(self.cars) do
		car.crc = 'car' .. util.CRC(car.name)

		//sql.Query('DROP TABLE ' .. car.crc)

		if not sql.TableExists(car.crc) then
			sql.Query('CREATE TABLE ' .. car.crc .. ' (SteamID string)')
		end
	end

	hook.Add('PlayerInitialSpawn', self.PrintName, function(ply)
		if IsValid(self) then
			self:SendCars(ply)
		end
	end)

	for i, ply_n in ipairs(player.GetAll()) do 
		self:SendCars(ply_n)
	end
end

function ENT:BuyCar(car, ply)
	sql.Query( string.format('INSERT INTO %s VALUES ("%s")', car.crc, ply:SteamID()) )
	self:SendCars(ply)
	GAMEMODE:Notify(ply, 'Вы приобрели ' .. car.name)
end

function ENT:IsOwningCar(car, ply)
	return tobool(sql.Query( string.format('SELECT * FROM %s WHERE SteamID = "%s"', car.crc, ply:SteamID()) ))
end

function ENT:GetCars(ply)
	local owned_cars = {}

	for i, car in ipairs(self.cars) do 
		//print(self, i, car.crc)

		local owned = self:IsOwningCar(car, ply)

		if owned then
			owned_cars[i] = true
		end
	end

	return owned_cars
end

util.AddNetworkString('car_update')
function ENT:SendCars(ply) 
	net.Start('car_update')
	net.WriteEntity(self)
	net.WriteString(self.PrintName)
	net.WriteTable(self:GetCars(ply))
	net.Send(ply)
end

util.AddNetworkString('car_buy')
net.Receive('car_buy', function(l, ply)
	if false then
		GAMEMODE:Notify(ply, 'Покупка машин на данный момент отключена')
		return
	end
	
	local ent = net.ReadEntity()
	local car = ent.cars[net.ReadInt(8)]

	if car and not ent:IsOwningCar(car, ply) then
		if ply:CanAfford(car.price) then
			ply:AddMoney(-car.price)

			ent:BuyCar(car, ply)
		else
			GAMEMODE:Error(ply, 'Недостаточно денег!')
		end
	end
end)

util.AddNetworkString('car_spawn')
net.Receive('car_spawn', function(l, ply)
	local ent = net.ReadEntity()
	local car = ent.cars[net.ReadInt(8)]
	local color = net.ReadTable()

	if car and ent:IsOwningCar(car, ply) then
		if ent.cooldown and ent.cooldown > CurTime() then
			return 
		end
		ent.cooldown = CurTime() + 2

		if Vehicles[ply] and IsValid(Vehicles[ply]) then
			Vehicles[ply]:Remove()
		end

		if tobool(ply:GetPData('car_shouldpay')) then
			if ply:CanAfford(1000) then
				ply:RemovePData('car_shouldpay')
				ply:AddMoney(-100)

				GAMEMODE:Notify(ply, 'С вас списано ' .. GAMEMODE.formatMoney(1000) .. ' за починку машины.')
			else
				GAMEMODE:Error(ply, 'Недостаточно денег на починку машины!')
				
				return
			end
		end

		local vtable = list.Get('Vehicles')[car.class]
		local ent_car = ents.Create(vtable.Class)
		ent_car:SetModel(car.model)
		ent_car:SetPos(ent.spawn_pos)
		
		if vtable and vtable.KeyValues  then
			for k, v in pairs(vtable.KeyValues) do
				local kLower = string.lower( k )
				if kLower == "vehiclescript" or kLower == "limitview" or kLower == "vehiclelocked" or kLower == "cargovisible" or kLower == "enablegun" then
					ent_car:SetKeyValue( k, v )
				end
			end
		end
		
		ent_car:Spawn()
		ent_car:Activate()
		
		--ent_car:SetCollisionGroup

		ent_car:SetVehicleClass(car.class)
		ent_car.VehicleName = vtable.Name
		ent_car.VehicleTable = vtable
		
		ent_car.ClassOverride = car.class
		ent_car.ParentEnt = ent    
		ent_car.Owner = ply

		ent_car:MakeBreakable({
			health = car.health or 250,
			explode = true,
			onbreak = function()
				ply:SetPData('car_shouldpay', true)
			end
		})
		
		--timer.Simple(0.1, function() 
		--	ent_car:SetCollisionGroup(COLLISION_GROUP_PASSABLE_DOOR)
		--end)

		Vehicles[ply] = ent_car

		ent_car:SetColor(color)

		if car.seats then
			ent_car.seats = {}

			for k, s in ipairs(car.seats) do 
				local seat = ents.Create( "prop_vehicle_prisoner_pod" )

				seat:SetModel( "models/nova/jeep_seat.mdl" )

				seat:SetKeyValue( "vehiclescript", "scripts/vehicles/prisoner_pod.txt" )
				seat:SetKeyValue( "limitview", 1 )

				local ang = ent_car:GetAngles()
				seat:SetAngles( ang )
				seat:SetPos( ent_car:GetPos() + ang:Forward() * s.x + ang:Right() * s.y + ang:Up() * s.z )

				seat:Spawn()
				seat:Activate()

				seat:SetNotSolid( true )
				seat:SetParent( ent_car )

				seat:SetColor( Color( 0, 0, 0, 0 ) )
				seat:SetRenderMode( RENDERMODE_TRANSALPHA )

				seat:SetNoDraw( true )
				seat:DrawShadow( false )

				seat:SetMoveType( MOVETYPE_NONE )
				seat:SetCollisionGroup( COLLISION_GROUP_IN_VEHICLE )

				seat:CollisionRulesChanged() -- Just in case

				seat.car = ent_car

				table.insert(ent_car.seats, seat)
			end

			timer.Simple(0.5, function()
				if IsValid(ent_car) and IsValid(ply) and ent_car.seats then
					net.Start('car_spawn')
					net.WriteEntity(ent_car)
					net.WriteInt(#ent_car.seats, 4)
					net.Send(ply)
				end
			end)
		end
	end
end)

hook.Add('FindUseEntity', 'Cars', function(ply, veh)
	if IsValid(ply) and IsValid(veh) and ply ~= veh.Owner and veh.seats then
		if ply.seatcd and ply.seatcd > CurTime() then
			return
		end

		ply.seatcd = CurTime() + 2

		local trace = ply:GetEyeTrace().HitPos
		local seats = table.Copy(veh.seats)

		table.sort(seats, function(a, b)
			return a:WorldSpaceCenter():DistToSqr(trace) < b:WorldSpaceCenter():DistToSqr(trace)
		end)

		ply:EnterVehicle(seats[1])
	end
end)

hook.Add('PlayerEnteredVehicle', 'Cars', function(ply, veh)
	if IsValid(veh.ParentEnt) and Vehicles[ply] ~= veh then
		GAMEMODE:Error(ply, 'Вы не являетесь владельцем машины!')
		ply:ExitVehicle()
	end
end)

hook.Add('PlayerDisconnected', 'Cars', function(ply)
	local veh = Vehicles[ply]

	if IsValid(veh) then
		veh:Remove()
	end
end)

hook.Add('PlayerDeath', 'Cars', function(ply)
	ply:ExitVehicle()
end)

hook.Add('EntityTakeDamage', 'Cars', function(ent, dmg)
	if ent:IsVehicle() and ent.seats then
		for i, seat in ipairs(ent.seats) do
			
			local driver = seat:GetDriver()
			if IsValid(driver) and driver:GetVehicle() == seat then
				dmg:SetDamageType(0)
				driver:TakeDamageInfo(dmg)
			end
		end
	end
end)

util.AddNetworkString('drop_from_seat')
net.Receive('drop_from_seat', function(l, ply)
	local veh = ply:GetVehicle()
	if IsValid(veh) and veh.seats then
		local seat = veh.seats[net.ReadInt(4)]
		local driver = seat:GetDriver()
		
		if IsValid(driver) and driver:GetVehicle() == seat then
			driver:ExitVehicle()
			driver.seatcd = CurTime() + 5
		end
	end
end)