ENT.Type = 'anim'
ENT.Base = 'base_anim'

ENT.Spawnable = false
ENT.AdminSpawnable = false
ENT.RenderGroup = RENDERGROUP_TRANSLUCENT


ENT.Model = 'models/props_lab/tpplug.mdl'

function ENT:SetupDataTables()
	self:NetworkVar('Bool', 0, 'Enabled')
	self:NetworkVar('Float', 0, 'LastUse')
end