include 'shared.lua'

ENT.SoundName = 'ambient/atmosphere/city_beacon_loop1.wav'

function ENT:Initialize()
	self.Pos = self:GetPos()
	self.SignalPos = self:GetPos() + self:GetForward() * 12.25
	self.BallPos = self:GetPos() + self:GetForward() * 25
	self.Sound = CreateSound(self, self.SoundName)
	self.Playing = false //IsPlaying somehow bugs that
	self.Sound:ChangeVolume(0)
end

function ENT:SoundState(bool)
	if bool and not self.Playing then
		self.Playing = true
		self.Sound:Play()
		self.Sound:ChangeVolume(0.5, 3.5)
	elseif not bool and self.Playing then
		self.Playing = false
		self.Sound:ChangeVolume(0, 3.5)
		timer.Simple(3.5, function()
			self.Sound:Stop()
		end)
	end
end

local e = FindMetaTable('Entity')
local DrawModel, GetPos = e.DrawModel, e.GetPos
local SetColorMaterial, DrawQuadEasy, SetMaterial, DrawSprite, DrawSphere = render.SetColorMaterial, render.DrawQuadEasy, render.SetMaterial, render.DrawSprite, render.DrawSphere

local refrac = Material('sprites/heatwave')
local glow = Material('sprites/light_glow02_add')

function ENT:DrawTranslucent()
	self:DrawModel()

	if GetPos(LocalPlayer()):DistToSqr(GetPos(self)) > 570025 then return end

	local col = self:GetEnabled() and Color(0, 255, 0) or Color(255, 0, 0)

	SetColorMaterial()
	DrawQuadEasy(self.SignalPos, self.Pos - (self.Pos - Vector(0, 0, 1)), 1, 1, col)
		
	SetMaterial(glow)
	DrawSprite(self.SignalPos, 5, 10, col)
	
	local size = math.sin( math.min((CurTime() - self:GetLastUse()) / 2, math.pi / 2) ) * 10
	if not self:GetEnabled() then 
		size = 10 - size 
	end 
	
	self:SoundState(self:GetEnabled())

	if size == 0 then
		return 
	end
	
	for i = 1, 2 do
		local even, to = i % 2 == 0, CurTime() * 2.7 * i
		local pos = self.BallPos + Vector(math[even and 'sin' or 'cos'](to) * 12, math[even and 'cos' or 'sin'](to) * 12, 0)
	
		SetColorMaterial()
		DrawSphere(pos, size / 3, 15, 15, Color(130, 50, 160))
	
		SetMaterial(glow)
		DrawSprite(pos, size * 3, size * 3, Color(130, 50, 160))
	
		SetMaterial(refrac)
		DrawSprite(pos, size, size)
	end

end