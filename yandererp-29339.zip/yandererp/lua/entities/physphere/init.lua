include 'shared.lua'

AddCSLuaFile 'shared.lua'
AddCSLuaFile 'cl_init.lua'

ENT.AllowedTeams = {
	--[TEAM_TEACHER_PHYS] = true,
	[TEAM_TEACHER_MATH] = true,
}
ENT.Cool = 0

local teslat = {
	{"m_SoundName", "DoSpark"},
	{"texture", "sprites/laserbeam.spr"},
	{"m_Color", "255 255 255"},
	{"m_flRadius", 100},
	{"beamcount_max", 4},
	{"thick_min", 1},
	{"thick_max", 2},
	{"lifetime_min", "0.1"},
	{"lifetime_max", "0.3"},
	{"interval_min", "0.1"},
	{"interval_max", "0.2"},
}

local function spawnTesla(p)
	local tesla = ents.Create("point_tesla")
	tesla:SetPos(p)

	for k, v in ipairs(teslat) do
		tesla:SetKeyValue(v[1], v[2])
	end

	tesla:Spawn()

	timer.Simple(2, function() 
		tesla:Remove() 
	end)
	return tesla
end


//surface.PlaySound('ambient/atmosphere/tunnel1.wav')

function ENT:Initialize()
	self:SetModel(self.Model)
	self:PhysicsInit(SOLID_VPHYSICS)
	self:GetPhysicsObject():EnableMotion(false)
	self:SetUseType(ONOFF_USE)
end

function ENT:Use(pl)
	if not self.AllowedTeams[pl:Team()] then return end

	if CurTime() - self.Cool > 5 then
		self:SetEnabled(not self:GetEnabled())

		if self:GetEnabled() then
			timer.Create('tesla', 5, 0, function()
				local tesla = spawnTesla(self:GetPos() + Vector(0, 0, 25))
				tesla:Fire( "DoSpark", "", 0 )
				tesla:EmitSound('ambient/energy/ion_cannon_shot' .. math.random(1, 3) .. '.wav', 150, 50)
			end)
		else
			timer.Remove('tesla')
			self:EmitSound('buttons/combine_button2.wav')
		end

		self.Cool = CurTime()
		self:SetLastUse(CurTime())
	end
end

function ENT:OnRemove()
	timer.Remove('tesla')
end