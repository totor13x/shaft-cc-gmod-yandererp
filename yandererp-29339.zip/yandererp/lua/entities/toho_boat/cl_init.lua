include('shared.lua')

function ENT:Draw()
	if not IsValid(boatmodel) then
		boatmodel = ClientsideModel('models/props_canal/boat002b.mdl')
		boatmodel:SetNoDraw(true)
	end
    
	boatmodel:SetPos(self:GetPos() + Vector(0, 0, 10))
	boatmodel:SetAngles(self:GetAngles())
	boatmodel:DrawModel()
end