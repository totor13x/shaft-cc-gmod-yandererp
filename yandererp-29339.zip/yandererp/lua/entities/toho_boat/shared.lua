ENT.Type = 'anim'
ENT.Base = 'base_anim'

ENT.PrintName = 'Touhou Boat'
ENT.Author = 'maxmol'
