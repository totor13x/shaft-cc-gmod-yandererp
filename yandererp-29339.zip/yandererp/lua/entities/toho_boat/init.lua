include('shared.lua')

AddCSLuaFile('shared.lua')
AddCSLuaFile('cl_init.lua')

	--;:
function ENT:Initialize()
	self:SetModel('models/props_canal/boat002b.mdl')
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)
	--self:SetCollisionGroup(COLLISION_GROUP_WORLD)
	
	local phys = self:GetPhysicsObject()
	if IsValid(phys) then
		phys:Wake()
		phys:SetMass(100)
		--phys:EnableGravity(false)
	end

	local vehicle = ents.Create("prop_vehicle_prisoner_pod")
	local a = self:GetAngles()
	a:RotateAroundAxis(a:Up(), -90)
	vehicle:SetAngles(a)
	vehicle:SetPos(self:GetPos() - a:Right() * 30 + a:Up() * 27)
	vehicle:SetModel("models/nova/airboat_seat.mdl") -- DO NOT CHANGE OR CRASHES WILL HAPPEN
	vehicle:SetKeyValue("vehiclescript", "scripts/vehicles/prisoner_pod.txt")
	vehicle:SetKeyValue("limitview","0")
	vehicle:Spawn()
	vehicle:Activate()

	vehicle:SetMoveType(MOVETYPE_PUSH)
	vehicle:GetPhysicsObject():Sleep()	
	vehicle:SetCollisionGroup(COLLISION_GROUP_NONE)

	vehicle:SetNotSolid(true)
	vehicle:GetPhysicsObject():Sleep()	
	vehicle:GetPhysicsObject():EnableGravity(false)
	vehicle:GetPhysicsObject():EnableMotion(false)
	vehicle:GetPhysicsObject():EnableCollisions(false)
	vehicle:GetPhysicsObject():SetMass(1)
	
	-- Visibles
	vehicle:DrawShadow(false)
	vehicle:SetColor(Color(0,0,0,0))
	vehicle:SetRenderMode(RENDERMODE_TRANSALPHA)
	vehicle:SetNoDraw(true)

	vehicle.VehicleName = "Airboat Seat"
	vehicle.ClassOverride = "prop_vehicle_prisoner_pod"
	vehicle:SetParent(self)

	self.chair = vehicle
	LS_InitEntHealth(self, 1000, false, false)
end

function ENT:Think()
	if IsValid(self.ply) then
		if self.ply:KeyDown(IN_USE) then
			if not self.ply.boatToggle then
				self:PlyRelease()
				return
			end
		else
			self.ply.boatToggle = nil
		end
			
		if self.ply:KeyDown(IN_FORWARD) then
			self:GetPhysicsObject():AddVelocity(self:GetForward() * 30)	
		end
		
		if self.ply:KeyDown(IN_BACK) then
			self:GetPhysicsObject():AddVelocity(-self:GetForward() * 15)	
		end
		
		if self.ply:KeyDown(IN_MOVELEFT) then
			self:GetPhysicsObject():ApplyTorqueCenter(Vector(0, 0, 1000))
		end
		
		if self.ply:KeyDown(IN_MOVERIGHT) then
			self:GetPhysicsObject():ApplyTorqueCenter(Vector(0, 0, -1000))
		end
	end
end

function ENT:PlyRelease()
	self.ply:ExitVehicle()
	self.ply = nil	
end

function ENT:OnRemove()
	if IsValid(self.ply) then self:PlyRelease() end
end

function ENT:Use(ply)
	if not IsValid(self.ply) and (not self.owner or self.owner == ply) then
		self.ply = ply
		ply:EnterVehicle(self.chair)
		ply.boatToggle = true
	end
end

function ENT:PhysicsCollide(data, physobj)
	if data.Speed > 60 && data.DeltaTime > 0.2 then
		sound.Play('physics/wood/wood_crate_break' .. math.random(5) .. '.wav', self:GetPos(), 75, 100, math.Clamp(data.Speed / 100, 0, 1))
		self:TakeDamage(data.Speed/2)
	end
end
