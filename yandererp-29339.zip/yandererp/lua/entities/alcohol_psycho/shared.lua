if SERVER then   
	AddCSLuaFile("shared.lua")

	function ENT:StartTouch(ent)
		if IsValid(ent) and ent:IsPlayer() then
			self:Use(ent, ent, USE_ON, 0)
		end
	end
end

ENT.Base = "alcohol"
ENT.Model = 'models/prop/syringe.mdl'
ENT.Strength = 5