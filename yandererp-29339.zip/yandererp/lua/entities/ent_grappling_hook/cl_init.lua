include("shared.lua")

function ENT:Draw()
	self.Entity:DrawModel()
end