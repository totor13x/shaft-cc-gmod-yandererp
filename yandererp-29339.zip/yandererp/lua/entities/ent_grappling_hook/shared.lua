ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Grapplink Hook"
ENT.Author = "Sinavestos"
ENT.Spawnable = false
ENT.AdminSpawnable = false