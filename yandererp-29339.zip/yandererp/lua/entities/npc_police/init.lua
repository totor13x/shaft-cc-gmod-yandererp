include('shared.lua')

AddCSLuaFile('shared.lua')
AddCSLuaFile('cl_init.lua')

local spawncooldown = 0
table.Merge(ENT.Items[1], {
    canbuy = function(self, ply, ent)
		if ply:Team() != TEAM_POLICE_CHIEF then
			return false
		end
		
		return true
	end,
	buy = function(self, ply, ent)
		if CurTime() < spawncooldown then
			return
		end
		spawncooldown = CurTime() + 5
		local pos = Vector(4685, -1079, 160)
		if IsValid(LS_PoliceCar) then
			LS_PoliceCar:Remove()
		end
		local VName = "jag_xfr_pol"
		local VTable = list.Get( "Vehicles" )[VName]
		local Class = VTable.Class
		local Model = VTable.Model
		local Ent = ents.Create( Class )
		if ( !Ent ) then return NULL end

		duplicator.DoGeneric( Ent, data )

		Ent:SetModel( Model )

		// Fallback vehiclescripts for HL2 maps ( dupe support )
		if ( Model == "models/buggy.mdl" ) then Ent:SetKeyValue( "vehiclescript", "scripts/vehicles/jeep_test.txt" ) end
		if ( Model == "models/vehicle.mdl" ) then Ent:SetKeyValue( "vehiclescript", "scripts/vehicles/jalopy.txt" ) end

		-- Fill in the keyvalues if we have them
		if ( VTable && VTable.KeyValues ) then
			for k, v in pairs( VTable.KeyValues ) do

				local kLower = string.lower( k )

				if ( kLower == "vehiclescript" ||
				     kLower == "limitview"     ||
				     kLower == "vehiclelocked" ||
				     kLower == "cargovisible"  ||
				     kLower == "enablegun" )
				then
					Ent:SetKeyValue( k, v )
				end

			end
		end

		Ent:SetAngles( Angle(0, 90, 0) )
		Ent:SetPos( pos )

		DoPropSpawnedEffect( Ent )

		Ent:Spawn()
		Ent:Activate()

		if ( Ent.SetVehicleClass && VName ) then Ent:SetVehicleClass( VName ) end
		Ent.VehicleName = VName
		Ent.VehicleTable = VTable

		-- We need to override the class in the case of the Jeep, because it
		-- actually uses a different class than is reported by GetClass
		Ent.ClassOverride = Class

		GAMEMODE:Notify(ply, 'Автомобиль доставлен на депо!')
		Ent:MakeBreakable({health = 2500})

		LS_PoliceCar = Ent
		timer.Simple(0.1, function() Ent:SetCollisionGroup(COLLISION_GROUP_PASSABLE_DOOR) end)
	end,
})

hook.Add('PlayerEnteredVehicle', 'PolicePrivateSeat', function(ply, veh, role)
	if veh == LS_PoliceCar and not (ply:Team() == TEAM_POLICE or ply:Team() == TEAM_POLICE_CHIEF) then
		GAMEMODE:Error(ply, 'Вы не полицейский')
		ply:ExitVehicle()
		return false
	end
end)

hook.Add('OnPlayerChangedTeam', 'PoliceCarRemove', function(p, b, a) 
	if b == TEAM_POLICE_CHIEF then
		if IsValid(LS_PoliceCar) then LS_PoliceCar:Remove() end
	end
end)
