ENT.Base = 'npc_base'
ENT.Type = 'ai'
ENT.PrintName = 'Полицейский NPC'
ENT.Model = 'models/player/dewobedil/kancolle/u511/default_e.mdl'

ENT.Items = {
	{
		name = 'Полицейская машина',
		price = 0,
		model = 'models/lonewolfie/jaguar_xfr_pol.mdl',
	}
}
