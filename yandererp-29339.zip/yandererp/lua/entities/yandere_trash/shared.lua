ENT.Type = 'anim'
ENT.Base = 'base_anim'
ENT.Tag = 'yandere_trash'
ENT.SearchTime = 30