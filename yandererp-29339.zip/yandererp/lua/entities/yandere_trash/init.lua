include('shared.lua')

AddCSLuaFile('shared.lua')
AddCSLuaFile('cl_init.lua')

local users = {}
	
function ENT:Initialize()
	self:SetModel('models/props_junk/trashdumpster01a.mdl')
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetUseType(CONTINUOUS_USE)
end
function ENT:Use(ply)
	if not users[ply] then 
		users[ply] = {start = CurTime(), last = CurTime()}
			
		net.Start(self.Tag)
		net.Send(ply)
	end
	
	if users[ply] then
		if CurTime() - users[ply].last > 0.15 then
			users[ply] = nil
			
			return
		end
		
		if CurTime() - users[ply].start > self.SearchTime then
			local ent = ents.Create('lrp_detail')
			ent:SetPos(self:WorldSpaceCenter() + self:GetForward() * 25)
			ent:Spawn()

			if inv_put(ent, ply) then
				GAMEMODE:Notify(ply, "Деталь помещена в Ваш инвентарь")
			end
			
			users[ply] = nil
		else
			users[ply].last = CurTime()
		end
	end
end