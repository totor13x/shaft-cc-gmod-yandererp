include('shared.lua')
local tag, search_time = ENT.Tag, ENT.SearchTime

function ENT:RPHUDDraw()
	return {'Помойка', 'Чтобы исследовать её, удерживай Е'}
end

local w, h = ScrW() / 2 - 350 / 2, ScrH() / 2 - 20
net.Receive(tag, function()
	local start, localplayer = CurTime(), LocalPlayer()
	
	hook.Add('HUDPaint', tag, function()
		local ww = 350 * (CurTime() - start) / search_time
		
		surface.SetDrawColor(Color(25, 25, 25, 150))
		surface.DrawRect(w, h, 350, 40)
		surface.SetDrawColor(Color(128, 128, 0, 255))
		surface.DrawRect(w, h, ww, 40)
		
		if ww >= 350 or localplayer:GetEyeTrace().Entity:GetClass() ~= 'yandere_trash' or not input.IsButtonDown(KEY_E) then
			hook.Remove('HUDPaint', tag)	
		end
	end)
end)