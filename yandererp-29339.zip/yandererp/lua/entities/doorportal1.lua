AddCSLuaFile()
ENT.Base = "doorportal_base"
ENT.Type = "anim"
ENT.ExitPoint = Vector(4203, 1784, 55)
ENT.AddAng = Angle(0, 180, 0)