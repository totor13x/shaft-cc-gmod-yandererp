include('shared.lua')

function ENT:RPHUDDraw()
	return {'Автомат с напитками', 'Цена: ' .. GAMEMODE.formatMoney(self.Price)}
end	