AddCSLuaFile('shared.lua')
AddCSLuaFile('cl_init.lua')

include('shared.lua')

ENT.Model = 'models/props_interiors/VendingMachineSoda01a.mdl'--'models/map_detail/lobby_vendingmachine.mdl'

local mdls = {
	'models/props_junk/PopCan01a.mdl',
	'models/props_junk/garbage_glassbottle003a.mdl',
	'models/props_junk/garbage_glassbottle001a.mdl'
}

function ENT:Initialize()
	self:SetModel(self.Model)
	self:PhysicsInit(SOLID_VPHYSICS)
	self:GetPhysicsObject():EnableMotion(true)
	self:SetUseType(ONOFF_USE)
	self.Cool = 0
end

function ENT:Use(ply, _, usetype)
	if usetype == 1 and CurTime() - self.Cool > 1 and ply:GetEyeTrace().Entity == self then
		if ply:CanAfford(self.Price) then
			GAMEMODE:Notify(ply, string.format('Вы купили напиток за %s!', GAMEMODE.formatMoney(self.Price)))
			self:EmitSound('ambient/office/coinslot1.wav')
			ply:AddMoney(-self.Price)
			
			
			local ent = ents.Create('spawned_food')
			ent:SetPos(self:LocalToWorld(Vector(25, -5, -27)))
			ent:SetAngles(self:LocalToWorldAngles(Angle(90, 90, 0)))
			
			if math.random(1, 100) < 3 then
				ent:SetModel('models/props_junk/Shoe001a.mdl')
			else
				ent:SetModel(mdls[math.random(#mdls)])
			end
			
			ent:Spawn()
			
			ent:GetPhysicsObject():SetVelocity(self:GetForward() * 20)
			ent:SetCollisionGroup(COLLISION_GROUP_DEBRIS_TRIGGER)
			ent.FoodEnergy = 15
		else
			GAMEMODE:Error(ply, 'Недостаточно денег!')
		end
		
		self.Cool = CurTime()
	end
end