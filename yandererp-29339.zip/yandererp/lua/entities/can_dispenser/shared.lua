ENT.Type = 'anim'
ENT.Base = 'base_anim'
ENT.PrintName = 'Автомат с напитками'
ENT.Spawnable = true

ENT.Price = 45
