include('shared.lua')

local ent = FindMetaTable('Entity')
local me = LocalPlayer()
local pos, ang
local DrawModel = ent.DrawModel

function ENT:Initialize()
	self.pos = self:GetPos() + self:GetForward() * 0.3 + self:GetUp() * 32
	self.ang = self:GetAngles()

	self.ang:RotateAroundAxis(self.ang:Up(), -90)
	self.ang:RotateAroundAxis(self.ang:Forward(), 90)
end

function ENT:Draw()
	DrawModel(self)

	if self.pos:DistToSqr(EyePos()) > 250000 then return end
	
	cam.Start3D2D(self.pos, self.ang, 0.2)
		draw.DrawText(self:GetBoardText(), "GModWorldtip", 0, 0, color_white, TEXT_ALIGN_CENTER)	
	cam.End3D2D()
end

net.Receive('WriteOnBlackboard', function()
	local ent = net.ReadEntity()
	
	local dframe = vgui.Create('DFrame')
	dframe:SetSize(400, 200)
	dframe:Center()
	dframe.Paint = function(self, w, h)
		surface.SetDrawColor(Color(255, 137, 38))
		surface.DrawRect(0, 0, w, h)
	end
	dframe:SetTitle('Доска')
	
	local text = vgui.Create('DTextEntry', dframe)
	text:Dock(FILL)
	text:SetText(ent:GetBoardText())
	text:SetMultiline(true)
	text.OnChange = function()
		local val = text:GetValue()
		timer.Create('blackboardPreSend', 0.5, 1, function()
			if IsValid(ent) then
				net.Start('WriteOnBlackboard')
					net.WriteEntity(ent)
					net.WriteString(val)
				net.SendToServer()
			end
		end)
	end
	text.Paint = function(self, w, h)
		surface.SetDrawColor(38, 148, 103)
		surface.DrawRect(0, 0, w, h)
		
		self:DrawTextEntryText(color_white, Color(0, 0, 255), color_white)
	end
	
	text.OnKeyCode = function(k)
		if k == KEY_ESCAPE then
			dframe:Close()
			dframe:Remove()
		end
	end
	
	dframe:MakePopup()
end)