ENT.PrintName = 'Доска'
ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.Author = 'maxmol'
ENT.Spawnable = true

function ENT:SetupDataTables()
	self:NetworkVar('String', 0, 'BoardText')
end