AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

function ENT:Initialize()
	self:SetModel('models/blackboard/blackboard.mdl')
		
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)
	self:GetPhysicsObject():EnableMotion(false)
end

util.AddNetworkString('WriteOnBlackboard')
net.Receive('WriteOnBlackboard', function(_, ply)
    local ent = net.ReadEntity()
    local k = net.ReadString()
    
    if not IsValid(ent) or ent:GetClass() ~= 'maxmol_blackboard' then
        return
    end
    
    if ent:GetPos():Distance(ply:GetShootPos()) > 500 then
        return
    end
    
    local f
    
    f = function()
        local counter = 0
        for i, v in pairs(string.Explode('\n', k)) do
            if utf8.len(v) and utf8.len(v) > 50 then
                k = string.sub(k, 0, counter + utf8.offset(v, 48)) .. '\n' .. string.sub(k, counter + utf8.offset(k, 49))
                f()
                return
            end
            
            counter = counter + string.len(v) + 1
            if i == 14 then
                k = string.sub(k, 0, counter)
                break
            end
        end
    end
    f()
    
    ent:SetBoardText(k)
end)

function ENT:Use(_, ply)
	if IsValid(ply) and ply:IsPlayer() then
		net.Start('WriteOnBlackboard')
			net.WriteEntity(self)
		net.Send(ply)
	end
end