include('shared.lua')

AddCSLuaFile('shared.lua')
AddCSLuaFile('cl_init.lua')

local models = {
	'binderblue',
	'binderbluelabel',
	'bindergreen',
	'bindergreenlabel',
	'binderredlabel',
}

function ENT:Initialize()
	self:SetModel('models/props_lab/'.. models[math.random(#models)] ..'.mdl')
	self:SetUseType(SIMPLE_USE)
	self:PhysicsInit(SOLID_VPHYSICS)
end

util.AddNetworkString('library_textbook')
function ENT:Use(ply)
	if ply:IsStudent() then
			if ply.last_grade and ply:GetGrade() ~= ply.last_grade then
			ply:SetLastGrade(ply:GetGrade())
		
			net.Start('library_textbook')
			net.WriteEntity(self)
			net.WriteEntity(ply)
			net.WriteInt(ply:GetGrade(), 5)
			net.SendPVS(self:GetPos())
			
			self:EmitSound('gmodtower/lobby/instruments/harp/a30.wav', 75, 100)
			self:Remove()
		else 
			GAMEMODE:Error(ply, 'Ты сможешь взять новые учебники, когда перейдёшь в следующий класс!')	
		end
	else
		GAMEMODE:Error(ply, 'Ты не ученик!')
	end
end
