include('shared.lua')

function ENT:RPHUDDraw()
	return {'Школьные учебники', 'Нажми Е чтобы взять новые учебники!'}, self:WorldSpaceCenter() + Vector(0, 0, 15)
end

local mat = Material('sprites/glow04_noz')

function ENT:Draw()
	local pos = self:WorldSpaceCenter() + (EyePos() - self:WorldSpaceCenter()):GetNormalized() * 25
	local col = HSVToColor(CurTime() * 50 % 365, 1, 1)

	self:DrawModel()
	render.SetMaterial(mat)
	render.DrawSprite(pos, 50, 50, Color(col.r, col.g, col.b, 20))
end

net.Receive('library_textbook', function()
	local book = net.ReadEntity()
	local ply = net.ReadEntity()
	local grade	= net.ReadInt(5)
	
	if IsValid(book) then
		ParticleEffect('zfs_health_effect', book:WorldSpaceCenter(), Angle(0, 0, 0))
	end

	if IsValid(ply) then
		local add = {Color(255, 0, 128), '[Школа] ', ply, Color(255, 255, 255), ' перешёл в ' .. grade .. 'й класс!'}

		EasyChat.AddText(EasyChat.GUI.RichText, unpack(add))
		add[4] = '<hsv=t()*90, 0.15>'
		EasyChat.ChatHUD:AddText(unpack(add))
	end
end)
