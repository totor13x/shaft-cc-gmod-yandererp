ENT.Type = 'anim'
ENT.Base = 'base_anim'
ENT.PrintName = 'Школьные учебники'
ENT.Spawnable = true
