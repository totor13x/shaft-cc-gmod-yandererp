include('shared.lua')

function ENT:Think()
	local inRange = self:GetPos():DistToSqr(EyePos()) < 250000
	if inRange and not self.IsLoading and not IsValid(self.Song) and self:GetEnabled() then
		self.IsLoading = true
		sound.PlayURL(self.url, "3d", function(channel) // http://touhouradio.com:8000/touhouradio.mp3
			self.IsLoading = false
			if IsValid(channel) and IsValid(self) then
				channel:SetPos(self:GetPos())
				channel:Play()
				channel:SetVolume(0.5)
				self.Song = channel
			end
		end)
	end
	
	if IsValid(self.Song) then
		self.Song:SetPos(self:GetPos())
		if not inRange or not self:GetEnabled() then
			self.Song:Stop()
		elseif not self.SongNameCooldown or self.SongNameCooldown < CurTime() then
			self.SongNameCooldown = CurTime() + 16
			http.Fetch('https://gensokyoradio.net/json/', function(json)
				local t = util.JSONToTable(json)
				if t then
					self.SongInfo = t.SONGINFO
				end
			end)
		end
	end
end

function ENT:OnRemove()
	if IsValid(self.Song) then self.Song:Stop() end	
end

local sprite = Material('sprites/glow04_noz')
function ENT:Draw()
	self:DrawModel()
	render.SetMaterial(sprite)
	render.DrawSprite(self:GetPos() + self:GetForward() * 9 + self:GetUp() * 12 + self:GetRight() * 9.8, 6, 6, self:GetEnabled() and Color(0, 255, 0) or Color(255, 0, 0))
end

net.Receive('ls_radio', function()
	gui.EnableScreenClicker(true)
	local e = net.ReadEntity()

	--timer.Simple(0.2, function()
		local m = DermaMenu()
		local o = m:AddOption(e:GetEnabled() and 'Выключить' or 'Включить', function() 
			net.Start('ls_radio') 
				net.WriteEntity(e) 
			net.SendToServer() 
		end)
		o:SetIcon(e:GetEnabled() and 'icon16/delete.png' or 'icon16/accept.png')
		
		if e:GetEnabled() and IsValid(e.Song) then
			local ss = m:AddSubMenu('Громкость')
			for i = 0, 100, 10 do
				o = ss:AddOption(i .. '%', function()
					e.Song:SetVolume(i/100)
				end)
				if math.floor(e.Song:GetVolume() * 10) == i/10 then
					o:SetIcon('icon16/accept.png')
				end
			end
			
			if e:GetEnabled() and e.SongInfo then
				m:AddSpacer()
				o = m:AddOption('Сейчас играет:')
				function o:OnMousePressed() end
				o:SetIcon('icon16/sound.png')
				
				for k, v in pairs(e.SongInfo) do
					m:AddOption(k .. ': ' .. v, function()
						chat.AddText(Color(0, 255, 0), 'Скопировано в буфер обмена')
						SetClipboardText(v)
					end)
				end
			end
		end
		m:Open()
		m.OnRemove = function()
			gui.EnableScreenClicker(false)
		end
	--end)
end)