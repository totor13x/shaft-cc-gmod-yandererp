ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "LS Radio"
ENT.Author = "maxmol"
ENT.Category		= "LampServ"
ENT.Spawnable = true
ENT.AdminOnly = true
ENT.url = 'https://gensokyoradio.net/GensokyoRadio.m3u'--'http://touhouradio.com:8000/.mp3'

function ENT:SetupDataTables()
	self:NetworkVar("Bool", 0, "Enabled")
end