AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

util.AddNetworkString('ls_radio')

net.Receive('ls_radio', function(len, ply)
	local e = net.ReadEntity()

	if ply:GetPos():Distance(e:GetPos()) < 500 then
		if e:IsValid() and e:GetClass() == 'ls_radio' then
			e:SetEnabled(not e:GetEnabled())
		end
		--PlayerActions.Do(ply, ACT_SIGNAL_FORWARD, 1.2)
	end
end)

function ENT:Use(ply)
	net.Start('ls_radio')
		net.WriteEntity(self)
	net.Send(ply)
end

function ENT:Initialize()
	self:SetModel('models/props_lab/citizenradio.mdl')
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)
	local phys = self:GetPhysicsObject()
	phys:Wake()
end