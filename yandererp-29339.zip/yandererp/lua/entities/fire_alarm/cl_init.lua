include('shared.lua')

alarm = alarm or {}
alarm.started = false
alarm.sound_url = 'https://lampserv.org/assets/gmod/firealarm1.mp3'
alarm.sound_pos = Vector(1456, 943, 200)
alarm.positions = {
	Vector(1455, -232, 132),
	Vector(672, 188, 127),
	Vector(672, 1598, 123),
	Vector(2240, 1604, 121),
	Vector(2240, 258, 123),
	Vector(672, 1300, 255),
	Vector(2240, 491, 253),
	Vector(2240, 492, 390),
	Vector(1219, 160, 392),
	Vector(672, 1302, 387),
}

function alarm:Start()
	self:End()
	
	sound.PlayURL(self.sound_url, 'noblock 3d', function(chan)
		if IsValid(chan) then
			chan:SetPos(self.sound_pos)
			chan:SetVolume(0.2)
			chan:Set3DFadeDistance(2000, 1000000)
			chan:Play()
			chan:EnableLooping(true)
			
			self.alarm = chan
			self.started = true
			
			timer.Create('fire_alarm_timer', 79, 1, function()
				self:End()
			end)
		end
	end)
end

function alarm:End()
	if IsValid(self.alarm) then
		self.alarm:Stop()		
	end
	
	self.started = false
end

function alarm:Think()
	if self.cooldown and self.cooldown > CurTime() or LocalPlayer():GetPos():DistToSqr(self.sound_pos) > 5500000 then
		return	
	end
	
	self.cooldown = CurTime() + 2
	
	for i, light_pos in ipairs(self.positions) do
		local light = DynamicLight(1488 + i)
		if light then
			light.pos = light_pos
			light.r = 255
			light.g = 0
			light.b = 0
			light.brightness = 6
			light.Decay = 0
			light.Size = 1024
			light.DieTime = CurTime() + 1
		end
	end
end

hook.Add('Think', 'Fire Alarm', function()
	if alarm.started then
		alarm:Think()
	end
end)

net.Receive('fire_alarm', function()
	alarm:Start()
end)

function ENT:RPHUDDraw()
	return {'Кнопка пожарной тревоги', 'Нажми Е чтобы запустить тревогу'}
end
