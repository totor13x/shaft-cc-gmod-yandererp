include('shared.lua')

AddCSLuaFile('shared.lua')
AddCSLuaFile('cl_init.lua')

function ENT:Initialize()
	self:SetModel('models/firealarm/callpoint_us.mdl')
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)

	fire_alarm_started = false
end

util.AddNetworkString('fire_alarm')
function ENT:Use(ply)
	if not fire_alarm_started then
		local fire_ents = ents.FindByClass('vfire')
	
		for i, fire in ipairs(fire_ents) do 
			if fire:GetPos():WithinAABox(Vector(368, -240, 8), Vector(2544, 2032, 560)) then
				net.Start('fire_alarm')
				net.Broadcast()
				
				GAMEMODE:ChatPrint(Color(255, 128, 128), '[Пожарная Тревога] ', ply, Color(220, 220, 220), ' нажал на кнопку пожарной тревоги!')
				
				fire_alarm_started = true

				timer.Create('fire_alarm', 79, 1, function()
					fire_alarm_started = false
				end)
				
				return	
			end
		end
			
		GAMEMODE:Error(ply, 'Рядом нет пожара!')
	end
end
