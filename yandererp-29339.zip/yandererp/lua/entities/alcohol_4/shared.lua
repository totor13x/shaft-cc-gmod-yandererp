AddCSLuaFile()

ENT.Base = "alcohol"
ENT.Model = 'models/props_interiors/bottles_shelf_break08.mdl'
ENT.Strength = 4.5