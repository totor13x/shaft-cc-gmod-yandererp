include("shared.lua")

net.Receive('coronavirus_effect', function()
	local pos = net.ReadVector()
	
	for i = 1, 16 do
		local vel = VectorRand() * 120
		SpawnParticle(4, 64, 700, 'particle/smokesprites_000' .. math.random(1, 9), Color(20, 100, 20), 
			pos, vel, -vel/2 + Vector(0, 0, 10), 0, 0, 128, 0)
	end
end)

function ENT:Initialize()
	self:SetModel('models/weapons/w_npcnade.mdl')
end