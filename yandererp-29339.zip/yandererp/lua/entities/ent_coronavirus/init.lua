include('shared.lua')

local conf = {
	zombie_pills = {
		'zombie', 'zombie_fast', 'zombie_poison'
	},
	immune = {
		["models/kerry/citizens/male_01_hamza.mdl"] = true, 
		["models/kerry/citizens/male_02_hamza.mdl"] = true, 
		["models/kerry/citizens/male_03_hamza.mdl"] = true, 
		["models/kerry/citizens/male_04_hamza.mdl"] = true,
	},
	infected_player_color = Color(128, 255, 128),
}


function ENT:Initialize()
	self:SetModel('models/weapons/w_npcnade.mdl')
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetCollisionGroup(COLLISION_GROUP_WEAPON)
	
	util.SpriteTrail(self, 0, Color(255, 0, 0), true, 15, 0, 0.2, 0.03, 'trails/laser')
	
	local phys = self:GetPhysicsObject()
	if IsValid(phys) then
		phys:Wake()
	end
	
	timer.Simple(0.5, function()
		if IsValid(self) then
			self:SetCollisionGroup(COLLISION_GROUP_NONE)
			timer.Create('ent_coronavirus' .. self:EntIndex(), 0.5, 4, function()
				if IsValid(self) then
					self:EmitSound('hl1/fvox/fuzz.wav')	
				end
			end)
		end
	end)

	timer.Simple(3, function()
		if IsValid(self) then
			local pos = self:GetPos()
			local effectdata = EffectData()
			effectdata:SetOrigin(pos)
			util.Effect("HunterDamage", effectdata)
			
			net.Start('coronavirus_effect')
			net.WriteVector(pos)
			net.SendPVS(pos)
			
			self:EmitSound('hl1/fvox/hiss.wav')
			self:EmitSound('weapons/ar2/ar2_altfire.wav')
			self:Remove()
			
			for k, v in ipairs(player.GetAll()) do
				if v:GetPos():DistToSqr(pos) < 262144 then
					v:Coronavirus()
				end
			end
		end
	end)
end

util.AddNetworkString('coronavirus_effect')
	
local meta = FindMetaTable('Player')

local cough

cough = function(ply, sec)
	if not IsValid(ply) or not ply.coronavirus then return end
	
	if ply:Alive() then
		sec = math.max(sec - 1, 5)

		ply:SetColor(conf.infected_player_color)
		
		ply:EmitSound('ambient/voices/cough' .. math.random(1, 4) .. '.wav', 75, math.random(90, 100))
		local radius = 10000
		if sec < 25 then 
			if ply:Health() <= 10 then
				ply.coronavirus = nil
				ply:SetColor(color_white)
				
				if true then
					ply:Kill()
				else
					pk_pills.apply(ply, conf.zombie_pills[math.random(#conf.zombie_pills)], 'lock-life')
				end
				
				return
			end
			
			ply:TakeDamage(10) 
			--radius = 160000 
		end
		
		for k, v in ipairs(player.GetAll()) do
			if v:GetPos():DistToSqr(ply:GetPos()) < radius then
				v:Coronavirus()
			end
		end
	end

	timer.Create('coronaviruscough' .. ply:EntIndex(), sec, 1, function()
		cough(ply, sec)
	end)
end

local first = true
function meta:Coronavirus()
	if self.coronavirus or conf.immune[self:GetModel()] then return end
		
	if first then
		GAMEMODE:Tip(Color(64, 255, 0), "В городе обнаружен первый случай заражения коронавирусом!", false, 'music/stingers/hl1_stinger_song16.mp3')
		
		timer.Create('coronavirus_government', 30, 1, function()
			GAMEMODE:Tip(Color(64, 255, 0), "Полиции разрешено убивать зараженных для предотвращения распространение вируса", false, 'music/stingers/hl1_stinger_song7.mp3')
		end)
		first = false
	end
	
	self.coronavirus = true
	cough(self, 30)
end

concommand.Add('coronavirus_cure', function(ply)
	if ply:IsSuperAdmin() then
		for k, v in ipairs(player.GetAll()) do
			if v.coronavirus then
				v:SetColor(color_white)
				v.coronavirus = nil
			end
		end
	
		GAMEMODE:Tip(Color(64, 255, 0), "Коронавирус уничтожен!", false, 'music/stingers/hl1_stinger_song27.mp3')
	end
end)

hook.Add('PlayerDeath', 'Coronavirus', function(ply, inf, att)
	if ply ~= att then
		ply:SetColor(color_white)
		ply.coronavirus = nil
	end
end)
