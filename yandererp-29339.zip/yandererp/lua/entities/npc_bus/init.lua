include('shared.lua')

AddCSLuaFile('shared.lua')
AddCSLuaFile('cl_init.lua')

local spawncooldown = 0
table.Merge(ENT.Items[1], {
	canbuy = function(self, ply, ent)
		if ply:Team() ~= TEAM_BUS_DRIVER or CurTime() < spawncooldown then
			spawncooldown = CurTime() + 5
			return false
		end
			
		return true
	end,
	buy = function(self, ply, ent)
		local pos = Vector(3459, 3533, 44)
		if IsValid(LS_Bus) then
			LS_Bus:Remove()
		end
		local VName = "sw_bus"
		local VTable = list.Get( "Vehicles" )[VName]
		local Class = VTable.Class
		local Model = VTable.Model
		local Ent = ents.Create( Class )
		if ( !Ent ) then return NULL end

		duplicator.DoGeneric( Ent, data )

		Ent:SetModel( Model )

		-- Fill in the keyvalues if we have them
		if ( VTable && VTable.KeyValues ) then
			for k, v in pairs( VTable.KeyValues ) do

				local kLower = string.lower( k )

				if ( kLower == "vehiclescript" ||
					 kLower == "limitview"     ||
					 kLower == "vehiclelocked" ||
					 kLower == "cargovisible"  ||
					 kLower == "enablegun" )
				then
					Ent:SetKeyValue( k, v )
				end

			end
		end

		Ent:SetAngles( Angle(0, 0, 0) )
		Ent:SetPos( pos )

		DoPropSpawnedEffect( Ent )

		Ent:Spawn()
		Ent:Activate()

		if ( Ent.SetVehicleClass && VName ) then Ent:SetVehicleClass( VName ) end
		Ent.VehicleName = VName
		Ent.VehicleTable = VTable

		-- We need to override the class in the case of the Jeep, because it
		-- actually uses a different class than is reported by GetClass
		Ent.ClassOverride = Class

		ply:PrintMessage(3, 'Автобус доставлен на депо!')
		Ent:MakeBreakable()
		--LS_InitEntHealth(Ent, 5000, true, true)

		LS_Bus = Ent
		local world = game.GetWorld()
		world.AddCount = function() end
		world.Nick = function() return 'maxmol huesos' end
		world.SteamID = function() return 'maxmol huesos' end
		world.IsSuperAdmin = function() return true end

		gamemode.Call( "PlayerSpawnedVehicle", world, Ent )
	end,

})

hook.Add('PlayerEnteredVehicle', 'PrivateSeat', function(ply, veh, role)
	if veh == LS_Bus and ply:Team() != TEAM_BUS_DRIVER then
		ply:PrintMessage(3, 'Вы не водитель автобуса')
		ply:ExitVehicle()
		ply:SetPos(veh:GetPos() + Vector(0, 0, 15))
		return false
	end

	if IsValid(LS_Bus) and veh.__SW_Vars and veh.__SW_Vars.SuperParentENT == LS_Bus and ply:Team() ~= TEAM_BUS_DRIVER then
		GAMEMODE:Vote('Оплатите, пожалуйста, проезд (55 йен)', function(yes)
			if yes then
				ply:addMoney(-55)
				for k, v in pairs(player.GetAll()) do
					if v:Team() == TEAM_BUS_DRIVER then
						v:addMoney(55)
						break
					end
				end
			else
				ply:ExitVehicle()
			end
		end, {ply})
	end
end)

hook.Add('OnPlayerChangedTeam', 'BusRemove', function(p, b, a) 
	if b == TEAM_BUS_DRIVER then
		if IsValid(LS_Bus) then LS_Bus:Remove() end
	end
end)	