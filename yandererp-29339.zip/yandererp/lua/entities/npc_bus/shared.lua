ENT.Base = 'npc_base'
ENT.Type = 'ai'
ENT.PrintName = 'Автобусный диспетчер'
ENT.Model = 'models/jazzmcfly/tanya/npc/tanya.mdl'

local spawncooldown = 0
ENT.Items = {
	{
		name = 'Запросить автобус',
		model = 'models/sligwolf/bus/bus.mdl',
		price = 0,
	}
}