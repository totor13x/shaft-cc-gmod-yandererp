include('shared.lua')
AddCSLuaFile('cl_init.lua')
AddCSLuaFile('shared.lua')

util.AddNetworkString(ENT.Tag)

local cameras = ENT.Cameras
local users = {}

function ENT:Initialize()
	self:SetModel(self.Model)
	self:SetUseType(ONOFF_USE)
	self:PhysicsInit(SOLID_VPHYSICS)
	self:GetPhysicsObject():EnableMotion(false)
end

function ENT:Use(ply, _, usetype)
	if usetype == 1 then
			net.Start(self.Tag)
			net.Send(ply)
			users[ply] = 1
	end
end

hook.Add('SetupPlayerVisibility', 'CamVisiblity', function(ply)
	if users[ply] then
		AddOriginToPVS(cameras[users[ply]].origin)
	end
end)

net.Receive(ENT.Tag, function(l, ply)
	local CamNum = net.ReadInt(5)

	if CamNum == 0 then
		users[ply] = nil
	else
		users[ply] = CamNum
	end
end)

