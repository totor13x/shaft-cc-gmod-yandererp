include('shared.lua')

function ENT:RPHUDDraw()
	return 'Показать камеры'
end

local cameras = ENT.Cameras
local tag = ENT.Tag

for i, cam in ipairs(cameras) do
	cam.pos = 87.5
end

local shouldpaint, current = true, 1

local function SendState()
	net.Start(tag)
	net.WriteInt(current, 5)
	net.SendToServer()
end

net.Receive(ENT.Tag, function()

	for k, v in ipairs(ents.FindByClass('prop_dynamic')) do
		if v:GetModel() == 'models/props/cs_assault/camera.mdl' then
			v.RenderOverride = function() end		
		end
	end

	gui.EnableScreenClicker(true)

	hook.Add('ShouldDrawLocalPlayer', tag, function()
		return true
	end)

	LocalPlayer():ConCommand('luatab_highperf 1')

	local frame = vgui.Create('DFrame')
	frame:SetTitle('Управление камерами')
	frame:SetSize(ScrW() / 1.25, ScrH() / 1.25)
	frame:Center()
	
	local mousedelta, oldx = 0, gui.MouseX()
	local smallerframe = vgui.Create('DPanel', frame)
	smallerframe:DockMargin(0, 0, 0, frame:GetTall() / 13.5)
	smallerframe:Dock(FILL)

	local w, h = smallerframe:GetSize()
	function smallerframe:Paint(w, h)
		if not shouldpaint then return end
		
		chatbox.donodraw(true)
		
		local x, y = self:LocalToScreen()
		
		if gui.MouseX() > x and gui.MouseX() < x + w and gui.MouseY() > y and gui.MouseY() < y + h then
			if input.IsButtonDown(MOUSE_LEFT) then
				cameras[current].pos = math.Clamp(cameras[current].pos + (gui.MouseX() - oldx) / 10, 25, 150)
			end
			smallerframe:SetCursor('hand')
		else
			smallerframe:SetCursor('arrow')
		end
	
		oldx = gui.MouseX()
		
		render.RenderView({
			origin = cameras[current].origin,
			angles = cameras[current].ang + Angle(0, cameras[current].pos, 0),
			x = x, 
			y = y,
			w = w, h = h
		})
	
		local text = cameras[current].name
		surface.SetFont('TargetID')
		local size_w, size_h = surface.GetTextSize(text)
		
		draw.RoundedBoxEx(8, w / 2 - size_w / 2, 0, size_w + 12, size_h + 12, Color(48.5, 48.5, 48.5), false, false, true, true)
		
		surface.SetTextColor(Color(255, 255, 255))
		surface.SetTextPos(w / 2 - size_w / 2 + 6, 6)
		surface.DrawText(text)
	end
	
	function frame:OnRemove()
		for k, v in ipairs(ents.FindByClass('prop_dynamic')) do
			if v:GetModel() == 'models/props/cs_assault/camera.mdl' then
				v.RenderOverride = nil	
			end
		end

		current = 0
		SendState()
		current = 1

		hook.Remove('ShouldDrawLocalPlayer', tag)
		LocalPlayer():ConCommand('luatab_highperf 0')

		gui.EnableScreenClicker(false)
	end

	local nextbutton = vgui.Create('DButton', frame)
	nextbutton:SetText('>')
	nextbutton:SetSize(frame:GetWide() / 15, frame:GetTall() / 15)
	nextbutton:SetPos(frame:GetWide() - nextbutton:GetWide() - 10, frame:GetTall() - nextbutton:GetTall() - 5)
	function nextbutton:DoClick()
		if current ~= #cameras then
			current = current + 1
			SendState()
		end
	end

	local prevbutton = vgui.Create('DButton', frame)
	prevbutton:SetText('<')
	prevbutton:SetSize(frame:GetWide() / 15, frame:GetTall() / 15)
	prevbutton:SetPos(10, frame:GetTall() - prevbutton:GetTall() - 5)
	function prevbutton:DoClick()
		if current ~= 1 then
			current = current - 1
			SendState()
		end
	end

	local camlist = vgui.Create('DButton', frame)
	camlist:SetText('Список доступных камер')
	camlist:SetSize(frame:GetWide() - nextbutton:GetWide() * 2 - 30, frame:GetTall() / 15)
	camlist:SetPos(prevbutton:GetWide() + 15, frame:GetTall() - camlist:GetTall() - 5)
	function camlist:DoClick()
		shouldpaint = false
	
		nextbutton:Hide()
		prevbutton:Hide()
		camlist:Hide()
	
		local camlistview = vgui.Create('DListView', frame)
		camlistview:Dock(FILL)
		camlistview:AddColumn('Камеры')
	
		function camlistview:DoDoubleClick(i)
			shouldpaint = true

			current = i
			SendState() 

			self:Remove()
			nextbutton:Show()
			prevbutton:Show()
			camlist:Show()
		end
	
		for k, v in ipairs(cameras) do
			camlistview:AddLine(v.name)
		end
	end

end)