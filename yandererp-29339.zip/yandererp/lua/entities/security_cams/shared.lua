ENT.Type = 'anim'
ENT.Base = 'base_anim'

ENT.Spawnable = false
ENT.AdminSpawnable = false

ENT.Model = 'models/props_lab/securitybank.mdl'
ENT.Tag = 'SecurityCams'

ENT.Cameras = {
	{
		name = 'Вход в школу',
		origin = Vector(1240, -217, 125),
		ang = Angle(2, 17, 0)
	},
	{
		name = 'Внутренний сад',
		origin = Vector(2055, 338, 251),
		ang = Angle(2, 17, 0)
	},
	{
		name = 'Штоловая',
		origin = Vector(1660, 163, 265),
		ang = Angle(2, 17, 0)
	},
	{
		name = 'Левая рекреация, первый этаж',
		origin = Vector(696, 169, 122),
		ang = Angle(2, 17, 0)
	},
	{
		name = 'Правая рекреация, первый этаж',
		origin = Vector(2211, 1684, 111),
		ang = Angle(2, 17, 0)
	},
	{
		name = 'Левая рекреация, второй этаж',
		origin = Vector(701, 179, 249),
		ang = Angle(2, 17, 0)
	},
	{
		name = 'Правая рекреация, второй этаж',
		origin = Vector(2108, 605, 258),
		ang = Angle(2, 17, 0)
	},
	{
		name = 'Левая рекреация, третий этаж',
		origin = Vector(702, 180, 390),
		ang = Angle(2, 17, 0)
	},
	{
		name = 'Правая рекреация, третий этаж',
		origin = Vector(2121, 594, 392),
		ang = Angle(2, 17, 0)
	},
}


