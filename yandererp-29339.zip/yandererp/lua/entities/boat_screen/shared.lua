ENT.Base = 'car_screen'
ENT.Type = 'anim'
ENT.PrintName = 'Лодки'

function ENT:CarTable()
	return  {
		{
			name = 'Гидроцикл', 
			class = 'seashark_rytrak', 
			model = 'models/rytrak/seashark.mdl', 
			price = 35000, 
			health = 1000
		},
		{
			name = 'Банан', 
			class = 'bananaboat', 
			model = 'models/props/hhp227/bananaboat.mdl', 
			price = 5000, 
			health = 300
		},
		{
			name = 'Катер "WellCraft"', 
			class = 'wellcraft_rytrak', 
			model = 'models/rytrak/wellcraft.mdl', 
			price = 95000, 
			health = 6000,
			scale = 0.15,
			pos = Vector(-3058, 3205, 45),
		},
		{
			name = 'Воздушная Подушка', 
			class = 'sw_powerboat', 
			model = 'models/sligwolf/powerboat/powerboat.mdl', 
			price = 125000, 
			health = 4500
		},
		{
			name = 'Яхта "РОССИЯ"', 
			class = 'Yacht_1', 
			model = 'models/tru/yacht_a.mdl', 
			price = 220000, 
			health = 9500,
			scale = 0.07
		},
	}
end