include('shared.lua')

AddCSLuaFile('shared.lua')
AddCSLuaFile('cl_init.lua')

ENT.spawn_pos = Vector(-2927, 3964, -30)