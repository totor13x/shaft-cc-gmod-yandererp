include('shared.lua')

ENT.clmodel_pos = Vector(-3058, 3205, 38)