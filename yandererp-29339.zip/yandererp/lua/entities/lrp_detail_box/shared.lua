ENT.PrintName = 'LRP Коробка для деталек'
ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.Author = 'maxmol'

ENT.detail_items = {
	{
		name = 'Металлическая труба',
		model = 'models/props_canal/mattpipe.mdl',
		class = 'weapon_hl2pipe',
		need = {
			[LRP_DETAIL_TYPE_METAL] = 8
		}
	},
	{
		name = 'Бутылка',
		model = 'models/weapons/HL2meleepack/w_bottle.mdl',
		class = 'weapon_hl2bottle',
		need = {
			[LRP_DETAIL_TYPE_GLASS] = 6
		}
	},
	{
		name = 'Топор',
		model = 'models/weapons/hl2meleepack/w_axe.mdl',
		class = 'weapon_hl2axe',
		need = {
			[LRP_DETAIL_TYPE_METAL] = 5,
			[LRP_DETAIL_TYPE_WOOD] = 6
		}
	},
	{
		name = 'Лазерный пистолет',
		model = 'models/weapons/w_toolgun.mdl',
		class = 'lasergun',
		need = {
			[LRP_DETAIL_TYPE_METAL] = 5,
			[LRP_DETAIL_TYPE_CHIP] = 3
		}
	},
	{
		name = 'Nintendo Zapper',
		model = 'models/weapons/w_pist_nesz.mdl',
		class = 'weapon_zapper',
		need = {
			[LRP_DETAIL_TYPE_METAL] = 10,
			[LRP_DETAIL_TYPE_CHIP] = 5
		}
	},
	{
		name = 'Ломатель пропов',
		model = 'models/weapons/w_crowbar.mdl',
		class = 'lrp_prop_destroyer',
		need = {
			[LRP_DETAIL_TYPE_METAL] = 10,
		}
	},
}

function ENT:GetDetailCount(t)
	return self:GetNWInt('DetailCount_' .. t)
end

function ENT:CanCraft(i)
	for k, v in pairs(self.detail_items[i].need) do
		if self:GetDetailCount(k) < v then
			return false
		end
	end
	
	return true
end

hook.Add('InvItems', 'lrp_detail_box', function(items)
	items['lrp_detail_box'] = {
		perform = function(data)
			return {
				name = 'Коробка Для Деталей',
				model = "models/props/cs_office/cardboard_box01.mdl"
			}
		end,
		getTable = function(e)
			local t = {}
			for k, v in pairs(LS_DetailTypes) do
				t[k] = e:GetDetailCount(k)
			end

			return t
		end,
		spawn = function(data)
			local e = ents.Create('lrp_detail_box')
			for k, v in pairs(LS_DetailTypes) do
				e:SetDetailCount(k, data[k])
			end
			
			return e
		end
	}
end)