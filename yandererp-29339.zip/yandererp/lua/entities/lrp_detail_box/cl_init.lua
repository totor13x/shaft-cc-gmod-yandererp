include('shared.lua')

function ENT:RPHUDDraw()
	local tab = {'Коробка Для Деталей', 'Складывайте в нее детали', 'Нажмите Е, чтобы собрать предмет', ''}
	for k, v in pairs(LS_DetailTypes) do
		table.insert(tab, v.name .. ': ' .. self:GetDetailCount(k))
	end

	return tab
end

net.Receive('details_craft', function()
	local ent = net.ReadEntity()
	
	local menu = DermaMenu()
	gui.EnableScreenClicker(true)
	
	for k, v in pairs(ent.detail_items) do
		local submenu = menu:AddSubMenu(v.name)
		
		for k, v in pairs(v.need) do
			local opt = submenu:AddOption(LS_DetailTypes[k].name .. ': ' .. v)
			opt:SetIcon('icon16/brick.png')
			function opt:OnMousePressed() end
		end
		
		submenu:AddOption(ent:CanCraft(k) and 'Собрать' or 'Не хватает деталей', function()
			if not ent:CanCraft(k) then
				notification.AddLegacy('Не хватает деталей!', NOTIFY_ERROR, 5)
				surface.PlaySound('buttons/button15.wav')
				return
			end
			
			net.Start('details_craft')
				net.WriteEntity(ent)
				net.WriteInt(k, 8)
			net.SendToServer() 
		end):SetIcon(ent:CanCraft(k) and 'icon16/accept.png' or 'icon16/delete.png')
	end

	menu:Open()
	
	menu.OnRemove = function()
		gui.EnableScreenClicker(false)
	end
end)