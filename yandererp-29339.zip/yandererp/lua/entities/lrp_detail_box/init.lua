include('shared.lua')

AddCSLuaFile('shared.lua')
AddCSLuaFile('cl_init.lua')

function ENT:Initialize()
	if SERVER then
		self:SetModel('models/props/cs_office/cardboard_box01.mdl')
		self:PhysicsInit(SOLID_VPHYSICS)
		self:SetMoveType(MOVETYPE_VPHYSICS)
		self:SetSolid(SOLID_VPHYSICS)
		self:SetUseType(SIMPLE_USE)
		local physObj = self:GetPhysicsObject()
		if IsValid(physObj) then
			physObj:Wake()
		end
		
		self:MakeBreakable({health = 750})
	end
end

function ENT:SetDetailCount(t, i)
	self:SetNWInt('DetailCount_' .. t, i)
end

util.AddNetworkString('details_craft')
net.Receive('details_craft', function(_, ply)
	local ent = net.ReadEntity()
	local i = net.ReadInt(8)
	
	if not IsValid(ent) or ent:GetClass() ~= 'lrp_detail_box' then
		return
	end
	
	if ent:GetPos():Distance(ply:GetShootPos()) > 100 then
		return
	end
	
	for k, v in pairs(ent.detail_items[i].need) do
		if ent:GetDetailCount(k) < v then
			ent:EmitSound('buttons/button10.wav')
			return
		end
		
		ent:SetDetailCount(k, ent:GetDetailCount(k) - v)
	end
	
	local e = ents.Create('spawned_weapon')
	e:SetModel(ent.detail_items[i].model)
	e:SetPos(ent:GetPos() + ent:GetUp() * 25)
	e:SetWeaponClass(ent.detail_items[i].class)
	e.nodupe = true
	e:Spawn()
end)

function ENT:Use(_, ply)
	if IsValid(ply) and ply:IsPlayer() then
		net.Start('details_craft')
			net.WriteEntity(self)
		net.Send(ply)
	end
end

function ENT:Touch(e)
	if IsValid(e) and e:GetClass() == 'lrp_detail' and not e.boxused then
		self:SetDetailCount(e:GetDetailType(), self:GetDetailCount(e:GetDetailType()) + 1)
		e.boxused = true
		e:Remove()
	end
end