AddCSLuaFile()

ENT.Base = "alcohol"
ENT.Type = "anim"
ENT.Author = 'maxmol'
ENT.PrintName = 'Алкоголь1'
ENT.Model = 'models/props_interiors/bottles_shelf_break12.mdl'
ENT.Strength = 6