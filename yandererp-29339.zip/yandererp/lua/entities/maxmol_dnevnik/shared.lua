schoolrp_subjects = {
	'Математика',
	'Биология',
	'Химия',
	'Иностранный',
	'Информатика',
	'Физра',
	'История',
	'География',
}

ENT.gradeMarks = 5

ENT.PrintName = 'Дневник'
ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.Author = 'maxmol'

function ENT:SetupDataTables()
	self:NetworkVar('Entity', 0, 'owning_ent')
end
