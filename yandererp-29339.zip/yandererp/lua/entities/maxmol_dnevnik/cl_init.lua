include('shared.lua')

surface.CreateFont("DNEVNIK_FONT", {
	font = "Times New Roman",
	extended = true,
	size = 20,
	weight = 900,
	antialias = true,
	italic = true,
})

function ENT:RPHUDDraw()
	return {'Дневник', (IsValid(self:Getowning_ent()) and self:Getowning_ent():GetName() or ''), 'Нажми Е, чтобы открыть'}
end

local ENT = ENT
net.Receive('ReadDnevnik', function()
	local ent = net.ReadEntity()
	local tbl = net.ReadTable()
	
	local dframe = vgui.Create('DFrame')
	dframe:SetSize(420*2, 588)
	dframe:Center()
	dframe:SetTitle('Дневник ' .. ent:Getowning_ent():GetName())
	dframe.Paint = function(self, w, h)
		surface.SetDrawColor(Color(27, 116, 173))
		surface.DrawRect(0, 0, w, h)
	end
	
	local text = vgui.Create('DPanel', dframe)
	text:Dock(FILL)
	text.Paint = function(self, w, h)
		surface.SetDrawColor(color_white)
		surface.DrawRect(0, 0, w, h)
		
		local lineH = 20
		local lineW = 20
		local curH = 0
		
		surface.SetDrawColor(color_black)
		for i = 1, h/lineH do
			curH = curH + lineH
			
			surface.DrawLine(0, curH, w, curH)
		end
		
		local curW = 144
		local linesC = w/lineW - 12
		surface.SetDrawColor(color_black)
		for i = 1, linesC do
			curW = curW + lineW
			
			surface.DrawLine(curW, 0, curW, h)
		end
		
		surface.SetDrawColor(Color(27, 116, 173))
		surface.DrawRect(w/2 - 10, 0, 20, h)
		
		curH = lineH * 3
		local grade = 12

		for k, v in pairs(tbl) do
			curH = curH + lineH
			draw.SimpleText(k, "DNEVNIK_FONT", 5, curH, color_black, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM) 
			
			local sum = 0
			local noMoreMarks = false
			for i = 1, string.len(v) - 1 do
				local char = string.GetChar(v, i + 1)
				if not noMoreMarks then
					l = i < 13 and i or i + 1
					if l >= linesC - 2 then
						draw.SimpleText('...', "DNEVNIK_FONT", 144 + l * lineW + lineW/2, curH, Color(255, 64, 64), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
						noMoreMarks = true
					else
						draw.SimpleText(char, "DNEVNIK_FONT", 144 + l * lineW + lineW/2, curH, Color(255, 64, 64), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
					end
				end
				sum = sum + (tonumber(char) or 0)
			end
			
			local curgrade = math.Clamp(math.floor(sum / ENT.gradeMarks) + 1, 1, 12)
			if curgrade < grade then
				grade = curgrade
			end
			
			draw.SimpleText('Общ. ' .. sum, "DNEVNIK_FONT", 144 + lineW * linesC, curH, color_black, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM) 
		end
		
		draw.SimpleText(ent:Getowning_ent():GetName(), "DNEVNIK_FONT", lineW, lineH, color_black, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM) 
		draw.SimpleText(grade < 12 and 'Ученик ' .. grade .. ' класса' or 'Выпускник', "DNEVNIK_FONT", lineW, lineH * 2, color_black, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM) 
		
		draw.SimpleText(grade == 12 and 'Поздравляем с окончанием 11го класса!' or 'Набери ' .. (grade * ENT.gradeMarks) .. ' баллов по всем предметам', "DNEVNIK_FONT", lineW, curH + lineH * 2, color_black, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM) 
		if grade < 12 then
			draw.SimpleText((grade < 11 and 'чтобы поступить в ' .. (grade + 1) or 'чтобы закончить 11 класс') .. ' класс', "DNEVNIK_FONT", lineW, curH + lineH * 3, color_black, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM) 
			draw.SimpleText('Закончи 11 классов чтобы получить награду!', "DNEVNIK_FONT", lineW, curH + lineH * 5, color_black, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
		else
			draw.SimpleText('Чтобы получить награду, напиши в чат', "DNEVNIK_FONT", lineW, curH + lineH * 4, color_black, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM) 
			draw.SimpleText('"/выпускник"', "DNEVNIK_FONT", lineW, curH + lineH * 5, color_black, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
		end
		
		return true
	end

	dframe:MakePopup()
end)

hook.Add('PostGamemodeLoaded', 'dnevnik', function()
	GAMEMODE:DescribeCommand('dnevnik', 'Получить дневник')
end)