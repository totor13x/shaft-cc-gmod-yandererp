AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

util.AddNetworkString('ReadDnevnik')
function ENT:Use(_, ply)
	if IsValid(ply) and ply:IsPlayer() then
		net.Start('ReadDnevnik')
			net.WriteEntity(self)
			net.WriteTable(self:Getowning_ent().SchoolMarks)
		net.Send(ply)
	end
end

if not sql.TableExists('SchoolMarks') then
	PrintMessage(3, 'Дневники игроков пересозданы')

	sql.Query('CREATE TABLE SchoolMarks (SteamID string, Subject string, Marks string)')
end

local PLAYER = FindMetaTable('Player')

local ENT = ENT
hook.Add('PlayerAuthed', 'SetMarksTable', function(ply)
	ply.SchoolMarks = {}
	for k, v in pairs(schoolrp_subjects) do
		local m = sql.QueryValue('SELECT Marks FROM SchoolMarks WHERE SteamID = "' .. ply:SteamID() .. '" AND Subject = "' .. v .. '"')
		if not m then
			sql.Query('INSERT INTO SchoolMarks (SteamID, Subject, Marks) VALUES ("' .. ply:SteamID() .. '", "' .. v .. '", "H")')
			ply.SchoolMarks[v] = 'H';
		else
			ply.SchoolMarks[v] = m;
		end
	end
end)

function PLAYER:GetMarks(subject)
	return self.SchoolMarks[subject] or ''
end

function PLAYER:SetMarks(subject, marks)
	local m = sql.QueryValue('SELECT Marks FROM SchoolMarks WHERE SteamID = "' .. self:SteamID() .. '" AND Subject = "' .. subject .. '"')
	if not m then
		sql.Query('INSERT INTO SchoolMarks (SteamID, Subject, Marks) VALUES ("' .. self:SteamID() .. '", "' .. subject .. '", "' .. marks .. '")')
	else
		sql.Query('UPDATE SchoolMarks SET Marks = "' .. marks .. '" WHERE Subject = "' .. subject .. '" AND SteamID = "' .. self:SteamID() .. '"')
	end
	
	self.SchoolMarks[subject] = marks
end

function PLAYER:AddMark(subject, mark)
	self:SetMarks(subject, self:GetMarks(subject) .. mark)
end

function PLAYER:SetLastGrade(num)
	self.last_grade = num
end

function PLAYER:GetGrade()
	local grade = 12
	for k, v in pairs(self.SchoolMarks) do
		local sum = 0
		for i = 2, string.len(v) do
			local char = string.GetChar(v, i)
			sum = sum + (tonumber(char) or 0)
		end
				
		local curgrade = math.Clamp(math.floor(sum / 5) + 1, 1, 12)
		if curgrade < grade then
			grade = curgrade
		end
	end
	return grade
end

function ENT:Initialize()
	self:SetModel('models/school/notepad.mdl')
	self:SetSkin(1)
	
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)
	local physObj = self:GetPhysicsObject()
	if IsValid(physObj) then
		physObj:SetMass(50)
		physObj:Wake()
	end

	MPP.ghost(self)

	self:MakeBreakable({
		health = 50
	})
end

local gradeMarks = ENT.gradeMarks

hook.Add('PostGamemodeLoaded', 'Dnevnik_command', function()
	GAMEMODE:AddCommand('dnevnik', function(ply)
		if IsValid(ply.dnevnik) then
			ply.dnevnik:SetPos(GAMEMODE.playerDropPos(ply))
			ply.dnevnik:SetAngles(ply:EyeAngles())
		else
			ply.dnevnik = ents.Create('maxmol_dnevnik')
			ply.dnevnik:SetPos(GAMEMODE.playerDropPos(ply))
			ply.dnevnik:SetAngles(ply:EyeAngles())
			ply.dnevnik:Setowning_ent(ply)
			ply.dnevnik.rp_owner = ply
			ply.dnevnik:Spawn()
			ply.rp_ents = ply.rp_ents or {}
			table.insert(ply.rp_ents, ply.dnevnik)
		end
	end)

	
	GAMEMODE:AddCommand('выпускник', function(ply)
		local grade = ply:GetGrade()
		
		if grade < 12 then
			ply:ChatPrint('Ты не закончил 11 классов!')
			return
		end
		
		if ply:HasPointshopItem('Graduation') then
			ply:ChatPrint('Ты уже получил награду')
			return
		end
		
		ply:ChatPrint('Вы получили в награду за окончание 11 классов - шапку "Graduation" и 30 поинтов и 5000 йен')
		ply:AddPointshopItem('Graduation')
		ply:AddPoints(30)
		ply:addMoney(5000)
	end)
	
end)


function ENT:Think()
	if not IsValid(self:Getowning_ent()) then
		self:Remove()
	end
end