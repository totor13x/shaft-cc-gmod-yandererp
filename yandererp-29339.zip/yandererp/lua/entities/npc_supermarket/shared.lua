ENT.Base = 'npc_base'
ENT.Type = 'ai'
ENT.PrintName = 'Продавец продуктов'
ENT.Model = 'models/player/shi/maql.mdl'
ENT.Sequence = 'idle_suitcase'
ENT.SpawnPoint = Vector(675, -1328, 92)

local function buy(self, ply, ent)
	local bought_ent = ents.Create('spawned_food')
	if self.model then
		bought_ent:SetModel(self.model)
	end
	bought_ent:PhysicsInit(SOLID_VPHYSICS)
	bought_ent:SetPos(ent.SpawnPoint)
	bought_ent:Spawn()

	bought_ent.FoodEnergy = self.price / 3
end

ENT.Items = {
	{
		name = 'Кавун',
		model = 'models/props_junk/watermelon01.mdl',
		price = 135,
		buy = buy
	},
	{
		name = 'Картошка',
		model = 'models/props_phx/misc/potato.mdl',
		price = 45,
		buy = buy
	},
	{
		name = 'Банан',
		model = 'models/props/cs_italy/bananna.mdl',
		price = 45,
		buy = buy
	},
	{
		name = 'Связка бананов',
		model = 'models/props/cs_italy/bananna_bunch.mdl',
		price = 105,
		buy = buy
	},
	{
		name = 'Апельсин',
		model = 'models/props/cs_italy/orange.mdl',
		price = 45,
		buy = buy
	},
	{
		name = 'Варёное яйцо',
		model = 'models/props_phx/misc/egg.mdl',
		price = 75,
		buy = buy
	},
	{
		name = 'Квас',
		model = 'models/props_junk/garbage_plasticbottle003a.mdl',
		price = 75,
		buy = buy
	},
	{
		name = 'Кефир',
		model = 'models/props_junk/garbage_milkcarton002a.mdl',
		price = 75,
		buy = buy
	},
}