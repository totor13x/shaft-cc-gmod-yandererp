ENT.Type = 'anim'
ENT.Base = 'base_anim'
ENT.PrintName = 'Футбольный мяч'
ENT.Spawnable = true
