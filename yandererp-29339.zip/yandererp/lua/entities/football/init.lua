include('shared.lua')

AddCSLuaFile('shared.lua')
AddCSLuaFile('cl_init.lua')

ENT.Center = Vector(3424, 283, 8)

function ENT:StartMatch()
	if not self.match then
		self:SetPos(self.Center)
		self:GetPhysicsObject():EnableMotion(false)
		
		timer.Simple(3, function()
			if IsValid(self) then
				self.match = true
				self:GetPhysicsObject():EnableMotion(true)
				self:Activate()
			end
		end)
	end	
end

function ENT:Notify(...)
	for i, ply in ipairs(player.GetAll()) do 
		if ply:GetPos():WithinAABox(Vector(3950, -382, 8), Vector(2954, 982, 550)) then
			GAMEMODE:ChatPrintTo(ply, Color(128, 255, 128), '[Футбол] ', Color(255, 255, 255), ...)	
		end
	end	
end

function ENT:OnField()
	return self:GetPos():WithinAABox(Vector(3776, -344, 8), Vector(3072, 912, 500))
end

function ENT:Initialize()
	self:SetModel('models/props_phx/misc/soccerball.mdl')
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetTrigger(true)
	self.match = true
	
	local len = 0.3
	local start = 32
	local end_n = 0
	
	util.SpriteTrail(self, 0, Color(255, 0, 255), true, start, end_n, len, 1 / (start + end_n) * 0.5, 'trails/plasma')
	
	self:SetCollisionGroup(COLLISION_GROUP_WEAPON)

	for i, ball in ipairs(ents.FindByClass('football')) do
		if ball ~= self then
			SafeRemoveEntity(ball)
		end
	end

	timer.Simple(0, function()
		local owner = self.rp_owner
		if IsValid(owner) and not self:OnField() then
			GAMEMODE:Error(owner, 'Вы не можете вытаскивать мяч за пределами поля!')
			SafeRemoveEntity(self)
		end
	end)
end

--https://steamcommunity.com/sharedfiles/filedetails/?id=293904092
function ENT:PhysicsUpdate(phys)
	if self:IsPlayerHolding() then
		return
	end

	phys:SetMass(10)
	phys:SetBuoyancyRatio(1.5)
	phys:SetDamping(0.25 , 1)
	
	if not self:OnField() and phys:IsMoveable() then
		phys:EnableMotion(false)
		self:Notify('мяч вылетел за пределы поля!')
		--self.match = false
		--self:StartMatch()
	end
end

function ENT:GravGunPickupAllowed()
	return false
end

function ENT:PhysicsCollide()
	local pos = self:WorldSpaceCenter()
	if self.match == true and (pos:WithinAABox(Vector(3516, -268, 8), Vector(3340, -320, 108)) or pos:WithinAABox(Vector(3516, 836, 8), Vector(3344, 884, 108))) then
		self.match = false
		
		self:Notify(self.last_player, ' забил гол!')
		self:EmitSound('garrysmod/save_load4.wav', 75, 50)
		
		local ed = EffectData()
		ed:SetOrigin(self:GetPos())
		ed:SetScale(0.1)
		util.Effect('VortDispel', ed)
		
		timer.Simple(2, function()
			self:StartMatch()
		end)
	end
end

function ENT:MakeSound()
	if self.cooldown and self.cooldown > CurTime() then
		return	
	end

	self:EmitSound('Rubber.BulletImpact')
	self.cooldown = CurTime() + 0.25
end

function ENT:StartTouch(ent)
	local phys = self:GetPhysicsObject()
	if not self:OnField() and not phys:IsMoveable() then
		phys:EnableMotion(true)
		self:SetPos(self:GetPos() + (self.Center - self:WorldSpaceCenter()):GetNormalized() * 15)
	end
	
	if IsValid(ent) and ent:IsPlayer() then
		local pos = self:WorldSpaceCenter()
		pos = Vector(pos.x, pos.y, 20)
		
		self:MakeSound()
		phys:SetVelocityInstantaneous((pos - ent:GetPos()) * ent:GetVelocity():Length() / 15)
		
		self.last_player = ent
	end
end