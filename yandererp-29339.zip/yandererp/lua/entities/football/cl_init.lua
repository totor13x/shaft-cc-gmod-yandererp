include('shared.lua')

function ENT:Initialize()
	self:SetCollisionGroup(COLLISION_GROUP_WEAPON)
end
