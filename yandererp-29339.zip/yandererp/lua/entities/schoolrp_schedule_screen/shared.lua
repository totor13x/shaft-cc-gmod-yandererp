ENT.Type = 'anim'
ENT.Base = 'base_anim'

function ENT:Initialize()
	self:SetModel("models/squad/sf_plates/sf_plate8x8.mdl")
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	
	if SERVER then self:PhysicsInit(SOLID_VPHYSICS) end
end

ENT.cabinets = {
	Vector(521, 51, 89),
	Vector(519, 456, 84),
	Vector(2392, 1719, 93),
	Vector(2393, 1339, 88),
	Vector(1753, 53, 224),
	Vector(3083, 404, 72),
	Vector(2393, 931, 95),
	Vector(2004, 18, 91),
}

function GetCurrentSchoolSubject()
	local sky_time = Sky.GetTime()
	local current_hour = math.floor(sky_time)
	current_subject = current_hour
	current_subject = math.ceil((current_subject - 7)/2)

	if current_subject < 1 or current_subject > 5 then
		current_subject = nil
	elseif sky_time > 17.75 or (sky_time - current_hour > .75 and current_hour/2 % 2 ~= 0) then
		current_subject = nil
	end

	return current_subject and schoolrp_schedule[current_subject]
end