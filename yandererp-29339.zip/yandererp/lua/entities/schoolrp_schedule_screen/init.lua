AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

util.AddNetworkString('schoolrp_schedule_send')

if not schoolrp_schedule then
	schoolrp_schedule = {
		'Математика',
		'Биология',
		'Химия',
		'Иностранный',
		'Информатика',
	}
end

net.Receive('schoolrp_schedule_send', function(len, ply)
    if ply:Team() != TEAM_DIRECTOR and ply:Team() != TEAM_HALFDIRECTOR then return end
    
    local num = net.ReadUInt(4)
    local subj = net.ReadUInt(4)
    
    if num >= 1 and num <= 5 and subj >= 1 and subj <= 9 then
        schoolrp_schedule[num] = schoolrp_subjects[subj]
        
        net.Start('schoolrp_schedule_send')
            net.WriteUInt(num, 4)
            net.WriteUInt(subj, 4)
        net.Broadcast()
    end
end)

hook.Add('PlayerFullyLoaded', 'schoolrp_schedule', function(ply)
    for i = 1, 5 do
        net.Start('schoolrp_schedule_send')
            net.WriteUInt(i, 4)
            net.WriteUInt(table.KeyFromValue(schoolrp_subjects, schoolrp_schedule[i]) or 0, 4)
        net.Send(ply)
    end
end)

local cabinets = ENT.cabinets
local meta = FindMetaTable('Player')
function meta:IsInClass()
	local subj = GetCurrentSchoolSubject()

	if subj then
		local subj_i = table.KeyFromValue(schoolrp_subjects, subj)
		if subj_i then
			local pos = cabinets[subj_i]
			local tr = util.TraceLine({
				start = self:GetShootPos(),
				endpos = pos,
				mask = MASK_SOLID_BRUSHONLY,
			})

			return not tr.Hit
		end
	end

	return false
end