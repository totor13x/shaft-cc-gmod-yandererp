include("shared.lua")
schoolrp_schedule = schoolrp_schedule or {}
local schoolrp_subjects = schoolrp_subjects

local frame
local change_subject = function(subject_number)
	local tm = LocalPlayer():Team()
	if tm != TEAM_DIRECTOR and tm != TEAM_HALFDIRECTOR then
		chat.AddText(Color(255, 0, 0), 'Только директор может менять расписание!')
		return
	end
	
	frame = vgui.Create('DFrame')
	frame:SetSize(200, 275)
	frame:Center()
	frame:SetTitle('Выберите предмет')
	frame:MakePopup()
	frame.btnMaxim:Hide()
	frame.btnMinim:Hide()
	
	local list = vgui.Create('DListView', frame)
	list:SetSize(250, 340)
	list:Dock(FILL)
	list:SetMultiSelect(false)
	list:AddColumn('Предметы')
	
	for k, v in pairs(schoolrp_subjects) do
		local line = list:AddLine(v)
	end
	
	list:AddLine('Нет Урока')
	
	list.OnRowSelected = function(panel, line)
		net.Start('schoolrp_schedule_send')
			net.WriteUInt(subject_number, 4)
			net.WriteUInt(line, 4)
			
			--local text = panel:GetLine(line):GetColumnText(1)
			--net.WriteString(text == 'Нет Урока' and '' or text)
		net.SendToServer()
		surface.PlaySound('buttons/button9.wav')
		frame:Close()
	end
end

net.Receive('schoolrp_schedule_send', function()
	local num = net.ReadUInt(4)
	local subj = net.ReadUInt(4)

	schoolrp_schedule[num] = schoolrp_subjects[subj]
end)

local schedule = schoolrp_schedule

local current_subject
local show_subject
local current_time = "00:00"
local current_text
local old_text
local should_draw = true

timer.Create('_check_current_class', 1, 0, function()
	local sky_time = Sky.GetTime()
	
	show_subject = nil
	local current_hour = math.floor(sky_time)
	current_subject = current_hour
	current_subject = math.ceil((current_subject - 7)/2)
	
	local hours = string.format("%02.f", current_hour)
	local mins = string.format("%02.f", math.floor(sky_time*60 - (hours*60)))
	
	current_time = hours .. ':' .. mins
	
	current_text = nil
	if current_subject < 1 or current_subject > 5 then
		current_subject = nil
	elseif sky_time < 17.75 then
		if sky_time - current_hour < .75 or current_hour/2 % 2 == 0 then
			current_text = schedule[current_subject] or 'Нет Урока'
			show_subject = table.KeyFromValue(schoolrp_subjects, current_text)
		else
			show_subject = table.KeyFromValue(schoolrp_subjects, schedule[current_subject + 1])
			current_text = 'Перемена / Потом ' .. (schedule[current_subject + 1] or 'нет урока')
			current_subject = nil
		end	
	else
		current_subject = nil
	end

	if old_text != current_text then
		sound.Play('lampoviy_server/zvonok.mp3', Vector(1456, 943, 200), 120, 150, 0.1)
		old_text = current_text
	end
	
	--local lp = LocalPlayer()
	--if IsValid(lp) then
		--local pos = lp:GetPos()
		--should_draw = LocalPlayer():GetJobTable().category != 'Городские профессии' and pos.x < -2459 and pos.y < 2867
	--end
end)

function ENT:Draw()
	if self:GetPos():DistToSqr(EyePos()) < 200000 then
	local hovered
	
	local tr = LocalPlayer():GetEyeTrace()
	
	
	if tr.Entity == self then
		local z = (self:GetPos().z - tr.HitPos.z) * 4
		local number = math.floor(z / 30)
		
		if number >= -9 and number <= -5 then
			hovered = number
			
			if input.IsKeyDown(KEY_E) then
				if not self.down and not IsValid(frame) then
					self.down = true
					change_subject(hovered + 10)
				end
			else
				self.down = nil
			end
		end
	end

	cam.Start3D2D(self:GetPos(), self:GetAngles(), 0.25)
		surface.SetDrawColor(0, 0, 0)
		surface.DrawRect(0, -300, 400, 200)
		
		if hovered then
			surface.SetDrawColor(96, 96, 96)
			surface.DrawRect(0, hovered * 30 - 2, 400, 30)
		end

		if current_subject then
			surface.SetDrawColor(128, 64, 64, 200)
			surface.DrawRect(0, (current_subject-10) * 30 - 2, 400, 30)
		end
		
		for i = 1, 5 do
			local hour = 6 + i * 2
			if hour < 10 then
				hour = '0' .. hour
			end
			
			draw.SimpleText('[ ' .. hour .. ':00 - ' .. (hour + 1) .. ':45 ] ' .. (schedule[i] or 'Нет Урока'), 'nunito24', 10, -300 + i * 30, color_white)
		end
	cam.End3D2D()
	
	end
end

surface.CreateFont("schoolrp_schedule", {
	font = "nunito",
	weight = 900,
	extended = false,
	size = 32,
	antialias = true,
})

surface.CreateFont("schoolrp_schedule2", {
	font = "nunito",
	extended = true,
	size = 24,
	antialias = true,
	shadow = true,
})

hook.Add('HUDPaint', 'schoolrp_schedule', function()
	surface.SetFont('schoolrp_schedule')
	surface.SetTextColor(255, 255, 255)
	surface.SetTextPos(16, 10)
	
	local tw, th = surface.GetTextSize(current_time)
	
	draw.RoundedBox(8, 12, 10, tw + 8, th, Color(50, 60, 70))
	surface.DrawText(current_time)

	if should_draw and current_text then
		surface.SetFont('schoolrp_schedule2')
		surface.SetTextPos(100, 14)
		tw, th = surface.GetTextSize(current_text)
		draw.RoundedBox(8, 96, 14, tw + 8, th, Color(50, 60, 70))
		surface.DrawText(current_text)
	end
end)

local cabinets = ENT.cabinets
hook.Add('HUDPaintBackground', 'schoolrp_schedule', function()
	if should_draw and show_subject and cabinets[show_subject] then
		local subject_name = schoolrp_subjects[show_subject]
		
		if subject_name then
			local pos2d = cabinets[show_subject]:ToScreen()
			
			if pos2d.visible then
				surface.SetDrawColor(200, 64, 96)
				draw.NoTexture()
				
				local x, y = math.floor(pos2d.x), math.floor(pos2d.y)
				local f = {	
					{x = x, 		y = y - 6},
					{x = x + 6,	y = y},
					{x = x, 		y = y + 6},
					{x = x - 6,	y = y},
				}
				
				surface.DrawPoly(f)
				
				surface.SetFont('schoolrp_schedule2')
				surface.SetTextColor(255, 255, 255)
				local tw = surface.GetTextSize(subject_name)
				surface.SetTextPos(x - tw/2, y - 30)
				surface.DrawText(subject_name)
			end
		end
	end
end)