ENT.PrintName = 'LRP PhotoPrint'
ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.Author = 'maxmol'
ENT.Spawnable = true

function ENT:SetupDataTables()
	self:NetworkVar('String', 0, 'URL')
	self:NetworkVar('Entity', 0, 'owning_ent')
end
