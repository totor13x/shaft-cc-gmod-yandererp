include('shared.lua')

function ENT:Draw()
	self:DrawModel()
	
	local pos = self:GetPos()
	local ang = self:GetAngles()
	ang:RotateAroundAxis(ang:Up(), 90)
	
	pos = pos + ang:Up() * 8
	local distance = EyePos():Distance(pos)
	if distance < 400 then
		cam.Start3D2D(pos, ang, 0.125)
			draw.SimpleTextOutlined('LRP PhotoPrint', 'Trebuchet24', 0, 0, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 2, color_black)
		cam.End3D2D()
	end
end

net.Receive('lrp_photoprint_request', function()
	local ent = net.ReadEntity()
	if IsValid(ent) then
		Derma_StringRequest(
			'Распечатать Картинку',
			'Вставьте сюда ссылку на изображение (оканч. на: ".png", ".jpg", ...)',
			'http://DOMAIN.NAME/filename.png',
			function(text) 
				if IsValid(ent) then
					net.Start('lrp_photoprint_request') 
						net.WriteString(text) 
						net.WriteEntity(ent)
					net.SendToServer() 
				end
			end,
			nil,
			'Распечатать',
			'Отмена'
		)
	 end
end)
