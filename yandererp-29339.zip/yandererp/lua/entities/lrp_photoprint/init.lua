include('shared.lua')

AddCSLuaFile('shared.lua')
AddCSLuaFile('cl_init.lua')

function ENT:Initialize()
	self:SetModel('models/props_c17/consolebox03a.mdl')
	
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)
	local physObj = self:GetPhysicsObject()
	if IsValid(physObj) then
		physObj:Wake()
	end
	
	self:MakeBreakable({health = 500})
end

function ENT:Use(ply)
	if IsValid(self:Getowning_ent()) and ply ~= self:Getowning_ent() then
		return	
	end
	
	net.Start('lrp_photoprint_request')
		net.WriteEntity(self)
	net.Send(ply)
end

util.AddNetworkString('lrp_photoprint_request')
net.Receive('lrp_photoprint_request', function(len, ply)
		
	if len > 8192 then
		ply:PrintMessage(3, 'Ссылка слишком длинная')
		return
	end
		
	local url = net.ReadString()
	local ent = net.ReadEntity()
		
	if not IsValid(ent) or ent:GetClass() ~= 'lrp_photoprint' then return end
		
	if IsValid(ent:Getowning_ent()) and ply ~= ent:Getowning_ent() then
		return	
	end
		
	local format = url:sub(url:len() - 3)

	if format == '.png' or format == '.jpg' or format == '.gif' or format == '.tga' or url:sub(url:len() - 4) == '.jpeg' or url:sub(0, 46) == 'http://images.akamai.steamusercontent.com/ugc/' then
		PrintPhoto(url, ent:GetPos() + Vector(0, 0, 10))
		ent:TakeDamage(250)
		ent:EmitSound('items/nvg_on.wav')
	else
		ply:PrintMessage(3, 'Это не изображение.')
	end
end)
