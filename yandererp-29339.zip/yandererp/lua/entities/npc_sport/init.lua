AddCSLuaFile('shared.lua')
include('shared.lua')
DEFINE_BASECLASS( "npc_base" )

function ENT:UpdateTransmitState()
	if self.hidden then
		return TRANSMIT_NEVER
	end
	
	return TRANSMIT_PVS
end

function ENT:Think()
	BaseClass.Think(self)
	
	if team.NumPlayers(TEAM_TEACHER_SPORT) > 0 then
		self:SetSolid(0)
		self.hidden = true
	else
		self:SetSolid(SOLID_BBOX)
		self.hidden = false
	end
	self:AddEFlags( EFL_FORCE_CHECK_TRANSMIT )
	self:NextThink(CurTime() + 20)
	return true	
end