ENT.Base = 'npc_base'
ENT.Type = 'ai'
ENT.PrintName = 'Учитель физкультуры'
ENT.Model = 'models/corpseparty/yuuya/yuuya.mdl'
ENT.Sequence = 'pose_standing_01'

local spawncooldown = 0
ENT.Items = {
	{
		name = 'Получить мячик',
		model = 'models/props_phx/misc/soccerball.mdl',
		price = 0,
		canbuy = function(self, ply, ent)
			if #ents.FindByClass('football') > 0 then
				ent:Say('На поле уже есть мяч, ' .. ply:GetName() .. '!')
				return false
			end
			
			return true
		end,
		buy = function(self, ply, ent)
			ent:Say('Твой мяч ждёт тебя на футбольном поле, ' .. ply:GetName() .. '!')

			local bought_ent = ents.Create('football')
			bought_ent:SetPos(bought_ent.Center)
			bought_ent:Spawn()
		end
	}, 
}