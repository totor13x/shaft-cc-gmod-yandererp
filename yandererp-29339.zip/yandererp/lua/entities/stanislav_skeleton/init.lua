include('shared.lua')

AddCSLuaFile('shared.lua')
AddCSLuaFile('cl_init.lua')

function ENT:Initialize()
	self:SetModel('models/player/skeleton.mdl')
	self:PhysicsInitBox(Vector(-5, -22.5, 0), Vector(5, 22.5, 70))
end