include('shared.lua')

function ENT:ResetBones()
	for i = 0, self:GetBoneCount() do 
		self:ManipulateBoneScale(i, Vector(1, 1, 1))
	end
end

local lastbone = {bone = -1, scale = Vector(1, 1, 1)}
local bone_desc = {
	[0] = {'Таз', 'Обеспечивает прикрепление к туловищу', 'нижних конечностей, является', 'опорой и вместилищем органов'},
	[3] = {'Рёбра и позвоночник', 'Защищают лёгкие и сердце', 'от внешнего воздействия'},
	[6] = {'Череп', 'Защищает мозг от внешнего воздействия'},
	[9] = {'Правая плечевая кость', 'Cкелетная основа плеча', 'Относится к скелету верхней конечности'},
	[10] = {'Лучевая и локтевая кости'},
	[11] = {'Тут должна быть кисть..'},
	[16] = {'И здесь тоже..'},
	[14] = {'Левая плечевая кость', 'Cкелетная основа плеча', 'Относится к скелету верхней конечности'},
	[15] = {'Лучевая и локтевая кости'},
	[18] = {'Правая бедренная кость'},
	[19] = {'Малая и большая берцовые кости'},
	[20] = {'ананас'},
	[22] = {'Левая бедренная кость'},
	[23] = {'Малая и большая берцовые кости'},
	[24] = {'лимон'}
	
}

function ENT:RPHUDDraw()
	local trace = LocalPlayer():GetEyeTrace()

	if trace.PhysicsBone and trace.Entity == self then
		bone = self:TranslatePhysBoneToBone(trace.PhysicsBone)
		
		if lastbone.bone ~= bone then
			self:ManipulateBoneScale(lastbone.bone, lastbone.scale)
			
			lastbone.bone = bone
			lastbone.scale = self:GetManipulateBoneScale(bone)
		end
		
		local s = math.sin(CurTime() * 5) / 30 + 0.1
		self:ManipulateBoneScale(bone, lastbone.scale + Vector(s, s, s))
		
		return bone_desc[bone] or {bone}, self:GetBonePosition(bone)
	end
	
	self:ResetBones()
	
	return 
end