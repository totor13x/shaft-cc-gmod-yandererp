AddCSLuaFile()

ENT.Base = "doorportal_base"
ENT.Type = "anim"
ENT.ExitPoint = Vector(-2708, -1567, 50)
ENT.AddAng = Angle(0, 180, 0)