ENT.Base = 'npc_base'
ENT.Type = 'ai'
ENT.PrintName = 'Учительница Химии'
ENT.Model = 'models/player/dewobedil/persona5/tae_takemi/doctor_p.mdl'
ENT.Sequence = 'pose_standing_01'

local spawncooldown = 0
ENT.Items = {
	{
		name = 'Получить пробирку',
		model = 'models/props/alchemy/fiole_ballon01.mdl',
		price = 0,
		canbuy = function(self, ply, ent)
			if ply:GetJobTable().adult then
				ent:Say('Ты не ученик, ' .. ply:GetName() .. '!')
				return false
			end
			
			if GetCurrentSchoolSubject() ~= 'Химия' then
				ent:Say('Сейчас не химия, ' .. ply:GetName() .. '!')
				return false
			end
			
			if ply.chem_npc and ply.chem_npc > CurTime() then
				ent:Say('Я не даю больше одной пробирки за урок, ' .. ply:GetName() .. '!')
				return false
			end
			
			ply.chem_npc = CurTime() + 600
			
			return true
		end,
		buy = function(self, ply, ent)
			local bought_ent = ents.Create('spl_alchemy_potion')
			bought_ent:SetPos(ent:GetPos() + ent:GetForward() * 30 + ent:GetUp() * 40)
			bought_ent:Spawn()
		end
	}, 
}