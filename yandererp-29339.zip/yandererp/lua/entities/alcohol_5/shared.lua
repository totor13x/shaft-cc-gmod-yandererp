AddCSLuaFile("shared.lua")

ENT.Base = "alcohol"
ENT.Model = 'models/props_interiors/bottles_shelf_break04.mdl'
ENT.Strength = 6