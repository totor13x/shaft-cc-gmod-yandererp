include('shared.lua')

AddCSLuaFile('shared.lua')
AddCSLuaFile('cl_init.lua')

if not sql.TableExists('bank_money') then
	sql.Query('CREATE TABLE bank_money (stm string, m int)')
end

local meta = FindMetaTable('Player')
function meta:SetBankMoney(m)
	m = tonumber(m)
	if not m then error('invalid amount') end

	m = math.floor(m)

	self:SetNWInt('bank_money', m)

	sql.Query('UPDATE bank_money SET m = ' .. m .. ' WHERE stm = ' .. SQLStr(self:SteamID()))
end

function meta:AddBankMoney(m)
	self:SetBankMoney(self:GetBankMoney() + m)
end

hook.Add('PlayerAuthed', 'bank_money', function(ply)
	local query = sql.QueryRow( 'SELECT * FROM bank_money WHERE stm = ' .. SQLStr(ply:SteamID()))
	local money = query and query.m or false
	if money then 
		ply:SetBankMoney(money)
	else
		local m = GAMEMODE.Settings.start_money or 0
		sql.Query('INSERT INTO bank_money(stm, m) VALUES (' .. SQLStr(ply:SteamID()) .. ', ' .. m .. ')')
		ply:SetBankMoney(m)
	end
end)

function ENT:Initialize()
	self:SetModel('models/vall_models/terminal_qiwi/terminal_qiwi_ver01.mdl')
	self:PhysicsInit(SOLID_VPHYSICS)

	self:GetPhysicsObject():EnableMotion(false)
end

util.AddNetworkString('qiwi_transfer')
net.Receive('qiwi_transfer', function(l, ply)
	local amount = net.ReadInt(32 /*не ну а чё вдруг миллиардер*/)

	if net.ReadBool() then
		if ply:CanAfford(amount) and amount > 0 then
			ply:AddBankMoney(amount)
			ply:AddMoney(-amount)

			GAMEMODE:Notify(ply, 'Вы успешно пополнили баланс!')
		else

			GAMEMODE:Error(ply, 'Ошибка!')
		end
	else
		if ply:GetBankMoney() >= amount and amount > 0 then
			ply:AddBankMoney(-amount)
			ply:AddMoney(amount)

			GAMEMODE:Notify(ply, 'Вы успешно сняли ' .. GAMEMODE.formatMoney(amount) .. '!')
		else

			GAMEMODE:Error(ply, 'Ошибка!')
		end
	end
end)