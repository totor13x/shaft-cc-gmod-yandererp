include('shared.lua')

http.Fetch('https://pngimage.net/wp-content/uploads/2018/06/qiwi-logo-png-3.png', function(img) 
	file.Write('qiwi.png', img)
end)
http.Fetch('http://pngimg.com/uploads/cursor/cursor_PNG94.png', function(img)
	file.Write('cursor_arrow.png', img)
end)
/*http.Fetch('https://carlitoz.com/images/cursor-finger-hand-hyperlink-link-mouse-pointer.png', function(img) 
	file.Write('cursor_hand1.png', img)
end)*/

local qiwi_material = Material('data/qiwi.png')
local cursor_arrow_material = Material('data/cursor_arrow.png')
//local cursor_hand_material = Material('data/cursor_hand1.png')
local toggle = false

surface.CreateFont('QIWIFont', {
	weight = 1000,
	size = 19,
})

local starty = 90
local buttons = {
	{
		text = 'Пополнить',
		color = Color(128, 128, 255, 255),
		func = function()
			Derma_StringRequest('', 'Введите сумму','',
				function(text)
					local amount = tonumber(text)
					if amount then
						net.Start('qiwi_transfer')
						net.WriteInt(tonumber(text), 32)
						net.WriteBool(true)
						net.SendToServer()
					end
					toggle = false
				end,
				function(text) 
					toggle = false 
				end
			)
		end,
	},
	{
		text = 'Снять',
		textcolor = Color(0, 0, 0, 255),
		color = Color(220, 220, 220, 255),
		func = function()
			Derma_StringRequest('', 'Введите сумму','',
				function(text)
					local amount = tonumber(text)
					if amount then
						net.Start('qiwi_transfer')
						net.WriteInt(tonumber(text), 32)
						net.WriteBool(false)
						net.SendToServer()
					end
					toggle = false
				end,
				function(text) 
					toggle = false 
				end
			)
		end
	},
	{
		text = 'Донат',
		color = Color(255, 128, 0, 255),
		func = function()
			surface.PlaySound('buttons/button10.wav')
			RunConsoleCommand('ls_shop')

			timer.Simple(1, function() toggle = false end)
		end
	},
}

for i, button in ipairs(buttons) do
	surface.SetFont('QIWIFont')
	button.textx = 92 + 128 / 2 - surface.GetTextSize(button.text) / 2
	
	if i == 1 then
		button.y = starty
		continue
	end
	
	button.y = buttons[i - 1].y + 36
end

function ENT:Initialize()
	if self:IsValid() then
		self.Pos = self:WorldSpaceCenter() - self:GetUp() * 6.25 + self:GetRight() * 7.75 - self:GetForward() * 27

		local ang = self:GetAngles()
		ang:RotateAroundAxis(self:GetUp(), 90)
		ang:RotateAroundAxis(self:GetRight(), 35)
		self.Ang = ang
	end
end

function ENT:Draw()
	self:DrawModel()

	if self:GetPos():DistToSqr(LocalPlayer():GetPos()) > 50000 then return end
	
	local pos, ang = self.Pos, self.Ang

	local trace, x, y = LocalPlayer():GetEyeTrace(), 0, 0
	if trace.Entity == self then
		local vec = pos - trace.HitPos
		vec:Rotate(self:GetAngles())
		y = math.Clamp(-vec.y * 20, 0, 304)
		if trace.HitPos.z < pos.z then
			x = math.min(math.sqrt(vec.x * vec.x + vec.z * vec.z) * 20, 248)
		end
	end
	
	cam.Start3D2D(pos, ang , 0.05)
		surface.SetDrawColor(Color(255, 255, 255))
		surface.DrawRect(0, 0, 312, 256)
		
		surface.SetMaterial(qiwi_material)
		surface.DrawTexturedRect(90, 10, 125, 125 * 0.4) -- 40 * 2.5, 40)
		
		for i, button in ipairs(buttons) do
			if y and x and (x > button.y and x < button.y + 32) and (y > 92 and y < 92 + 128) then
				button.hovering = true
				if input.IsKeyDown(KEY_E) and not toggle then
					button.func()
					toggle = true
				end
			else
				button.hovering = false
			end

			draw.RoundedBox(12, 92, button.y, 128, 32, button.hovering and Color(button.color.r - 25, button.color.g - 25, button.color.b - 25) or button.color)
			draw.SimpleText(button.text, 'QIWIFont', button.textx, button.y + 6, button.textcolor or Color(255, 255, 255, 255))
		end

		local text = 'На счету: ' .. GAMEMODE.formatMoney(LocalPlayer():GetBankMoney())

		surface.SetTextColor(Color(100, 100, 100, 255))
		surface.SetFont('QIWIFont')
		surface.SetTextPos(312 / 2 - surface.GetTextSize(text) / 2, 212.5)
		surface.DrawText(text)
			
		if x and y and x < 250 and y < 315 and x > -8 and y > -8 then
			surface.SetDrawColor(Color(255, 255, 255))
			
			surface.SetMaterial(cursor_arrow_material)
			surface.DrawTexturedRect(y, x, 12, 12 * 1.5)
		end
	cam.End3D2D()
end