ENT.Base = 'base_anim'
ENT.Type = 'anim'
ENT.PrintName = 'Терминал QIWI'
ENT.Spawnable = true


local meta = FindMetaTable('Player')
function meta:GetBankMoney()
	return self:GetNWInt('bank_money', 0)
end