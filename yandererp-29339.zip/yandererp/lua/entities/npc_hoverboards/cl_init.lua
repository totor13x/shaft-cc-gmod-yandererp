include('shared.lua')

local modelcvar = CreateClientConVar('hboard_model', 'models/dav0r/hoverboard/hoverboard.mdl', true, false)
local exists = false
local tag = ENT.Tag

function ENT:OpenMenu()
	gui.EnableScreenClicker(true)

	if exists then return end
	exists = true

	local panel = vgui.Create('DFrame')
	panel:SetTitle('Тайтл')
	panel:SetSize(800, 450)
	panel:Center()

	function panel:OnClose()
		gui.EnableScreenClicker(false)
		exists = false
	end

	local hpanel = vgui.Create('DPanel', panel)
	hpanel.select = vgui.Create('PropSelect', hpanel)
	hpanel.select:SetConVar('hboard_model')
	hpanel.select.Label:SetText('Выберите модель')
	hpanel.select.Label:SetFont('TargetIDSmall')

	for _, board in pairs(HoverboardTypes) do
		hpanel.select:AddModel(board.model)
		hpanel.select.Controls[#hpanel.select.Controls]:SetToolTip(board.name or "Unknown")
	
		hpanel.select.HoverboardTable = HoverboardTypes
	end

	hpanel:SetSize(panel:GetWide(), panel:GetTall() / 4)
	hpanel:SetPos(5, panel:GetTall() / 15)
	hpanel.select:SetSize(hpanel:GetSize())

	local trailcolor = vgui.Create('DColorMixer', panel)
	trailcolor:SetPos(15, panel:GetTall() / 3)
	trailcolor:SetLabel('Цвет трейла')
	trailcolor:SetAlphaBar(false)
	trailcolor:SetColor(Color(90, 90, 180))
	trailcolor.label:SetFont('TargetIDSmall')

	local mousecontrol = vgui.Create('DCheckBoxLabel', panel)
	mousecontrol:SetPos(trailcolor.X * 6 + trailcolor:GetWide(), trailcolor.Y * 1.15)
	mousecontrol:SetTextColor(Color(255, 255, 255))
	mousecontrol:SetFont('TargetIDSmall')
	mousecontrol:SetText('Включить управление мышью?')
	mousecontrol:SetValue(true)

	local boostshake = vgui.Create('DCheckBoxLabel', panel)
	boostshake:SetPos(mousecontrol.X, mousecontrol.Y + mousecontrol:GetTall() * 2)
	boostshake:SetTextColor(Color(255, 255, 255))
	boostshake:SetFont('TargetIDSmall')
	boostshake:SetText('Включить тряску при ускорении?')
	boostshake:SetValue(true)

	local button = vgui.Create('DButton', panel)
	button:Dock(BOTTOM)
	button:SetText('Заспавнить (250 йен за 20 минут)')
	button:SetFont('TargetIDSmall')
	button:SetHeight(panel:GetTall() / 14)
	function button:Paint(w, h)
		surface.SetDrawColor(self:IsHovered() and Color(215, 65, 65) or Color(200, 50, 50))
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(50, 50, 50)
		surface.DrawOutlinedRect(0, 0, w, h)
	end

	local self_ent = self

	function button:DoClick() 
		panel:Close()
		panel:Remove()

		local col = trailcolor:GetColor()

		net.Start('npc_buy')
		net.WriteEntity(self_ent)
		net.WriteString(modelcvar:GetString())
		net.WriteVector(Vector(col.r, col.g, col.b))
		net.WriteBool(mousecontrol:GetChecked())
		net.WriteBool(boostshake:GetChecked())
		net.SendToServer()
	end
end