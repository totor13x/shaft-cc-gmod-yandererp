ENT.Base = 'npc_base'
ENT.Type = 'ai'
ENT.RenderGroup = RENDERGROUP_TRANSLUCENT
ENT.PrintName = 'Премиум Ховерборды'
ENT.Model = 'models/player/shi/rom_maid_npc.mdl'