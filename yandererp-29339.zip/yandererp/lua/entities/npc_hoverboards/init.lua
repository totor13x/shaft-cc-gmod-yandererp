AddCSLuaFile('shared.lua')
AddCSLuaFile('cl_init.lua')

include('shared.lua')

ENT.SpawnPos = Vector(2967, -686, 8)

function ENT:Use(ply, _, usetype)
	if usetype == 1 then
		if ply:IsPremium() then
			net.Start('npc_openmenu')
			net.WriteEntity(self)
			net.Send(ply)
		else
			GAMEMODE:Error(ply, 'Вы должны быть премиумом чтобы спавнить ховерборды!')
		end
	end
end

function ENT:CustomBuy(ply)
	if not ply:IsPremium() then return end

	if not ply:CanAfford(250) then
		GAMEMODE:Error(L'cant_afford')
		return
	else
		ply:AddMoney(-250)
	end

	local model = net.ReadString()
	local trailcolor = net.ReadVector()
	local mousecontrol = net.ReadBool()
	local boostshake = net.ReadBool()

	if not ply:CheckLimit('hoverboards') then
		return
	end

	local hover = ents.Create('modulus_hoverboard')

	local boardinfo
	for _, board in pairs(HoverboardTypes) do
		if (board.model:lower() == model:lower()) then
			boardinfo = board
			break
		end
	end

	if not boardinfo then return end

	util.PrecacheModel(model)

	local ang = Angle(0, 0, 0)

	hover:SetModel(model)
	hover:SetAngles(ang)
	hover:SetPos(self.SpawnPos)

	hover:SetBoardRotation(0)

	if ( boardinfo[ "rotation" ] ) then
		local rot = tonumber( boardinfo[ "rotation" ] )
		hover:SetBoardRotation( tonumber( boardinfo[ "rotation" ] ) )
		ang.y = ang.y - rot
		hover:SetAngles(ang)
	end

	hover:Spawn()
	hover:Activate()

	hover:SetAvatarPosition(Vector(0, 0, 0))

	if ( boardinfo[ 'driver' ] ) then
		hover:SetAvatarPosition( boardinfo[ 'driver' ] )
	end

	for k, v in pairs(boardinfo) do
		if (k:sub( 1, 7 ):lower() == "effect_" and type(boardinfo[k] == "table"))  then
			local effect = boardinfo[k]
			local normal
			if (effect['normal']) then normal = effect['normal'] end
			hover:AddEffect(effect['effect'] or "trail", effect['position'], normal, effect['scale'] or 1 )
		end
	end

	hover:SetControls(mousecontrol and 1 or 0)
	hover:SetBoostShake(boostshake and 1 or 0)
	hover:SetHoverHeight(72)
	hover:SetViewDistance(128)
	hover:SetSpring(0.21)

	hover:SetTrailScale(1.5)
	hover:SetTrailColor(trailcolor)
	hover:SetTrailBoostColor(Vector(128, 255, 128))
	hover:SetTrailRechargeColor(Vector(255, 128, 128))

	hover:SetSpeed(10)
	hover:SetJumpPower(200)
	hover:SetTurnSpeed(37.5)
	hover:SetPitchSpeed(37.5)
	hover:SetYawSpeed(37.5)
	hover:SetRollSpeed(24.75)


	ply:AddCount("hoverboards", hover)
	ply:AddCleanup("hoverboards", hover)
	hover.Creator = ply:UniqueID()


	function hover:Use(activator, caller, usetype)
		if usetype == 1 then
			if activator:UniqueID() == self.Creator then
				if not IsValid( activator ) or not activator:IsPlayer() then return end
				if not self:IsUpright() or self:WaterLevel() > 0 then return end
				self.NextUse = self.NextUse or 0
				if CurTime() < self.NextUse then return end
				self.NextUse = CurTime() + 1 
				self:SetDriver(activator)
			else
				GAMEMODE:Error(activator, 'Вы должны быть владельцем!')
			end
		end
	end

	MPP.own(ply, hover)

	undo.Create('Hoverboard')
	undo.AddEntity(hover)
	undo.SetPlayer(ply)
	undo.Finish()

	SafeRemoveEntityDelayed(hover, 1200)

	GAMEMODE:Notify(ply, 'Ваш ховерборд готов!')
end