ENT.PrintName = 'LRP Деталька'
ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.Author = 'maxmol'

LRP_DETAIL_TYPE_METAL = 1
LRP_DETAIL_TYPE_GLASS = 2
LRP_DETAIL_TYPE_WOOD = 3
LRP_DETAIL_TYPE_BRICK = 4
LRP_DETAIL_TYPE_CHIP = 5

LS_DetailTypes = {
	[LRP_DETAIL_TYPE_METAL] = {
		name = 'Металлическая деталь',
		models = {
			'models/props_vents/vent_small_straight002.mdl',
			'models/props_debris/rebar_smallnorm01c.mdl',
			'models/gibs/metal_gib2.mdl',
			'models/props_c17/canisterchunk02d.mdl'
		},
	},
	[LRP_DETAIL_TYPE_GLASS] = {
		name = 'Стеклянная деталь',
		models = {
			'models/props/de_inferno/windowbreakable_damage_10.mdl',
			"models/props/de_inferno/windowbreakable_damage_09.mdl",
			//"models/props/de_inferno/windowbreakable_damage_11.mdl",
		},
	},
	[LRP_DETAIL_TYPE_WOOD] = {
		name = 'Деревянная деталь',
		models = {
			'models/items/item_item_crate_chunk02.mdl',
		},
	},
	[LRP_DETAIL_TYPE_BRICK] = {
		name = 'Кирпич',
		models = {
			'models/props_debris/concrete_cynderblock001.mdl',
		},
	},
	[LRP_DETAIL_TYPE_CHIP] = {
		name = 'Микросхема',
		models = {
			'models/props/cs_office/projector_p6.mdl',
		},
	},
}

function ENT:SetupDataTables()
	self:NetworkVar('Int', 0, 'DetailType')
end

hook.Add('InvItems', 'lrp_detail', function(items)
	items['lrp_detail'] = {
		perform = function(data)
			return {
				name = LS_DetailTypes[data.type].name,
				model = data.model
			}
		end,
		getTable = function(e)
			return {
				type = e:GetDetailType(),
				model = e:GetModel()
			}
		end,
		spawn = function(data)
			local e = ents.Create('lrp_detail')
			e:SetModel(data.model)
			e:SetDetailType(data.type)
			
			return e
		end
	}
end)