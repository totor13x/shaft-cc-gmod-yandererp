include('shared.lua')

function ENT:RPHUDDraw()
	return {'Деталь LRP', LS_DetailTypes[self:GetDetailType()].name,'Складывайте детали в Коробку Для Деталей,', 'чтобы собрать особые предметы'}
end
