include('shared.lua')

AddCSLuaFile('shared.lua')
AddCSLuaFile('cl_init.lua')

function ENT:Initialize()
	if not LS_DetailTypes[self:GetDetailType()] then
		self:SetDetailType(math.random(#LS_DetailTypes))
	end
	
	self:SetModel(LS_DetailTypes[self:GetDetailType()].models[math.random(#LS_DetailTypes[self:GetDetailType()].models)])
	
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)
	local physObj = self:GetPhysicsObject()
	if IsValid(physObj) then
		physObj:SetMass(50)
		physObj:Wake()
	end
	
	self:MakeBreakable()
end
