include('shared.lua')

AddCSLuaFile('shared.lua')
AddCSLuaFile('cl_init.lua')

function ENT:Initialize()
	self:SetModel('models/hunter/plates/plate05x05.mdl')
	self:SetMaterial('models/debug/debugwhite')
		
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	local physObj = self:GetPhysicsObject()
	if IsValid(physObj) then
		physObj:Wake()
	end

	self:MakeBreakable({health = 40})
end

function PrintPhoto(url, pos, ang, nomotion)
	local ent = ents.Create('lrp_photos')
	ent:SetPos(pos)
	if ang then ent:SetAngles(ang) end
	ent:SetURL(url)
	ent:Spawn()
	if nomotion then ent:GetPhysicsObject():EnableMotion(false) ent.PropGod = true end
end
