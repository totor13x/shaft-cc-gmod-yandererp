ENT.PrintName = 'Фотография'
ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.Author = 'maxmol'

function ENT:SetupDataTables()
	self:NetworkVar('String', 0, 'URL')
end
