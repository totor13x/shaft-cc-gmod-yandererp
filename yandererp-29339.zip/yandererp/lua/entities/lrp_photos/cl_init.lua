include('shared.lua')

file.CreateDir('lrp_photos') 

for k, v in pairs(file.Find('lrp_photos/*', 'DATA')) do
	file.Delete('lrp_photos/' .. v)
end

function ENT:Initialize()
	local scale = Vector(1, 1, 0.1)

	local mat = Matrix()
	mat:Scale(scale)
	self:EnableMatrix("RenderMultiply", mat)
	
	if self:GetURL() then
		self.filename = util.CRC(self:GetURL()) .. '.png'
		
		if not file.Exists('lrp_photos/' .. self.filename, 'DATA') then
			http.Fetch(self:GetURL(), function(data)
				file.Write('lrp_photos/' .. self.filename, data)
				self.PhotoMaterial = Material('../data/lrp_photos/' .. self.filename)
			end)
		else
			self.PhotoMaterial = Material('../data/lrp_photos/' .. self.filename)
		end
	end
end

function ENT:Think()
	local scale = Vector(1, 1, 0.1)

	local mat = Matrix()
	mat:Scale(scale)
	self:EnableMatrix("RenderMultiply", mat)

	self:NextThink(CurTime() + 30)
	return true
end

function ENT:Draw()
	self:DrawModel()
	
	local pos = self:GetPos()
	local ang = self:GetAngles()
	
	pos = pos + ang:Up() * 0.26
	local distance = EyePos():Distance(pos)
	if self.PhotoMaterial and distance < 400 then
		cam.Start3D2D(pos, ang, 1)
			surface.SetMaterial(self.PhotoMaterial)
			surface.SetDrawColor(255, 255, 255, 255)
			surface.DrawTexturedRect(-12, -12, 24, 24)
		cam.End3D2D()
	end
end
