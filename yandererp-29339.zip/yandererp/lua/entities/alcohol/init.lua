AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

function ENT:Use(ply)
	if self.used then return end
	self:Remove()
	self.used = true
	local a = ply:GetNWInt('alcohol') + self.Strength
	ply:SetNWInt('alcohol', a)
	--ply:TakeDamage(10)
	
	if ply:IsTeacher() and GetCurrentSchoolSubject() then
		ply:Achievement('Плохой учитель')
	end

	if a >= 70 then
		ply:Kill()
	end

	if ply:Team() == TEAM_YANDERE then
		net.Start('yandere')
		net.WriteFloat(0)
		net.Send(ply)
	end
end

hook.Add('PlayerDeath', 'alcohol', function(ply)
	ply:SetNWInt('alcohol', 0)
end)

timer.Create('alcohol', 2, 0, function()
	for _, p in ipairs(player.GetAll()) do
		local a = p:GetNWInt('alcohol')
		if a > 0 then
			p:SetNWInt('alcohol', a - 1)
		end
	end
end)
