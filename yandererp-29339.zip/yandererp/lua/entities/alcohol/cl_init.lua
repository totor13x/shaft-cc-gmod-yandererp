include('shared.lua')

timer.Create('alcohol', 0.5, 0, function()
	for _, p in ipairs(player.GetAll()) do
		local a = p:GetNWInt('alcohol')
		if a > 0 then
			//SpawnParticle(2, 0, 15 + a * 0.5, 'particle/particle_ring_wave_8', Vector(math.random(100, 150), math.random(100, 150), 255), p:GetShootPos(), VectorRand() * 20, Vector(0, 0, 25), 0, math.random(-800, 800), 196, 0)
		end
	end
end)

hook.Add('RenderScreenspaceEffects', 'alcohol', function()
	local a = LocalPlayer():GetNWInt('alcohol')
	if a > 0 then
		DrawMotionBlur(0.4, 0.8, 0.0025 * a)	
	end
end)

function ENT:Draw()
	self.Entity:DrawModel()
end