ENT.PrintName = 'Alcohol'
ENT.Type = 'anim'
ENT.Base = 'base_gmodentity'
ENT.Author = 'maxmol'
ENT.Spawnable = true
ENT.Model = 'models/props_junk/garbage_glassbottle003a.mdl'
ENT.Strength = 5

function ENT:Initialize()
	self:SetModel(self.Model)
	if SERVER then self:PhysicsInit(SOLID_VPHYSICS)
		self:SetMoveType(MOVETYPE_VPHYSICS)
		self:SetSolid(SOLID_VPHYSICS)
		self:SetUseType(SIMPLE_USE)
		local physObj = self:GetPhysicsObject()
		if IsValid(physObj) then
			physObj:Wake()
		end
	end
end