SWEP.WorldModel = ""

SWEP.Primary = {
	Delay = 0.3,
	ClipSize = -1,
	DefaultClip = 0,
	Automatic = false,
	Ammo = '',
}
SWEP.Secondary = SWEP.Primary

function SWEP:Initialize()
    self:SetHoldType("normal")
end

function SWEP:Holster()
    return true
end

function SWEP:PrimaryAttack()
end

function SWEP:SecondaryAttack()
end

