include('shared.lua')

SWEP.Slot = 1
SWEP.SlotPos = 1
SWEP.ViewModelFOV = 62

SWEP.DrawAmmo = false
SWEP.DrawCrosshair = false	
SWEP.ViewModelFlip = false
SWEP.UseHands = true

SWEP.PrintName = 'Яндере'
SWEP.Purpose = 'Нажми ЛКМ чтобы выбрать возлюбленного!'
SWEP.Author = 'LampServ'

function SWEP:PreDrawViewModel()
	return true
end

local beloved = nil
local love = 10
local love_min = 10
local love_max = 250
local love_width = 0
local lastalcohol = 0

net.Receive('yandere', function()
	love = net.ReadFloat()
end)

function SWEP:PrimaryAttack()
	if (self.cooldown and self.cooldown > CurTime()) or beloved and love > love_min then
		return	
	end
	
	local ply = self:GetOwner():getEyeSightHitEntity(90, 15, function(ent) return self:GetOwner() ~= ent and ent:IsSolid() and ent:IsPlayer() and ent:Team() == TEAM_SHKOLNIK end)
	if IsValid(ply) then
		beloved = ply
		love = love_min
		
		timer.Create('yandere', 1, 0, function()
			if LocalPlayer():GetNWInt('alcohol') > 0 then
				lastalcohol = CurTime()
			end

			if not IsValid(beloved) or beloved:Team() ~= TEAM_SHKOLNIK or LocalPlayer():Team() ~= TEAM_YANDERE then
				timer.Remove('yandere')
				beloved = nil
				love = love_min
				love_width = 0
			else
				local dist = lastalcohol + 60*5 < CurTime() and LocalPlayer():GetPos():Distance(beloved:GetPos()) or 1000
				love = math.Clamp(love + (dist < 400 and 400 / dist or -10), love_min, love_max)
				
				if love > 240 and not LocalPlayer():HasWeapon('weapon_knife') then
					net.Start('yandere')
					net.WriteBool(true)
					net.SendToServer()
				end
				
				if love < 250 / 2.5 then
					net.Start('yandere')
					net.WriteBool(false)
					net.SendToServer()
				end
			end
		end)

		chat.AddText(Color(255, 200, 255), '[Яндере] ', Color(240, 240, 240), 'Вы выбрали возлюбленного!')
		self.cooldown = CurTime() + 10
	end
end

local mat = Material('sprites/glow04_noz')
local function dorender(v)
	if v:Team() == TEAM_SHKOLNIK and not v:InVehicle() and v:Alive() then
		render.SetMaterial(mat)
		render.DrawSprite(v:WorldSpaceCenter() + (v:GetPos() - LocalPlayer():GetPos()):GetNormalized() * 25, 75, 115, Color(255, 100, 255, 165))
	end
end
function SWEP:Deploy()
	hook.Add('PostDrawTranslucentRenderables', 'Yandere', function()
		if beloved then
			dorender(beloved)
			return 
		end
		
		for k, v in ipairs(player.GetAll()) do
			dorender(v)
		end
	end)
end

function SWEP:Holster()
	hook.Remove('PostDrawTranslucentRenderables', 'Yandere')
end

local hearts = {}
local icon = Material('icon16/heart.png')
local createcooldown = 0

hook.Add('HUDPaint', 'Yandere', function()
	if LocalPlayer():Team() ~= TEAM_YANDERE then
		return
	end
	
	love_width = math.Clamp(Lerp(0.1, love_width, love), 0, 250)
	draw.RoundedBox(8, 10, 165, 250, 20, Color(255, 114, 167, 100))
	draw.RoundedBox(8, 10, 165, love_width, 20, Color(255, 114, 167))
	
	if love > love_min and love < love_max and love > love_width then
	
		if SysTime() > createcooldown then
			createcooldown = SysTime() + math.Rand(0.2, 0.3)
			table.insert(hearts, {x = 0, y = 0, dx = math.random(3, 6), dy = math.random(-3, 3), a = 255})  
		end
	
	
		local i = 1
		while i < #hearts do
			local info = hearts[i]
			info.x = info.x + info.dx * FrameTime() * 10
			info.y = info.y + info.dy * FrameTime() * 10
			
			if info.x > 25 or info.y > 25 then
				info.a = info.a - FrameTime() * 1000
			  
				if info.a < 0 then
				  	table.remove(hearts, i)
				  	continue
				end
			end
			
			surface.SetMaterial(icon)
			surface.SetDrawColor(Color(255, 255, 255, math.Clamp(info.a, 0, 255)))
			surface.DrawTexturedRect(3.5 + love_width + info.x, 167.5 + info.y, 16, 16)
			i = i + 1
		end
	end
end)	