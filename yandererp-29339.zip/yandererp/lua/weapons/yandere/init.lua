include('shared.lua')

AddCSLuaFile('shared.lua')
AddCSLuaFile('cl_init.lua')

util.AddNetworkString('yandere')
net.Receive('yandere', function(l, ply)
	if ply:Team() == TEAM_YANDERE and ply:Alive() then
		if net.ReadBool() then
			ply:Give('weapon_knife')
			ply:SelectWeapon('weapon_knife')
		else
			ply:StripWeapon('weapon_knife')
		end
	end
end)
