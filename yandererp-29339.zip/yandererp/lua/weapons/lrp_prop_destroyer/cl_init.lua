include('shared.lua')

SWEP.DrawAmmo = false
SWEP.DrawCrosshair = false
SWEP.Slot = 1
SWEP.SlotPos = 3
SWEP.UseHands = true

SWEP.Author = 'pidoras'
SWEP.Instructions = 'Destroy any prop in seconds'