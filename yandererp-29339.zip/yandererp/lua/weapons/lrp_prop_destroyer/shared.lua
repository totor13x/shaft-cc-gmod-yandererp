SWEP.PrintName = 'LRP Ломатель Пропов'
SWEP.ViewModel = 'models/weapons/c_crowbar.mdl'
SWEP.WorldModel = 'models/weapons/w_crowbar.mdl'

SWEP.PrintName = 'LRP Ломатель Пропов'
SWEP.Spawnable = true

SWEP.Primary = {
	Ammo = -1,
	ClipSize = -1,
	DefaultClip = -1,
	Automatic = false
}

SWEP.Secondary = {
	Ammo = -1,
	ClipSize = -1,
	DefaultClip = -1,
	Automatic = false
}

function SWEP:Initialize()
	self:SetHoldType('melee2')
end

function SWEP:Deploy()
	self:SetHoldType('melee2')
end

local RangeEyeTrace = function( ply, range, filter )
	local filterTable = filter or { }
	table.insert( filterTable, ply )
	local traceData = { }
	
	traceData.start = ply:GetShootPos( )
	traceData.endpos = ply:GetShootPos( ) + ply:EyeAngles( ):Forward( ) * range
	traceData.filter = filterTable

	local traceRes = util.TraceLine( traceData )
	return traceRes
end

local hitair = Sound("weapons/iceaxe/iceaxe_swing1.wav")
function SWEP:PrimaryAttack()
	self.Owner:SetAnimation(PLAYER_ATTACK1)
	self:SendWeaponAnim(ACT_VM_HITCENTER)
	self:SetNextPrimaryFire(CurTime() + 2)
	
	if SERVER then 
		self.Owner:EmitSound(hitair, 70, 100, 0.2) 
	end
	 
	local trace = RangeEyeTrace(self.Owner, 100, {self})
	local texture = trace.HitTexture
	
	if not trace.Hit or trace.HitSky then return end
	
	if IsValid(trace.Entity) then
		local bullet = {}
		bullet.Num 		= num_bullets
		bullet.Src 		= self.Owner:GetShootPos()			
		bullet.Dir 		= self.Owner:GetAimVector()			
		bullet.Spread 	= 0		
		bullet.Tracer	= 0
		bullet.Force	= 50
		bullet.Damage	= trace.Entity:GetClass() == 'prop_physics' and 200 or 8
		bullet.AmmoType = ""
		self.Owner:FireBullets(bullet)
	end
end

function SWEP:SecondaryAttack()
end