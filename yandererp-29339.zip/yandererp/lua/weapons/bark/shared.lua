AddCSLuaFile()

-- spisdeno s ki

SWEP.Base = "weapon_base"

if CLIENT then
	SWEP.PrintName = "гав"
	SWEP.Slot = 1
	SWEP.SlotPos = 1
	SWEP.DrawAmmo = false
	SWEP.DrawCrosshair = false
end

SWEP.WorldModel	= ""
SWEP.ViewModelFOV = 62
SWEP.ViewModelFlip = false
SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = 0
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = ""

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = 0
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = ""

local function KUSAT(self)
	if CLIENT then return end
	local tr = util.TraceLine( {
		start = self.Owner:GetShootPos(),
		endpos = self.Owner:GetShootPos() + self.Owner:GetAimVector() * 60,
		filter = self.Owner,
		mask = MASK_SHOT_HULL
	} )

	if ( IsValid( tr.Entity ) && ( tr.Entity:IsNPC() || tr.Entity:IsPlayer() ) ) then
		local dmginfo = DamageInfo()

		local attacker = self.Owner
		if ( !IsValid( attacker ) ) then attacker = self end
		dmginfo:SetAttacker( attacker )
		dmginfo:SetInflictor( self )
		dmginfo:SetDamage( 3 )

		tr.Entity:TakeDamageInfo( dmginfo )
		
		tr.Entity:SetVelocity(tr.Normal*250)
	end

end

function SWEP:Initialize()
	self:SetHoldType("normal")		
end

function SWEP:PreDrawViewModel()
	return true
end

function SWEP:PrimaryAttack()
	if CLIENT then return end
	self.Weapon:SetNextPrimaryFire(CurTime() + 1)
	self.Owner:EmitSound("ambient/animal/dog_med_inside_bark_1.wav")
	KUSAT(self)
end



function SWEP:SecondaryAttack()
	self.Weapon:SetNextSecondaryFire(CurTime() + 1)
	self.Owner:EmitSound("ambient/animal/dog_med_inside_bark_1.wav")
end