include('shared.lua')

AddCSLuaFile('shared.lua')
AddCSLuaFile('cl_init.lua')

function SWEP:PrimaryAttack()
	self:SetNextPrimaryFire(CurTime() + 1)
end

util.AddNetworkString('HackingDevice_Command')
util.AddNetworkString('HackingDevice_Message')

net.Receive('HackingDevice_Command', function(len, ply)
	if ply:GetActiveWeapon():GetClass() ~= 'lrp_hacking_device' then return end
	
	local command = commandz[net.ReadString()]
	if command and command.SERVER then command.SERVER(ply, ply:GetActiveWeapon()) end
end)