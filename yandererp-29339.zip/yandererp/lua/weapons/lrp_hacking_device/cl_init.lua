include('shared.lua')

function SWEP:PrimaryAttack()
	if not ValidPanel(self.Panel) then
		self:CreateHackMenu()
	else
		self.Panel:Show()
		self.Panel:SetAlpha(0)
		self.Panel:AlphaTo(255, 0.15)
		self.DownPanel.textentry:RequestFocus()
	end
end

function SWEP:CreateHackMenu()
	local swep = self
	
	self.Panel = vgui.Create('EditablePanel')
	local selfPanel = self.Panel
	self.Panel:SetSize(600, 420)
	self.Panel:Center()
	self.Panel:MakePopup()
	self.Panel:SetAlpha(0)
	self.Panel:AlphaTo(255, 0.15)
	self.Panel.Paint = function(s, w, h)
		surface.SetDrawColor(0, 0, 0)
		surface.DrawRect(0, 0, w, h)
	end
	
	self.RichText = vgui.Create('RichText', self.Panel)
	self.RichText:Dock(FILL)
	self.RichText:InsertColorChange(0, 192, 0, 255)
	self.RichText.PerformLayout = function()
		if not IsValid(self) then selfPanel:Remove() return end
		self.RichText:SetFontInternal('DebugFixed')
	end
	self.RichText:AppendText('LampServ HACKING DEVICE\nLS.OS Initialized...\n' .. 'Напишите "help" чтобы получить список команд.\n')
	
	self.DownPanel = vgui.Create('DPanel', self.Panel)
	self.DownPanel:SetSize(600, 20)
	self.DownPanel:Dock(BOTTOM)
	self.DownPanel.Paint = function(self, w, h)
		surface.SetDrawColor(255, 255, 255)
		surface.DrawRect(0, 0, w, h)
	end
	
	local bclose = vgui.Create('DButton', self.DownPanel)
	bclose:SetSize(48, 20)
	bclose:SetPos(self.DownPanel:GetWide() - bclose:GetWide(), 0)
	bclose.Paint = function(s, w, h)
		surface.SetDrawColor(192, 0, 0)
		surface.DrawRect(0, 0, w, h)
	end
	bclose:SetText('CLOSE')
	bclose.DoClick = function()
		swep.Panel:Hide()
	end
	
	local textentry = vgui.Create('DTextEntry', self.DownPanel)
	textentry:SetSize(self.DownPanel:GetWide() - bclose:GetWide(), 20)
	textentry:SetPos(0, 0)
	textentry:SetHistoryEnabled(true)
	textentry:RequestFocus()
	textentry.OnEnter = function()
		local cmd = string.lower(textentry:GetValue())
		if cmd:len() == 0 then return end
		
		if not textentry.History or textentry.History[#textentry.History] ~= cmd then textentry:AddHistory(cmd) end
		
		self.RichText:AppendText('> ' .. cmd .. '')
		textentry:SetText('')
		textentry:RequestFocus()
		
		local finalcmd = commandz[cmd] and cmd or 'error'
		commandz[finalcmd].CLIENT(self.RichText, cmd)
		self.RichText:AppendText('\n')
		
		if commandz[finalcmd].SERVER then
			net.Start('HackingDevice_Command')
				net.WriteString(finalcmd)
			net.SendToServer()
		end
	end
	self.DownPanel.textentry = textentry

	net.Receive('HackingDevice_Message', function()
		if IsValid(self) and ValidPanel(self.RichText) then self.RichText:AppendText(net.ReadString() .. '\n') end
	end)
end

function SWEP:OnRemove()
	if self.Panel then self.Panel:Remove() end
end
	