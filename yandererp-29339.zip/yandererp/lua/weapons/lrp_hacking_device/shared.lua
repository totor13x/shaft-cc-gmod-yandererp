SWEP.PrintName = 'LRPS Hacking Device'
SWEP.Author = 'maxmol'
SWEP.ViewModel = 'models/weapons/v_c4.mdl'
SWEP.WorldModel = 'models/weapons/w_c4.mdl'
SWEP.DrawAmmo = false
SWEP.DrawCrosshair = false
SWEP.Slot = 0
SWEP.SlotPos = 3
SWEP.Primary = {
	Ammo = -1,
	ClipSize = -1,
	DefaultClip = -1,
	Automatic = false
}
SWEP.Secondary = {
	Ammo = -1,
	ClipSize = -1,
	DefaultClip = -1,
	Automatic = false
}
SWEP.HoldType = 'slam'

function SWEP:Initialize()
	self:SetHoldType(self.HoldType)
end

function SWEP:Deploy()
	self:SetHoldType(self.HoldType)
end

commandz = { 			
	['help'] = { 
		CLIENT = function(richtext) 
			richtext:AppendText('\n' .. [[
hack_keypad 		-- Взломать кейпад (вы должны на него смотреть)
hack_type_increase 	-- Подбор пароля идет от 1 до 9999
hack_type_decrease 	-- Подбор пароля идет от 9999 до 1]])
		end
	},
	['hack_keypad'] = {
		CLIENT = function(richtext)
			richtext:AppendText("\nЗапущен взлом кейпада... \nСтойте рядом с кейпадом")
		end, 
		SERVER = function(ply, wep)
			local keypad = ply:GetEyeTrace().Entity
			local password = keypad.m_Password
			if not password then return end
			local mode = wep.HackingMode
			local i = mode and 9999 or 1
			local timername = 'Keypad_Hacking_' .. wep:EntIndex()
			timer.Create(timername, 0.1, 1000, function() 
				if not IsValid(wep) then timer.Remove(timername) return end
				if not IsValid(keypad) or ply:GetPos():Distance(keypad:GetPos()) > 120 then 
					net.Start('HackingDevice_Message')
						net.WriteString('Connection error!')
					net.Send(ply)
					timer.Remove(timername)
					return
				end
				
				if timer.RepsLeft(timername) % 10 == 0 then
					ply:EmitSound('buttons/blip2.wav')
				end
				
				i = i + math.random(10, 20) * (mode and -1 or 1)
				keypad:SetValue(tostring(i))
				if (mode and (i < tonumber(password))) or (not mode and (i > tonumber(password))) then 
					keypad:SetValue(password) 
					timer.Remove(timername)
					net.Start('HackingDevice_Message')
						net.WriteString('Password: ' .. password)
					net.Send(ply)
					ply:EmitSound('buttons/button24.wav')
				end 
			end)
		end 
	},
	['hack_type_increase'] = { 
		CLIENT = function(richtext)
			richtext:AppendText("Hacking type changed to INCREASE MODE")
		end, 
		SERVER = function(ply, wep) 
			wep.HackingMode = false
		end
	},
	['hack_type_decrease'] = { 
		CLIENT = function(richtext)
			richtext:AppendText("Hacking type changed to DECREASE MODE")
		end, 
		SERVER = function(ply, wep)
			wep.HackingMode = true
		end
	},
	['error'] = {
		CLIENT = function(richtext, cmd)
			richtext:AppendText('No such command: ' .. cmd)
		end
	}
}