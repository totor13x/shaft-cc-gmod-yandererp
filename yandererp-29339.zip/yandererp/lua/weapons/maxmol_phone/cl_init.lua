include("shared.lua")

local function nick(p, n)
	if not IsValid(p) or not p:IsPlayer() then
		return 'Неизвестн.'
	else
		local t = p:GetName()
		local len = string.len(t)
		if not len then return 'Неизвестн.' end
		return string.sub(t, 0, n or 11) .. (len > (n or 11) and '..' or '')
	end
end

local silentIcon = Material('icon16/status_busy.png')

local function chatprint(msg)
	chat.AddText(Color(96, 96, 255), '[Телефон] ', color_white, msg)
end

function SWEP:PrimaryAttack()
	if self.primarycooldown and self.primarycooldown > CurTime() then
		return
	end

	self.primarycooldown = CurTime() + 1

	if self.Incoming then
		if not self.Call then
			chatprint('Вы приняли вызов')
		end

		net.Start('maxmol_phone')
			net.WriteInt(2, 4)
		net.SendToServer()

		RunConsoleCommand('stopsound')
	elseif not self.Call then
		if self.CallCoolDown and self.CallCoolDown > CurTime() then
			chatprint('Вы не можете так часто звонить!')
		else
			self.Call = true
			self.CallCoolDown = CurTime() + 3
			local plys = self:PhonePlayers()
			local ply = plys[self.MenuSelect]
			if IsValid(ply) then
				net.Start('maxmol_phone')
					net.WriteInt(1, 4)
					net.WriteEntity(ply)
				net.SendToServer()
				chatprint('Вы звоните ' .. ply:GetName())
			end
		end
	end
end

function SWEP:SecondaryAttack()
	if IsValid(LocalPlayer():GetNWEntity('maxmol_phone')) then
		net.Start('maxmol_phone')
			net.WriteInt(3, 4)
		net.SendToServer()
	elseif self.Incoming then
		self.Incoming = nil
		RunConsoleCommand('stopsound')
		net.Start('maxmol_phone')
			net.WriteInt(4, 4)
		net.SendToServer()
	elseif self.Call then
		net.Start('maxmol_phone')
			net.WriteInt(5, 4)
		net.SendToServer()
		
		self.Call = false
	end
end

local bgMat = Material("models/props_lab/warp_sheet")

http.Fetch('https://sun9-7.userapi.com/c840629/v840629724/787ac/y5vUUe5TXEw.jpg', function(data)
	file.Write('maxmol_phone.png', data)
	timer.Simple(1, function()
		bgMat = Material('../data/maxmol_phone.png')
	end)
end)

function SWEP:Reload()
	if not self.nextReload or self.nextReload < CurTime() then
		self.nextReload = CurTime() + 1
		surface.PlaySound('buttons/lightswitch2.wav')
		self.Silent = not self.Silent
	end
end

function SWEP:PostDrawViewModel(vm)
	if self.Incoming and not IsValid(self.Incoming) then self.Incoming = nil end
	
	local plys = self:PhonePlayers()
	local ang = vm:GetAngles()
	ang:RotateAroundAxis(ang:Right(), 75.5)
	ang:RotateAroundAxis(ang:Up(), -90)
	
	cam.Start3D2D(vm:GetPos() - ang:Up() * 14.16 - ang:Right() * 1.24 + ang:Forward() * 4.41, ang, 0.0125)
		surface.SetMaterial(bgMat)
		surface.SetDrawColor(255, 255, 255)
		surface.DrawTexturedRect(0, 0, 128, 156)

		if self.Silent then
			surface.SetMaterial(silentIcon)
			surface.DrawTexturedRect(128 - 16, 0, 16, 16)
		end
		
		local phonetalking = LocalPlayer():GetNWEntity('maxmol_phone')
		if IsValid(phonetalking) and self.Incoming == phonetalking then self.Incoming = nil end
		
		if self.Incoming then
			surface.SetDrawColor(0, 0, 0, 196)
			surface.DrawRect(0, 13, 128, 26)
			draw.SimpleText(nick(self.Incoming), "Trebuchet24", 64, 26, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			
			surface.SetDrawColor(0, 0, 0, 196)
			surface.DrawRect(0, 100, 128, 26)
			draw.SimpleText("ЛКМ - Взять", "Trebuchet24", 64, 113, Color(0, 255, 0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			
			surface.SetDrawColor(0, 0, 0, 220)
			surface.DrawRect(0, 130, 128, 26)
			draw.SimpleText("ПКМ - Сброс", "Trebuchet24", 64, 143, Color(255, 96, 96), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		elseif IsValid(phonetalking) then
			self.Call = nil
			surface.SetDrawColor(0, 0, 0, 196)
			surface.DrawRect(0, 13, 128, 26)
			draw.SimpleText(nick(phonetalking), "Trebuchet24", 64, 26, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			
			surface.SetDrawColor(0, 0, 0, 196)
			surface.DrawRect(0, 100, 128, 26)
			draw.SimpleText("Разговор", "Trebuchet24", 64, 113, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			
			surface.SetDrawColor(0, 0, 0, 220)
			surface.DrawRect(0, 130, 128, 26)
			draw.SimpleText("ПКМ - Сброс", "Trebuchet24", 64, 143, Color(255, 96, 96), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		
		elseif self.Call then
			surface.SetDrawColor(0, 0, 0, 196)
			surface.DrawRect(0, 13, 128, 26)
			draw.SimpleText(nick(plys[self.MenuSelect]), "Trebuchet24", 64, 26, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			
			surface.SetDrawColor(0, 0, 0, 196)
			surface.DrawRect(0, 100, 128, 26)
			draw.SimpleText("Звоним...", "Trebuchet24", 64, 113, Color(0, 255, 0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			
			surface.SetDrawColor(0, 0, 0, 220)
			surface.DrawRect(0, 130, 128, 26)
			draw.SimpleText("ПКМ - Сброс", "Trebuchet24", 64, 143, Color(255, 96, 96), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		else
			if input.IsKeyDown(KEY_DOWN) then
				if not self.DownToggle then
					self.MenuSelect = self.MenuSelect + 1
					if self.MenuSelect > #plys then
						self.MenuSelect = 1
						self.MenuPos = 1
					end
					
					if self.MenuSelect > self.MenuPos + 5 then
						self.MenuPos = self.MenuSelect - 5
					end
					
					self.DownToggle = true
				end
			else
				self.DownToggle = false
			end
			
			if input.IsKeyDown(KEY_UP) then
				if not self.UpToggle then
					self.MenuSelect = self.MenuSelect - 1
					if self.MenuSelect < 1 then
						self.MenuSelect = #plys
						self.MenuPos = math.Clamp(#plys - 5, 1, #plys)
					end
					
					if self.MenuSelect < self.MenuPos then
						self.MenuPos = self.MenuSelect
					end
					self.UpToggle = true
				end
			else
				self.UpToggle = false
			end
			
			if self.MenuSelect > #plys then
				self.MenuSelect = #plys
				self.MenuPos = #plys - 5
			end
			
			for i = self.MenuPos, math.min(self.MenuPos + 5, self.MenuPos + #plys - 1) do
				local y = (i - self.MenuPos) * 26
				surface.SetDrawColor(0, 0, self.MenuSelect == i and 255 or 0, 196)
				surface.DrawRect(0, y, 128, 25)
				if IsValid(plys[i]) then
					draw.SimpleText(nick(plys[i], 18), "DermaDefault", 2, y + 13, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				end
			end
		end
	cam.End3D2D()
end

net.Receive('maxmol_phone', function()
	local wep = LocalPlayer():GetWeapon('maxmol_phone')
	local act = net.ReadInt(4)
	if IsValid(wep) then
		if act == 1 then
			local e = net.ReadEntity()
			wep.Incoming = e
			
			chatprint('Вам звонят, проверьте телефон!')
			if not wep.Silent then LocalPlayer():EmitSound('music/hl2_song20_submix0.mp3', 50) end
		elseif act == 3 then
			local e = net.ReadEntity()
			if LocalPlayer():GetNWEntity('maxmol_phone') == e then
				chatprint('Абонент сбросил!')
			end
		elseif act == 4 then
			wep.Call = nil
			chatprint('Абонент сбросил!')
		elseif act == 5 then
			wep.Incoming = nil
			chatprint('Абонент сбросил!')
			RunConsoleCommand('stopsound')
		elseif act == 6 then
			wep.Call = nil
			chatprint('Абонент занят!')
		end
	end
end)