AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

function SWEP:PrimaryAttack()
end

function SWEP:SecondaryAttack()
end

/*
hook.Add('PlayerSwitchFlashlight', 'maxmol_phone', function(ply, on)
	if on  then
		if ply:GetActiveWeapon():GetClass() != 'maxmol_phone' then
			ply.flashlight_lastweapon = ply:GetActiveWeapon():GetClass()
			ply:SelectWeapon('maxmol_phone')
		end
	elseif ply.flashlight_lastweapon then
		timer.Simple(0, function() 
			if ply.flashlight_lastweapon then ply:SelectWeapon(ply.flashlight_lastweapon) ply.flashlight_lastweapon = nil end
		end)
	end
end)

function SWEP:Holster()
	if self.Owner:FlashlightIsOn() then self.Owner:Flashlight(false) end
	return true
end

function SWEP:OnRemove()
	if self.Owner:FlashlightIsOn() then self.Owner:Flashlight(false) end
end*/

util.AddNetworkString('maxmol_phone')
resource.AddWorkshop(534923023)
hook.Remove("PlayerSpawn", "BuddyFinderSpawnGiver")

net.Receive('maxmol_phone', function(len, ply)
	local act = net.ReadInt(4)
	if act == 1 then
		if IsValid(ply.PhoneCalling) or IsValid(ply:GetNWEntity('maxmol_phone')) then return end

		local ent = net.ReadEntity()
		
		if IsValid(ent:GetNWEntity('maxmol_phone')) or ent.PhoneCalling then
			net.Start('maxmol_phone')
				net.WriteInt(6, 4)
			net.Send(ply)
			return
		end
		
		net.Start('maxmol_phone')
			net.WriteInt(1, 4)
			net.WriteEntity(ply)
		net.Send(ent)
		
		ply.PhoneCalling = ent
	elseif act == 2 then
		for k, v in pairs(player.GetAll()) do
			if v != ply and v.PhoneCalling == ply then
				ply:SetNWEntity("maxmol_phone", v)
				ply.maxmol_phone = v
				v:SetNWEntity("maxmol_phone", ply)
				v.maxmol_phone = ply
				ply.PhoneCalling = nil
				v.PhoneCalling = nil
				
				break	
			end
		end
	elseif act == 3 then
		if IsValid(ply:GetNWEntity('maxmol_phone')) then
			net.Start('maxmol_phone')
				net.WriteInt(3, 4)
				net.WriteEntity(ply)
			net.Send(ply:GetNWEntity('maxmol_phone'))
			
			local p2 = ply:GetNWEntity('maxmol_phone')
			p2:SetNWEntity('maxmol_phone', NULL)
			p2.maxmol_phone = nil
			ply:SetNWEntity('maxmol_phone', NULL)
			ply.maxmol_phone = nil
		end
	elseif act == 4 then
		local caller
		for k, v in pairs(player.GetAll()) do
			if v != ply and v.PhoneCalling == ply then
				caller = v
				break
			end
		end
		
		if caller then
			net.Start('maxmol_phone')
				net.WriteInt(4, 4)
			net.Send(caller)
			caller.PhoneCalling = nil
		end
	elseif act == 5 then
		net.Start('maxmol_phone')
			net.WriteInt(5, 4)
		net.Send(ply.PhoneCalling)
		ply.PhoneCalling = nil
	end	
end)

hook.Add('PlayerCanHearPlayersVoice', 'maxmol_phone', function(to, from)
	if to.maxmol_phone == from then
		return true, false
	end
end)

hook.Add('PlayerSay', 'maxmol_phone', function(speaker, text, isTeam)
	if IsValid(speaker:GetNWEntity('maxmol_phone')) and not isTeam then
		GAMEMODE:ChatPrintTo(speaker:GetNWEntity('maxmol_phone'), Color(255, 200, 0), '[Телефон] ' .. speaker:GetName(), color_white, ': ' .. text)
	end
end)