SWEP.PrintName = 'Maymol phone'
SWEP.WorldModel = "models/jessev92/weapons/buddyfinder_w.mdl"
SWEP.ViewModel =  "models/jessev92/weapons/buddyfinder_c.mdl"
SWEP.DrawCrosshair = false
SWEP.Slot = 1
SWEP.SlotPos = 2
SWEP.Spawnable = true
SWEP.Instructions = 'УПРАВЛЕНИЕ: \nСтрелочки вверх/вниз\nЛКМ/ПКМ\nR - беззвучный режим'
SWEP.MenuPos = 1
SWEP.MenuSelect = 1
SWEP.Silent = false

if CLIENT then
	local	_SELFENTNAME	= "util_buddyfinder"
	SWEP.BounceWeaponIcon	= false
	SWEP.WepSelectIcon 		= surface.GetTextureID("vgui/hud/" .. _SELFENTNAME )
end

SWEP.Primary = {
	Ammo = "None",
	ClipSize = -1,
	DefaultClip = -1,
	Automatic = false
}

SWEP.Secondary = {
	Ammo = "None",
	ClipSize = -1,
	DefaultClip = -1,
	Automatic = false
}

function SWEP:PhonePlayers()
	local plys = {}
	for _, v in ipairs(player.GetAll()) do
		if v != LocalPlayer() then table.insert(plys, v) end
	end
	
	return plys
end