SWEP.Author = ""
SWEP.Contact = ""
SWEP.Purpose = ""
SWEP.Instructions = "LMB - Enable/Disable. Lasering eyes causes damage."
SWEP.Category = "Other"

SWEP.Spawnable = true;
SWEP.AdminOnly = false

SWEP.ViewModel  = "models/weapons/c_toolgun.mdl";
SWEP.WorldModel = "models/weapons/w_toolgun.mdl";

SWEP.Primary = {}
SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = -1
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "none"

SWEP.Secondary = {}
SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"