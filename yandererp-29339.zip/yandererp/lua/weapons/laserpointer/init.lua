include('shared.lua')

AddCSLuaFile('shared.lua')
AddCSLuaFile('cl_init.lua')

SWEP.Weight = 8
SWEP.AutoSwitchTo = false
SWEP.AutoSwitchFrom = false

SWEP.Receiver = nil
SWEP.Pointing = false

function SWEP:Initialize()
	self.Pointing = false
	self:SetHoldType('pistol')
end

function SWEP:Equip( newOwner )
	if IsValid(newOwner.LasReceiver) then
		self.Receiver = newOwner.LasReceiver
		newOwner.LasReceiver = nil
		newOwner:PrintMessage( HUD_PRINTTALK, "Relinked Sucessfully" )
	end
end

function SWEP:PrimaryAttack()
	self.Pointing = !self.Pointing
	self.Weapon:SetNWBool("Active", self.Pointing)
end

function SWEP:SecondaryAttack()
end

util.AddNetworkString('blind')

local interval = 20
function SWEP:Think()
	if SERVER and self.Pointing then
		self.interval = self.interval and (self.interval + 1) or 1
		local trace = self.Owner:GetEyeTrace()
		
		if IsValid(trace.Entity) and trace.Entity:IsPlayer() and trace.HitGroup == HITGROUP_HEAD and self.interval >= interval then
			self.interval = 0
			local dmg = DamageInfo()
			dmg:SetAttacker(self.Owner)
			dmg:SetDamage(1)
			dmg:SetDamageType(DMG_BURN)

			net.Start('blind')
			net.Send(trace.Entity)

			trace.Entity:TakeDamageInfo(dmg)
		end
	end
end