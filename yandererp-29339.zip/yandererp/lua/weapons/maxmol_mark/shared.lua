hook.Add('PostGamemodeLoaded', 'InitTeacherSubjects', function()
	LRPS_TEACHER_SUBJECTS = {
		[TEAM_TEACHER_MATH] = 1,
		[TEAM_TEACHER_BIO] = 2,
		[TEAM_TEACHER_CHEM] = 3,
		[TEAM_TEACHER_FOREIGN] = 4,
		[TEAM_TEACHER_ICT] = 5,
		[TEAM_TEACHER_SPORT] = 6,
		[TEAM_TEACHER_HISTORY] = 7,
		[TEAM_TEACHER_GEOGRAPHY] = 8,
	}
end)

SWEP.PrintName = 'LampServ Marks'
SWEP.Author = 'maxmol'
SWEP.DrawAmmo = false
SWEP.DrawCrosshair = false
SWEP.Slot = 0
SWEP.SlotPos = 3
SWEP.Primary = {
	Ammo = -1,
	ClipSize = -1,
	DefaultClip = -1,
	Automatic = false
}
SWEP.Secondary = {
	Ammo = -1,
	ClipSize = -1,
	DefaultClip = -1,
	Automatic = false
}
SWEP.HoldType = 'normal'

function SWEP:SetupDataTables()
	self:NetworkVar('Int', 0, 'Mark')
end

function SWEP:Initialize()
	self:SetHoldType(self.HoldType)
	self:SetMark(5)
end

function SWEP:Deploy()
	self:SetHoldType(self.HoldType)
	if CLIENT or not IsValid(self:GetOwner()) then return true end
    self:GetOwner():DrawWorldModel(false)
end
