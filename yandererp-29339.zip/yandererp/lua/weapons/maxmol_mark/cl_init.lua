include("shared.lua")

function SWEP:DrawHUD()
	surface.DrawCircle(ScrW()/2, ScrH()/2, 15, 96, 255, 96) 
	
	draw.SimpleText('Оценка: ' .. self:GetMark(), 'DermaLarge', ScrW()/2, ScrH()/2 + 25, Color(255, 64, 64), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	draw.SimpleText('Нажми ЛКМ чтобы поставить оценку игроку', 'DermaLarge', ScrW()/2, ScrH()/2 + 75, Color(255, 64, 64), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	draw.SimpleText('Нажми ПКМ чтобы изменить оценку', 'DermaLarge', ScrW()/2, ScrH()/2 + 50, Color(255, 64, 64), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end	

function SWEP:PreDrawViewModel()
    return true
end