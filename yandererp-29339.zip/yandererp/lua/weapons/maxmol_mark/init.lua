AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

function SWEP:SecondaryAttack()
    if self:GetMark() == 5 then
        self:SetMark(2)
    else
        self:SetMark(self:GetMark() + 1)	
    end
    self:SetNextSecondaryFire(CurTime() + 0.5)
end

function SWEP:PrimaryAttack()
	local trace = self:GetOwner():GetEyeTrace()
	local ply = trace.Entity
	
	if not IsValid(ply) or not ply:IsPlayer() or trace.HitPos:Distance(self:GetOwner():GetShootPos()) > 150 then return end

	self:SetNextPrimaryFire(CurTime() + 1)

	if not ply:IsStudent() then
		GAMEMODE:ChatPrintTo(self:GetOwner(), 'Вы не можете ставить оценки взрослым')
		return
	end

	if ply.last_grade and ply.last_grade ~= ply:GetGrade() then
		GAMEMODE:Error(ply, 'Вы не можете получать оценки пока не возьмёте новые учебники у библиотекаря!')	
		GAMEMODE:Error(self:GetOwner(), 'Этот ученик не может получать оценки пока не возьмёт новые учебники у библиотекаря!')
		return
	else
		ply.last_grade = ply:GetGrade()
	end

	local effectdata = EffectData()
	effectdata:SetOrigin(ply:GetPos())
	effectdata:SetEntity(ply)
	util.Effect('entity_remove', effectdata, false, true)
	
	if ply.MarkTimeOut and ply.MarkTimeOut > CurTime() then
		GAMEMODE:Error(self:GetOwner(), 'Этот ученик недавно уже получал оценку')
		return
	end

    local subject = schoolrp_subjects[ LRPS_TEACHER_SUBJECTS[self:GetOwner():Team()] ]
	ply:AddMark(subject, self:GetMark())
    GAMEMODE:Notify(self:GetOwner(), 'Вы поставили оценку "' .. self:GetMark() .. '" ученику ' .. ply:GetName() .. '. Предмет: ' .. subject)
    GAMEMODE:Notify(ply, 'Вам поставили оценку "' .. self:GetMark() .. '". Учитель: ' .. self:GetOwner():GetName() .. '. Предмет: ' .. subject)
    ply.MarkTimeOut = CurTime() + 120
    self:EmitSound('garrysmod/save_load3.wav')

	ply.last_marks = ply.last_marks or {}

	table.insert(ply.last_marks, CurTime())

	hook.Call('PlayerAddedMark', GAMEMODE, self:GetOwner(), ply, self:GetMark())
end