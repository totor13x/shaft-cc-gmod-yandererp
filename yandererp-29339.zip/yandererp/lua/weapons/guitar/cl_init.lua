include('shared.lua')

notes = {
	E = 'guitar/guitar_E2_very-long_forte_normal.wav',
	F = 'guitar/guitar_F2_very-long_forte_normal.wav',
	Gb = 'guitar/guitar_Fs2_very-long_forte_normal.wav',
	G = 'guitar/guitar_G2_very-long_forte_normal.wav',
	Ab = 'guitar/guitar_Gs2_very-long_forte_normal.wav',
	A = 'guitar/guitar_A2_very-long_forte_normal.wav',
	Bb = 'guitar/guitar_As2_very-long_forte_normal.wav',
	B = 'guitar/guitar_B2_very-long_forte_normal.wav',
	C1 = 'guitar/guitar_C3_very-long_forte_normal.wav',
	Db1 = 'guitar/guitar_Cs3_very-long_forte_normal.wav',
	D1 = 'guitar/guitar_D3_very-long_forte_normal.wav',
	Eb1 = 'guitar/guitar_Ds3_very-long_forte_normal.wav',
	E1 = 'guitar/guitar_E3_very-long_forte_normal.wav',
	F1 = 'guitar/guitar_F3_very-long_forte_normal.wav',
	Gb1 = 'guitar/guitar_Fs3_very-long_forte_normal.wav',
	G1 = 'guitar/guitar_G3_very-long_forte_normal.wav',
	Ab1 = 'guitar/guitar_Gs3_very-long_forte_normal.wav',
	A1 = 'guitar/guitar_A3_very-long_forte_normal.wav',
	Bb1 = 'guitar/guitar_As3_very-long_forte_normal.wav',
	B1 = 'guitar/guitar_B3_very-long_forte_normal.wav',
	C2 = 'guitar/guitar_C4_very-long_forte_normal.wav',
	Db2 = 'guitar/guitar_Cs4_very-long_forte_normal.wav',
	D2 = 'guitar/guitar_D4_very-long_forte_normal.wav',
	Eb2 = 'guitar/guitar_Ds4_very-long_forte_normal.wav',
	E2 = 'guitar/guitar_E4_very-long_forte_normal.wav',
	F2 = 'guitar/guitar_F4_very-long_forte_normal.wav',
	Gb2 = 'guitar/guitar_Fs4_very-long_forte_normal.wav',
	G2 = 'guitar/guitar_G4_very-long_forte_normal.wav',
	Ab2 = 'guitar/guitar_Gs4_very-long_forte_normal.wav',
	A2 = 'guitar/guitar_A4_very-long_forte_normal.wav',
	Bb2 = 'guitar/guitar_As4_very-long_forte_normal.wav',
	B2 = 'guitar/guitar_B4_very-long_forte_normal.wav',
}

local i = 0
chords = {
	['default'] = {
		notes.E,
		notes.A,
		notes.D1,
		notes.G1,
		notes.B1,
		notes.E2,
	},
	['Ab'] = {
		notes.Ab,
		notes.Eb1,
		notes.Ab1,
		notes.C2,
		notes.Eb2,
		notes.Ab2,
	},
	['Ab7'] = {
		notes.Eb,
		notes.Ab,
		notes.Eb1,
		notes.Ab1,
		notes.C2,
		notes.Gb2,
	},
	['Abmin'] = {
		notes.Ab,
		notes.Eb1,
		notes.Ab1,
		notes.B1,
		notes.Eb2,
		notes.Ab2,
	},
	['Abmin7'] = {
		notes.Ab,
		notes.Eb1,
		notes.Gb1,
		notes.B1,
		notes.Eb2,
		notes.Ab2,
	},
	['A'] = {
		notes.E,
		notes.A,
		notes.E1,
		notes.A1,
		notes.Db2,
		notes.E2,
	},
	['A7'] = {
		notes.E,
		notes.A,
		notes.E1,
		notes.G1,
		notes.Db2,
		notes.E2,
	},
	['Amin'] = {
		notes.E,
		notes.A,
		notes.E1,
		notes.A1,
		notes.C2,
		notes.E2,
	},
	['Amin7'] = {
		notes.E,
		notes.A,
		notes.E1,
		notes.A1,
		notes.C2,
		notes.E2,
	},
	['A7'] = {
		notes.E,
		notes.A,
		notes.E1,
		notes.G1,
		notes.Db2,
		notes.E2,
	},
	['Bb'] = {
		notes.F,
		notes.Bb,
		notes.F1,
		notes.Bb1,
		notes.D2,
		notes.F2,
	},
	['Bb7'] = {
		notes.F,
		notes.Bb,
		notes.F1,
		notes.Bb1,
		notes.D2,
		notes.Ab2,
	},
	['Bbmin'] = {
		notes.F,
		notes.Bb,
		notes.F1,
		notes.Bb1,
		notes.Db2,
		notes.F2,
	},
	['Bbmin7'] = {
		notes.F,
		notes.Bb,
		notes.F1,
		notes.Ab1,
		notes.Db2,
		notes.F2,
	},
	['B'] = {
		notes.B,
		notes.Gb1,
		notes.B1,
		notes.Eb2,
		notes.Gb2,
		notes.B2,
	},
	['B7'] = {
		notes.Gb,
		notes.B,
		notes.Eb1,
		notes.A1,
		notes.B1,
		notes.Gb2,
	},
	['Bmin'] = {
		notes.Gb,
		notes.B,
		notes.Gb1,
		notes.B1,
		notes.D2,
		notes.Gb2,
	},
	['Bmin7'] = {
		notes.Gb,
		notes.B,
		notes.Gb1,
		notes.A1,
		notes.D2,
		notes.Gb2,
	},
	['C'] = {
		notes.E,
		notes.C1,
		notes.E1,
		notes.G1,
		notes.C2,
		notes.E2,
	},
	['C7'] = {
		notes.E,
		notes.C1,
		notes.E1,
		notes.Bb1,
		notes.C2,
		notes.E2,
	},
	['Cmin'] = {
		notes.G,
		notes.C1,
		notes.G1,
		notes.C2,
		notes.Eb2,
		notes.G2,
	},
	['Cmin7'] = {
		notes.G,
		notes.C1,
		notes.G1,
		notes.Bb1,
		notes.Eb2,
		notes.G2,
	},
	['Db'] = {
		notes.Ab,
		notes.Db1,
		notes.Ab1,
		notes.Db2,
		notes.F2,
		notes.Ab2,
	},
	['Dbmin'] = {
		notes.Db,
		notes.Ab,
		notes.Db1,
		notes.E1,
		notes.Ab1,
		notes.Db2,
	},
	['D'] = {
		notes.Gb,
		notes.A,
		notes.D1,
		notes.A1,
		notes.D2,
		notes.Gb2,
	},
	['Dmin'] = {
		notes.A,
		notes.D1,
		notes.A1,
		notes.D2,
		notes.F2,
		notes.A2,
	},
	['E'] = {
		notes.E,
		notes.B,
		notes.E1,
		notes.Ab1,
		notes.B1,
		notes.E2,
	},
	['E7'] = {
		notes.E,
		notes.B,
		notes.E1,
		notes.Ab1,
		notes.D1,
		notes.E2,
	},
	['Emin'] = {
		notes.E,
		notes.B,
		notes.E1,
		notes.G1,
		notes.B1,
		notes.E2,
	},
	['Eb'] = {
		notes.Bb,
		notes.Eb1,
		notes.Bb1,
		notes.Eb2,
		notes.G2,
		notes.Bb2,
	},
	['Ebmin'] = {
		notes.Bb,
		notes.Eb1,
		notes.Gb1,
		notes.Bb1,
		notes.Eb2,
		notes.Gb2,
	},
	['F'] = {
		notes.F,
		notes.C1,
		notes.F1,
		notes.A1,
		notes.C2,
		notes.F2,
	},
	['Fmin'] = {
		notes.F,
		notes.C1,
		notes.F1,
		notes.Ab1,
		notes.C2,
		notes.F2,
	},
	['Gb'] = {
		notes.Gb,
		notes.Db1,
		notes.Gb1,
		notes.Bb1,
		notes.Db2,
		notes.Gb2,
	},
	['Gbmin'] = {
		notes.Gb,
		notes.Db1,
		notes.Gb1,
		notes.A1,
		notes.Db2,
		notes.Gb2,
	},
	['G'] = {
		notes.G,
		notes.B,
		notes.D1,
		notes.G1,
		notes.B1,
		notes.G2,
	},
	['Gmin'] = {
		notes.G,
		notes.D1,
		notes.G1,
		notes.Bb1,
		notes.D2,
		notes.G2,
	},
}

local chordsLetters = {
	{'Ab', {KEY_A, KEY_LSHIFT}},
	{'A', KEY_A},
	{'Bb', {KEY_B, KEY_LSHIFT}},
	{'B', KEY_B},
	{'C', KEY_C},
	{'Db', {KEY_D, KEY_LSHIFT}},
	{'D', KEY_D},
	{'Eb', {KEY_E, KEY_LSHIFT}},
	{'E', KEY_E},
	{'F', KEY_F},
	{'Gb', {KEY_G, KEY_LSHIFT}},
	{'G', KEY_G},
}

local chordsPostfixes = {
	{'min', KEY_SPACE},
	{'7', KEY_LCONTROL},
	/*{'maj7', KEY_D},
	{'min7', KEY_F},
	{'sus2', KEY_G},
	{'sus4', KEY_H},*/
}

local panel
function SWEP:PrimaryAttack()
	if ValidPanel(panel) then return end

	chat.AddText(Color(255, 0, 0), 'Press TAB to close')

	local lastNoteTouched
	local lastYPos = 0
	
	local panel_width = ScrW()*0.5
	local panel_height = panel_width*0.6
	local chord_height = panel_height*0.35
	
	panel = vgui.Create('DPanel')
	panel:SetSize(panel_width, panel_height)
	panel:SetPos(ScrW()/2 - panel_width/2, ScrH() - panel_height*1.1)
	panel:MakePopup()
	
	local function isMouseInBox(x1, y1, x2, y2)
		local x, y = gui.MousePos()
		
		if x > x1 and x < x2 and y > y1 and y < y2 then
			return true
		else
			return false
		end
	end
	
	local function areKeysDown(tbl)
		for k, v in pairs(tbl) do
			if not input.IsKeyDown(v) then return false end
		end
		return true
	end
	
	panel.Paint = function(self, w, h)
		if input.IsKeyDown(KEY_TAB) then self:Remove() return end
		local mouseY = gui.MouseY()
		
		surface.SetDrawColor(196, 196, 196, 255)
		surface.DrawRect(0, 0, w, chord_height)
		
		surface.SetDrawColor(228, 228, 228, 255)
		surface.DrawRect(0, chord_height, w, h - chord_height)
		
		surface.SetDrawColor(0, 0, 0, 255)
		surface.DrawOutlinedRect(0, 0, w, h)

		local pressedChordPrefix = ''
		for i, chordLetter in pairs(chordsLetters) do
			local ispressed = false
			if istable(chordLetter[2]) and areKeysDown(chordLetter[2]) then ispressed = true end
			if isnumber(chordLetter[2]) and input.IsKeyDown(chordLetter[2]) then ispressed = true end
			if ispressed and pressedChordPrefix ~= chordLetter[1] .. 'b' then pressedChordPrefix = chordLetter[1] end
			local cw, ch = chord_height*0.35, chord_height*0.3
			local cx, cy = (cw+8)*(i-1) + w*0.015, chord_height*0.1
			surface.SetDrawColor(96, pressedChordPrefix == chordLetter[1] and 128 or 96, 96, 255)
			surface.DrawRect(cx, cy, cw, ch)
			
			draw.SimpleText(chordLetter[1], 'DermaLarge', cx + cw/2, cy, color_white, TEXT_ALIGN_CENTER)
		end
		
		local pressedChordPostfix = ''
		for i, chordsPostfix in pairs(chordsPostfixes) do
			local isKeyDown =  input.IsKeyDown(chordsPostfix[2])
			if isKeyDown then pressedChordPostfix = pressedChordPostfix .. chordsPostfix[1] end
			local cw, ch = chord_height*0.75, chord_height*0.3
			local cx, cy = (cw+8)*(i-1) + w*0.075, chord_height*0.2 + ch
			surface.SetDrawColor(96, isKeyDown and 128 or 96, 96, 255)
			surface.DrawRect(cx, cy, cw, ch)
			
			draw.SimpleText(chordsPostfix[1] .. '(' .. input.GetKeyName(chordsPostfix[2]) .. ')', 'DermaLarge', cx + cw/2, cy, color_white, TEXT_ALIGN_CENTER)
		end
		
		local CHORD = ''
		if pressedChordPrefix:len() > 0 then CHORD = pressedChordPrefix .. pressedChordPostfix end
		
		draw.SimpleText(CHORD, 'DermaLarge', w/2, chord_height, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
		
		surface.SetDrawColor(128, 128, 128, 255)
		for i = 1, 6 do
			local nx, ny, nw, nh = 0, (panel_height-chord_height)/7 * i + chord_height, w, math.ceil((panel_height-chord_height)*0.02)
			surface.DrawRect(nx, ny, nw, nh)

			local note = chords[CHORD] and chords[CHORD][i] or chords['default'][i]
			draw.SimpleText(table.KeyFromValue(notes, note), 'DermaLarge', nx+nw, ny, color_black, TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM)

			local selfx, selfy = self:GetPos()
			if input.IsMouseDown(MOUSE_LEFT) then
				if isMouseInBox(selfx + nx, selfy + ny, selfx + nx + nw, selfy + ny + nh) or (lastYPos < selfy + ny and mouseY > selfy + ny + nh) or (lastYPos > selfy + ny + nh and mouseY < selfy + ny) then
					if lastNoteTouched ~= i then
						net.Start('guitar_sendnote')
							net.WriteString(CHORD)
							net.WriteInt(i, 6)
						net.SendToServer()
						
						lastNoteTouched = i
					end
				elseif lastNoteTouched == i then
					lastNoteTouched = nil
				end
			else
				lastNoteTouched = nil
			end
		end
		lastYPos = mouseY

		draw.SimpleText('TAB - close', 'DermaLarge', w/2, chord_height, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

		draw.SimpleText('[X]b = [X] + Shift (Cb = C + Shift)', 'DermaLarge', w/2, chord_height*0.55, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end
end

function SWEP:DrawWorldModel()
	local bone = self.Owner:LookupBone('ValveBiped.Bip01_R_Hand')
	if not bone then return end
	local bonePos, boneAng = self.Owner:GetBonePosition(bone)
	boneAng:RotateAroundAxis(boneAng:Right(), 88)
	boneAng:RotateAroundAxis(boneAng:Up(), 15)
	boneAng:RotateAroundAxis(boneAng:Forward(), -90)
	bonePos = bonePos + boneAng:Forward() * -15 + boneAng:Up() * -5
	render.Model({
		model = self.WorldModel,
		pos = bonePos,
		angle = boneAng
	})
end

net.Receive('guitar_playnote', function()
	if not chords then return end
	
	local CHORD = net.ReadString()
	local i = net.ReadInt(6)
	
	local note = chords[CHORD] and chords[CHORD][i] or chords['default'][i]
	if note then
		net.ReadEntity():EmitSound(note, 80)
	end
end)