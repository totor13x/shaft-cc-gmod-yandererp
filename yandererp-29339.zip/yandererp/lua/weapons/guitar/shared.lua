SWEP.PrintName = 'The Playable Guitar'
SWEP.Author = 'maxmol'
SWEP.Instuctions = 'Left or right click...'
SWEP.ViewModel = 'models/weapons/c_arms.mdl'
SWEP.WorldModel = 'models/props_phx/misc/fender.mdl'
SWEP.DrawAmmo = false
SWEP.DrawCrosshair = false
SWEP.Slot = 0
SWEP.SlotPos = 3
SWEP.Primary = {
	Ammo = -1,
	ClipSize = -1,
	DefaultClip = -1,
	Automatic = false
}
SWEP.Secondary = {
	Ammo = -1,
	ClipSize = -1,
	DefaultClip = -1,
	Automatic = false
}
SWEP.HoldType = 'normal'

function SWEP:Initialize()
	self:SetHoldType(self.HoldType)
end

function SWEP:PrimaryAttack() self:SetNextPrimaryFire(CurTime() + 1) end
function SWEP:SecondaryAttack() end