include('shared.lua')

AddCSLuaFile('shared.lua')
AddCSLuaFile('cl_init.lua')

local function resetBones(ent)
	ent:ManipulateBoneAngles(ent:LookupBone("ValveBiped.Bip01_R_Clavicle"), Angle(0, 0, 0))
	ent:ManipulateBoneAngles(ent:LookupBone("ValveBiped.Bip01_L_Clavicle"), Angle(0, 0, 0))
	ent:ManipulateBoneAngles(ent:LookupBone("ValveBiped.Bip01_R_Forearm"), Angle(0, 0, 0))
	ent:ManipulateBoneAngles(ent:LookupBone("ValveBiped.Bip01_L_Forearm"), Angle(0, 0, 0))
	ent:ManipulateBoneAngles(ent:LookupBone("ValveBiped.Bip01_L_Hand"), Angle(0, 0, 0))
	ent.GuitarBonesMoved = false
end

local function setBones(ent)
	ent:ManipulateBoneAngles(ent:LookupBone("ValveBiped.Bip01_R_Clavicle"), Angle(0, 25, 0))
	ent:ManipulateBoneAngles(ent:LookupBone("ValveBiped.Bip01_L_Clavicle"), Angle(0, 40, 0))
	ent:ManipulateBoneAngles(ent:LookupBone("ValveBiped.Bip01_R_Forearm"), Angle(-20, -55, 0))
	ent:ManipulateBoneAngles(ent:LookupBone("ValveBiped.Bip01_L_Forearm"), Angle(-45, -100, 0))
	ent:ManipulateBoneAngles(ent:LookupBone("ValveBiped.Bip01_L_Hand"), Angle(0, 0, -90))
	ent.GuitarBonesMoved = true
end

timer.Create('guitar_fix', 30, 0, function()
	for k, v in pairs(player.GetAll()) do
		local wep = v:GetActiveWeapon()
		if v.GuitarBonesMoved and (not IsValid(wep) or wep:GetClass() ~= 'guitar') then
			resetBones(v)
		end
	end
end)

function SWEP:Holster()
	if util.IsValidModel(self.Owner:GetModel()) then
		resetBones(self.Owner)
	end
	return true
end

function SWEP:OnRemove()
	if IsValid(self.Owner) and util.IsValidModel(self.Owner:GetModel()) then
		resetBones(self.Owner)
	end
end

function SWEP:OnDrop()
	if IsValid(self.Owner) and util.IsValidModel(self.Owner:GetModel()) then
		resetBones(self.Owner)
	end
end

function SWEP:Think()
	if self.Owner:GetVelocity():Length2D() > 5 and self.Owner.GuitarBonesMoved and util.IsValidModel(self.Owner:GetModel()) then
		resetBones(self.Owner)
	end
	if self.Owner:GetVelocity():Length2D() < 5 and not self.Owner.GuitarBonesMoved and util.IsValidModel(self.Owner:GetModel()) then
		setBones(self.Owner)
	end
end

util.AddNetworkString('guitar_playnote')
util.AddNetworkString('guitar_sendnote')

net.Receive('guitar_sendnote', function(len, ply)
	net.Start('guitar_playnote')
		net.WriteString(net.ReadString())
		net.WriteInt(net.ReadInt(6), 6)
		net.WriteEntity(ply)
	net.Broadcast()
end)