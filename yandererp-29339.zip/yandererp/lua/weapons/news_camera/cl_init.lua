include('shared.lua')

local rtTexture = surface.GetTextureID( "pp/rt" )
local rtSize = {}
local drawTex = false

function DrawRTTexture()
	if not drawTex then return end
	rtSize.x = 25
	rtSize.y = 25
	rtSize.w = ScrW( ) * 0.25
	rtSize.h = ScrH( ) * 0.25
	
	rtTexture = surface.GetTextureID( "pp/rt" )
	surface.SetTexture( rtTexture )
	surface.SetDrawColor( 255, 255, 255, 255 )
	surface.DrawTexturedRect( rtSize.x , rtSize.y, rtSize.w, rtSize.h ) 
	
	surface.SetDrawColor( 0, 0, 0, 220 )
	surface.DrawOutlinedRect( rtSize.x-1, rtSize.y-1, rtSize.w+2, rtSize.h+2 )
end

function SWEP:GetViewModelPosition( pos, ang )
 
	pos = pos + ( ang:Right() * 8 )
 
	return pos, ang
 
end