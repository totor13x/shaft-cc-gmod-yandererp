include('shared.lua')

AddCSLuaFile('shared.lua')
AddCSLuaFile('cl_init.lua')

function UpdateRenderTarget( ent )
	if ( !ent || !ent:IsValid( ) ) then 
		SafeRemoveEntity( RenderTargetCamera ) 
		SafeRemoveEntity( RenderThing )
		return 
	end

	local angle = ent:EyeAngles()
	pos = ent:GetShootPos() + (angle:Forward() * 40)
	if ( !RenderTargetCamera || !RenderTargetCamera:IsValid() ) then

		RenderTargetCamera = ents.Create( "point_camera" )
		RenderTargetCamera:SetKeyValue( "GlobalOverride", 1 )
		RenderTargetCamera:SetPos( pos )
		RenderTargetCamera:SetAngles( angle )
		RenderTargetCamera:Spawn( )
		RenderTargetCamera:Activate( )
		RenderTargetCamera:Fire( "SetOn", "", 0.0 )
		RenderThing = ents.Create( "camera_node" )
		RenderThing:SetPos(pos)
		RenderThing:SetAngles(angle)
		RenderThing:Spawn( )
		RenderThing:Activate( )
		RenderTargetCamera:SetParent(RenderThing)
	end
	
	RenderThing:GetPhysicsObject( ):SetPos( pos )
	RenderThing:GetPhysicsObject( ):SetVelocity( ent:GetVelocity( ) )
	RenderThing:GetPhysicsObject( ):SetAngles( angle )

	RenderTargetCameraProp = ent
	
end