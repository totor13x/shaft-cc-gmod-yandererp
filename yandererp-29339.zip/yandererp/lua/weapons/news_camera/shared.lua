SWEP.PrintName = "News Camera"
SWEP.Slot = 4
SWEP.SlotPos = 1
SWEP.DrawAmmo = false
SWEP.DrawCrosshair = false

SWEP.Author = "Sinavestos"
SWEP.Instructions = "Equip to use"
SWEP.Contact = ""
SWEP.Purpose = ""

SWEP.ViewModelFOV = 62
SWEP.ViewModelFlip = false
SWEP.AnimPrefix	 = "rpg"

SWEP.ViewModel = Model( "models/maxofs2d/camera.mdl" )
SWEP.WorldModel = "models/maxofs2d/camera.mdl"

SWEP.Spawnable = false
SWEP.AdminSpawnable = true
SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = 0
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = ""

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = 0
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = ""

SWEP.FrameVisible = false
SWEP.OnceReload = false

function SWEP:Initialize()
	self:SetHoldType("rpg")
	if CLIENT then drawTex = true end
end

function SWEP:Deploy()
	if SERVER then self:TurnOnCamera() end
	if CLIENT then
		drawTex = true
		hook.Add( "HUDPaint", "N00BRP_DrawRTTexture", DrawRTTexture )
	end
	return true
end

function SWEP:Holster()
	if SERVER then self:TurnOffCamera() end
	if CLIENT then
		drawTex = false
		hook.Remove( "HUDPaint", "N00BRP_DrawRTTexture" )
	end
	return true
end

function SWEP:OnRemove()
	if SERVER then self:TurnOffCamera() end
	if CLIENT then
		drawTex = false
		hook.Remove( "HUDPaint", "N00BRP_DrawRTTexture" )
	end
end

local running = false

function SWEP:TurnOnCamera( )
	self:SetHoldType( "slam" )
	SetGlobalBool('CameraMan', self.Owner)
	running = true
	UpdateRenderTarget( self.Owner )
end

function SWEP:TurnOffCamera()
	running = false
	UpdateRenderTarget( nil )
	SetGlobalBool('CameraMan', NULL)
end

function SWEP:Think()
	if SERVER and running and (not self.tout or self.tout < SysTime()) then
		UpdateRenderTarget( self.Owner ) 
		self.tout = SysTime() + 0.2
	end
end