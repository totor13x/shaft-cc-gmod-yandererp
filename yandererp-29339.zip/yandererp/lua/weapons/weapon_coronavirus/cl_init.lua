include("shared.lua")

local selection_icon
http.Fetch('https://i.imgur.com/yML3vxc.png', function(data)
	file.Write('coronavirus.png', data)
	timer.Simple(1, function()
		selection_icon = Material('../data/coronavirus.png')
	end)
end)

function SWEP:DrawWeaponSelection(x, y, wide, tall, alpha)
	if selection_icon then
		surface.SetDrawColor(255, 255, 255, alpha)
		surface.SetMaterial(selection_icon)
		surface.DrawTexturedRect( x, y,  wide, wide / 2)
	end
end

function SWEP:PrimaryAttack()
	self.Owner:SetAnimation(PLAYER_ATTACK1)
end