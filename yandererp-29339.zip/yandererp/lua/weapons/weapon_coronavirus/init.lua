AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

function SWEP:PrimaryAttack()
	self.Owner:SetAnimation(PLAYER_ATTACK1)
	
	self:SendWeaponAnim(ACT_VM_PULLBACK_HIGH)
	
	timer.Create("weapon_idle" .. self:EntIndex(), self:SequenceDuration(), 1, function() 
		if IsValid(self) then 
			self:SendWeaponAnim(ACT_VM_THROW)
			timer.Create("weapon_idle" .. self:EntIndex(), self:SequenceDuration(), 1, function() 
				self.Owner:StripWeapon('weapon_coronavirus') 
			end)
			
			local aimvec = self.Owner:GetAimVector()
			local grenade = ents.Create('ent_coronavirus')
			grenade:SetPos(self.Owner:GetShootPos() + aimvec * 15)
			grenade:Spawn()
			grenade:GetPhysicsObject():SetVelocity((aimvec + Vector(0, 0, 0.1)) * 1000)
		end 
	end)
end