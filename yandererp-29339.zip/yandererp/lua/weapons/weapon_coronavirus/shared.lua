SWEP.PrintName = 'Coronavirus Container'
SWEP.Spawnable = true
SWEP.AdminOnly = true
SWEP.ViewModel = 'models/weapons/c_grenade.mdl'
SWEP.WorldModel = 'models/weapons/w_grenade.mdl'
SWEP.Slot = 4
SWEP.UseHands = true

SWEP.Primary = {}
SWEP.Primary.ClipSize = 1
SWEP.Primary.DefaultClip = 1
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "none"

SWEP.Secondary = {}
SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"

function SWEP:Initialize()
	self:SetHoldType("grenade")
end

function SWEP:Deploy()
	self:SendWeaponAnim(ACT_VM_DRAW)
	timer.Create("weapon_idle" .. self:EntIndex(), self:SequenceDuration(), 1, function() 
		if IsValid(self) then 
			self:SendWeaponAnim(ACT_VM_IDLE) 
		end 
	end)
end

function SWEP:SecondaryAttack()
end