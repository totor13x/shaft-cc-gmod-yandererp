include('shared.lua')

AddCSLuaFile('shared.lua')
AddCSLuaFile('cl_init.lua')

function Corpse(ply)
	local corpse = ents.Create("prop_ragdoll")
	corpse:SetPos(ply:GetPos())
	corpse:SetAngles(ply:GetAngles())
	corpse:SetModel(util.IsValidModel(ply:GetModel()) and ply:GetModel() or 'models/Humans/Charple01.mdl')
	corpse:SetSkin(ply:GetSkin())
	corpse:SetCollisionGroup(COLLISION_GROUP_WEAPON)

	local v = ply:GetVelocity()/5
	local num = corpse:GetPhysicsObjectCount() - 1

	corpse:Spawn()
	corpse:Activate()
	
	local phys = corpse:GetPhysicsObject()

	corpse:SetCollisionGroup(COLLISION_GROUP_WEAPON)

	local prop = ents.Create("prop_physics")
	prop:SetModel("models/hunter/blocks/cube025x025x025.mdl")
	prop:SetPos(corpse:GetPos())
	prop:SetCollisionGroup(COLLISION_GROUP_WORLD)
	prop:SetNoDraw(true)

	prop:Spawn()
	prop:Activate()

	corpse.block = prop
	corpse.owner = ply
	corpse.IsCorpse = true

	constraint.Weld(corpse, prop, 0, 0, 0, false)

	// Corpse (Or Ragdoll)
	phys:SetMass(1)

	// Box (Or prop)
	local phys_prop = prop:GetPhysicsObject()
	phys_prop:SetMass(1)

	ply.corpse = corpse
	return corpse
end

function SWEP:PrimaryAttack()
	if self:SharedPrimaryAttack() == false then
		return
	end

	self:TakePrimaryAmmo(2)
	
	local tr = self.Owner:GetEyeTrace()
	
	local ent = tr.Entity
	
	if IsValid(ent) and ent:IsVehicle() and IsValid(ent:GetDriver()) then
		ent = ent:GetDriver()
		ent:ExitVehicle()
	end

	if IsValid(ent) and ent:IsPlayer() and tr.HitPos:Distance(self.Owner:GetShootPos()) < 500 then
		local corpse = {}
		corpse.weapons = {}
		corpse.ammo = {}
		for k, v in pairs(ent:GetWeapons()) do
			table.insert(corpse.weapons, v:GetClass())
			corpse.ammo[v:GetPrimaryAmmoType()] = ent:GetAmmoCount(v:GetPrimaryAmmoType())
		end
		
		corpse.hp = ent:Health()
		corpse.armor = ent:Armor()
		corpse.hunger = ent:GetCSVar("Hunger", 100)
		corpse.runSpeed = ent:GetRunSpeed()
		corpse.model = ent:GetModel()
		local ragdoll = Corpse(ent)

		ent:TakeDamage(10, self.Owner, self)
		
		ent:SetParent(ragdoll)
		ent:Spectate(OBS_MODE_CHASE)
		ent:SpectateEntity(ragdoll)
		ent:StripWeapons()
		ent.tased = true
		
		hook.Call('PlayerTased', GAMEMODE, ent, self:GetOwner())

		timer.Simple(20, function()
			if not IsValid(ent) then return end
			ent:SetParent()
			ent:UnSpectate()
			ent.tased = nil

			local pos = ragdoll:GetPos()
			ent:Spawn()
			ent:SetModel(corpse.model)
			ent:SetPos(pos)
			ent:SetHealth(corpse.hp)
			ent:SetArmor(corpse.armor)
			ent:SetCSVar("Energy", corpse.hunger)
			ent:SetRunSpeed(corpse.runSpeed)
			for k, v in pairs(corpse.weapons) do
				ent:Give(v)
			end
			
			for k, v in pairs(corpse.ammo) do
				ent:SetAmmo(v, k)
			end
		end)
	end
end

hook.Add("PlayerDisconnected", "Corpse.PlayerDisconnected", function(ply)
	if ply.corpse && IsValid(ply.corpse) then
		SafeRemoveEntity(ply.corpse.block)
		SafeRemoveEntity(ply.corpse)
	end
end)

hook.Add("PlayerSpawn", "Corpse.PlayerSpawn", function(ply)
	if ply.corpse && IsValid(ply.corpse) then
		SafeRemoveEntity(ply.corpse.block)
		SafeRemoveEntity(ply.corpse)
	end
end)