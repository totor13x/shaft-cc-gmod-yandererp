SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true
SWEP.PrintName			= "Электрошокер"
SWEP.ViewModel			= "models/weapons/c_pistol.mdl"
SWEP.WorldModel			= "models/weapons/w_pistol.mdl"
SWEP.UseHands			= true
SWEP.cd 				= 0
SWEP.Author = 'maxmol'
SWEP.Instructions = "шокируй........"
SWEP.Primary = {}
SWEP.Primary.Ammo = "SniperRound"
SWEP.Primary.ClipSize = 2
SWEP.Primary.DefaultClip = 0

function SWEP:SharedPrimaryAttack()
	if self:Clip1() < 2 then
		self:EmitSound('weapons/clipempty_pistol.wav')
		return false
	end

	self:EmitSound("ambient/energy/spark" .. math.random(6) .. ".wav")
	timer.Simple(0.1, function()
		self:EmitSound('weapons/physcannon/superphys_small_zap' .. math.random(4) .. '.wav', 75, 70)
	end)

	local aim = self.Owner:GetAimVector()
	
	self:ShootEffects()
	
	self.Weapon:SetNextPrimaryFire(CurTime() + 0.2)

	local trace = self.Owner:GetEyeTrace()
	
	local effectdata = EffectData()
	effectdata:SetOrigin(trace.HitPos)
	effectdata:SetNormal(trace.HitNormal)
	effectdata:SetEntity(trace.Entity)
	effectdata:SetAttachment(trace.PhysicsBone)
	util.Effect("AR2Impact", effectdata)

	effectdata = EffectData()
	effectdata:SetOrigin(self.Owner:GetShootPos() + aim * 500)
	effectdata:SetStart(self.Owner:GetShootPos())
	effectdata:SetAttachment(1)
	effectdata:SetEntity(self.Weapon)
	util.Effect('ToolTracer', effectdata )	
	util.Effect('cball_bounce', effectdata)
	
	local at = self.Owner:LookupAttachment('anim_attachment_rh')
	local att = self.Owner:GetAttachment(at)

	if att then
		effectdata = EffectData()
		effectdata:SetOrigin(att.Pos + att.Ang:Forward() * 8 + att.Ang:Up() * 6)
		effectdata:SetAttachment(at)
		effectdata:SetEntity(self.Owner)
		effectdata:SetNormal(aim)
		util.Effect('cball_bounce', effectdata)
	end
end

function SWEP:PrimaryAttack()
	self:SharedPrimaryAttack()
end

function SWEP:SecondaryAttack()
end

hook.Add('playerCanChangeTeam', 'maxmol_taser', function(ply, team, force)
	if ply.tased then
		return false
	end
end)