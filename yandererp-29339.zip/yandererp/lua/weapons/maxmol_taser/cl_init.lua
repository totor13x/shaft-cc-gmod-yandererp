include('shared.lua')

SWEP.WepSelectIcon = surface.GetTextureID('cable/blue_elec')