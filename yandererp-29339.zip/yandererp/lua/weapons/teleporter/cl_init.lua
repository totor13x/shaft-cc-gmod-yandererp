include('shared.lua')

function SWEP:DrawWorldModel( )
	if ( !IsValid( self.Owner ) or !IsValid( self ) ) then return end
	self:SetRenderOrigin( self.Owner:GetPos( ) + Vector(0, 0, 1) )
	self:SetRenderAngles( Angle( -90, 0, 0 ) )
	self:DrawModel( )
end