SWEP.PrintName = "Телепортёр"
SWEP.Slot = 4
SWEP.SlotPos = 3
SWEP.Contact = ""
SWEP.Purpose = ""
SWEP.Instructions = "ЛКМ чтобы указать точку телепортации, ПКМ чтобы телепортироваться"

SWEP.Spawnable = false       -- Change to false to make Admin only.
SWEP.AdminSpawnable = true

SWEP.ViewModel = "models/effects/combineball.mdl"
SWEP.WorldModel = "models/effects/combineball.mdl"

SWEP.Primary.Recoil = 0
SWEP.Primary.ClipSize  = -1
SWEP.Primary.DefaultClip = 1
SWEP.Primary.Automatic  = false
SWEP.Primary.Ammo = "none"

SWEP.Secondary.Recoil = 0
SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = 1
SWEP.Secondary.Ammo = "none"

SWEP.TeleportSound = "ambient/machines/teleport4.wav"

function SWEP:Initialize()
	util.PrecacheSound( self.TeleportSound )
	self:SetHoldType( "normal" )
	self:DrawShadow( false )
end