include('shared.lua')

AddCSLuaFile('shared.lua')
AddCSLuaFile('cl_init.lua')

	
function util.BeginPortalEffect( origin, magnitude, scale, radius, normal, followEnt, hookName, timedRemoval )
	hook.Add( "Think", "N00BRP_PortalEffectThink_" .. hookName, function( )
		local effectData = EffectData( )
		effectData:SetOrigin( origin )
		effectData:SetMagnitude( magnitude )
		effectData:SetScale( scale )
		effectData:SetRadius( radius )
		effectData:SetNormal( normal )
		if ( IsValid( followEnt ) ) then
			effectData:SetOrigin( followEnt:GetPos( ) )
		end
		util.Effect( "AR2Explosion", effectData )
	end )
	if ( timedRemoval and tonumber( timedRemoval ) ) then
		timer.Create( "N00BRP_PortalEffectThinkDestroy_" .. hookName, timedRemoval, 1, function( )
			hook.Remove( "Think", "N00BRP_PortalEffectThink_" .. hookName )
		end )
	end
end

local function BeginTeleportEffects( entIndex )
	local plyEnt = Entity( entIndex )
	if not ( IsValid( plyEnt ) ) then return end
	if not ( plyEnt.teleSWEPDestination ) then return end
	local hookOriginName = "TeleSWEPOrigin_" .. entIndex
	local hookDestName = "TeleSWEPDest_" .. entIndex
	util.BeginPortalEffect( plyEnt:GetPos( ), 1, 1, 40, Vector( 0, 0, 1 ), plyEnt, hookOriginName, nil )
	util.BeginPortalEffect( plyEnt.teleSWEPDestination, 1, 1, 40, Vector( 0, 0, 1 ), nil, hookDestName, nil )
end

local function EndTeleportEffects( entIndex )
	local hookOriginName = "TeleSWEPOrigin_" .. entIndex
	local hookDestName = "TeleSWEPDest_" .. entIndex
	hook.Remove( "Think", "N00BRP_PortalEffectThink_" .. hookOriginName )
	hook.Remove( "Think", "N00BRP_PortalEffectThink_" .. hookDestName )
end

function SWEP:PrimaryAttack()
	local wep = self
	wep:SetNextPrimaryFire( CurTime( ) + 1 )
	wep:SetHoldType( "pistol" )
	timer.Simple( 0.2, function( ) 
		if ( IsValid( wep ) ) then 
			wep:SetHoldType( "normal" ) 
		end 
	end )
	self.Owner.teleSWEPDestination = self.Owner:GetPos()
	self.Owner:ChatPrint( "Вы указали точку телепортации (Ваша позиция)" )
end

function SWEP:SecondaryAttack()
	self:SetNextSecondaryFire( CurTime( ) + 1 )
	self.Owner.teleSWEPNextUse = self.Owner.teleSWEPNextUse or 0
	self.Owner.teleSWEPNextAttempt = self.Owner.teleSWEPNextAttempt or 0
	if ( self.Owner.teleSWEPNextUse > CurTime( ) ) then
		local remainTime = string.NiceTime( self.Owner.teleSWEPNextUse - CurTime( ) )
		DarkRP.notify( self.Owner, 1, 4, "Перезарядка завершится через " .. remainTime )
		return
	end
	if ( self.Owner.teleSWEPNextAttempt > CurTime( ) ) then
		local remainTime = string.NiceTime( self.Owner.teleSWEPNextAttempt - CurTime( ) )
		DarkRP.notify( self.Owner, 1, 4, "Вы должны подождать " ..  remainTime .. " сек. перед следующей телепортацией." )
		return
	end
	if not ( self.Owner.teleSWEPDestination ) then
		self.Owner:ChatPrint( "Точка телепортации не указана." )
		self.teleSWEPNextAttempt = CurTime( ) + 5
		return
	end
	local wep = self
	local wepOwner = self.Owner
	local ownerIndex = wepOwner:EntIndex( )
	local beginPos = wepOwner:GetPos( )
	local teleTick = 0
	BeginTeleportEffects( ownerIndex )
	timer.Create( "N00BRP_TeleporterSWEP_AttemptTeleport_" .. ownerIndex, 1, 5, function( )
		if ( !IsValid( wep ) or !IsValid( wepOwner ) ) then
			timer.Destroy( "N00BRP_TeleporterSWEP_AttemptTeleport_" .. ownerIndex )
			EndTeleportEffects( ownerIndex )
			return
		end
		--[[if ( wepOwner:GetPos( ):FastDist( beginPos ) > 80 ) then
			timer.Destroy( "N00BRP_TeleporterSWEP_AttemptTeleport_" .. ownerIndex )
			EndTeleportEffects( ownerIndex )
			wepOwner.teleSWEPNextAttempt = CurTime( ) + 5
			return
		end]]--
		teleTick = teleTick + 1
		if ( teleTick == 5 ) then
			wep:EmitSound( wep.TeleportSound, 50 )
			sound.Play( wep.TeleportSound, wepOwner.teleSWEPDestination, 50 )
			wepOwner:SetPos( wepOwner.teleSWEPDestination )
			wepOwner.teleSWEPDestination = nil
			wepOwner.teleSWEPNextUse = CurTime( ) + 20
			EndTeleportEffects( ownerIndex )
			return
		end
	end )
end